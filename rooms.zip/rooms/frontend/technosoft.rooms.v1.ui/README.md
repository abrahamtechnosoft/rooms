# Technosoft.Rooms.v1 - UI

Frontend Next.js para reservacion de salas de **Corporacion Millenium**.

## Stack

- Next.js (App Router) + TypeScript
- Tailwind CSS (configurado con variables Millenium)
- Axios (cliente HTTP)
- Zustand (estado de autenticacion con persistencia en localStorage)
- date-fns (formato de fechas en espanol)

## Instalacion

```bash
npm install
```

## Variables de entorno

Crear `.env.local`:

```
NEXT_PUBLIC_API_URL=http://localhost:4000/api
```

## Arranque

```bash
npm run dev
```

La aplicacion levanta en `http://localhost:3000`. Requiere que el backend este corriendo en el puerto 4000 (ver `backend/Technosoft.Rooms.v1`).

## Build de produccion

```bash
npm run build
npm start
```

## Credenciales por defecto

| Email                  | Password    | Rol   |
|------------------------|-------------|-------|
| admin@millenium.cr     | Admin123!   | admin |

> Estas credenciales se crean al ejecutar el script SQL del backend.

## Estructura

```
src/
  app/
    layout.tsx                    Layout raiz
    page.tsx                      Redirige a /login o /dashboard
    globals.css                   Tema Millenium (variables CSS + Tailwind 4)
    login/page.tsx                Pantalla de login
    dashboard/
      layout.tsx                  Navbar + sidebar + ProtectedRoute
      page.tsx                    Calendario diario por sala
      reservations/
        page.tsx                  Mis reservas (cancelar)
        new/page.tsx              Form de nueva reserva
      rooms/page.tsx              CRUD de salas (admin)
      users/page.tsx              Alta de usuarios (admin)
  components/
    MilleniumLogo.tsx             SVG corporativo
    Navbar.tsx                    Cabecera + menu movil
    ProtectedRoute.tsx            Guard de rutas autenticadas
    ReservationCard.tsx
    ReservationForm.tsx
    RoomCard.tsx
    DayTimeline.tsx               Franja horaria 07-19 con bloques
    ui/
      Button.tsx Input.tsx Select.tsx Modal.tsx
  lib/
    api.ts                        Axios + interceptor JWT
    dates.ts                      Helpers de fechas en espanol CR
  store/
    authStore.ts                  Zustand persistido
  types/index.ts                  Tipos compartidos
```

## Paleta Millenium

| Token              | Color    |
|--------------------|----------|
| `millenium-red`    | `#C0392B`|
| `millenium-green`  | `#27AE60`|
| `millenium-blue`   | `#2C3E50`|
| `millenium-dark`   | `#1A1A1A`|
| `millenium-light`  | `#F5F5F5`|
| `millenium-gray`   | `#7F8C8D`|

Las clases `btn-primary`, `btn-success`, `btn-danger`, `btn-outline`, `card`, `input` y `label` estan listas en `globals.css`.

## Reglas de reserva (espejo del backend)

1. No se puede reservar en el pasado.
2. No se puede solapar con otra reserva activa de la misma sala.
3. Maximo 30 dias a futuro.
4. Solo el creador o un admin pueden cancelar.
5. Duracion entre 15 minutos y 4 horas.
6. Horario permitido 08:00 - 17:00 (mismo dia).
