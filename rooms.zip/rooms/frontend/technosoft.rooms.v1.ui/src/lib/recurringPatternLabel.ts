import type { Reservation } from "@/types";

/**
 * Genera una etiqueta humana corta para describir el patron de una serie
 * recurrente. Pensado para mostrar debajo del titulo de la card en
 * Mis Reuniones.
 *
 * Dias ISO: 1=lunes, 2=martes, ..., 7=domingo (formato usado por
 * core.recurring_series.days_of_week).
 *
 * Ejemplos de salida:
 *   - weekly, days=[1,2,3,4,5], freq=1        → "L-V"
 *   - weekly, days=[1,2,3,4,5,6,7], freq=1    → "Todos los días"
 *   - weekly, days=[6,7], freq=1              → "Findes"
 *   - weekly, days=[1], freq=1                → "Cada lunes"
 *   - weekly, days=[3], freq=2                → "Cada 2 semanas, miércoles"
 *   - weekly, days=[1,3,5], freq=1            → "L-X-V"
 *   - monthly, dayOfMonth=15                  → "Día 15 de cada mes"
 *   - patron desconocido                      → "Recurrente"
 */
export function describeRecurringPattern(reservation: Reservation): string {
  const series = reservation.series;
  if (!series) return "Recurrente";
  const pattern = series.pattern;
  if (!pattern) return "Recurrente";

  if (pattern === "monthly") {
    if (series.dayOfMonth) return `Día ${series.dayOfMonth} de cada mes`;
    return "Mensual";
  }

  if (pattern === "weekly") {
    const days = parseDays(series.daysOfWeek);
    const freq = series.frequencyWeeks || 1;

    if (days.length === 0) {
      return freq === 1 ? "Semanal" : `Cada ${freq} semanas`;
    }

    const isAllDays = days.length === 7;
    const isWeekdays =
      days.length === 5 && [1, 2, 3, 4, 5].every((d) => days.includes(d));
    const isWeekend =
      days.length === 2 && days.includes(6) && days.includes(7);

    if (freq === 1) {
      if (isAllDays) return "Todos los días";
      if (isWeekdays) return "L-V";
      if (isWeekend) return "Findes";
      if (days.length === 1) return `Cada ${ISO_DAY_FULL[days[0]]}`;
      return days.map((d) => ISO_DAY_SHORT[d]).join("-");
    }

    // freq > 1
    if (isAllDays) return `Todos los días, cada ${freq} semanas`;
    if (isWeekdays) return `L-V, cada ${freq} semanas`;
    if (days.length === 1) {
      return `Cada ${freq} semanas, ${ISO_DAY_FULL[days[0]]}`;
    }
    return `Cada ${freq} semanas: ${days.map((d) => ISO_DAY_SHORT[d]).join("-")}`;
  }

  return "Recurrente";
}

// ISO day index → etiqueta corta (no usamos índice 0; 1=L .. 7=D).
const ISO_DAY_SHORT: Record<number, string> = {
  1: "L",
  2: "M",
  3: "X",
  4: "J",
  5: "V",
  6: "S",
  7: "D",
};

const ISO_DAY_FULL: Record<number, string> = {
  1: "lunes",
  2: "martes",
  3: "miércoles",
  4: "jueves",
  5: "viernes",
  6: "sábado",
  7: "domingo",
};

function parseDays(
  raw: string | number[] | null | undefined
): number[] {
  if (!raw) return [];
  if (Array.isArray(raw)) {
    return raw
      .filter((n): n is number => Number.isInteger(n) && n >= 1 && n <= 7)
      .sort((a, b) => a - b);
  }
  if (typeof raw === "string") {
    return raw
      .split(",")
      .map((s) => parseInt(s.trim(), 10))
      .filter((n) => Number.isInteger(n) && n >= 1 && n <= 7)
      .sort((a, b) => a - b);
  }
  return [];
}
