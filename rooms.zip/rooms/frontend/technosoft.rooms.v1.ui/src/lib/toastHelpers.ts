import {
  toast as sonnerToast,
  type ExternalToast,
} from "sonner";

// Ventana de deduplicación por tipo:
// - errores: 5 min, suficiente para suprimir repeticiones del polling
//   (que típicamente corre cada 30-60s) sin perder un error nuevo si la
//   condición se prolonga mucho.
// - el resto: 2 s, para evitar dobles dispatches en handlers.
const DEDUP_WINDOWS_MS: Record<string, number> = {
  error: 5 * 60_000,
  success: 2000,
  info: 2000,
  warning: 2000,
  message: 2000,
};
const recentToasts = new Map<string, number>();

function windowFor(type: string): number {
  return DEDUP_WINDOWS_MS[type] ?? 2000;
}

function dedupeKey(message: string, type: string): string {
  return `${type}:${message}`;
}

function shouldShow(message: string, type: string): boolean {
  const key = dedupeKey(message, type);
  const now = Date.now();
  const last = recentToasts.get(key);

  if (last && now - last < windowFor(type)) return false;

  recentToasts.set(key, now);

  if (recentToasts.size > 50) {
    const maxWindow = Math.max(...Object.values(DEDUP_WINDOWS_MS));
    const cutoff = now - maxWindow;
    for (const [k, t] of recentToasts.entries()) {
      if (t < cutoff) recentToasts.delete(k);
    }
  }

  return true;
}

export function resetToastDedupe(message?: string): void {
  if (message) {
    for (const k of recentToasts.keys()) {
      if (k.endsWith(`:${message}`)) recentToasts.delete(k);
    }
  } else {
    recentToasts.clear();
  }
}

export const toast = {
  success: (message: string, options?: ExternalToast) => {
    if (!shouldShow(message, "success")) return;
    return sonnerToast.success(message, options);
  },
  error: (message: string, options?: ExternalToast) => {
    if (!shouldShow(message, "error")) return;
    return sonnerToast.error(message, options);
  },
  info: (message: string, options?: ExternalToast) => {
    if (!shouldShow(message, "info")) return;
    return sonnerToast.info(message, options);
  },
  warning: (message: string, options?: ExternalToast) => {
    if (!shouldShow(message, "warning")) return;
    return sonnerToast.warning(message, options);
  },
  message: (message: string, options?: ExternalToast) => {
    if (!shouldShow(message, "message")) return;
    return sonnerToast(message, options);
  },
};
