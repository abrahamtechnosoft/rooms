/**
 * Helpers para el componente <TimeRangeInput> y validaciones de hora.
 * El input acepta cualquier minuto (10:37, 10:43…). El backend redondea al
 * múltiplo de 5 más cercano al persistir, así que aquí no aplicamos esa
 * restricción.
 */

/** Duración mínima de una reunión, en minutos. Sincronizado con el backend. */
export const MIN_DURATION_MIN = 15;

export function formatHHMM(date: Date): string {
  const h = String(date.getHours()).padStart(2, "0");
  const m = String(date.getMinutes()).padStart(2, "0");
  return `${h}:${m}`;
}

export function combineDateAndTime(
  date: Date,
  hour: number,
  minute: number
): Date {
  const d = new Date(date);
  d.setHours(hour, minute, 0, 0);
  return d;
}

export function addMinutes(date: Date, minutes: number): Date {
  return new Date(date.getTime() + minutes * 60000);
}

/**
 * Valida un string "HH:MM" exacto: dos dígitos cada uno, dentro del rango
 * 00-23 / 00-59, y opcionalmente dentro de un rango de horas hábil.
 */
export function isValidHHMM(
  str: string,
  minHour: number,
  maxHour: number
): boolean {
  const match = /^(\d{1,2}):(\d{2})$/.exec(str);
  if (!match) return false;
  const h = parseInt(match[1], 10);
  const m = parseInt(match[2], 10);
  if (h < 0 || h > 23) return false;
  if (m < 0 || m > 59) return false;
  if (h < minHour || h > maxHour) return false;
  return true;
}

/**
 * Parser flexible que acepta:
 *   "10:30" → { hour: 10, minute: 30 }
 *   "1030"  → { hour: 10, minute: 30 }
 *   "10"    → { hour: 10, minute: 0 }
 *   "10:5"  → { hour: 10, minute: 5 }
 *   "9:30"  → { hour: 9, minute: 30 }
 *   "930"   → { hour: 9, minute: 30 } (3 dígitos)
 */
export function parseTimeInput(
  input: string
): { hour: number; minute: number } | null {
  const trimmed = input.trim();
  if (!trimmed) return null;

  // Formato "HH:MM" o "H:M" (con dos puntos)
  const withColon = /^(\d{1,2}):(\d{1,2})$/.exec(trimmed);
  if (withColon) {
    return {
      hour: parseInt(withColon[1], 10),
      minute: parseInt(withColon[2], 10),
    };
  }

  // Formato "HHMM" o "HMM" (sin separador, 3 o 4 dígitos)
  const noColon = /^(\d{3,4})$/.exec(trimmed);
  if (noColon) {
    const num = noColon[1];
    if (num.length === 3) {
      return {
        hour: parseInt(num.substring(0, 1), 10),
        minute: parseInt(num.substring(1), 10),
      };
    }
    return {
      hour: parseInt(num.substring(0, 2), 10),
      minute: parseInt(num.substring(2), 10),
    };
  }

  // Formato solo hora "10" → 10:00
  const onlyHour = /^(\d{1,2})$/.exec(trimmed);
  if (onlyHour) {
    return { hour: parseInt(onlyHour[1], 10), minute: 0 };
  }

  return null;
}

/**
 * Genera opciones de hora cada `stepMin` minutos entre minHour y maxHour
 * (maxHour incluido como "HH:00" final pero sin "HH:15" en adelante).
 * Si `minTime` se provee, descarta opciones <= minTime.
 */
export function generateTimeOptions(
  minHour: number,
  maxHour: number,
  stepMin: number,
  minTime?: Date | null
): string[] {
  const options: string[] = [];
  for (let h = minHour; h <= maxHour; h++) {
    for (let m = 0; m < 60; m += stepMin) {
      if (h === maxHour && m > 0) break;

      if (minTime) {
        const opt = new Date(minTime);
        opt.setHours(h, m, 0, 0);
        if (opt <= minTime) continue;
      }

      const hh = String(h).padStart(2, "0");
      const mm = String(m).padStart(2, "0");
      options.push(`${hh}:${mm}`);
    }
  }
  return options;
}

export function formatDurationMins(minutes: number): string {
  const m = Math.max(0, Math.round(minutes));
  if (m < 60) return `${m} ${m === 1 ? "minuto" : "minutos"}`;
  const h = Math.floor(m / 60);
  const rest = m % 60;
  if (rest === 0) return `${h} ${h === 1 ? "hora" : "horas"}`;
  return `${h} h ${rest} min`;
}

/**
 * Redondea hacia arriba al próximo múltiplo de `step` minutos.
 * Ej. roundUpToNext(10:23, 15) → 10:30. roundUpToNext(10:30, 15) → 10:30.
 */
export function roundUpToNext(date: Date, stepMin: number): Date {
  const d = new Date(date);
  d.setSeconds(0, 0);
  const m = d.getMinutes();
  const remainder = m % stepMin;
  if (remainder !== 0) {
    d.setMinutes(m + (stepMin - remainder));
  }
  return d;
}

/**
 * Próximo múltiplo de 5 minutos. 10:23 → 10:25. 10:25 → 10:25. 10:26 → 10:30.
 * Usado para el default inteligente al abrir el form y para auto-ajustar
 * cuando el usuario tipea una hora pasada.
 */
export function getNextMultipleOf5Min(date: Date = new Date()): Date {
  return roundUpToNext(date, 5);
}

/**
 * Default inteligente: si la fecha es HOY, retorna el próximo múltiplo de 5
 * minutos desde ahora; si es futura, retorna el `selectedDate` a las 08:00.
 */
export function getSmartDefaultStart(selectedDate: Date): Date {
  const now = new Date();
  const isToday =
    selectedDate.getFullYear() === now.getFullYear() &&
    selectedDate.getMonth() === now.getMonth() &&
    selectedDate.getDate() === now.getDate();

  if (isToday) {
    return getNextMultipleOf5Min(now);
  }

  const result = new Date(selectedDate);
  result.setHours(8, 0, 0, 0);
  return result;
}

/** True si ambas Date corresponden al mismo año/mes/día en hora local. */
export function isSameDay(a: Date, b: Date): boolean {
  return (
    a.getFullYear() === b.getFullYear() &&
    a.getMonth() === b.getMonth() &&
    a.getDate() === b.getDate()
  );
}
