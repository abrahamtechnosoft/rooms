import type { Reservation } from "@/types";
import type { ReservationFilters } from "@/types/filters";

/**
 * Aplica los filtros del dashboard a una lista de reservas.
 *
 * Reglas:
 *   1. Chip (single-select):
 *      - 'all'      → pasa cualquier tipo.
 *      - 'room' N   → solo physical con roomId === N.
 *      - 'virtual'  → solo virtual.
 *      - 'external' → solo external.
 *   2. departmentIds (multi-select): si vacio → todas pasan. Si tiene al
 *      menos uno → solo pasan reservas cuyo organizador pertenezca a uno
 *      de esos departamentos (organizerDepartmentId).
 *      Nota: este sprint NO filtra por departamento de los participantes —
 *      solo del organizador, igual que el sprint anterior. Si la reserva
 *      no tiene organizerDepartmentId, no pasa el filtro.
 */
export function applyReservationFilters(
  meetings: Reservation[],
  filters: ReservationFilters
): Reservation[] {
  const hasChipFilter = filters.chip.kind !== "all";
  const hasDeptFilter = filters.departmentIds.length > 0;

  if (!hasChipFilter && !hasDeptFilter) return meetings;

  const deptSet = new Set(filters.departmentIds);

  return meetings.filter((m) => {
    switch (filters.chip.kind) {
      case "all":
        break;
      case "room":
        if (m.type !== "physical" || m.roomId !== filters.chip.roomId) {
          return false;
        }
        break;
      case "office":
        if (m.type !== "office") return false;
        break;
      case "virtual":
        if (m.type !== "virtual") return false;
        break;
      case "external":
        if (m.type !== "external") return false;
        break;
    }

    if (hasDeptFilter) {
      const orgDept = m.organizerDepartmentId;
      if (orgDept == null || !deptSet.has(orgDept)) return false;
    }

    return true;
  });
}
