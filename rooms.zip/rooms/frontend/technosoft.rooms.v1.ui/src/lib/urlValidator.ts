export function isValidUrl(value: string | null | undefined): boolean {
  if (!value) return true;
  const trimmed = value.trim();
  if (trimmed.length === 0) return true;

  if (!/^https?:\/\//i.test(trimmed)) return false;

  try {
    const url = new URL(trimmed);
    if (!url.hostname || url.hostname.length === 0) return false;
    if (!url.hostname.includes(".")) return false;
    return true;
  } catch {
    return false;
  }
}

export function getUrlError(
  value: string | null | undefined,
  fieldName = "enlace"
): string | null {
  if (!value) return null;
  const trimmed = value.trim();
  if (trimmed.length === 0) return null;

  if (!/^https?:\/\//i.test(trimmed)) {
    return `El ${fieldName} debe comenzar con http:// o https://`;
  }

  try {
    const url = new URL(trimmed);
    if (!url.hostname || !url.hostname.includes(".")) {
      return `El ${fieldName} debe tener un dominio válido`;
    }
    return null;
  } catch {
    return `El ${fieldName} es inválido`;
  }
}
