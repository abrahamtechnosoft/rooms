// Rango de marcas diacríticas combinables en Unicode (̀..ͯ).
// Después de NFD cada letra acentuada queda separada en letra base +
// estas marcas; al borrarlas obtenemos la letra "limpia".
const DIACRITIC_RE = /[̀-ͯ]/g;

/**
 * Normaliza un string para búsquedas sin tildes ni mayúsculas.
 * "José Pérez" → "jose perez", "Núñez" → "nunez".
 */
export function normalizeForSearch(str: string | null | undefined): string {
  if (!str) return "";
  return str.toLowerCase().normalize("NFD").replace(DIACRITIC_RE, "").trim();
}

/**
 * True si `text` contiene `query`, ignorando tildes y mayúsculas.
 * Si `query` está vacío, devuelve true (no se filtra nada).
 */
export function matchesSearch(
  text: string | null | undefined,
  query: string | null | undefined
): boolean {
  if (!query || !query.trim()) return true;
  const normalizedText = normalizeForSearch(text);
  const normalizedQuery = normalizeForSearch(query);
  return normalizedText.includes(normalizedQuery);
}
