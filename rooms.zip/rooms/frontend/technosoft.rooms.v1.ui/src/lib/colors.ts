/**
 * Paleta semantica de la app. Centralizar aqui evita hex hardcoded
 * repartido por componentes.
 */
export const COLORS = {
  // Tipos de reunion
  physical: "#2C3E50",
  office: "#E67E22",
  virtual: "#8B5CF6",
  external: "#27AE60",

  // Estados
  live: "#C0392B",
  ended: "#6B7280",
  cancelled: "#9CA3AF",
  upcoming: "#3B82F6",

  // Acciones / brand
  primary: "#2C3E50",
  danger: "#C0392B",
  success: "#27AE60",
  warning: "#F59E0B",

  // Greys
  text: "#1A1A1A",
  textSecondary: "#6B7280",
  border: "#E5E7EB",
} as const;

export type ColorKey = keyof typeof COLORS;

import type { ReservationType } from "@/constants/reservationTypes";

/** Devuelve el color hex correspondiente al tipo de reunion. */
export function reservationTypeColor(type: ReservationType): string {
  switch (type) {
    case "office":
      return COLORS.office;
    case "virtual":
      return COLORS.virtual;
    case "external":
      return COLORS.external;
    case "physical":
    default:
      return COLORS.physical;
  }
}
