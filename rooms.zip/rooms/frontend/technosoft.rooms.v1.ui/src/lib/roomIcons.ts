import {
  Building,
  Building2,
  Briefcase,
  Video,
  Users,
  Coffee,
  Wifi,
  Monitor,
  Mic,
  Presentation,
  Lightbulb,
  Headphones,
  BookOpen,
  Pen,
  Calendar,
  Globe,
  Home,
  MapPin,
  MessageSquare,
  Smartphone,
  Star,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";

export interface RoomIconOption {
  name: string;
  component: LucideIcon;
}

export const ROOM_ICONS: RoomIconOption[] = [
  { name: "Building2", component: Building2 },
  { name: "Briefcase", component: Briefcase },
  { name: "Video", component: Video },
  { name: "Users", component: Users },
  { name: "Coffee", component: Coffee },
  { name: "Wifi", component: Wifi },
  { name: "Monitor", component: Monitor },
  { name: "Mic", component: Mic },
  { name: "Presentation", component: Presentation },
  { name: "Lightbulb", component: Lightbulb },
  { name: "Headphones", component: Headphones },
  { name: "BookOpen", component: BookOpen },
  { name: "Pen", component: Pen },
  { name: "Calendar", component: Calendar },
  { name: "Globe", component: Globe },
  { name: "Home", component: Home },
  { name: "MapPin", component: MapPin },
  { name: "MessageSquare", component: MessageSquare },
  { name: "Smartphone", component: Smartphone },
  { name: "Star", component: Star },
];

export interface RoomColorOption {
  name: string;
  hex: string;
}

export const ROOM_COLORS: RoomColorOption[] = [
  { name: "Azul", hex: "#2C3E50" },
  { name: "Naranja", hex: "#E67E22" },
  { name: "Morado", hex: "#8B5CF6" },
  { name: "Verde", hex: "#27AE60" },
  { name: "Rojo", hex: "#C0392B" },
  { name: "Turquesa", hex: "#16A085" },
  { name: "Rosa", hex: "#EC4899" },
  { name: "Gris", hex: "#64748B" },
];

export const DEFAULT_ROOM_COLOR = "#64748B";

const ICON_MAP: Record<string, LucideIcon> = ROOM_ICONS.reduce(
  (acc, { name, component }) => {
    acc[name] = component;
    return acc;
  },
  {} as Record<string, LucideIcon>
);

export function getRoomIcon(
  iconName: string | null | undefined
): LucideIcon {
  if (!iconName) return Building;
  return ICON_MAP[iconName] || Building;
}

export function getRoomColor(
  colorHex: string | null | undefined
): string {
  return colorHex && /^#[0-9A-Fa-f]{6}$/.test(colorHex)
    ? colorHex
    : DEFAULT_ROOM_COLOR;
}
