import type { Person, PersonDetail, PersonMeeting } from "@/types";

export type PersonStatusKind = "in_meeting" | "soon" | "available";

export interface PersonStatusUi {
  kind: PersonStatusKind;
  /** Clases del punto/dot. Incluye animate-pulse cuando el estado es in_meeting. */
  dotCls: string;
  /** Etiqueta legible ("En reunión", "Sin reuniones", "Reunión en N min"). */
  label: string;
  /** Color del texto que acompaña al estado. */
  textColor: string;
}

const IN_MEETING: PersonStatusUi = {
  kind: "in_meeting",
  dotCls: "bg-millenium-red animate-pulse",
  label: "En reunión",
  textColor: "text-millenium-red",
};

const AVAILABLE: PersonStatusUi = {
  kind: "available",
  dotCls: "bg-millenium-green",
  label: "Sin reuniones",
  textColor: "text-millenium-green",
};

function soon(minutesUntil: number): PersonStatusUi {
  return {
    kind: "soon",
    dotCls: "bg-yellow-500",
    label:
      minutesUntil <= 0
        ? "Reunión por iniciar"
        : `Reunión en ${minutesUntil} min`,
    textColor: "text-yellow-700",
  };
}

/** Versión que toma el `status` adjuntado por el backend en `Person`. */
export function personStatusUi(person: Person): PersonStatusUi {
  if (person.status.kind === "in_meeting") return IN_MEETING;
  if (person.status.kind === "soon") return soon(person.status.minutesUntil);
  return AVAILABLE;
}

/**
 * Versión que deriva el estado a partir de las próximas reuniones — usado por
 * el drawer, que recibe `PersonDetail` sin un campo `status` precalculado.
 * Considera "soon" si la próxima reunión empieza en ≤15 minutos.
 */
export function personDetailStatusUi(
  data: PersonDetail | null
): PersonStatusUi {
  if (!data) return AVAILABLE;

  const current = data.meetings.find(
    (m: PersonMeeting) => m.state === "in_progress"
  );
  if (current) return IN_MEETING;

  const nextStart = data.meetings
    .filter((m) => m.state === "upcoming")
    .map((m) => new Date(m.startsAt).getTime())
    .sort((a, b) => a - b)[0];

  if (nextStart != null) {
    const minutes = Math.floor((nextStart - Date.now()) / 60000);
    if (minutes <= 15 && minutes >= 0) return soon(minutes);
  }
  return AVAILABLE;
}
