// Event bus minimo para sincronizar widgets que muestran los mismos datos
// (notas/recordatorios). Cuando un componente crea/edita/elimina, dispara
// el evento y los widgets que escuchan refrescan.
//
// SSR-safe: noop si `window` no existe.

type WidgetEvent = "notes:changed" | "reminders:changed";

export function emitWidgetEvent(name: WidgetEvent): void {
  if (typeof window === "undefined") return;
  window.dispatchEvent(new CustomEvent(name));
}

export function onWidgetEvent(
  name: WidgetEvent,
  handler: () => void
): () => void {
  if (typeof window === "undefined") return () => {};
  window.addEventListener(name, handler);
  return () => window.removeEventListener(name, handler);
}
