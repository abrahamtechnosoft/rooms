import { format, parseISO } from "date-fns";
import { es } from "date-fns/locale";

const capitalizeFirst = (s: string) =>
  s.length === 0 ? s : s[0].toUpperCase() + s.slice(1);

export const fmtDate = (iso: string | Date) => {
  const d = typeof iso === "string" ? parseISO(iso) : iso;
  return capitalizeFirst(format(d, "EEEE d 'de' MMMM yyyy", { locale: es }));
};

// "Miércoles 13 de mayo" — sin año. Capitalizada para titulos.
export const fmtLong = (iso: string | Date) => {
  const d = typeof iso === "string" ? parseISO(iso) : iso;
  return capitalizeFirst(format(d, "EEEE d 'de' MMMM", { locale: es }));
};

export const fmtDateShort = (iso: string | Date) => {
  const d = typeof iso === "string" ? parseISO(iso) : iso;
  return format(d, "dd/MM/yyyy", { locale: es });
};

export const fmtTime = (iso: string | Date) => {
  const d = typeof iso === "string" ? parseISO(iso) : iso;
  return format(d, "HH:mm", { locale: es });
};

export const fmtDateTime = (iso: string | Date) => {
  const d = typeof iso === "string" ? parseISO(iso) : iso;
  return format(d, "dd/MM/yyyy HH:mm", { locale: es });
};

// Combine date (yyyy-MM-dd) + time (HH:mm) into an ISO-ish local string
// for sending to the backend. The backend interprets it as local CR time.
export const combineDateTime = (date: string, time: string): string => {
  const [y, m, d] = date.split("-").map((v) => parseInt(v, 10));
  const [hh, mm] = time.split(":").map((v) => parseInt(v, 10));
  const local = new Date(y, (m || 1) - 1, d || 1, hh || 0, mm || 0, 0, 0);
  return local.toISOString();
};

// Parse YYYY-MM-DD as a LOCAL Date (date-fns `parseISO` would treat it as UTC,
// which in any negative-offset timezone resolves to the previous local day).
export const parseYmd = (ymd: string): Date => {
  const [y, m, d] = ymd.split("-").map((v) => parseInt(v, 10));
  return new Date(y, (m || 1) - 1, d || 1, 0, 0, 0, 0);
};

export const today = (): string => {
  const d = new Date();
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  return `${yyyy}-${mm}-${dd}`;
};

export const addDaysIso = (days: number): string => {
  const d = new Date();
  d.setDate(d.getDate() + days);
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  return `${yyyy}-${mm}-${dd}`;
};

export const startOfDayIso = (yyyymmdd: string): string => {
  const [y, m, d] = yyyymmdd.split("-").map((v) => parseInt(v, 10));
  return new Date(y, (m || 1) - 1, d || 1, 0, 0, 0, 0).toISOString();
};

export const endOfDayIso = (yyyymmdd: string): string => {
  const [y, m, d] = yyyymmdd.split("-").map((v) => parseInt(v, 10));
  return new Date(y, (m || 1) - 1, d || 1, 23, 59, 59, 999).toISOString();
};

/**
 * Formato de duración legible en español.
 *   30  → "30 minutos"
 *   60  → "1 hora"
 *   90  → "1 h 30 min"
 *   180 → "3 horas"
 *   15  → "15 minutos"
 */
export const formatDuration = (mins: number): string => {
  const m = Math.max(0, Math.round(mins));
  if (m < 60) return `${m} ${m === 1 ? "minuto" : "minutos"}`;
  const horas = Math.floor(m / 60);
  const minutos = m % 60;
  if (minutos === 0) {
    return `${horas} ${horas === 1 ? "hora" : "horas"}`;
  }
  return `${horas} h ${minutos} min`;
};

/** True si `now` está dentro del rango [startsAt, endsAt). */
export const isInProgress = (
  startsAt: string | Date,
  endsAt: string | Date,
  now: Date = new Date()
): boolean => {
  const s = typeof startsAt === "string" ? new Date(startsAt) : startsAt;
  const e = typeof endsAt === "string" ? new Date(endsAt) : endsAt;
  return now >= s && now < e;
};
