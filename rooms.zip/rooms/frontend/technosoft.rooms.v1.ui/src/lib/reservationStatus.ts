export type ReservationVisualStatus = "past" | "live" | "upcoming" | "cancelled";

/**
 * Devuelve el ISO string del fin EFECTIVO de la reunión:
 *  - Si la reunión terminó antes (`endedEarly=true` con `endedAt`), retorna
 *    `endedAt` — el slot post-ended_at queda libre.
 *  - En caso contrario, retorna `endsAt`.
 */
export function effectiveEndsAt(reservation: {
  endsAt: string;
  endedEarly?: boolean;
  endedAt?: string | null;
}): string {
  if (reservation.endedEarly && reservation.endedAt) {
    return reservation.endedAt;
  }
  return reservation.endsAt;
}

export function getReservationStatus(
  reservation: {
    startsAt: string;
    endsAt: string;
    status: "active" | "cancelled";
    endedEarly?: boolean;
    endedAt?: string | null;
  },
  now: Date = new Date()
): ReservationVisualStatus {
  if (reservation.status === "cancelled") return "cancelled";

  const start = new Date(reservation.startsAt);
  // Si terminó antes, su fin EFECTIVO es ended_at, no ends_at.
  const effectiveEnd =
    reservation.endedEarly && reservation.endedAt
      ? new Date(reservation.endedAt)
      : new Date(reservation.endsAt);

  if (effectiveEnd <= now) return "past";
  if (start <= now) return "live";
  return "upcoming";
}

export interface BlockStyles {
  backgroundColor: string;
  borderColor: string;
  /** Color del icono. `undefined` ⇒ que el caller use gris/neutro. */
  iconColor: string | undefined;
  textColorClass: string;
  subtextColorClass: string;
  /** Tailwind opacity-* aplicada al contenedor (además del color de fondo). */
  opacityClass: string;
  titleClass: string;
}

/**
 * Estilos visuales del bloque por estado. Centraliza colores y clases para que
 * todos los timelines apliquen el mismo lenguaje:
 *  - upcoming  → tinte normal (~15%), texto vivo.
 *  - live      → tinte más saturado (~28%), texto vivo.
 *  - past      → tinte casi imperceptible (~4%) + opacity-50 + texto gris.
 *  - cancelled → igual que past + opacity-60 + tachado.
 */
export function getBlockStyles(
  reservation: {
    startsAt: string;
    endsAt: string;
    status: "active" | "cancelled";
    endedEarly?: boolean;
    endedAt?: string | null;
  },
  now: Date,
  roomColor: string
): BlockStyles {
  const status = getReservationStatus(reservation, now);
  switch (status) {
    case "upcoming":
      return {
        backgroundColor: `${roomColor}26`, // ~15%
        borderColor: roomColor,
        iconColor: roomColor,
        textColorClass: "text-gray-900",
        subtextColorClass: "text-gray-500",
        opacityClass: "",
        titleClass: "",
      };
    case "live":
      return {
        backgroundColor: `${roomColor}47`, // ~28%
        borderColor: roomColor,
        iconColor: roomColor,
        textColorClass: "text-gray-900",
        subtextColorClass: "text-gray-600",
        opacityClass: "",
        titleClass: "",
      };
    case "past":
      return {
        backgroundColor: `${roomColor}0a`, // ~4%
        borderColor: `${roomColor}60`,
        iconColor: undefined,
        textColorClass: "text-gray-500",
        subtextColorClass: "text-gray-400",
        opacityClass: "opacity-50",
        titleClass: "",
      };
    case "cancelled":
      return {
        backgroundColor: `${roomColor}0a`,
        borderColor: `${roomColor}40`,
        iconColor: undefined,
        textColorClass: "text-gray-500",
        subtextColorClass: "text-gray-400",
        opacityClass: "opacity-60",
        titleClass: "line-through",
      };
  }
}
