import type { Reservation } from "@/types";
import { effectiveEndsAt } from "@/lib/reservationStatus";

export interface MeetingGroup {
  id: string;
  /** epoch ms del inicio mas temprano del grupo */
  start: number;
  /** epoch ms del fin mas tardio del grupo (usando effectiveEndsAt) */
  end: number;
  items: Reservation[];
}

export interface OverlapItem {
  /** null cuando isOverflowSlot=true */
  meeting: Reservation | null;
  col: number;
  totalCols: number;
  groupId: string;
  groupSize: number;
  widthPct: number;
  leftPct: number;
  topPct: number;
  heightPct: number;
  isOverflowSlot?: boolean;
  hiddenMeetings?: Reservation[];
}

export interface OverlapLayout {
  items: OverlapItem[];
  groups: MeetingGroup[];
}

export interface LayoutBounds {
  openHour: number;
  closeHour: number;
}

/** Cap de columnas visibles antes de mostrar "+N mas". */
export const OVERFLOW_VISIBLE_COLS = 2;
/** A partir de cuantos items en un grupo se aplica el cap. */
export const OVERFLOW_THRESHOLD = 3;
/** Total efectivo de columnas cuando aplica el cap (2 visibles + 1 chip). */
export const OVERFLOW_TOTAL_COLS = OVERFLOW_VISIBLE_COLS + 1;

/** Ancho porcentual de cada tarjeta visible cuando hay overflow. */
const OVERFLOW_VISIBLE_WIDTH_PCT = 45;
/** Ancho porcentual del chip "+N mas". */
const OVERFLOW_SLOT_WIDTH_PCT = 10;

function userParticipates(
  meeting: Reservation,
  userId: number | null
): boolean {
  if (!userId) return false;
  if (meeting.createdBy === userId) return true;
  return (meeting.participants ?? []).some(
    (p) => p.id === userId && p.status !== "cancelled"
  );
}

function pctFromHours(
  h: number,
  openHour: number,
  closeHour: number
): number {
  const totalHours = closeHour - openHour;
  if (totalHours <= 0) return 0;
  return (
    ((Math.max(openHour, Math.min(closeHour, h)) - openHour) / totalHours) *
    100
  );
}

interface VBounds {
  topPct: number;
  heightPct: number;
}

function computeVBounds(
  startsAt: string,
  effectiveEnd: string,
  bounds: LayoutBounds
): VBounds {
  const s = new Date(startsAt);
  const e = new Date(effectiveEnd);
  const startH = s.getHours() + s.getMinutes() / 60;
  const endH = e.getHours() + e.getMinutes() / 60;
  const topPct = pctFromHours(startH, bounds.openHour, bounds.closeHour);
  const heightPct = Math.max(
    0,
    pctFromHours(endH, bounds.openHour, bounds.closeHour) - topPct
  );
  return { topPct, heightPct };
}

/**
 * Asigna columnas y anchos a reuniones que se solapan.
 *
 * Reglas:
 * - Cuando `groupSize >= OVERFLOW_THRESHOLD` (3+), se muestran 2 reuniones
 *   visibles (45% c/u) y un slot chip "+N mas" (10%, col 2).
 * - Cuando `groupSize <= 2`, las reuniones se reparten uniformemente.
 * - Priorizacion: reuniones donde participa `currentUserId` (organizador o
 *   colaborador activo) van primero en el orden de columnas. El resto en
 *   orden ascendente por `startsAt`.
 *
 * Cada `OverlapItem` lleva tambien su `topPct` / `heightPct` (segun
 *   `effectiveEndsAt` del meeting o, para el slot overflow, segun los
 *   bordes del grupo).
 */
export function computeOverlapLayout(
  meetings: Reservation[],
  currentUserId: number | null,
  bounds: LayoutBounds
): OverlapLayout {
  const sorted = [...meetings].sort(
    (a, b) =>
      new Date(a.startsAt).getTime() - new Date(b.startsAt).getTime()
  );

  // 1. Agrupar en islas (cadenas de solape). Se usa endsAt original (no
  //    effectiveEndsAt) para decidir si dos reuniones se solapan en su
  //    intencion original.
  const islands: Reservation[][] = [];
  const islandEnds: number[] = [];

  for (const m of sorted) {
    const start = new Date(m.startsAt).getTime();
    const end = new Date(m.endsAt).getTime();
    const lastIdx = islands.length - 1;
    if (lastIdx >= 0 && start < islandEnds[lastIdx]) {
      islands[lastIdx].push(m);
      islandEnds[lastIdx] = Math.max(islandEnds[lastIdx], end);
    } else {
      islands.push([m]);
      islandEnds.push(end);
    }
  }

  const items: OverlapItem[] = [];
  const groups: MeetingGroup[] = [];

  islands.forEach((island, idx) => {
    const groupId = `g-${idx}`;
    const groupSize = island.length;

    // Bounds verticales del grupo (para el slot overflow).
    const groupStartMs = Math.min(
      ...island.map((m) => new Date(m.startsAt).getTime())
    );
    const groupEndMs = Math.max(
      ...island.map((m) => new Date(effectiveEndsAt(m)).getTime())
    );
    const groupV = computeVBounds(
      new Date(groupStartMs).toISOString(),
      new Date(groupEndMs).toISOString(),
      bounds
    );

    groups.push({
      id: groupId,
      start: groupStartMs,
      end: groupEndMs,
      items: island,
    });

    // 2. Priorizar reuniones donde participa el usuario.
    const userMeetings: Reservation[] = [];
    const otherMeetings: Reservation[] = [];
    for (const m of island) {
      if (userParticipates(m, currentUserId)) {
        userMeetings.push(m);
      } else {
        otherMeetings.push(m);
      }
    }
    const ordered = [...userMeetings, ...otherMeetings];

    const hasOverflow = groupSize >= OVERFLOW_THRESHOLD;

    if (hasOverflow) {
      const visible = ordered.slice(0, OVERFLOW_VISIBLE_COLS);
      const hidden = ordered.slice(OVERFLOW_VISIBLE_COLS);

      visible.forEach((m, col) => {
        const v = computeVBounds(m.startsAt, effectiveEndsAt(m), bounds);
        items.push({
          meeting: m,
          col,
          totalCols: OVERFLOW_TOTAL_COLS,
          groupId,
          groupSize,
          widthPct: OVERFLOW_VISIBLE_WIDTH_PCT,
          leftPct: col * OVERFLOW_VISIBLE_WIDTH_PCT,
          topPct: v.topPct,
          heightPct: v.heightPct,
        });
      });

      // Slot chip "+N mas" — ocupa el alto del grupo.
      items.push({
        meeting: null,
        col: OVERFLOW_VISIBLE_COLS,
        totalCols: OVERFLOW_TOTAL_COLS,
        groupId,
        groupSize,
        widthPct: OVERFLOW_SLOT_WIDTH_PCT,
        leftPct: 100 - OVERFLOW_SLOT_WIDTH_PCT,
        topPct: groupV.topPct,
        heightPct: groupV.heightPct,
        isOverflowSlot: true,
        hiddenMeetings: hidden,
      });
    } else {
      const widthPct = 100 / Math.max(groupSize, 1);
      ordered.forEach((m, col) => {
        const v = computeVBounds(m.startsAt, effectiveEndsAt(m), bounds);
        items.push({
          meeting: m,
          col,
          totalCols: groupSize,
          groupId,
          groupSize,
          widthPct,
          leftPct: col * widthPct,
          topPct: v.topPct,
          heightPct: v.heightPct,
        });
      });
    }
  });

  return { items, groups };
}
