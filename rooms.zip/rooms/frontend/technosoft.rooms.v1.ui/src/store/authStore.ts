"use client";

import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";
import type { User, Reply, LoginResponse } from "@/types";

interface AuthState {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
  hydrated: boolean;

  requestCode: (email: string) => Promise<{ ok: boolean; msg: string }>;
  verifyCode: (
    email: string,
    code: string
  ) => Promise<{ ok: boolean; msg: string }>;
  updateProfile: (
    fields: { fullName?: string; departmentId?: number | null }
  ) => Promise<{ ok: boolean; msg: string }>;
  refreshMe: () => Promise<void>;
  setAvatarUrl: (avatarUrl: string | null) => void;
  logout: () => void;
  setHydrated: () => void;
}

const API_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:4000/api";

// ────────────────────────────────────────────────────────────────────────────
// BYPASS DE LOGIN TEMPORAL — Desactivar antes de productivo.
// Cuando esta en `true`: el store arranca con un usuario admin simulado, no se
// persiste nada en localStorage, y `logout` queda como no-op. La pagina de
// login redirige automaticamente a /dashboard porque `isAuthenticated` ya es
// true al cargar. Nota: las llamadas a la API necesitan un JWT valido del
// backend; el token simulado fallara con 401 a menos que el backend tambien
// tenga modo bypass.
const BYPASS_AUTH = false;

const MOCK_USER: User = {
  id: 1,
  email: "desarrollador1@technosoftcr.com",
  fullName: "Desarrollador (bypass)",
  role: "admin",
  isActive: true,
};
const MOCK_TOKEN = "dev-bypass-token";
// ────────────────────────────────────────────────────────────────────────────

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      user: BYPASS_AUTH ? MOCK_USER : null,
      token: BYPASS_AUTH ? MOCK_TOKEN : null,
      isAuthenticated: BYPASS_AUTH ? true : false,
      hydrated: BYPASS_AUTH ? true : false,

      requestCode: async (email: string) => {
        try {
          const res = await fetch(`${API_URL}/auth/request-code`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ email }),
          });
          const data: Reply<{ sent: boolean }> = await res.json();
          if (!data.ok) {
            return { ok: false, msg: data.msg || "No fue posible enviar el código" };
          }
          return { ok: true, msg: data.msg || "Código enviado al correo" };
        } catch {
          return { ok: false, msg: "No fue posible conectar con el servidor" };
        }
      },

      verifyCode: async (email: string, code: string) => {
        try {
          const res = await fetch(`${API_URL}/auth/verify-code`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ email, code }),
          });
          const data: Reply<LoginResponse> = await res.json();
          if (!data.ok || !data.obj) {
            return { ok: false, msg: data.msg || "Código no válido o vencido" };
          }
          set({
            user: data.obj.user,
            token: data.obj.token,
            isAuthenticated: true,
          });
          return { ok: true, msg: data.msg || "Acceso autorizado" };
        } catch {
          return { ok: false, msg: "No fue posible conectar con el servidor" };
        }
      },

      updateProfile: async (fields) => {
        const token = get().token;
        if (!token) return { ok: false, msg: "Sesión no válida" };
        try {
          const res = await fetch(`${API_URL}/auth/me`, {
            method: "PUT",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${token}`,
            },
            body: JSON.stringify(fields),
          });
          const data: Reply<unknown> = await res.json();
          if (!data.ok) {
            return {
              ok: false,
              msg: data.msg || "No fue posible actualizar el perfil",
            };
          }
          // Refrescar perfil para traer departmentId/Name/Color actualizados.
          await get().refreshMe();
          return { ok: true, msg: data.msg || "Perfil actualizado" };
        } catch {
          return { ok: false, msg: "No fue posible conectar con el servidor" };
        }
      },

      refreshMe: async () => {
        const token = get().token;
        if (!token) return;
        try {
          const res = await fetch(`${API_URL}/auth/me`, {
            headers: { Authorization: `Bearer ${token}` },
          });
          const data: Reply<User> = await res.json();
          if (data.ok && data.obj) {
            set({ user: data.obj });
          }
        } catch {
          // ignore — el polling siguiente lo intentará de nuevo
        }
      },

      setAvatarUrl: (avatarUrl: string | null) => {
        const current = get().user;
        if (current) set({ user: { ...current, avatarUrl } });
      },

      logout: () => {
        if (BYPASS_AUTH) return;
        set({ user: null, token: null, isAuthenticated: false });
      },

      setHydrated: () => set({ hydrated: true }),
    }),
    {
      name: "millenium-rooms-auth",
      storage: createJSONStorage(() => localStorage),
      partialize: (state) =>
        BYPASS_AUTH
          ? ({} as Partial<AuthState>)
          : {
              user: state.user,
              token: state.token,
              isAuthenticated: state.isAuthenticated,
            },
      onRehydrateStorage: () => (state) => {
        state?.setHydrated();
      },
    }
  )
);
