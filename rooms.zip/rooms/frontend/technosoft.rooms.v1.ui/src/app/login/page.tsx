"use client";

import {
  FormEvent,
  KeyboardEvent,
  ClipboardEvent,
  useEffect,
  useRef,
  useState,
} from "react";
import { useRouter } from "next/navigation";
import { ArrowLeft, Mail } from "lucide-react";
import { toast } from "@/lib/toastHelpers";
import { useAuthStore } from "@/store/authStore";
import MilleniumLogo from "@/components/MilleniumLogo";
import Input from "@/components/ui/Input";
import Button from "@/components/ui/Button";

type Step = "email" | "code";
const CODE_LEN = 6;
const RESEND_COOLDOWN = 30;

export default function LoginPage() {
  const router = useRouter();
  const { requestCode, verifyCode, isAuthenticated, hydrated } = useAuthStore();

  const [step, setStep] = useState<Step>("email");
  const [email, setEmail] = useState("");
  const [digits, setDigits] = useState<string[]>(Array(CODE_LEN).fill(""));
  const [sending, setSending] = useState(false);
  const [verifying, setVerifying] = useState(false);
  const [cooldown, setCooldown] = useState(0);

  const inputsRef = useRef<Array<HTMLInputElement | null>>([]);

  useEffect(() => {
    if (hydrated && isAuthenticated) router.replace("/dashboard");
  }, [hydrated, isAuthenticated, router]);

  useEffect(() => {
    if (cooldown <= 0) return;
    const t = setInterval(() => setCooldown((v) => (v > 0 ? v - 1 : 0)), 1000);
    return () => clearInterval(t);
  }, [cooldown]);

  useEffect(() => {
    if (step === "code") {
      const first = inputsRef.current[0];
      if (first) first.focus();
    }
  }, [step]);

  const sendCode = async (
    targetEmail: string,
    opts: { isResend?: boolean } = {}
  ) => {
    setSending(true);
    const r = await requestCode(targetEmail);
    setSending(false);
    if (r.ok) {
      setCooldown(RESEND_COOLDOWN);
      if (opts.isResend) {
        toast.success("Código reenviado al correo");
      } else {
        setStep("code");
      }
    } else {
      toast.error(r.msg);
    }
  };

  const handleEmailSubmit = async (e: FormEvent) => {
    e.preventDefault();
    const value = email.trim().toLowerCase();
    if (!value) {
      toast.error("Ingrese su correo");
      return;
    }
    await sendCode(value);
  };

  const setDigit = (idx: number, value: string) => {
    const next = [...digits];
    next[idx] = value;
    setDigits(next);
  };

  const handleDigitChange = (idx: number, raw: string) => {
    const v = raw.replace(/\D/g, "").slice(-1);
    setDigit(idx, v);
    if (v && idx < CODE_LEN - 1) {
      inputsRef.current[idx + 1]?.focus();
    }
  };

  const handleKeyDown = (idx: number, e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Backspace" && !digits[idx] && idx > 0) {
      inputsRef.current[idx - 1]?.focus();
    } else if (e.key === "ArrowLeft" && idx > 0) {
      e.preventDefault();
      inputsRef.current[idx - 1]?.focus();
    } else if (e.key === "ArrowRight" && idx < CODE_LEN - 1) {
      e.preventDefault();
      inputsRef.current[idx + 1]?.focus();
    } else if (e.key === "Enter") {
      e.preventDefault();
      submitCode();
    }
  };

  const handlePaste = (e: ClipboardEvent<HTMLInputElement>) => {
    const txt = e.clipboardData.getData("text").replace(/\D/g, "");
    if (txt.length < 2) return;
    e.preventDefault();
    const filled = txt.slice(0, CODE_LEN).split("");
    const next = Array(CODE_LEN).fill("");
    filled.forEach((c, i) => (next[i] = c));
    setDigits(next);
    const last = Math.min(filled.length, CODE_LEN) - 1;
    if (last >= 0) inputsRef.current[last]?.focus();
    if (filled.length === CODE_LEN) {
      setTimeout(() => submitCodeWith(filled.join("")), 50);
    }
  };

  const submitCodeWith = async (code: string) => {
    if (code.length !== CODE_LEN || verifying) return;
    setVerifying(true);
    const r = await verifyCode(email.trim().toLowerCase(), code);
    setVerifying(false);
    if (r.ok) {
      toast.success(r.msg);
      router.replace("/dashboard");
    } else {
      toast.error(r.msg);
      setDigits(Array(CODE_LEN).fill(""));
      inputsRef.current[0]?.focus();
    }
  };

  const submitCode = () => {
    const code = digits.join("");
    if (code.length !== CODE_LEN) {
      toast.error("Ingrese los 6 dígitos del código");
      return;
    }
    submitCodeWith(code);
  };

  const handleCodeSubmit = (e: FormEvent) => {
    e.preventDefault();
    submitCode();
  };

  const goBackToEmail = () => {
    setStep("email");
    setDigits(Array(CODE_LEN).fill(""));
  };

  return (
    <main className="flex min-h-screen flex-col items-center justify-center bg-linear-to-br from-gray-50 to-gray-100 px-4 py-10">
      <div className="w-full max-w-md rounded-2xl border border-gray-200 bg-white p-8 shadow-xl">
        <div className="mb-7 flex flex-col items-center">
          <MilleniumLogo size={100} />
        </div>

        <div className="transition-all duration-200">
          {step === "email" ? (
            <form onSubmit={handleEmailSubmit} className="flex flex-col gap-4">
              <div className="text-center">
                <h1 className="text-2xl font-semibold tracking-tight text-gray-900">
                  Bienvenido a Rooms
                </h1>
                <p className="mt-1.5 text-base text-gray-500">
                  Ingrese su correo corporativo
                </p>
              </div>

              <Input
                id="email"
                type="email"
                inputMode="email"
                name="email"
                label="Correo electrónico"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="su.correo@millenium.cr"
                autoComplete="email"
                required
                leadingIcon={<Mail size={18} />}
              />

              <Button
                type="submit"
                variant="primary"
                loading={sending}
                className="mt-2 w-full"
              >
                {sending ? "Enviando código..." : "Enviar código"}
              </Button>
            </form>
          ) : (
            <form onSubmit={handleCodeSubmit} className="flex flex-col gap-4">
              <div className="text-center">
                <h1 className="text-2xl font-semibold tracking-tight text-gray-900">
                  Revise su correo
                </h1>
                <p className="mt-1.5 text-base text-gray-500">
                  Enviamos un código a
                </p>
                <p className="text-base font-medium text-millenium-blue break-all">
                  {email}
                </p>
              </div>

              <div className="flex justify-center gap-1 sm:gap-2">
                {digits.map((d, i) => (
                  <input
                    key={i}
                    ref={(el) => {
                      inputsRef.current[i] = el;
                    }}
                    type="text"
                    inputMode="numeric"
                    autoComplete="one-time-code"
                    maxLength={1}
                    value={d}
                    onChange={(e) => handleDigitChange(i, e.target.value)}
                    onKeyDown={(e) => handleKeyDown(i, e)}
                    onPaste={handlePaste}
                    className="h-12 w-10 rounded-lg border-2 border-gray-200 text-center text-xl font-semibold text-gray-900 focus:border-millenium-blue focus:outline-none sm:h-14 sm:w-12 sm:text-2xl"
                    aria-label={`Dígito ${i + 1}`}
                  />
                ))}
              </div>

              <Button
                type="submit"
                variant="primary"
                loading={verifying}
                disabled={digits.join("").length !== CODE_LEN}
                className="mt-2 w-full"
              >
                {verifying ? "Verificando..." : "Verificar"}
              </Button>

              <div className="mt-2 flex items-center justify-center gap-4 text-sm text-gray-500">
                <Button
                  type="button"
                  variant="link"
                  onClick={() => sendCode(email, { isResend: true })}
                  disabled={cooldown > 0 || sending}
                >
                  {cooldown > 0
                    ? `Reintentar en ${cooldown}s`
                    : "No recibí nada"}
                </Button>
                <span className="text-gray-500" aria-hidden="true">·</span>
                <Button
                  type="button"
                  variant="link"
                  onClick={goBackToEmail}
                  className="text-gray-500! hover:text-gray-700! hover:no-underline!"
                >
                  <ArrowLeft className="h-3.5 w-3.5" />
                  Usar otro correo
                </Button>
              </div>
            </form>
          )}
        </div>
      </div>

      <p className="mt-6 text-sm text-gray-500">
        Corporación Millenium © 2026
      </p>
    </main>
  );
}
