import type { Metadata } from "next";
import { Inter } from "next/font/google";
import { Toaster } from "sonner";
import "./globals.css";

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
  display: "swap",
});

export const metadata: Metadata = {
  title: "Technosoft Rooms - Corporación Millenium",
  description: "Plataforma de reuniones - Corporación Millenium",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="es" className={`${inter.variable} h-full antialiased`}>
      <body className="min-h-full flex flex-col font-sans">
        {children}
        <Toaster
          position="top-right"
          richColors
          closeButton
          theme="light"
          duration={4000}
          toastOptions={{
            style: { borderRadius: "8px", fontSize: "14px" },
            classNames: {
              toast: "shadow-lg border",
            },
          }}
        />
      </body>
    </html>
  );
}
