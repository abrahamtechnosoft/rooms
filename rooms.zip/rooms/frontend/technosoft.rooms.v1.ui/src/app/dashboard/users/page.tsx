"use client";

import { FormEvent, useCallback, useEffect, useMemo, useState } from "react";
import { Edit2, Info, Plus, Power, Search, SearchX, UserPlus } from "lucide-react";
import { toast } from "@/lib/toastHelpers";
import ProtectedRoute from "@/components/ProtectedRoute";
import PageHeader from "@/components/layout/PageHeader";
import Avatar from "@/components/Avatar";
import EmptyState from "@/components/EmptyState";
import TableSkeleton from "@/components/skeletons/TableSkeleton";
import Modal from "@/components/ui/Modal";
import Input from "@/components/ui/Input";
import Button from "@/components/ui/Button";
import Pagination from "@/components/ui/Pagination";
import api from "@/lib/api";
import { matchesSearch } from "@/lib/stringHelpers";
import DepartmentInlinePicker from "@/components/DepartmentInlinePicker";
import type { Department, Reply, Role, User } from "@/types";

const ITEMS_PER_PAGE = 30;

interface FormState {
  email: string;
  fullName: string;
  role: Role;
}

const emptyForm: FormState = {
  email: "",
  fullName: "",
  role: "empleado",
};

export default function UsersAdminPage() {
  const [users, setUsers] = useState<User[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [loading, setLoading] = useState(false);
  const [modalOpen, setModalOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [form, setForm] = useState<FormState>(emptyForm);
  const [submitting, setSubmitting] = useState(false);
  const [confirmingDeactivate, setConfirmingDeactivate] = useState<User | null>(
    null
  );
  const [togglingPower, setTogglingPower] = useState(false);
  const [search, setSearch] = useState("");
  const [currentPage, setCurrentPage] = useState(1);

  const filteredUsers = useMemo(() => {
    const q = search.trim();
    if (!q) return users;
    return users.filter(
      (u) => matchesSearch(u.fullName, q) || matchesSearch(u.email, q)
    );
  }, [users, search]);

  useEffect(() => {
    setCurrentPage(1);
  }, [search]);

  const totalPages = Math.max(1, Math.ceil(filteredUsers.length / ITEMS_PER_PAGE));
  const safePage = Math.min(currentPage, totalPages);
  const paginatedUsers = filteredUsers.slice(
    (safePage - 1) * ITEMS_PER_PAGE,
    safePage * ITEMS_PER_PAGE
  );

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await api.get<Reply<User[]>>("/users");
      setUsers(res.data.obj || []);
    } catch {
      toast.error("No fue posible cargar los usuarios");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  // G4 — Lista de departamentos para el picker inline.
  useEffect(() => {
    let cancelled = false;
    api
      .get<Reply<Department[]>>("/departments")
      .then((res) => {
        if (cancelled) return;
        setDepartments(res.data.obj || []);
      })
      .catch(() => {
        if (!cancelled) setDepartments([]);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  const openCreate = () => {
    setEditingUser(null);
    setForm(emptyForm);
    setModalOpen(true);
  };

  const openEdit = (u: User) => {
    setEditingUser(u);
    setForm({ email: u.email, fullName: u.fullName, role: u.role });
    setModalOpen(true);
  };

  const closeModal = () => {
    setModalOpen(false);
    setEditingUser(null);
  };

  const setActive = async (u: User, isActive: boolean) => {
    try {
      const res = await api.patch<Reply<{ id: number; isActive: boolean }>>(
        `/users/${u.id}/active`,
        { isActive }
      );
      if (res.data.ok) {
        toast.success(isActive ? "Usuario activado" : "Usuario desactivado");
        await load();
      } else {
        toast.error(res.data.msg || "No fue posible actualizar el usuario");
      }
    } catch {
      toast.error("No fue posible actualizar el usuario");
    }
  };

  const handleTogglePower = (u: User) => {
    if (!u.isActive) {
      setActive(u, true);
      return;
    }
    if (u.role === "admin") {
      const adminsActivos = users.filter(
        (x) => x.role === "admin" && x.isActive
      ).length;
      if (adminsActivos <= 1) {
        toast.info(
          "No se puede desactivar al único administrador activo del sistema."
        );
        return;
      }
    }
    setConfirmingDeactivate(u);
  };

  const confirmDeactivate = async () => {
    if (!confirmingDeactivate || togglingPower) return;
    setTogglingPower(true);
    try {
      await setActive(confirmingDeactivate, false);
      setConfirmingDeactivate(null);
    } finally {
      setTogglingPower(false);
    }
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!form.fullName.trim() || (!editingUser && !form.email.trim())) {
      toast.error("Complete los campos requeridos");
      return;
    }
    setSubmitting(true);
    try {
      let res;
      if (editingUser) {
        res = await api.patch<Reply<User>>(`/users/${editingUser.id}`, {
          fullName: form.fullName.trim(),
          role: form.role,
        });
      } else {
        res = await api.post<Reply<User>>("/users", {
          email: form.email.trim().toLowerCase(),
          fullName: form.fullName.trim(),
          role: form.role,
        });
      }
      if (!res.data.ok) {
        toast.error(
          res.data.msg ||
            (editingUser
              ? "No fue posible actualizar el usuario"
              : "No fue posible crear el usuario")
        );
        return;
      }
      toast.success(editingUser ? "Usuario actualizado" : "Usuario creado");
      closeModal();
      await load();
    } catch (e: unknown) {
      const errObj = e as { response?: { data?: { msg?: string } } };
      toast.error(
        errObj?.response?.data?.msg ||
          (editingUser
            ? "No fue posible actualizar el usuario"
            : "No fue posible crear el usuario")
      );
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <ProtectedRoute requireRole="admin">
      <>
        <PageHeader
          title="Usuarios"
          description="Gestione las personas que pueden ingresar al sistema."
          actions={
            <Button variant="primary" onClick={openCreate}>
              <Plus className="h-4 w-4" />
              Nuevo usuario
            </Button>
          }
        />

        <div className="mb-5 flex items-start gap-2 rounded-lg border border-blue-100 bg-blue-50/60 px-3.5 py-2.5 text-base text-gray-600">
          <Info className="mt-0.5 h-5 w-5 shrink-0 text-millenium-blue" />
          <span>
            Los usuarios inician sesión con un código enviado a su correo. No
            requieren contraseña.
          </span>
        </div>

        {!loading && users.length > 0 && (
          <div className="mb-4 flex flex-wrap items-center gap-3">
            <div className="relative max-w-sm flex-1">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Buscar por nombre o correo..."
                aria-label="Buscar usuarios"
                className="w-full rounded-lg border border-gray-300 bg-white py-2.5 pl-10 pr-3 text-base focus:border-millenium-blue focus:outline-none focus:ring-2 focus:ring-millenium-blue/20"
              />
            </div>
            <span className="text-sm text-gray-500">
              {filteredUsers.length}{" "}
              {filteredUsers.length === 1 ? "resultado" : "resultados"}
            </span>
          </div>
        )}

        {loading && users.length === 0 ? (
          <TableSkeleton rows={8} columns={5} />
        ) : !loading && users.length === 0 ? (
          <div className="rounded-xl border border-dashed border-gray-300 bg-white">
            <EmptyState
              icon={UserPlus}
              title="Sin usuarios registrados"
              description="Cree el primer usuario para empezar."
              action={
                <Button variant="primary" onClick={openCreate}>
                  <Plus className="h-4 w-4" />
                  Nuevo usuario
                </Button>
              }
            />
          </div>
        ) : !loading && filteredUsers.length === 0 ? (
          <div className="rounded-xl border border-dashed border-gray-300 bg-white">
            <EmptyState
              icon={SearchX}
              title={`Sin resultados para "${search}"`}
              description="Intente con otro término de búsqueda."
            />
          </div>
        ) : (
          <>
            {/* Mobile: cards */}
            <ul className="space-y-2 md:hidden">
              {paginatedUsers.map((u) => (
                <li
                  key={u.id}
                  className="rounded-lg border border-gray-200 bg-white p-3 shadow-sm"
                >
                  <div className="flex items-start gap-3">
                    <Avatar
                      name={u.fullName}
                      email={u.email}
                      avatarUrl={u.avatarUrl}
                      size="md"
                    />
                    <div className="min-w-0 flex-1">
                      <div className="flex items-start justify-between gap-2">
                        <div className="min-w-0 flex-1">
                          <div
                            className="truncate text-sm font-semibold text-gray-900"
                            title={u.fullName}
                          >
                            {u.fullName}
                          </div>
                          <div className="break-all text-xs text-gray-500">
                            {u.email}
                          </div>
                        </div>
                        <span
                          className={
                            "shrink-0 rounded-full px-2 py-0.5 text-[10px] font-medium " +
                            (u.isActive
                              ? "bg-emerald-50 text-emerald-700"
                              : "bg-gray-100 text-gray-600")
                          }
                        >
                          {u.isActive ? "Activo" : "Inactivo"}
                        </span>
                      </div>

                      <div className="mt-2 flex flex-wrap items-center gap-1.5">
                        <span
                          className={
                            "rounded-full px-2 py-0.5 text-[10px] font-medium " +
                            (u.role === "admin"
                              ? "bg-blue-50 text-blue-700"
                              : "bg-gray-100 text-gray-700")
                          }
                        >
                          {u.role === "admin" ? "Administrador" : "Empleado"}
                        </span>
                        <DepartmentInlinePicker
                          userId={u.id}
                          currentDepartmentId={u.departmentId ?? null}
                          currentDepartmentName={u.departmentName ?? null}
                          currentDepartmentColor={u.departmentColor ?? null}
                          departments={departments}
                          onUpdated={load}
                        />
                      </div>

                      <div className="mt-3 flex gap-2 border-t border-gray-100 pt-2">
                        <button
                          type="button"
                          onClick={() => openEdit(u)}
                          className="inline-flex flex-1 items-center justify-center gap-1 rounded-md border border-gray-200 bg-white px-3 py-1.5 text-xs font-medium text-gray-700 hover:bg-gray-50"
                          aria-label={`Editar usuario: ${u.fullName || u.email}`}
                        >
                          <Edit2 className="h-3 w-3" aria-hidden="true" />
                          Editar
                        </button>
                        <button
                          type="button"
                          onClick={() => handleTogglePower(u)}
                          className={
                            "inline-flex flex-1 items-center justify-center gap-1 rounded-md border px-3 py-1.5 text-xs font-medium " +
                            (u.isActive
                              ? "border-red-200 bg-white text-millenium-red hover:bg-red-50"
                              : "border-emerald-200 bg-white text-millenium-green hover:bg-emerald-50")
                          }
                          aria-label={
                            u.isActive
                              ? `Desactivar usuario: ${u.fullName}`
                              : `Activar usuario: ${u.fullName}`
                          }
                        >
                          <Power className="h-3 w-3" aria-hidden="true" />
                          {u.isActive ? "Desactivar" : "Activar"}
                        </button>
                      </div>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
            <div className="mt-2 md:hidden">
              <Pagination
                currentPage={safePage}
                totalPages={totalPages}
                onPageChange={setCurrentPage}
                totalItems={filteredUsers.length}
                itemsPerPage={ITEMS_PER_PAGE}
              />
            </div>

            {/* Desktop: tabla */}
            <div className="hidden overflow-x-auto rounded-xl border border-gray-200 bg-white shadow-sm md:block">
            <table className="min-w-full text-base">
              <thead className="bg-gray-50 text-left text-gray-500">
                <tr>
                  <th scope="col" className="px-4 py-3 text-sm font-semibold uppercase tracking-wide">
                    Nombre
                  </th>
                  <th scope="col" className="px-4 py-3 text-sm font-semibold uppercase tracking-wide">
                    Correo
                  </th>
                  <th scope="col" className="px-4 py-3 text-sm font-semibold uppercase tracking-wide">
                    Rol
                  </th>
                  <th scope="col" className="px-4 py-3 text-sm font-semibold uppercase tracking-wide">
                    Departamento
                  </th>
                  <th scope="col" className="px-4 py-3 text-sm font-semibold uppercase tracking-wide">
                    Estado
                  </th>
                  <th scope="col" className="px-4 py-3"><span className="sr-only">Acciones</span></th>
                </tr>
              </thead>
              <tbody>
                {paginatedUsers.map((u) => (
                  <tr
                    key={u.id}
                    className="h-16 border-t border-gray-100 transition hover:bg-gray-50"
                  >
                    <td className="px-4 py-3">
                      <div className="flex min-w-0 items-center gap-2.5">
                        <Avatar
                          name={u.fullName}
                          email={u.email}
                          avatarUrl={u.avatarUrl}
                          size="sm"
                        />
                        <span
                          className="truncate font-medium text-gray-900"
                          title={u.fullName}
                        >
                          {u.fullName}
                        </span>
                      </div>
                    </td>
                    <td
                      className="break-all px-4 py-3 text-gray-700 sm:wrap-break-word"
                      title={u.email}
                    >
                      {u.email}
                    </td>
                    <td className="px-4 py-3 capitalize text-gray-700">
                      {u.role === "admin" ? "Administrador" : "Empleado"}
                    </td>
                    <td className="px-4 py-3">
                      <DepartmentInlinePicker
                        userId={u.id}
                        currentDepartmentId={u.departmentId ?? null}
                        currentDepartmentName={u.departmentName ?? null}
                        currentDepartmentColor={u.departmentColor ?? null}
                        departments={departments}
                        onUpdated={load}
                      />
                    </td>
                    <td className="px-4 py-3">
                      <span
                        className={
                          "rounded-full px-2.5 py-1 text-xs font-semibold " +
                          (u.isActive
                            ? "bg-green-100 text-millenium-green"
                            : "bg-gray-100 text-gray-500")
                        }
                      >
                        {u.isActive ? "Activo" : "Inactivo"}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-right">
                      <div className="flex justify-end gap-1">
                        <button
                          type="button"
                          onClick={() => openEdit(u)}
                          className="flex h-11 w-11 items-center justify-center rounded-md text-gray-500 transition hover:bg-gray-100 hover:text-millenium-blue focus:outline-none focus:ring-2 focus:ring-millenium-blue focus:ring-offset-1"
                          aria-label={`Editar usuario: ${u.fullName || u.email}`}
                        >
                          <Edit2 className="h-5 w-5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => handleTogglePower(u)}
                          className={
                            "flex h-11 w-11 items-center justify-center rounded-md transition focus:outline-none focus:ring-2 focus:ring-millenium-blue focus:ring-offset-1 " +
                            (u.isActive
                              ? "text-gray-500 hover:bg-red-50 hover:text-millenium-red"
                              : "text-gray-500 hover:bg-green-50 hover:text-millenium-green")
                          }
                          aria-label={
                            u.isActive
                              ? `Desactivar usuario: ${u.fullName}`
                              : `Activar usuario: ${u.fullName}`
                          }
                        >
                          <Power className="h-5 w-5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            <Pagination
              currentPage={safePage}
              totalPages={totalPages}
              onPageChange={setCurrentPage}
              totalItems={filteredUsers.length}
              itemsPerPage={ITEMS_PER_PAGE}
            />
            </div>
          </>
        )}

        <Modal
          open={modalOpen}
          title={editingUser ? "Editar usuario" : "Nuevo usuario"}
          onClose={closeModal}
          footer={
            <>
              <Button variant="outline" onClick={closeModal}>
                Cancelar
              </Button>
              <Button
                variant="primary"
                loading={submitting}
                onClick={handleSubmit}
              >
                {editingUser ? "Guardar cambios" : "Crear"}
              </Button>
            </>
          }
        >
          <form onSubmit={handleSubmit} className="flex flex-col gap-4">
            <div>
              <Input
                label="Nombre completo"
                value={form.fullName}
                onChange={(e) =>
                  setForm({ ...form, fullName: e.target.value })
                }
                maxLength={80}
                required
              />
              <p className="mt-1 text-right text-xs text-gray-500 tabular-nums">
                {form.fullName.length}/80
              </p>
            </div>
            <Input
              label="Correo electrónico"
              type="email"
              inputMode="email"
              value={form.email}
              onChange={(e) => setForm({ ...form, email: e.target.value })}
              placeholder="usuario@millenium.cr"
              hint={
                editingUser
                  ? "El correo no se puede modificar."
                  : "El usuario recibirá un código en este correo cada vez que inicie sesión."
              }
              disabled={!!editingUser}
              required
            />
            <div>
              <span className="label">Rol</span>
              <div className="grid grid-cols-2 gap-2">
                {(["empleado", "admin"] as Role[]).map((r) => {
                  const active = form.role === r;
                  return (
                    <button
                      type="button"
                      key={r}
                      onClick={() => setForm({ ...form, role: r })}
                      className={
                        "rounded-lg border px-3.5 py-2.5 text-left text-base transition " +
                        (active
                          ? "border-2 border-millenium-blue bg-blue-50 font-medium text-millenium-blue"
                          : "border border-gray-200 bg-white text-gray-700 hover:border-millenium-blue/50")
                      }
                    >
                      <div className="font-medium">
                        {r === "admin" ? "Administrador" : "Empleado"}
                      </div>
                      <div className="text-sm text-gray-500">
                        {r === "admin"
                          ? "Gestiona salas, usuarios y todas las reuniones"
                          : "Agenda reuniones y gestiona las propias"}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          </form>
        </Modal>

        <Modal
          open={!!confirmingDeactivate}
          title={
            confirmingDeactivate
              ? `¿Desactivar a ${confirmingDeactivate.fullName}?`
              : undefined
          }
          onClose={() => setConfirmingDeactivate(null)}
          actions={
            <>
              <Button
                variant="outline"
                onClick={() => setConfirmingDeactivate(null)}
                disabled={togglingPower}
              >
                Cancelar
              </Button>
              <Button
                variant="danger"
                loading={togglingPower}
                onClick={confirmDeactivate}
              >
                Sí, desactivar
              </Button>
            </>
          }
        >
          <p className="text-base text-gray-700">
            Este usuario no podrá iniciar sesión más. Puede reactivarlo en
            cualquier momento.
          </p>
        </Modal>
      </>
    </ProtectedRoute>
  );
}
