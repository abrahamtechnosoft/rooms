"use client";

import { FormEvent, useCallback, useEffect, useState } from "react";
import { Edit2, Network, Plus, Power } from "lucide-react";
import { toast } from "@/lib/toastHelpers";
import ProtectedRoute from "@/components/ProtectedRoute";
import PageHeader from "@/components/layout/PageHeader";
import EmptyState from "@/components/EmptyState";
import TableSkeleton from "@/components/skeletons/TableSkeleton";
import Modal from "@/components/ui/Modal";
import Input from "@/components/ui/Input";
import Textarea from "@/components/ui/Textarea";
import Button from "@/components/ui/Button";
import api from "@/lib/api";
import type { Department, Reply } from "@/types";

const COLOR_OPTIONS = [
  "#2C3E50",
  "#27AE60",
  "#E67E22",
  "#8B5CF6",
  "#C0392B",
  "#475569",
  "#0EA5E9",
  "#EC4899",
];

const DEFAULT_COLOR = COLOR_OPTIONS[0];

const MAX_NAME = 60;
const MAX_DESCRIPTION = 200;

interface FormState {
  name: string;
  description: string;
  colorHex: string;
}

const emptyForm: FormState = {
  name: "",
  description: "",
  colorHex: DEFAULT_COLOR,
};

export default function DepartmentsAdminPage() {
  const [departments, setDepartments] = useState<Department[]>([]);
  const [loading, setLoading] = useState(false);
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Department | null>(null);
  const [form, setForm] = useState<FormState>(emptyForm);
  const [submitting, setSubmitting] = useState(false);
  const [togglingId, setTogglingId] = useState<number | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await api.get<Reply<Department[]>>("/departments", {
        params: { includeInactive: true },
      });
      setDepartments(res.data.obj || []);
    } catch {
      toast.error("No fue posible cargar los departamentos");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const openCreate = () => {
    setEditing(null);
    setForm(emptyForm);
    setModalOpen(true);
  };

  const openEdit = (d: Department) => {
    setEditing(d);
    setForm({
      name: d.name,
      description: d.description || "",
      colorHex: d.colorHex || DEFAULT_COLOR,
    });
    setModalOpen(true);
  };

  const toggleActive = async (d: Department) => {
    if (togglingId) return;
    setTogglingId(d.id);
    try {
      const res = await api.patch<Reply<unknown>>(`/departments/${d.id}`, {
        name: d.name,
        description: d.description,
        colorHex: d.colorHex,
        isActive: !d.isActive,
      });
      if (res.data.ok) {
        toast.success(
          d.isActive ? "Departamento desactivado" : "Departamento activado"
        );
        await load();
      } else {
        toast.error(res.data.msg || "No fue posible cambiar el estado");
      }
    } catch (e: unknown) {
      const errObj = e as { response?: { data?: { msg?: string } } };
      toast.error(
        errObj?.response?.data?.msg || "No fue posible cambiar el estado"
      );
    } finally {
      setTogglingId(null);
    }
  };

  const handleSubmit = async (e?: FormEvent) => {
    if (e) e.preventDefault();
    if (!form.name.trim()) {
      toast.error("Indique el nombre del departamento");
      return;
    }
    if (form.name.length > MAX_NAME) {
      toast.error(`El nombre no puede superar ${MAX_NAME} caracteres`);
      return;
    }
    setSubmitting(true);
    try {
      const body: Record<string, unknown> = {
        name: form.name.trim(),
        description: form.description.trim() || null,
        colorHex: form.colorHex || null,
      };

      const res = editing
        ? await api.patch<Reply<unknown>>(`/departments/${editing.id}`, {
            ...body,
            isActive: editing.isActive,
          })
        : await api.post<Reply<{ id: number }>>(`/departments`, body);

      if (!res.data.ok) {
        toast.error(res.data.msg || "No fue posible guardar");
        return;
      }
      toast.success(
        editing ? "Departamento actualizado" : "Departamento creado"
      );
      setModalOpen(false);
      await load();
    } catch (e: unknown) {
      const errObj = e as { response?: { data?: { msg?: string } } };
      toast.error(errObj?.response?.data?.msg || "No fue posible guardar");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <ProtectedRoute requireRole="admin">
      <div>
        <PageHeader
          title="Departamentos"
          description="Cree, edite o desactive los departamentos del equipo."
          actions={
            <Button variant="primary" onClick={openCreate}>
              <Plus className="h-4 w-4" />
              Nuevo departamento
            </Button>
          }
        />

        {loading && departments.length === 0 ? (
          <TableSkeleton rows={5} columns={4} />
        ) : !loading && departments.length === 0 ? (
          <div className="rounded-xl border border-dashed border-gray-300 bg-white">
            <EmptyState
              icon={Network}
              title="Sin departamentos registrados"
              description="Cree el primer departamento para organizar al equipo."
              action={
                <Button variant="primary" onClick={openCreate}>
                  <Plus className="h-4 w-4" />
                  Nuevo departamento
                </Button>
              }
            />
          </div>
        ) : (
          <>
            {/* Mobile: cards */}
            <ul className="space-y-2 md:hidden">
              {departments.map((d) => {
                const color = d.colorHex || "#475569";
                return (
                  <li
                    key={d.id}
                    className="rounded-lg border border-gray-200 bg-white p-3 shadow-sm"
                  >
                    <div className="flex items-start gap-3">
                      <span
                        className="flex h-10 w-10 shrink-0 items-center justify-center rounded-md"
                        style={{ backgroundColor: `${color}26` }}
                        aria-hidden="true"
                      >
                        <Network className="h-5 w-5" style={{ color }} />
                      </span>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-start justify-between gap-2">
                          <div className="min-w-0 flex-1">
                            <div className="text-sm font-semibold text-gray-900 wrap-break-word">
                              {d.name}
                            </div>
                            <div className="mt-0.5 text-xs text-gray-500">
                              {typeof d.memberCount === "number"
                                ? `${d.memberCount} ${d.memberCount === 1 ? "miembro" : "miembros"}`
                                : "Sin datos de miembros"}
                            </div>
                          </div>
                          <span
                            className={
                              "shrink-0 rounded-full px-2 py-0.5 text-[10px] font-medium " +
                              (d.isActive
                                ? "bg-emerald-50 text-emerald-700"
                                : "bg-gray-100 text-gray-600")
                            }
                          >
                            {d.isActive ? "Activo" : "Inactivo"}
                          </span>
                        </div>
                        {d.description && (
                          <p className="mt-2 line-clamp-2 text-xs text-gray-600 wrap-break-word">
                            {d.description}
                          </p>
                        )}
                        <div className="mt-3 flex gap-2 border-t border-gray-100 pt-2">
                          <button
                            type="button"
                            onClick={() => openEdit(d)}
                            className="inline-flex flex-1 items-center justify-center gap-1 rounded-md border border-gray-200 bg-white px-3 py-1.5 text-xs font-medium text-gray-700 hover:bg-gray-50"
                            aria-label={`Editar departamento: ${d.name}`}
                          >
                            <Edit2 className="h-3 w-3" aria-hidden="true" />
                            Editar
                          </button>
                          <button
                            type="button"
                            onClick={() => toggleActive(d)}
                            disabled={togglingId === d.id}
                            className={
                              "inline-flex flex-1 items-center justify-center gap-1 rounded-md border px-3 py-1.5 text-xs font-medium disabled:opacity-50 " +
                              (d.isActive
                                ? "border-red-200 bg-white text-millenium-red hover:bg-red-50"
                                : "border-emerald-200 bg-white text-millenium-green hover:bg-emerald-50")
                            }
                            aria-label={
                              d.isActive
                                ? `Desactivar departamento: ${d.name}`
                                : `Activar departamento: ${d.name}`
                            }
                          >
                            <Power className="h-3 w-3" aria-hidden="true" />
                            {d.isActive ? "Desactivar" : "Activar"}
                          </button>
                        </div>
                      </div>
                    </div>
                  </li>
                );
              })}
            </ul>

            {/* Desktop: tabla */}
            <div className="hidden overflow-x-auto rounded-xl border border-gray-200 bg-white shadow-sm md:block">
            <table className="min-w-full text-base">
              <thead className="bg-gray-50 text-left text-gray-500">
                <tr>
                  <th scope="col" className="px-4 py-3 text-sm font-semibold uppercase tracking-wide">
                    Departamento
                  </th>
                  <th scope="col" className="px-4 py-3 text-sm font-semibold uppercase tracking-wide">
                    Descripción
                  </th>
                  <th scope="col" className="px-4 py-3 text-sm font-semibold uppercase tracking-wide">
                    Miembros
                  </th>
                  <th scope="col" className="px-4 py-3 text-sm font-semibold uppercase tracking-wide">
                    Estado
                  </th>
                  <th scope="col" className="px-4 py-3"><span className="sr-only">Acciones</span></th>
                </tr>
              </thead>
              <tbody>
                {departments.map((d) => {
                  const color = d.colorHex || "#475569";
                  return (
                    <tr
                      key={d.id}
                      className="h-14 border-t border-gray-100 transition hover:bg-gray-50"
                    >
                      <td className="px-4 py-3">
                        <div className="flex min-w-0 items-center gap-2">
                          <span
                            className="inline-block h-3 w-3 shrink-0 rounded-full"
                            style={{ backgroundColor: color }}
                          />
                          <span
                            className="truncate font-medium text-gray-900"
                            title={d.name}
                          >
                            {d.name}
                          </span>
                        </div>
                      </td>
                      <td className="max-w-md px-4 py-3 text-sm text-gray-600">
                        <p
                          className="line-clamp-2"
                          title={d.description || ""}
                        >
                          {d.description || "—"}
                        </p>
                      </td>
                      <td className="px-4 py-3 text-gray-700">
                        {typeof d.memberCount === "number"
                          ? d.memberCount
                          : "—"}
                      </td>
                      <td className="px-4 py-3">
                        <span
                          className={
                            "rounded-full px-2.5 py-1 text-xs font-semibold " +
                            (d.isActive
                              ? "bg-green-100 text-millenium-green"
                              : "bg-gray-100 text-gray-500")
                          }
                        >
                          {d.isActive ? "Activo" : "Inactivo"}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-right">
                        <div className="flex justify-end gap-1">
                          <button
                            type="button"
                            onClick={() => openEdit(d)}
                            className="flex h-11 w-11 items-center justify-center rounded-md text-gray-500 transition hover:bg-gray-100 hover:text-millenium-blue focus:outline-none focus:ring-2 focus:ring-millenium-blue focus:ring-offset-1"
                            aria-label={`Editar departamento: ${d.name}`}
                          >
                            <Edit2 className="h-5 w-5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => toggleActive(d)}
                            disabled={togglingId === d.id}
                            className={
                              "flex h-11 w-11 items-center justify-center rounded-md transition focus:outline-none focus:ring-2 focus:ring-millenium-blue focus:ring-offset-1 " +
                              (d.isActive
                                ? "text-gray-500 hover:bg-red-50 hover:text-millenium-red"
                                : "text-gray-500 hover:bg-green-50 hover:text-millenium-green")
                            }
                            aria-label={
                              d.isActive
                                ? `Desactivar departamento: ${d.name}`
                                : `Activar departamento: ${d.name}`
                            }
                          >
                            <Power className="h-5 w-5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
            </div>
          </>
        )}

        <Modal
          open={modalOpen}
          title={editing ? "Editar departamento" : "Nuevo departamento"}
          size="lg"
          onClose={() => setModalOpen(false)}
          footer={
            <>
              <Button
                variant="outline"
                onClick={() => setModalOpen(false)}
                disabled={submitting}
              >
                Cancelar
              </Button>
              <Button
                variant="primary"
                loading={submitting}
                onClick={() => handleSubmit()}
              >
                Guardar
              </Button>
            </>
          }
        >
          <form onSubmit={handleSubmit} className="flex flex-col gap-5">
            <div>
              <Input
                label="Nombre"
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                maxLength={MAX_NAME}
                required
              />
              <p className="mt-1 text-right text-xs text-gray-500 tabular-nums">
                {form.name.length}/{MAX_NAME}
              </p>
            </div>

            <div>
              <Textarea
                label="Descripción (opcional)"
                rows={3}
                maxLength={MAX_DESCRIPTION}
                value={form.description}
                onChange={(e) =>
                  setForm({ ...form, description: e.target.value })
                }
              />
              <p className="mt-1 text-right text-xs text-gray-500 tabular-nums">
                {form.description.length}/{MAX_DESCRIPTION}
              </p>
            </div>

            <div>
              <label className="label">Color identificador</label>
              <div className="flex flex-wrap gap-2">
                {COLOR_OPTIONS.map((c) => {
                  const active = form.colorHex === c;
                  return (
                    <button
                      key={c}
                      type="button"
                      onClick={() => setForm({ ...form, colorHex: c })}
                      aria-pressed={active}
                      aria-label={`Elegir color ${c}`}
                      className={
                        "h-9 w-9 rounded-full transition focus:outline-none focus:ring-2 focus:ring-offset-2 " +
                        (active
                          ? "ring-2 ring-millenium-blue ring-offset-2"
                          : "")
                      }
                      style={{ backgroundColor: c }}
                    />
                  );
                })}
              </div>
            </div>
          </form>
        </Modal>
      </div>
    </ProtectedRoute>
  );
}
