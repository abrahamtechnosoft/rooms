"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import {
  AlertCircle,
  Building2,
  ClipboardList,
  FileX,
  UserX,
} from "lucide-react";
import { toast } from "@/lib/toastHelpers";
import api from "@/lib/api";
import type { Reply } from "@/types";
import ProtectedRoute from "@/components/ProtectedRoute";
import PageHeader from "@/components/layout/PageHeader";
import Section from "@/components/layout/Section";
import Avatar from "@/components/Avatar";
import EmptyState from "@/components/EmptyState";
import TableSkeleton from "@/components/skeletons/TableSkeleton";
import Pagination from "@/components/ui/Pagination";

type Tab = "events" | "summary";

const ITEMS_PER_PAGE = 10;

interface ReportEvent {
  eventType: "reservation_cancelled" | "participation_cancelled";
  reservationId: number;
  reservationTitle: string;
  eventAt: string;
  reason: string | null;
  actorId: number | null;
  actorName: string | null;
  actorEmail: string | null;
  actorAvatarUrl: string | null;
  inProgress: boolean;
}

interface TopUser {
  userId: number;
  fullName: string | null;
  email: string;
  avatarUrl: string | null;
  cancellations: number;
}

interface TopRoom {
  roomId: number;
  roomName: string;
  totalMeetings: number;
  cancelled: number;
}

interface Summary {
  range: { from: string; to: string };
  cancellations: {
    totalReservationCancellations: number;
    cancellationsInProgress: number;
  };
  participations: {
    totalParticipationCancellations: number;
  };
  topUsers: TopUser[];
  topRooms: TopRoom[];
}

function toYmd(d: Date): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

// Defaults: ultimos 30 dias.
function defaultRange(): { from: string; to: string } {
  const to = new Date();
  const from = new Date(to.getTime() - 30 * 24 * 60 * 60 * 1000);
  return { from: toYmd(from), to: toYmd(to) };
}

function formatRelativeTime(iso: string): string {
  const date = new Date(iso);
  const diffMs = Date.now() - date.getTime();
  const diffMin = Math.floor(diffMs / 60000);
  const diffHr = Math.floor(diffMin / 60);
  const diffDay = Math.floor(diffHr / 24);
  if (diffMin < 1) return "Hace un momento";
  if (diffMin < 60)
    return `Hace ${diffMin} ${diffMin === 1 ? "minuto" : "minutos"}`;
  if (diffHr < 24) return `Hace ${diffHr} ${diffHr === 1 ? "hora" : "horas"}`;
  if (diffDay < 7) return `Hace ${diffDay} ${diffDay === 1 ? "día" : "días"}`;
  return date.toLocaleDateString("es", {
    day: "numeric",
    month: "short",
    year: "numeric",
  });
}

function rangeToParams(range: { from: string; to: string }) {
  // Convertimos YYYY-MM-DD local → desde 00:00 hasta 23:59:59 del dia.
  const fromIso = new Date(`${range.from}T00:00:00`).toISOString();
  const toIso = new Date(`${range.to}T23:59:59`).toISOString();
  return { from: fromIso, to: toIso };
}

export default function RegistrosPage() {
  return (
    <ProtectedRoute requireRole="admin">
      <RegistrosInner />
    </ProtectedRoute>
  );
}

function RegistrosInner() {
  const [activeTab, setActiveTab] = useState<Tab>("events");
  const [range, setRange] = useState<{ from: string; to: string }>(
    defaultRange
  );

  return (
    <div>
      <PageHeader
        title="Registros"
        description="Historial de cancelaciones y métricas del sistema."
      />

      <div className="mb-4 flex flex-wrap items-center gap-2">
        <label className="flex items-center gap-2 text-sm text-gray-600">
          Desde
          <input
            type="date"
            value={range.from}
            onChange={(e) =>
              setRange((r) => ({ ...r, from: e.target.value }))
            }
            max={range.to}
            className="rounded-lg border border-gray-300 px-3 py-2 text-sm tabular-nums focus:border-millenium-blue focus:outline-none focus:ring-2 focus:ring-millenium-blue/20"
          />
        </label>
        <label className="flex items-center gap-2 text-sm text-gray-600">
          Hasta
          <input
            type="date"
            value={range.to}
            onChange={(e) =>
              setRange((r) => ({ ...r, to: e.target.value }))
            }
            min={range.from}
            className="rounded-lg border border-gray-300 px-3 py-2 text-sm tabular-nums focus:border-millenium-blue focus:outline-none focus:ring-2 focus:ring-millenium-blue/20"
          />
        </label>
      </div>

      <div
        role="tablist"
        aria-label="Vistas de registros"
        className="mb-4 flex gap-1 border-b border-gray-200"
      >
        <TabBtn
          active={activeTab === "events"}
          onClick={() => setActiveTab("events")}
        >
          Eventos
        </TabBtn>
        <TabBtn
          active={activeTab === "summary"}
          onClick={() => setActiveTab("summary")}
        >
          Resumen
        </TabBtn>
      </div>

      {activeTab === "events" ? (
        <EventsTab range={range} />
      ) : (
        <SummaryTab range={range} />
      )}
    </div>
  );
}

function TabBtn({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      role="tab"
      aria-selected={active}
      onClick={onClick}
      className={
        "relative px-3.5 py-2.5 text-base transition focus:outline-none focus:ring-2 focus:ring-millenium-blue focus:ring-offset-1 " +
        (active
          ? "font-semibold text-millenium-blue"
          : "font-medium text-gray-500 hover:text-gray-700")
      }
    >
      {children}
      {active && (
        <span className="absolute -bottom-px left-0 right-0 h-0.5 rounded-full bg-millenium-blue" />
      )}
    </button>
  );
}

function EventsTab({ range }: { range: { from: string; to: string } }) {
  const [events, setEvents] = useState<ReportEvent[]>([]);
  const [loading, setLoading] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const params = rangeToParams(range);
      const res = await api.get<Reply<ReportEvent[]>>(
        "/admin/reports/events",
        { params }
      );
      setEvents(res.data.obj || []);
    } catch {
      toast.error("No fue posible cargar los eventos");
    } finally {
      setLoading(false);
    }
  }, [range]);

  useEffect(() => {
    load();
  }, [load]);

  // Reset a página 1 cuando cambia el rango o llegan nuevos eventos.
  useEffect(() => {
    setCurrentPage(1);
  }, [range]);

  const totalPages = Math.max(1, Math.ceil(events.length / ITEMS_PER_PAGE));
  const safePage = Math.min(currentPage, totalPages);
  const paginated = events.slice(
    (safePage - 1) * ITEMS_PER_PAGE,
    safePage * ITEMS_PER_PAGE
  );

  if (loading) {
    return <TableSkeleton rows={10} columns={4} />;
  }

  if (events.length === 0) {
    return (
      <div className="rounded-xl border border-dashed border-gray-300 bg-white">
        <EmptyState
          icon={ClipboardList}
          title="Sin eventos"
          description="No hubo cancelaciones en el rango seleccionado."
        />
      </div>
    );
  }

  return (
    <>
      <ul className="space-y-2">
        {paginated.map((ev) => {
          const actorName = ev.actorName || ev.actorEmail || "Usuario";
          const isMeetingCancel = ev.eventType === "reservation_cancelled";
          const EventIcon = isMeetingCancel ? FileX : UserX;
          return (
            <li
              key={`${ev.eventType}-${ev.reservationId}-${ev.eventAt}`}
              className="rounded-lg border border-gray-200 bg-white p-3"
            >
            <div className="flex items-start gap-3">
              <Avatar
                name={ev.actorName}
                email={ev.actorEmail}
                avatarUrl={ev.actorAvatarUrl}
                size="sm"
              />
              <div className="min-w-0 flex-1">
                <p className="text-sm text-gray-800">
                  <span className="font-medium">{actorName}</span>
                  {isMeetingCancel ? (
                    <> canceló la reunión </>
                  ) : (
                    <> canceló su participación en </>
                  )}
                  <span className="font-medium">
                    &ldquo;{ev.reservationTitle}&rdquo;
                  </span>
                  {ev.inProgress && (
                    <span className="ml-2 inline-flex items-center gap-1 rounded-full bg-red-100 px-2 py-0.5 text-xs font-medium text-red-700">
                      <AlertCircle className="h-3 w-3" />
                      En curso
                    </span>
                  )}
                </p>
                {ev.reason && (
                  <p className="mt-1 text-sm italic text-gray-600">
                    &ldquo;{ev.reason}&rdquo;
                  </p>
                )}
                <p className="mt-1 text-xs text-gray-400">
                  {formatRelativeTime(ev.eventAt)}
                  {" · "}
                  {new Date(ev.eventAt).toLocaleString("es")}
                </p>
              </div>
              <EventIcon
                className={
                  "h-5 w-5 shrink-0 " +
                  (isMeetingCancel
                    ? "text-millenium-red"
                    : "text-orange-500")
                }
              />
            </div>
          </li>
        );
      })}
      </ul>
      <Pagination
        currentPage={safePage}
        totalPages={totalPages}
        onPageChange={setCurrentPage}
        totalItems={events.length}
        itemsPerPage={ITEMS_PER_PAGE}
      />
    </>
  );
}

function SummaryTab({ range }: { range: { from: string; to: string } }) {
  const [summary, setSummary] = useState<Summary | null>(null);
  const [loading, setLoading] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const params = rangeToParams(range);
      const res = await api.get<Reply<Summary>>(
        "/admin/reports/summary",
        { params }
      );
      setSummary(res.data.obj || null);
    } catch {
      toast.error("No fue posible cargar el resumen");
    } finally {
      setLoading(false);
    }
  }, [range]);

  useEffect(() => {
    load();
  }, [load]);

  const totalRoomMeetings = useMemo(
    () =>
      (summary?.topRooms || []).reduce((sum, r) => sum + r.totalMeetings, 0),
    [summary]
  );

  if (loading || !summary) {
    return (
      <div className="space-y-4">
        <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
          {[0, 1, 2].map((i) => (
            <div
              key={i}
              className="h-24 animate-pulse rounded-lg border border-gray-200 bg-white"
            />
          ))}
        </div>
        <div className="h-40 animate-pulse rounded-xl border border-gray-200 bg-white" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
        <StatCard
          icon={<FileX className="h-6 w-6 text-millenium-red" />}
          label="Reuniones canceladas"
          value={summary.cancellations.totalReservationCancellations}
          sublabel={
            summary.cancellations.cancellationsInProgress > 0
              ? `${summary.cancellations.cancellationsInProgress} en curso`
              : "Ninguna en curso"
          }
        />
        <StatCard
          icon={<UserX className="h-6 w-6 text-orange-500" />}
          label="Participaciones canceladas"
          value={summary.participations.totalParticipationCancellations}
        />
        <StatCard
          icon={<ClipboardList className="h-6 w-6 text-gray-600" />}
          label="Total de reuniones"
          value={totalRoomMeetings}
          sublabel={`En ${summary.topRooms.length} ${summary.topRooms.length === 1 ? "sala" : "salas"}`}
        />
      </div>

      <Section label="Usuarios con más cancelaciones de participación">
        {summary.topUsers.length === 0 ? (
          <p className="text-sm text-gray-500">
            Sin cancelaciones en el rango seleccionado.
          </p>
        ) : (
          <ul className="space-y-2">
            {summary.topUsers.map((u) => (
              <li
                key={u.userId}
                className="flex items-center gap-3 rounded border border-gray-200 bg-white p-2"
              >
                <Avatar
                  name={u.fullName}
                  email={u.email}
                  avatarUrl={u.avatarUrl}
                  size="sm"
                />
                <div className="min-w-0 flex-1">
                  <p
                    className="truncate text-sm font-medium text-gray-900"
                    title={u.fullName || u.email}
                  >
                    {u.fullName || u.email}
                  </p>
                  {u.fullName && (
                    <p
                      className="truncate text-xs text-gray-500"
                      title={u.email}
                    >
                      {u.email}
                    </p>
                  )}
                </div>
                <span className="text-sm font-semibold tabular-nums text-gray-900">
                  {u.cancellations}
                </span>
              </li>
            ))}
          </ul>
        )}
      </Section>

      <Section label="Uso por sala">
        {summary.topRooms.length === 0 ? (
          <p className="text-sm text-gray-500">
            Sin reuniones en el rango seleccionado.
          </p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-xs uppercase tracking-wide text-gray-500">
                  <th scope="col" className="py-2 font-medium">Sala</th>
                  <th scope="col" className="py-2 text-right font-medium">Reuniones</th>
                  <th scope="col" className="py-2 text-right font-medium">Canceladas</th>
                </tr>
              </thead>
              <tbody>
                {summary.topRooms.map((r) => (
                  <tr key={r.roomId} className="border-t border-gray-100">
                    <td className="py-2.5">
                      <span className="inline-flex items-center gap-2">
                        <Building2 className="h-4 w-4 text-gray-500" />
                        {r.roomName}
                      </span>
                    </td>
                    <td className="py-2.5 text-right tabular-nums">
                      {r.totalMeetings}
                    </td>
                    <td className="py-2.5 text-right tabular-nums text-millenium-red">
                      {r.cancelled}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Section>
    </div>
  );
}

function StatCard({
  icon,
  label,
  value,
  sublabel,
}: {
  icon: React.ReactNode;
  label: string;
  value: number;
  sublabel?: string;
}) {
  return (
    <div className="rounded-lg border border-gray-200 bg-white p-4 shadow-sm">
      <div className="mb-2 flex items-center gap-2">{icon}</div>
      <p className="text-3xl font-bold tabular-nums text-gray-900">{value}</p>
      <p className="text-sm text-gray-500">{label}</p>
      {sublabel && (
        <p className="mt-1 text-xs text-gray-400">{sublabel}</p>
      )}
    </div>
  );
}
