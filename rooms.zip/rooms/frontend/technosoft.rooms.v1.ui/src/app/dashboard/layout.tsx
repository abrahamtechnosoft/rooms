"use client";

import { ReactNode, useEffect, useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Plus } from "lucide-react";
import ProtectedRoute from "@/components/ProtectedRoute";
import Navbar from "@/components/Navbar";
import Sidebar from "@/components/layout/Sidebar";
import MobileSidebar from "@/components/MobileSidebar";
import FirstTimeDepartmentModal from "@/components/FirstTimeDepartmentModal";
import AvatarPromptModal from "@/components/AvatarPromptModal";
import { useAuthStore } from "@/store/authStore";
import { useNotificationDispatcher } from "@/hooks/useNotificationDispatcher";

export default function DashboardLayout({ children }: { children: ReactNode }) {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [showDeptModal, setShowDeptModal] = useState(false);
  const [showAvatarPrompt, setShowAvatarPrompt] = useState(false);
  const pathname = usePathname();
  const hideFab = pathname === "/dashboard/reservations/new";
  const user = useAuthStore((s) => s.user);
  const hydrated = useAuthStore((s) => s.hydrated);
  const refreshMe = useAuthStore((s) => s.refreshMe);

  // Dispatcher de notificaciones del navegador (reuniones + recordatorios).
  // Activo en todas las páginas del dashboard.
  useNotificationDispatcher();

  // Al primer render con usuario autenticado, traemos el perfil completo para
  // que `departmentId` esté presente (no viene en el login response).
  useEffect(() => {
    if (hydrated && user) {
      refreshMe();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [hydrated]);

  // Onboarding paso 1 — modal obligatorio si falta departamento.
  // Onboarding paso 2 — modal sugerido si falta foto y aún no se le ha
  // preguntado. Solo aparece cuando ya hay departamento (no chocan).
  useEffect(() => {
    if (!user) {
      setShowDeptModal(false);
      setShowAvatarPrompt(false);
      return;
    }
    const needsDept =
      user.departmentId === null || user.departmentId === undefined;
    setShowDeptModal(needsDept);
    if (needsDept) {
      setShowAvatarPrompt(false);
      return;
    }
    setShowAvatarPrompt(!user.avatarUrl && !user.avatarPromptSeen);
  }, [user?.departmentId, user?.avatarUrl, user?.avatarPromptSeen, user]);

  return (
    <ProtectedRoute>
      <div className="flex h-screen flex-col">
        <Navbar onOpenMobileMenu={() => setMobileOpen(true)} />
        <MobileSidebar open={mobileOpen} onClose={() => setMobileOpen(false)} />
        <div className="flex flex-1 overflow-hidden">
          <Sidebar />
          <main className="flex flex-1 flex-col overflow-y-auto">
            <div className="mx-auto flex w-full max-w-400 flex-1 flex-col p-6 pb-16 md:p-8 md:pb-12">
              {children}
            </div>
          </main>
        </div>
        {!hideFab && (
          <Link
            href="/dashboard/reservations/new"
            className="fixed bottom-6 right-6 z-40 flex h-14 w-14 items-center justify-center rounded-full bg-millenium-blue text-white shadow-lg transition hover:bg-[#1f2c3a] md:hidden"
            aria-label="Nueva reunión"
          >
            <Plus className="h-6 w-6" />
          </Link>
        )}
        {showDeptModal && (
          <FirstTimeDepartmentModal
            onSelected={() => setShowDeptModal(false)}
          />
        )}
        {!showDeptModal && showAvatarPrompt && (
          <AvatarPromptModal
            onSkip={() => setShowAvatarPrompt(false)}
            onUploaded={() => setShowAvatarPrompt(false)}
          />
        )}
      </div>
    </ProtectedRoute>
  );
}
