"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  AlertCircle,
  Calendar,
  ChevronLeft,
  ChevronRight,
  Clock,
  Plus,
} from "lucide-react";
import { toast } from "@/lib/toastHelpers";
import { addDays, format } from "date-fns";
import { es } from "date-fns/locale";
import api from "@/lib/api";
import { useBackendPolling } from "@/hooks/useBackendPolling";
import { useLocalStorageBoolean } from "@/hooks/useLocalStorageBoolean";
import { useReservationFilters } from "@/hooks/useReservationFilters";
import { applyReservationFilters } from "@/lib/applyReservationFilters";
import type { Department, Reply, Reservation, Room } from "@/types";
import WeekTimeline from "@/components/WeekTimeline";
import MyDayPanel from "@/components/MyDayPanel";
import DashboardLayout from "@/components/dashboard/DashboardLayout";
import ReservationDetailModal from "@/components/ReservationDetailModal";
import FilterChips from "@/components/FilterChips";
import MoreFiltersButton from "@/components/MoreFiltersButton";
import Button from "@/components/ui/Button";
import DashboardSkeleton from "@/components/skeletons/DashboardSkeleton";
import {
  endOfDayIso,
  fmtLong,
  parseYmd,
  startOfDayIso,
  today,
} from "@/lib/dates";
import { useAuthStore } from "@/store/authStore";

type View = "day" | "week";

const capitalizeFirst = (s: string) =>
  s.length === 0 ? s : s[0].toUpperCase() + s.slice(1);

const toIsoYmd = (d: Date): string => {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
};

const shift = (ymd: string, days: number): string =>
  toIsoYmd(addDays(parseYmd(ymd), days));

const hhmm = (h: number, m: number) =>
  `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}`;

function startOfWeek(date: Date): Date {
  const d = new Date(date);
  const day = d.getDay();
  // Lunes = 1, Domingo = 0. Si es domingo retrocedemos 6, sino (1 - day).
  const diff = day === 0 ? -6 : 1 - day;
  d.setDate(d.getDate() + diff);
  d.setHours(0, 0, 0, 0);
  return d;
}

function endOfWeek(date: Date): Date {
  const start = startOfWeek(date);
  const end = new Date(start);
  end.setDate(end.getDate() + 6);
  return end;
}

const fmtWeekRange = (start: Date, end: Date): string => {
  const startMonth = format(start, "MMM", { locale: es });
  const endMonth = format(end, "MMM", { locale: es });
  const sameMonth = startMonth === endMonth;
  if (sameMonth) {
    return `${start.getDate()} – ${end.getDate()} ${capitalizeFirst(endMonth)}`;
  }
  return `${start.getDate()} ${capitalizeFirst(startMonth)} – ${end.getDate()} ${capitalizeFirst(endMonth)}`;
};

export default function DashboardHomePage() {
  const router = useRouter();
  const { user } = useAuthStore();
  const [date, setDate] = useState<string>(today());
  const [view, setView] = useState<View>("day"); // default mobile-safe; ajustado en mount
  const [rooms, setRooms] = useState<Room[]>([]);
  const [reservations, setReservations] = useState<Reservation[]>([]);
  const [virtualMeetings, setVirtualMeetings] = useState<Reservation[]>([]);
  const [externalMeetings, setExternalMeetings] = useState<Reservation[]>([]);
  const [weekReservations, setWeekReservations] = useState<Reservation[]>([]);
  const [loading, setLoading] = useState(false);
  const [hasLoadedOnce, setHasLoadedOnce] = useState(false);
  const [detail, setDetail] = useState<Reservation | null>(null);
  const pollFailRef = useRef(0);
  const [pendingCount, setPendingCount] = useState(0);
  const [myRequestsCount, setMyRequestsCount] = useState(0);
  const [showWeekends, setShowWeekends] = useLocalStorageBoolean(
    "rooms.week.showWeekends",
    false
  );
  const [departments, setDepartments] = useState<Department[]>([]);
  const { filters, setFilters } = useReservationFilters();

  // Cargar departamentos una sola vez para el panel de filtros.
  useEffect(() => {
    let cancelled = false;
    api
      .get<Reply<Department[]>>("/departments")
      .then((res) => {
        if (cancelled) return;
        setDepartments(res.data.obj || []);
      })
      .catch(() => {
        // silencioso — el panel mostrara "Sin departamentos cargados".
      });
    return () => {
      cancelled = true;
    };
  }, []);

  // G2 — Banner de confirmación de uso. Polleamos cada minuto para detectar
  // nuevas solicitudes generadas por el cron del backend.
  useEffect(() => {
    let cancelled = false;
    const fetchPending = async () => {
      try {
        const res = await api.get<Reply<unknown[]>>(
          "/reservations/pending-confirmation"
        );
        if (cancelled) return;
        setPendingCount((res.data.obj || []).length);
      } catch {
        // silencioso — no es crítico
      }
    };
    fetchPending();
    const id = setInterval(fetchPending, 60_000);
    return () => {
      cancelled = true;
      clearInterval(id);
    };
  }, []);

  // Banner de solicitudes pendientes por bloqueo personal.
  useEffect(() => {
    let cancelled = false;
    const fetchMyRequests = async () => {
      try {
        const res = await api.get<Reply<unknown[]>>(
          "/reservations/my-requests"
        );
        if (cancelled) return;
        setMyRequestsCount((res.data.obj || []).length);
      } catch {
        // silencioso
      }
    };
    fetchMyRequests();
    const id = setInterval(fetchMyRequests, 60_000);
    return () => {
      cancelled = true;
      clearInterval(id);
    };
  }, []);

  // Default por viewport: semanal en desktop (>=768px), diaria en mobile.
  useEffect(() => {
    if (typeof window === "undefined") return;
    if (window.innerWidth >= 768) setView("week");
  }, []);

  // Si el usuario reduce el viewport a mobile mientras está en semanal, forzar diaria.
  useEffect(() => {
    function handleResize() {
      if (window.innerWidth < 768 && view === "week") setView("day");
    }
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, [view]);

  const weekStart = useMemo(() => startOfWeek(parseYmd(date)), [date]);
  const weekEnd = useMemo(() => endOfWeek(parseYmd(date)), [date]);
  const weekStartYmd = useMemo(() => toIsoYmd(weekStart), [weekStart]);

  const load = useCallback(
    async (opts: { silent?: boolean } = {}) => {
      if (!opts.silent) setLoading(true);
      try {
        if (view === "week") {
          const [roomsRes, weekRes] = await Promise.all([
            api.get<Reply<Room[]>>("/rooms"),
            api.get<Reply<Reservation[]>>("/reservations/week", {
              params: { from: weekStartYmd },
            }),
          ]);
          setRooms(roomsRes.data.obj || []);
          setWeekReservations(weekRes.data.obj || []);
        } else {
          const [roomsRes, resvRes, virtualRes, externalRes] = await Promise.all([
            api.get<Reply<Room[]>>("/rooms"),
            api.get<Reply<Reservation[]>>("/reservations", {
              params: { from: startOfDayIso(date), to: endOfDayIso(date) },
            }),
            api.get<Reply<Reservation[]>>("/reservations/virtual", {
              params: { date },
            }),
            api.get<Reply<Reservation[]>>("/reservations/external", {
              params: { date },
            }),
          ]);
          setRooms(roomsRes.data.obj || []);
          setReservations(resvRes.data.obj || []);
          setVirtualMeetings(virtualRes.data.obj || []);
          setExternalMeetings(externalRes.data.obj || []);
        }
      } catch (e) {
        if (!opts.silent) {
          toast.error("No fue posible cargar la disponibilidad");
        }
        throw e;
      } finally {
        if (!opts.silent) setLoading(false);
        setHasLoadedOnce(true);
      }
    },
    [date, view, weekStartYmd]
  );

  useEffect(() => {
    load().catch(() => {});
  }, [load]);

  // Polling 30s mientras la pestaña esté visible. Pausa en background.
  const pollingLoad = useCallback(async () => {
    try {
      await load({ silent: true });
      pollFailRef.current = 0;
    } catch {
      pollFailRef.current += 1;
      if (pollFailRef.current === 3) {
        toast.warning(
          "Problemas de conexión. Algunos datos pueden estar desactualizados."
        );
      }
    }
  }, [load]);
  useBackendPolling(pollingLoad, 30_000, [date, view, weekStartYmd]);

  const isToday = date === today();
  // YMD strings con zero-padding ordenan lexicograficamente como fechas reales.
  const isPastDate = useMemo(() => view === "day" && date < today(), [date, view]);
  const dateLabel = fmtLong(parseYmd(date));

  const todayYmd = today();
  const todayDate = useMemo(() => parseYmd(todayYmd), [todayYmd]);
  const weekStartIsCurrent = useMemo(() => {
    const wsToday = startOfWeek(todayDate);
    return toIsoYmd(wsToday) === weekStartYmd;
  }, [todayDate, weekStartYmd]);
  const weekIsPast = useMemo(() => {
    return weekEnd.getTime() < todayDate.getTime();
  }, [weekEnd, todayDate]);

  const goNew = useCallback(
    (params?: {
      roomId?: number;
      virtual?: boolean;
      date?: string;
      start?: string;
    }) => {
      const qs = new URLSearchParams();
      if (params?.roomId) qs.set("roomId", String(params.roomId));
      if (params?.virtual) qs.set("virtual", "true");
      if (params?.date) qs.set("date", params.date);
      if (params?.start) qs.set("start", params.start);
      const url =
        "/dashboard/reservations/new" + (qs.toString() ? "?" + qs : "");
      router.push(url);
    },
    [router]
  );

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (detail) return;
      const target = e.target as HTMLElement | null;
      if (target) {
        const tag = target.tagName;
        if (
          tag === "INPUT" ||
          tag === "TEXTAREA" ||
          tag === "SELECT" ||
          target.isContentEditable
        ) {
          return;
        }
      }
      const step = view === "week" ? 7 : 1;
      if (e.key === "ArrowLeft") setDate((d) => shift(d, -step));
      else if (e.key === "ArrowRight") setDate((d) => shift(d, step));
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [detail, view]);

  // El modal hace la llamada HTTP con el motivo y nos avisa con onCancel.
  const cancelDetail = async () => {
    setDetail(null);
    await load();
  };

  const canCancelDetail =
    !!detail &&
    !!user &&
    (detail.createdBy === user.id || user.role === "admin");

  const goPrev = () => setDate((d) => shift(d, view === "week" ? -7 : -1));
  const goNext = () => setDate((d) => shift(d, view === "week" ? 7 : 1));
  const goToday = () => setDate(today());

  const physicalRooms = useMemo(
    () => rooms.filter((r) => r.isActive),
    [rooms]
  );

  // Listado unificado del dia (fisicas + virtuales + externas) para vista
  // diaria. Aqui combinamos las 3 fuentes (cargadas por separado en el
  // endpoint) antes de aplicar filtros.
  const allDayMeetings = useMemo(
    () => [...reservations, ...virtualMeetings, ...externalMeetings],
    [reservations, virtualMeetings, externalMeetings]
  );

  // Aplicar filtros del dashboard a ambas vistas.
  const filteredWeekReservations = useMemo(
    () => applyReservationFilters(weekReservations, filters),
    [weekReservations, filters]
  );
  const filteredDayMeetings = useMemo(
    () => applyReservationFilters(allDayMeetings, filters),
    [allDayMeetings, filters]
  );

  const rangeLabel =
    view === "week" ? fmtWeekRange(weekStart, weekEnd) : dateLabel;

  return (
    <div className="flex h-full flex-col">
      {/* Panel resumen "Mi día de hoy" — siempre visible en dashboard */}
      <MyDayPanel />

      {/* G2 — Banner de confirmación de uso pendiente */}
      {pendingCount > 0 && (
        <Link
          href="/dashboard/pending-confirmation"
          className="mb-4 flex shrink-0 items-center gap-2 rounded-lg border border-amber-200 bg-amber-50 px-3 py-3 transition hover:bg-amber-100"
        >
          <AlertCircle className="h-5 w-5 shrink-0 text-amber-600" />
          <span className="flex-1 text-sm text-amber-900">
            Tienes{" "}
            <strong>
              {pendingCount}{" "}
              {pendingCount === 1
                ? "reunión pendiente"
                : "reuniones pendientes"}
            </strong>{" "}
            de confirmar.
          </span>
          <span className="text-xs font-medium text-amber-700">
            Revisar →
          </span>
        </Link>
      )}

      {/* Banner de solicitudes pendientes por bloqueo personal */}
      {myRequestsCount > 0 && (
        <Link
          href="/dashboard/my-requests"
          className="mb-4 flex shrink-0 items-center gap-2 rounded-lg border border-amber-200 bg-amber-50 px-3 py-3 transition hover:bg-amber-100"
        >
          <AlertCircle className="h-5 w-5 shrink-0 text-amber-600" />
          <span className="flex-1 text-sm text-amber-900">
            Tienes{" "}
            <strong>
              {myRequestsCount}{" "}
              {myRequestsCount === 1
                ? "solicitud pendiente"
                : "solicitudes pendientes"}
            </strong>{" "}
            por bloqueo personal.
          </span>
          <span className="text-xs font-medium text-amber-700">
            Responder →
          </span>
        </Link>
      )}

      {/* Header */}
      <div className="mb-4 flex shrink-0 flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-1 rounded-lg border border-gray-200 bg-white p-1">
            <button
              type="button"
              onClick={goPrev}
              className="flex h-11 w-11 items-center justify-center rounded-md text-gray-600 transition hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-millenium-blue focus:ring-offset-1"
              aria-label={view === "week" ? "Semana anterior" : "Día anterior"}
              title={view === "week" ? "Semana anterior" : "Día anterior"}
            >
              <ChevronLeft className="h-5 w-5" />
            </button>
            <button
              type="button"
              onClick={goNext}
              className="flex h-11 w-11 items-center justify-center rounded-md text-gray-600 transition hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-millenium-blue focus:ring-offset-1"
              aria-label={view === "week" ? "Semana siguiente" : "Día siguiente"}
              title={view === "week" ? "Semana siguiente" : "Día siguiente"}
            >
              <ChevronRight className="h-5 w-5" />
            </button>
          </div>
          <h1 className="text-2xl font-semibold tracking-tight text-gray-900 sm:text-3xl">
            {rangeLabel}
            {view === "day" && isToday && (
              <span className="ml-2 text-base font-semibold text-millenium-blue">
                · Hoy
              </span>
            )}
            {view === "week" && weekStartIsCurrent && (
              <span className="ml-2 text-base font-semibold text-millenium-blue">
                · Esta semana
              </span>
            )}
          </h1>
          {((view === "day" && !isToday) ||
            (view === "week" && !weekStartIsCurrent)) && (
            <button
              type="button"
              onClick={goToday}
              className="rounded-md border border-millenium-blue px-3 py-1 text-sm font-medium text-millenium-blue transition hover:bg-millenium-blue/10 focus:outline-none focus:ring-2 focus:ring-millenium-blue focus:ring-offset-1"
            >
              {view === "week" ? "Esta semana" : "Volver a hoy"}
            </button>
          )}
        </div>

        <div className="flex items-center gap-3">
          {/* Toggle Diaria / Semanal — oculto en mobile */}
          <div className="hidden items-center rounded-lg bg-gray-100 p-0.5 md:flex">
            <button
              type="button"
              onClick={() => setView("day")}
              className={
                "rounded-md px-3 py-1 text-sm font-medium transition " +
                (view === "day"
                  ? "bg-white text-gray-900 shadow-sm"
                  : "text-gray-500 hover:text-gray-700")
              }
              aria-pressed={view === "day"}
            >
              Diaria
            </button>
            <button
              type="button"
              onClick={() => setView("week")}
              className={
                "rounded-md px-3 py-1 text-sm font-medium transition " +
                (view === "week"
                  ? "bg-white text-gray-900 shadow-sm"
                  : "text-gray-500 hover:text-gray-700")
              }
              aria-pressed={view === "week"}
            >
              Semanal
            </button>
          </div>

          {/* Toggle "Mostrar fines de semana" — solo en vista semanal */}
          {view === "week" && (
            <button
              type="button"
              onClick={() => setShowWeekends(!showWeekends)}
              className={
                "hidden items-center gap-1.5 rounded-md border px-2.5 py-1.5 text-xs font-medium transition-colors md:inline-flex " +
                (showWeekends
                  ? "border-millenium-blue bg-millenium-blue/10 text-millenium-blue"
                  : "border-gray-300 bg-white text-gray-700 hover:bg-gray-50")
              }
              title={
                showWeekends
                  ? "Ocultar sábado y domingo"
                  : "Mostrar sábado y domingo"
              }
              aria-pressed={showWeekends}
            >
              <Calendar className="h-3.5 w-3.5" />
              {showWeekends ? "L - D" : "L - V"}
            </button>
          )}

          <Button
            variant="primary"
            disabled={isPastDate}
            title={
              isPastDate
                ? "No se puede agendar en fechas pasadas"
                : undefined
            }
            onClick={() => goNew({ date })}
          >
            <Plus className="h-5 w-5" />
            Nueva reunión
          </Button>
        </div>
      </div>

      {/* Barra de filtros: chips de tipo/sala + dropdown departamentos */}
      <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
        <FilterChips
          rooms={rooms}
          activeChip={filters.chip}
          onChange={(chip) => setFilters({ ...filters, chip })}
        />
        <MoreFiltersButton
          departments={departments}
          selectedIds={filters.departmentIds}
          onChange={(ids) => setFilters({ ...filters, departmentIds: ids })}
        />
      </div>

      {view === "day" && isPastDate && (
        <div className="mb-4 flex shrink-0 items-center gap-2 rounded-lg border border-gray-200 bg-gray-100 px-4 py-2.5 text-sm text-gray-600">
          <Clock className="h-4 w-4 shrink-0" />
          <span>
            Estás viendo una fecha pasada. Las reuniones son solo de consulta.
          </span>
        </div>
      )}

      {view === "week" && weekIsPast && (
        <div className="mb-4 flex shrink-0 items-center gap-2 rounded-lg border border-gray-200 bg-gray-100 px-4 py-2.5 text-sm text-gray-600">
          <Clock className="h-4 w-4 shrink-0" />
          <span>
            Estás viendo una semana pasada. Las reuniones son solo de consulta.
          </span>
        </div>
      )}

      {/* Contenido */}
      <div
        className={
          "flex min-h-0 flex-1 flex-col transition-opacity duration-150 " +
          (loading && hasLoadedOnce ? "opacity-60" : "opacity-100")
        }
      >
        {!hasLoadedOnce ? (
          <DashboardSkeleton />
        ) : view === "week" ? (
          // `key={view}` fuerza re-mount al cambiar de vista → animate-fadeIn
          // dispara la transición. Los tabs de sala fueron reemplazados por
          // el sistema de filtros unificado (boton "Filtros" en el header).
          <div key="week" className="animate-fadeIn flex min-h-0 flex-1 flex-col">
            <div className="min-h-0 flex-1 overflow-x-auto">
              <WeekTimeline
                startOfWeek={weekStart}
                reservations={filteredWeekReservations}
                showWeekends={showWeekends}
                onReservationClick={(rv) => setDetail(rv)}
                onEmptySlotClick={
                  weekIsPast
                    ? undefined
                    : (slot) =>
                        goNew({
                          date: slot.date,
                          start: hhmm(slot.hour, slot.minute),
                        })
                }
              />
            </div>
          </div>
        ) : physicalRooms.length === 0 ? (
          <div className="rounded-xl border border-dashed border-gray-300 bg-white p-10 text-center text-base text-gray-500">
            No hay salas activas.
          </div>
        ) : (
          <div
            key="day"
            className="animate-fadeIn flex min-h-0 flex-1 flex-col overflow-y-auto"
          >
            <DashboardLayout
              date={date}
              meetings={filteredDayMeetings}
              currentUserId={user?.id ?? null}
              currentUserDeptId={user?.departmentId ?? null}
              readOnly={isPastDate}
              onReservationClick={(rv) => setDetail(rv)}
              onEmptyClick={
                isPastDate
                  ? undefined
                  : (slot) =>
                      goNew({
                        date: slot.date,
                        start: hhmm(slot.hour, slot.minute),
                      })
              }
            />
          </div>
        )}
      </div>

      <ReservationDetailModal
        reservation={detail}
        roomCapacity={
          detail && detail.roomId
            ? rooms.find((r) => r.id === detail.roomId)?.capacity
            : undefined
        }
        canCancel={canCancelDetail}
        onCancel={cancelDetail}
        onClose={() => {
          setDetail(null);
        }}
      />
    </div>
  );
}
