"use client";

import { ChangeEvent, useCallback, useEffect, useRef, useState } from "react";
import {
  AlertCircle,
  Camera,
  Lock,
  Mail,
  Plus,
  Save,
  ShieldCheck,
  Trash2,
  Upload,
} from "lucide-react";
import { toast } from "@/lib/toastHelpers";
import PageHeader from "@/components/layout/PageHeader";
import { useAuthStore } from "@/store/authStore";
import Button from "@/components/ui/Button";
import Input from "@/components/ui/Input";
import ReadonlyField from "@/components/ui/ReadonlyField";
import Avatar from "@/components/Avatar";
import UserBlocksList from "@/components/UserBlocksList";
import UserBlockFormModal from "@/components/UserBlockFormModal";
import NotificationPreferencesForm from "@/components/NotificationPreferencesForm";
import api from "@/lib/api";
import { resizeImage } from "@/lib/images";
import type { Department, Reply, UserBlock } from "@/types";

type PendingPhoto =
  | null
  | { kind: "upload"; dataUrl: string }
  | { kind: "remove" };

export default function ProfilePage() {
  const user = useAuthStore((s) => s.user);
  const updateProfile = useAuthStore((s) => s.updateProfile);
  const setAvatarUrl = useAuthStore((s) => s.setAvatarUrl);

  const [fullName, setFullName] = useState(user?.fullName ?? "");
  const [departmentId, setDepartmentId] = useState<number | null>(
    user?.departmentId ?? null
  );
  const [departments, setDepartments] = useState<Department[]>([]);
  const [pendingPhoto, setPendingPhoto] = useState<PendingPhoto>(null);
  const [saving, setSaving] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  const [myBlocks, setMyBlocks] = useState<UserBlock[]>([]);
  const [showBlockForm, setShowBlockForm] = useState(false);

  const loadBlocks = useCallback(async () => {
    try {
      const res = await api.get<Reply<UserBlock[]>>("/users/me/blocks");
      setMyBlocks(res.data.obj || []);
    } catch {
      // silencioso
    }
  }, []);

  useEffect(() => {
    loadBlocks();
  }, [loadBlocks]);

  useEffect(() => {
    setDepartmentId(user?.departmentId ?? null);
  }, [user?.departmentId]);

  useEffect(() => {
    let cancelled = false;
    api
      .get<Reply<Department[]>>("/departments")
      .then((res) => {
        if (cancelled) return;
        setDepartments(res.data.obj || []);
      })
      .catch(() => {
        if (!cancelled) setDepartments([]);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!menuOpen) return;
    const handleClick = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setMenuOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClick);
    return () => document.removeEventListener("mousedown", handleClick);
  }, [menuOpen]);

  if (!user) return null;

  const trimmedName = fullName.trim();
  const hasNameChange = trimmedName !== (user.fullName || "");
  const hasPhotoChange = pendingPhoto !== null;
  const currentDeptId = user.departmentId ?? null;
  const hasDeptChange = departmentId !== currentDeptId;
  const canSave = hasNameChange || hasPhotoChange || hasDeptChange;

  const displayedAvatarUrl =
    pendingPhoto?.kind === "upload"
      ? pendingPhoto.dataUrl
      : pendingPhoto?.kind === "remove"
        ? null
        : user.avatarUrl;

  const handleFileSelected = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!["image/jpeg", "image/png", "image/webp"].includes(file.type)) {
      toast.error("Formato no soportado. Use JPG, PNG o WebP.");
      if (fileInputRef.current) fileInputRef.current.value = "";
      return;
    }
    if (file.size > 2 * 1024 * 1024) {
      toast.error("La imagen pesa demasiado. Máximo 2 MB.");
      if (fileInputRef.current) fileInputRef.current.value = "";
      return;
    }

    try {
      const dataUrl = await resizeImage(file, 256);
      setPendingPhoto({ kind: "upload", dataUrl });
    } catch {
      toast.error("No fue posible procesar la imagen");
    } finally {
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  };

  const handleRemovePhotoIntent = () => {
    setPendingPhoto({ kind: "remove" });
  };

  const handleDiscard = () => {
    setFullName(user.fullName || "");
    setDepartmentId(user.departmentId ?? null);
    setPendingPhoto(null);
  };

  const handleSave = async () => {
    if (!canSave || saving) return;

    if (hasNameChange && trimmedName.length < 2) {
      toast.error("El nombre debe tener al menos 2 caracteres");
      return;
    }

    setSaving(true);
    try {
      if (hasNameChange || hasDeptChange) {
        const fields: { fullName?: string; departmentId?: number | null } = {};
        if (hasNameChange) fields.fullName = trimmedName;
        if (hasDeptChange) fields.departmentId = departmentId;
        const r = await updateProfile(fields);
        if (!r.ok) {
          toast.error(r.msg);
          return;
        }
      }

      if (pendingPhoto?.kind === "upload") {
        const res = await api.post<Reply<{ avatarUrl: string }>>(
          "/users/me/avatar",
          { dataUrl: pendingPhoto.dataUrl }
        );
        if (!res.data.ok || !res.data.obj) {
          toast.error(res.data.msg || "No fue posible actualizar la foto");
          return;
        }
        setAvatarUrl(res.data.obj.avatarUrl);
      } else if (pendingPhoto?.kind === "remove") {
        const res = await api.delete<Reply<{ avatarUrl: null }>>(
          "/users/me/avatar"
        );
        if (!res.data.ok) {
          toast.error(res.data.msg || "No fue posible eliminar la foto");
          return;
        }
        setAvatarUrl(null);
      }

      setPendingPhoto(null);
      toast.success("Cambios guardados");
    } catch (e: unknown) {
      const errObj = e as { response?: { data?: { msg?: string } } };
      toast.error(
        errObj?.response?.data?.msg || "No fue posible guardar los cambios"
      );
    } finally {
      setSaving(false);
    }
  };

  const roleLabel = user.role === "admin" ? "Administrador" : "Empleado";

  return (
    <>
      <PageHeader
        title="Mi perfil"
        description="Información personal de su cuenta."
      />

      <div className="max-w-2xl space-y-6">
        {!user.avatarUrl && !displayedAvatarUrl && (
          <div className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-blue-200 bg-blue-50 px-4 py-3">
            <div className="flex items-center gap-2 text-sm text-blue-900">
              <Camera className="h-4 w-4 shrink-0 text-millenium-blue" />
              <span>
                Sube una foto para que tus colaboradores te identifiquen mejor.
              </span>
            </div>
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="rounded-md bg-millenium-blue px-3 py-1.5 text-xs font-medium text-white transition hover:bg-millenium-blue/90 focus:outline-none focus:ring-2 focus:ring-millenium-blue/40"
            >
              Subir foto
            </button>
          </div>
        )}

        <div className="flex items-center gap-4 rounded-xl border border-gray-200 bg-white p-6">
          <div ref={menuRef} className="relative inline-block shrink-0">
            <button
              type="button"
              onClick={() => setMenuOpen((o) => !o)}
              className="group relative rounded-full focus:outline-none focus:ring-2 focus:ring-millenium-blue/40 focus:ring-offset-2"
              aria-label="Cambiar foto de perfil"
              aria-haspopup="menu"
              aria-expanded={menuOpen}
            >
              {!user.fullName?.trim() && !displayedAvatarUrl ? (
                <span
                  className="flex h-16 w-16 shrink-0 items-center justify-center rounded-full bg-gray-200 text-gray-500"
                  aria-label={user.email}
                >
                  <Mail className="h-8 w-8" />
                </span>
              ) : (
                <Avatar
                  name={user.fullName}
                  email={user.email}
                  avatarUrl={displayedAvatarUrl}
                  size="xl"
                />
              )}
              <span className="pointer-events-none absolute inset-0 flex items-center justify-center rounded-full bg-black/40 opacity-0 transition group-hover:opacity-100 group-focus:opacity-100">
                <Camera className="h-6 w-6 text-white" />
              </span>
            </button>

            {menuOpen && (
              <div
                role="menu"
                className="absolute right-0 z-20 mt-2 w-48 max-w-[calc(100vw-2rem)] rounded-lg border border-gray-200 bg-white py-1 shadow-lg sm:left-0 sm:right-auto"
              >
                <button
                  type="button"
                  role="menuitem"
                  onClick={() => {
                    fileInputRef.current?.click();
                    setMenuOpen(false);
                  }}
                  className="flex w-full items-center gap-2 px-3 py-2 text-sm text-gray-700 transition hover:bg-gray-50 focus:bg-gray-100 focus:outline-none"
                >
                  <Upload className="h-4 w-4" />
                  {displayedAvatarUrl ? "Cambiar foto" : "Subir foto"}
                </button>

                {displayedAvatarUrl && (
                  <button
                    type="button"
                    role="menuitem"
                    onClick={() => {
                      handleRemovePhotoIntent();
                      setMenuOpen(false);
                    }}
                    className="flex w-full items-center gap-2 px-3 py-2 text-sm text-millenium-red transition hover:bg-gray-50 focus:bg-gray-100 focus:outline-none"
                  >
                    <Trash2 className="h-4 w-4" />
                    Quitar foto
                  </button>
                )}
              </div>
            )}

            <input
              ref={fileInputRef}
              type="file"
              accept="image/jpeg,image/png,image/webp"
              onChange={handleFileSelected}
              className="hidden"
            />
          </div>

          <div className="min-w-0">
            <h2 className="truncate text-xl font-semibold text-gray-900">
              {user.fullName || user.email}
            </h2>
            <p className="text-base text-gray-500">{roleLabel}</p>
          </div>
        </div>

        <div className="space-y-5 rounded-xl border border-gray-200 bg-white p-6">
          <h3 className="text-lg font-semibold text-gray-900">
            Información personal
          </h3>

          <div>
            <Input
              id="fullName"
              name="fullName"
              type="text"
              label="Nombre completo"
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              maxLength={80}
            />
            <p className="mt-1 text-right text-xs text-gray-500 tabular-nums">
              {fullName.length}/80
            </p>
          </div>

          <div>
            <label
              htmlFor="departmentId"
              className="mb-1.5 block text-sm font-medium text-gray-700"
            >
              Departamento
            </label>
            {currentDeptId === null ? (
              <>
                <select
                  id="departmentId"
                  value={departmentId ?? ""}
                  onChange={(e) =>
                    setDepartmentId(
                      e.target.value ? parseInt(e.target.value, 10) : null
                    )
                  }
                  className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:border-millenium-blue focus:outline-none focus:ring-2 focus:ring-millenium-blue/20"
                >
                  <option value="">Selecciona tu departamento</option>
                  {departments.map((d) => (
                    <option key={d.id} value={d.id}>
                      {d.name}
                    </option>
                  ))}
                </select>
                <p className="mt-1 flex items-start gap-1 text-xs text-amber-600">
                  <AlertCircle className="mt-0.5 h-3 w-3 shrink-0" />
                  <span>
                    Solo puedes elegir tu departamento una vez. Después solo
                    un administrador podrá cambiarlo.
                  </span>
                </p>
              </>
            ) : (
              <>
                <div
                  className="inline-flex w-full items-center gap-2 rounded-lg border border-gray-200 bg-gray-50 px-3 py-2"
                  style={{
                    borderLeftColor: user.departmentColor || "#6b7280",
                    borderLeftWidth: "4px",
                  }}
                >
                  <span
                    className="h-2 w-2 shrink-0 rounded-full"
                    style={{
                      backgroundColor: user.departmentColor || "#6b7280",
                    }}
                  />
                  <span className="line-clamp-2 wrap-break-word flex-1 text-sm font-medium text-gray-900">
                    {user.departmentName || "Sin departamento"}
                  </span>
                  <Lock className="h-3.5 w-3.5 shrink-0 text-gray-400" />
                </div>
                <p className="mt-1 text-xs text-gray-500">
                  Si necesitas cambiar de departamento, contacta al
                  administrador.
                </p>
              </>
            )}
          </div>

          {user.fullName && user.fullName.trim().length > 0 && (
            <ReadonlyField
              label="Correo electrónico"
              icon={<Mail className="h-4 w-4" />}
              value={user.email}
              hint="No editable"
            />
          )}

          <ReadonlyField
            label="Rol"
            icon={<ShieldCheck className="h-4 w-4" />}
            value={roleLabel}
            hint="Asignado por administrador"
          />

          <div className="flex flex-wrap items-center justify-end gap-3 pt-2">
            {canSave && (
              <p className="mr-auto text-sm italic text-gray-500">
                Tienes cambios sin guardar.
              </p>
            )}
            {canSave && (
              <button
                type="button"
                onClick={handleDiscard}
                disabled={saving}
                className="text-sm font-medium text-gray-600 transition hover:text-gray-900 focus:outline-none focus:ring-2 focus:ring-millenium-blue/40 focus:ring-offset-1 disabled:opacity-60"
              >
                Descartar cambios
              </button>
            )}
            <Button
              variant="primary"
              loading={saving}
              disabled={!canSave || saving}
              onClick={handleSave}
            >
              <Save className="h-4 w-4" />
              {saving ? "Guardando..." : "Guardar cambios"}
            </Button>
          </div>
        </div>

        <div className="space-y-4 rounded-xl border border-gray-200 bg-white p-6">
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <h3 className="text-lg font-semibold text-gray-900">
                Mis bloqueos personales
              </h3>
              <p className="mt-0.5 text-sm text-gray-500">
                Horarios o fechas en los que no aceptas reuniones
                automáticamente. Las invitaciones que se solapen llegarán como
                solicitud pendiente.
              </p>
            </div>
            <button
              type="button"
              onClick={() => setShowBlockForm(true)}
              className="inline-flex shrink-0 items-center gap-1.5 rounded-lg bg-millenium-blue px-3 py-1.5 text-sm font-medium text-white transition hover:bg-[#1f2c3a] focus:outline-none focus:ring-2 focus:ring-millenium-blue/40"
            >
              <Plus className="h-4 w-4" />
              Agregar bloqueo
            </button>
          </div>

          <UserBlocksList blocks={myBlocks} onUpdate={loadBlocks} />
        </div>

        <div className="space-y-2 rounded-xl border border-gray-200 bg-white p-6">
          <div>
            <h3 className="text-lg font-semibold text-gray-900">
              Notificaciones por correo
            </h3>
            <p className="mt-0.5 text-sm text-gray-500">
              Las notificaciones dentro de la app (campanita) siempre llegan.
              Aquí decides cuáles quieres recibir también por correo.
            </p>
          </div>
          <NotificationPreferencesForm />
        </div>
      </div>

      {showBlockForm && (
        <UserBlockFormModal
          onClose={() => setShowBlockForm(false)}
          onSaved={() => {
            loadBlocks();
            setShowBlockForm(false);
          }}
        />
      )}
    </>
  );
}
