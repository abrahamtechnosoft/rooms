"use client";

import { useCallback, useEffect, useState } from "react";
import {
  Building2,
  Calendar,
  Check,
  Clock,
  MapPin,
  Video,
  X as XIcon,
} from "lucide-react";
import api from "@/lib/api";
import { toast } from "@/lib/toastHelpers";
import EmptyState from "@/components/EmptyState";
import PageHeader from "@/components/layout/PageHeader";
import Avatar from "@/components/Avatar";
import { fmtDateTime, fmtTime } from "@/lib/dates";
import type { MyRequest, Reply } from "@/types";
import type { ReservationType } from "@/constants/reservationTypes";

function iconForType(type: ReservationType) {
  if (type === "virtual") return Video;
  if (type === "external") return MapPin;
  return Building2;
}

export default function MyRequestsPage() {
  const [items, setItems] = useState<MyRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const [respondingId, setRespondingId] = useState<number | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await api.get<Reply<MyRequest[]>>(
        "/reservations/my-requests"
      );
      setItems(res.data.obj || []);
    } catch {
      toast.error("No fue posible cargar tus solicitudes");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  async function respond(id: number, response: "accept" | "reject") {
    if (respondingId) return;
    setRespondingId(id);
    try {
      const res = await api.post<Reply<{ status: string }>>(
        `/reservations/${id}/invitation-response`,
        { response }
      );
      if (!res.data.ok) {
        toast.error(res.data.msg || "No fue posible responder");
        return;
      }
      toast.success(
        res.data.msg ||
          (response === "accept"
            ? "Aceptaste la invitación"
            : "Rechazaste la invitación")
      );
      await load();
    } catch (e: unknown) {
      const errObj = e as { response?: { data?: { msg?: string } } };
      toast.error(
        errObj?.response?.data?.msg || "No fue posible responder"
      );
    } finally {
      setRespondingId(null);
    }
  }

  return (
    <div>
      <PageHeader
        title="Solicitudes pendientes"
        description="Estas reuniones coinciden con tus bloqueos personales. Por favor decide si participas."
      />

      {loading ? (
        <div className="space-y-3">
          {[1, 2, 3].map((i) => (
            <div
              key={i}
              className="h-40 animate-pulse rounded-lg bg-gray-100"
            />
          ))}
        </div>
      ) : items.length === 0 ? (
        <div className="rounded-xl border border-dashed border-gray-300 bg-white">
          <EmptyState
            icon={Check}
            title="No tienes solicitudes pendientes"
            description="Todas tus invitaciones a reuniones están al día."
          />
        </div>
      ) : (
        <div className="space-y-3">
          {items.map((item) => {
            const TypeIcon = iconForType(item.type);
            return (
              <div
                key={item.id}
                className="flex min-h-30 flex-col rounded-lg border border-amber-200 bg-white p-4 sm:min-h-40"
              >
                <div className="flex items-start gap-3">
                  <div className="shrink-0 rounded-lg bg-amber-50 p-2">
                    <TypeIcon className="h-5 w-5 text-amber-600" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <h3 className="font-semibold text-gray-900">
                      {item.title}
                    </h3>
                    <p className="mt-0.5 flex items-center gap-1.5 text-sm text-gray-600">
                      Invitada por
                      <span className="inline-flex items-center gap-1.5">
                        <Avatar
                          name={item.organizerName}
                          email={item.organizerEmail || undefined}
                          avatarUrl={item.organizerAvatarUrl}
                          size="sm"
                          className="h-5 w-5"
                        />
                        <strong className="text-gray-900">
                          {item.organizerName}
                        </strong>
                      </span>
                    </p>
                    <p className="mt-1 flex items-center gap-1 text-sm text-gray-600">
                      <Clock className="h-3.5 w-3.5" />
                      {fmtDateTime(item.startsAt)} - {fmtTime(item.endsAt)}
                    </p>
                    {item.roomName && (
                      <p className="mt-0.5 flex items-center gap-1 text-xs text-gray-500">
                        <MapPin className="h-3 w-3" />
                        {item.roomName}
                      </p>
                    )}
                    {item.blockName && (
                      <div className="mt-2 inline-flex items-center gap-1 rounded bg-amber-50 px-2 py-1 text-xs text-amber-700">
                        <Calendar className="h-3 w-3" />
                        Coincide con tu bloqueo:{" "}
                        <strong>{item.blockName}</strong>
                      </div>
                    )}
                  </div>
                </div>

                <div className="mt-auto flex justify-end gap-2 pt-4">
                  <button
                    type="button"
                    onClick={() => respond(item.id, "reject")}
                    disabled={respondingId === item.id}
                    className="inline-flex items-center gap-1.5 rounded-lg border border-gray-200 px-3 py-1.5 text-sm text-gray-700 transition hover:bg-gray-50 disabled:cursor-not-allowed disabled:opacity-50"
                  >
                    <XIcon className="h-4 w-4" />
                    No participar
                  </button>
                  <button
                    type="button"
                    onClick={() => respond(item.id, "accept")}
                    disabled={respondingId === item.id}
                    className="inline-flex items-center gap-1.5 rounded-lg bg-millenium-blue px-3 py-1.5 text-sm font-medium text-white transition hover:bg-[#1f2c3a] disabled:cursor-not-allowed disabled:opacity-50"
                  >
                    <Check className="h-4 w-4" />
                    {respondingId === item.id ? "Procesando..." : "Aceptar"}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
