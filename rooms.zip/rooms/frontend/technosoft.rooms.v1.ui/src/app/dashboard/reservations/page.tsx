"use client";

import { Suspense, useCallback, useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { toast } from "@/lib/toastHelpers";
import {
  Calendar,
  History,
  Plus,
  Search,
  SearchX,
  X,
} from "lucide-react";
import api from "@/lib/api";
import { useBackendPolling } from "@/hooks/useBackendPolling";
import { matchesSearch } from "@/lib/stringHelpers";
import type { Reply, Reservation } from "@/types";
import PageHeader from "@/components/layout/PageHeader";
import ReservationCard from "@/components/ReservationCard";
import ReservationDetailModal from "@/components/ReservationDetailModal";
import Pagination from "@/components/ui/Pagination";
import EmptyState from "@/components/EmptyState";
import ReservationListSkeleton from "@/components/skeletons/ReservationListSkeleton";
import { getReservationStatus } from "@/lib/reservationStatus";
import { useAuthStore } from "@/store/authStore";

type Tab = "upcoming" | "history";
type FilterType = "all" | "physical" | "virtual" | "external" | "office";
type FilterRole = "all" | "organizer" | "participant";
type SubFilter = "all" | "recurring" | "unique";

const ITEMS_PER_PAGE = 20;

function MyReservationsInner() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const focusId = searchParams.get("focus");

  const { user } = useAuthStore();
  const [items, setItems] = useState<Reservation[]>([]);
  const [loading, setLoading] = useState(false);
  const [tab, setTab] = useState<Tab>("upcoming");
  const [detail, setDetail] = useState<Reservation | null>(null);
  const [historySearch, setHistorySearch] = useState("");
  const [upcomingPage, setUpcomingPage] = useState(1);
  const [historyPage, setHistoryPage] = useState(1);

  // Filtros server-side. Tipo, rol y rango de fechas se mandan al backend.
  // El estado (próximas vs historial) sigue manejado por los tabs existentes.
  const [filterType, setFilterType] = useState<FilterType>("all");
  const [filterRole, setFilterRole] = useState<FilterRole>("all");
  const [subFilter, setSubFilter] = useState<SubFilter>("all");
  const [filterDateFrom, setFilterDateFrom] = useState("");
  const [filterDateTo, setFilterDateTo] = useState("");
  const hasActiveFilters =
    filterType !== "all" ||
    filterRole !== "all" ||
    filterDateFrom !== "" ||
    filterDateTo !== "";

  const clearFilters = useCallback(() => {
    setFilterType("all");
    setFilterRole("all");
    setFilterDateFrom("");
    setFilterDateTo("");
  }, []);

  // Si entramos con ?focus=<id> (típicamente desde una notificación), abrir el
  // modal de detalle de esa reunión y limpiar el query param.
  useEffect(() => {
    if (!focusId || !/^\d+$/.test(focusId)) return;
    let cancelled = false;
    api
      .get<Reply<Reservation>>(`/reservations/${focusId}`)
      .then((res) => {
        if (!cancelled && res.data.obj) setDetail(res.data.obj);
      })
      .catch(() => {})
      .finally(() => {
        if (!cancelled) router.replace("/dashboard/reservations");
      });
    return () => {
      cancelled = true;
    };
  }, [focusId, router]);

  const load = useCallback(
    async (opts: { silent?: boolean } = {}) => {
      if (!opts.silent) setLoading(true);
      try {
        const params: Record<string, string> = {};
        if (filterType !== "all") params.type = filterType;
        if (filterRole !== "all") params.role = filterRole;
        if (filterDateFrom) params.dateFrom = filterDateFrom;
        if (filterDateTo) params.dateTo = filterDateTo;
        const res = await api.get<Reply<Reservation[]>>(
          "/reservations/mine",
          { params }
        );
        setItems(res.data.obj || []);
      } catch (e) {
        if (!opts.silent) {
          toast.error("No fue posible cargar sus reuniones");
        }
        throw e;
      } finally {
        if (!opts.silent) setLoading(false);
      }
    },
    [filterType, filterRole, filterDateFrom, filterDateTo]
  );

  useEffect(() => {
    load().catch(() => {});
  }, [load]);

  // Polling 60s (lista histórica, no crítica). Pausa en background.
  useBackendPolling(
    () => {
      load({ silent: true }).catch(() => {});
    },
    60_000,
    [filterType, filterRole, filterDateFrom, filterDateTo]
  );

  // Resetear paginación cuando cambian los filtros.
  useEffect(() => {
    setUpcomingPage(1);
    setHistoryPage(1);
  }, [filterType, filterRole, subFilter, filterDateFrom, filterDateTo]);

  const now = Date.now();
  const upcoming = useMemo(
    () =>
      items
        .filter(
          (r) => r.status === "active" && new Date(r.endsAt).getTime() > now
        )
        .sort((a, b) => {
          const sa = getReservationStatus(a);
          const sb = getReservationStatus(b);
          if (sa === "live" && sb !== "live") return -1;
          if (sb === "live" && sa !== "live") return 1;
          return (
            new Date(a.startsAt).getTime() - new Date(b.startsAt).getTime()
          );
        }),
    [items, now]
  );

  const history = useMemo(
    () =>
      items
        .filter(
          (r) =>
            r.status === "cancelled" || new Date(r.endsAt).getTime() <= now
        )
        .sort(
          (a, b) =>
            new Date(b.startsAt).getTime() - new Date(a.startsAt).getTime()
        ),
    [items, now]
  );

  const filteredHistory = useMemo(() => {
    const q = historySearch.trim();
    if (!q) return history;
    return history.filter(
      (r) =>
        matchesSearch(r.title, q) ||
        matchesSearch(r.roomName, q) ||
        matchesSearch(r.externalAddress, q) ||
        matchesSearch(r.description, q)
    );
  }, [history, historySearch]);

  // Reset de páginas al cambiar búsqueda o cambiar de tab.
  useEffect(() => {
    setHistoryPage(1);
  }, [historySearch]);
  useEffect(() => {
    if (tab === "upcoming") setUpcomingPage(1);
    else setHistoryPage(1);
  }, [tab]);

  const baseList = tab === "upcoming" ? upcoming : filteredHistory;
  const list = useMemo(() => {
    if (subFilter === "recurring") {
      return baseList.filter((r) => r.recurringSeriesId != null);
    }
    if (subFilter === "unique") {
      return baseList.filter((r) => r.recurringSeriesId == null);
    }
    return baseList;
  }, [baseList, subFilter]);
  const subCounts = useMemo(
    () => ({
      all: baseList.length,
      recurring: baseList.filter((r) => r.recurringSeriesId != null).length,
      unique: baseList.filter((r) => r.recurringSeriesId == null).length,
    }),
    [baseList]
  );
  const currentPage = tab === "upcoming" ? upcomingPage : historyPage;
  const setCurrentPage = tab === "upcoming" ? setUpcomingPage : setHistoryPage;
  const totalPages = Math.max(1, Math.ceil(list.length / ITEMS_PER_PAGE));
  const safePage = Math.min(currentPage, totalPages);
  const paginatedList = list.slice(
    (safePage - 1) * ITEMS_PER_PAGE,
    safePage * ITEMS_PER_PAGE
  );

  // El modal hace la llamada HTTP con el motivo y nos avisa con onCancel.
  const doCancel = async () => {
    setDetail(null);
    await load();
  };

  const tabBtn = (key: Tab, label: string, count: number) => {
    const active = tab === key;
    return (
      <button
        type="button"
        role="tab"
        id={`tab-${key}`}
        aria-selected={active}
        aria-controls={`panel-${key}`}
        tabIndex={active ? 0 : -1}
        onClick={() => setTab(key)}
        className={
          "relative px-3.5 py-2.5 text-base transition " +
          (active
            ? "font-semibold text-millenium-blue"
            : "font-medium text-gray-500 hover:text-gray-700")
        }
      >
        {label}
        <span
          className={
            "ml-2 inline-flex items-center justify-center rounded-full px-2 py-0.5 text-xs font-semibold " +
            (active
              ? "bg-millenium-blue/10 text-millenium-blue"
              : "bg-gray-100 text-gray-500")
          }
        >
          {count}
        </span>
        {active && (
          <span className="absolute -bottom-px left-0 right-0 h-0.5 rounded-full bg-millenium-blue" />
        )}
      </button>
    );
  };

  const handleTablistKey = (e: React.KeyboardEvent<HTMLDivElement>) => {
    if (e.key === "ArrowRight") {
      e.preventDefault();
      setTab(tab === "upcoming" ? "history" : "upcoming");
    } else if (e.key === "ArrowLeft") {
      e.preventDefault();
      setTab(tab === "history" ? "upcoming" : "history");
    } else if (e.key === "Home") {
      e.preventDefault();
      setTab("upcoming");
    } else if (e.key === "End") {
      e.preventDefault();
      setTab("history");
    }
  };

  const canCancelDetail =
    !!detail &&
    !!user &&
    (detail.createdBy === user.id || user.role === "admin");

  return (
    <div>
      <PageHeader
        title="Mis reuniones"
        description="Sus reuniones activas y el historial reciente."
        actions={
          <Link
            href="/dashboard/reservations/new"
            className="btn btn-primary"
          >
            <Plus className="h-4 w-4" />
            Nueva reunión
          </Link>
        }
      />

      {/* Filtros server-side */}
      <div className="mb-4 rounded-lg border border-gray-200 bg-white p-3">
        <div className="grid grid-cols-2 gap-2 sm:flex sm:flex-wrap sm:items-end sm:gap-3">
          <div className="flex flex-col">
            <label
              htmlFor="filter-type"
              className="mb-1 text-xs text-gray-500"
            >
              Tipo
            </label>
            <select
              id="filter-type"
              value={filterType}
              onChange={(e) => setFilterType(e.target.value as FilterType)}
              className="w-full rounded border border-gray-300 px-2 py-1.5 text-sm focus:border-millenium-blue focus:outline-none focus:ring-2 focus:ring-millenium-blue/20 sm:min-w-32"
            >
              <option value="all">Todas</option>
              <option value="physical">En sala</option>
              <option value="office">Oficina</option>
              <option value="virtual">Virtuales</option>
              <option value="external">Externas</option>
            </select>
          </div>

          <div className="flex flex-col">
            <label
              htmlFor="filter-role"
              className="mb-1 text-xs text-gray-500"
            >
              Rol
            </label>
            <select
              id="filter-role"
              value={filterRole}
              onChange={(e) => setFilterRole(e.target.value as FilterRole)}
              className="w-full rounded border border-gray-300 px-2 py-1.5 text-sm focus:border-millenium-blue focus:outline-none focus:ring-2 focus:ring-millenium-blue/20 sm:min-w-32"
            >
              <option value="all">Todas</option>
              <option value="organizer">Organizador</option>
              <option value="participant">Invitado</option>
            </select>
          </div>

          <div className="flex flex-col">
            <label
              htmlFor="filter-from"
              className="mb-1 text-xs text-gray-500"
            >
              Desde
            </label>
            <input
              id="filter-from"
              type="date"
              value={filterDateFrom}
              onChange={(e) => setFilterDateFrom(e.target.value)}
              className="w-full rounded border border-gray-300 px-2 py-1.5 text-sm focus:border-millenium-blue focus:outline-none focus:ring-2 focus:ring-millenium-blue/20 sm:min-w-32"
            />
          </div>

          <div className="flex flex-col">
            <label
              htmlFor="filter-to"
              className="mb-1 text-xs text-gray-500"
            >
              Hasta
            </label>
            <input
              id="filter-to"
              type="date"
              value={filterDateTo}
              onChange={(e) => setFilterDateTo(e.target.value)}
              className="w-full rounded border border-gray-300 px-2 py-1.5 text-sm focus:border-millenium-blue focus:outline-none focus:ring-2 focus:ring-millenium-blue/20 sm:min-w-32"
            />
          </div>

          {hasActiveFilters && (
            <button
              type="button"
              onClick={clearFilters}
              className="col-span-2 inline-flex items-center justify-center gap-1 rounded border border-gray-300 bg-white px-2 py-1.5 text-sm text-gray-600 transition hover:text-millenium-red focus:outline-none focus:ring-2 focus:ring-millenium-blue/40 sm:col-auto sm:self-end sm:border-0 sm:bg-transparent sm:text-gray-500"
            >
              <X className="h-3.5 w-3.5" aria-hidden="true" />
              Limpiar filtros
            </button>
          )}
        </div>
      </div>

      <div
        role="tablist"
        aria-label="Filtrar reuniones"
        onKeyDown={handleTablistKey}
        className="mb-4 flex gap-1 border-b border-gray-200"
      >
        {tabBtn("upcoming", "Próximas", upcoming.length)}
        {tabBtn("history", "Historial", history.length)}
      </div>

      <div
        role="tabpanel"
        id={`panel-${tab}`}
        aria-labelledby={`tab-${tab}`}
      >
        {!loading && baseList.length > 0 && (
          <div className="mb-4 flex items-center gap-1 border-b border-gray-100">
            {(["all", "recurring", "unique"] as const).map((s) => {
              const label =
                s === "all"
                  ? "Todas"
                  : s === "recurring"
                    ? "Recurrentes"
                    : "Únicas";
              const active = subFilter === s;
              return (
                <button
                  key={s}
                  type="button"
                  onClick={() => setSubFilter(s)}
                  className={
                    "relative px-3 py-2 text-sm font-medium transition-colors " +
                    (active
                      ? "text-millenium-blue"
                      : "text-gray-500 hover:text-gray-700")
                  }
                  aria-pressed={active}
                >
                  {label}
                  <span className="ml-1.5 text-xs text-gray-400">
                    {subCounts[s]}
                  </span>
                  {active && (
                    <span className="absolute -bottom-px left-0 right-0 h-0.5 rounded-t bg-millenium-blue" />
                  )}
                </button>
              );
            })}
          </div>
        )}

        {tab === "history" && !loading && history.length > 0 && (
          <div className="mb-4 flex flex-wrap items-center gap-3">
            <div className="relative w-full sm:max-w-sm sm:flex-1">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                value={historySearch}
                onChange={(e) => setHistorySearch(e.target.value)}
                placeholder="Buscar en mis reuniones pasadas..."
                aria-label="Buscar en historial"
                className="w-full rounded-lg border border-gray-300 bg-white py-2.5 pl-10 pr-3 text-base focus:border-millenium-blue focus:outline-none focus:ring-2 focus:ring-millenium-blue/20"
              />
            </div>
            <span className="text-sm text-gray-500">
              {filteredHistory.length}{" "}
              {filteredHistory.length === 1 ? "resultado" : "resultados"}
            </span>
          </div>
        )}

        {loading ? (
          <ReservationListSkeleton count={5} />
        ) : list.length === 0 ? (
          <div
            key={`empty-${tab}`}
            className="animate-fadeIn rounded-xl border border-dashed border-gray-300 bg-white"
          >
            {hasActiveFilters ? (
              <EmptyState
                icon={SearchX}
                title="Sin resultados"
                description="Prueba con otros filtros o quita los activos."
                action={
                  <button
                    type="button"
                    onClick={clearFilters}
                    className="btn btn-outline btn-sm"
                  >
                    <X className="h-4 w-4" />
                    Limpiar filtros
                  </button>
                }
              />
            ) : tab === "upcoming" ? (
              <EmptyState
                icon={Calendar}
                title="Sin reuniones próximas"
                description="Cuando agende una reunión, aparecerá aquí."
                action={
                  <Link
                    href="/dashboard/reservations/new"
                    className="btn btn-primary btn-sm"
                  >
                    <Plus className="h-4 w-4" />
                    Nueva reunión
                  </Link>
                }
              />
            ) : history.length > 0 && historySearch.trim() ? (
              <EmptyState
                icon={SearchX}
                title={`Sin resultados para "${historySearch}"`}
                description="Pruebe con otro término de búsqueda."
              />
            ) : (
              <EmptyState
                icon={History}
                title="Sin reuniones pasadas"
                description="Aquí verá el historial de reuniones que ya pasaron."
              />
            )}
          </div>
        ) : (
          <div key={tab} className="animate-fadeIn">
            <div className="flex flex-col gap-3">
              {paginatedList.map((r) => (
                <ReservationCard
                  key={r.id}
                  reservation={r}
                  currentUserId={user?.id ?? null}
                  onOpen={(x) => setDetail(x)}
                />
              ))}
            </div>
            <Pagination
              currentPage={safePage}
              totalPages={totalPages}
              onPageChange={setCurrentPage}
              totalItems={list.length}
              itemsPerPage={ITEMS_PER_PAGE}
            />
            <div className="pb-8" />
          </div>
        )}
      </div>

      <ReservationDetailModal
        reservation={detail}
        canCancel={canCancelDetail}
        onCancel={doCancel}
        onClose={() => {
          setDetail(null);
        }}
      />
    </div>
  );
}

export default function MyReservationsPage() {
  return (
    <Suspense fallback={null}>
      <MyReservationsInner />
    </Suspense>
  );
}
