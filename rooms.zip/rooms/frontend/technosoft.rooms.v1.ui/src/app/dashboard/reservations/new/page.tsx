"use client";

import { Suspense } from "react";
import { useSearchParams } from "next/navigation";
import PageHeader from "@/components/layout/PageHeader";
import ReservationForm from "@/components/ReservationForm";
import { Skeleton } from "@/components/ui/Skeleton";

const VALID_DATE = /^\d{4}-\d{2}-\d{2}$/;
const VALID_TIME = /^\d{2}:\d{2}$/;

function NewReservationInner() {
  const params = useSearchParams();
  const editIdParam = params.get("editId");
  const editId =
    editIdParam && /^\d+$/.test(editIdParam) ? parseInt(editIdParam, 10) : undefined;

  const roomIdParam = params.get("roomId");
  const dateParam = params.get("date");
  const startParam = params.get("start");
  const startsAtParam = params.get("startsAt");
  const durationParam = params.get("duration");

  let initialDate: string | undefined;
  let initialStart: string | undefined;
  let initialDuration: number | undefined;

  if (dateParam && VALID_DATE.test(dateParam)) {
    initialDate = dateParam;
  }
  if (startParam && VALID_TIME.test(startParam)) {
    initialStart = startParam;
  }
  if (durationParam) {
    const n = parseInt(durationParam, 10);
    if (!isNaN(n) && n >= 15 && n <= 240) initialDuration = n;
  }

  // Compatibilidad con flujo viejo: ?startsAt=<ISO>
  if (!initialStart && startsAtParam) {
    const s = new Date(startsAtParam);
    if (!isNaN(s.getTime())) {
      const y = s.getFullYear();
      const m = String(s.getMonth() + 1).padStart(2, "0");
      const d = String(s.getDate()).padStart(2, "0");
      const hh = String(s.getHours()).padStart(2, "0");
      const mm = String(s.getMinutes()).padStart(2, "0");
      if (!initialDate) initialDate = `${y}-${m}-${d}`;
      initialStart = `${hh}:${mm}`;
    }
  }

  const initialRoomId = roomIdParam ? parseInt(roomIdParam, 10) : undefined;
  const initialVirtual = params.get("virtual") === "true";

  return (
    <div>
      <PageHeader
        title={editId ? "Reagendar reunión" : "Nueva reunión"}
        description={
          editId
            ? "Modifique sala, fecha, horario o colaboradores. Los participantes serán notificados de los cambios."
            : "Elija sala, fecha y horario. Máximo 30 días a futuro, entre las 08:00 y las 17:00."
        }
      />
      <ReservationForm
        editId={editId}
        initialRoomId={initialRoomId}
        initialDate={initialDate}
        initialStart={initialStart}
        initialDuration={initialDuration}
        initialVirtual={initialVirtual}
        redirectOnSuccess="/dashboard/reservations"
      />
    </div>
  );
}

function NewReservationFallback() {
  return (
    <div>
      <PageHeader
        title="Nueva reunión"
        description="Elija sala, fecha y horario. Máximo 30 días a futuro, entre las 08:00 y las 17:00."
      />
      <div className="flex flex-col gap-6">
        <Skeleton className="h-28 w-full" />
        <Skeleton className="h-20 w-full" />
        <Skeleton className="h-64 w-full" />
        <Skeleton className="h-32 w-full" />
      </div>
    </div>
  );
}

export default function NewReservationPage() {
  return (
    <Suspense fallback={<NewReservationFallback />}>
      <NewReservationInner />
    </Suspense>
  );
}
