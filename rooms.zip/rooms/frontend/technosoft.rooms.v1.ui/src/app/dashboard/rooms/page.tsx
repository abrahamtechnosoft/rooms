"use client";

import { FormEvent, useCallback, useEffect, useState } from "react";
import { Building2, Edit2, MapPin, Plus, Power, Users } from "lucide-react";
import { toast } from "@/lib/toastHelpers";
import ProtectedRoute from "@/components/ProtectedRoute";
import PageHeader from "@/components/layout/PageHeader";
import EmptyState from "@/components/EmptyState";
import TableSkeleton from "@/components/skeletons/TableSkeleton";
import Modal from "@/components/ui/Modal";
import Input from "@/components/ui/Input";
import Textarea from "@/components/ui/Textarea";
import Button from "@/components/ui/Button";
import api from "@/lib/api";
import type { Reply, Room } from "@/types";
import {
  ROOM_COLORS,
  ROOM_ICONS,
  getRoomColor,
  getRoomIcon,
} from "@/lib/roomIcons";

interface FormState {
  name: string;
  capacity: string;
  location: string;
  colorHex: string;
  iconName: string;
  description: string;
}

const emptyForm: FormState = {
  name: "",
  capacity: "4",
  location: "",
  colorHex: ROOM_COLORS[0].hex,
  iconName: ROOM_ICONS[0].name,
  description: "",
};

export default function RoomsAdminPage() {
  const [rooms, setRooms] = useState<Room[]>([]);
  const [loading, setLoading] = useState(false);
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Room | null>(null);
  const [form, setForm] = useState<FormState>(emptyForm);
  const [submitting, setSubmitting] = useState(false);
  const [confirmingDeactivate, setConfirmingDeactivate] = useState<Room | null>(
    null
  );
  const [togglingPower, setTogglingPower] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await api.get<Reply<Room[]>>("/rooms", {
        params: { includeInactive: true },
      });
      setRooms(res.data.obj || []);
    } catch {
      toast.error("No fue posible cargar las salas");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const openCreate = () => {
    setEditing(null);
    setForm(emptyForm);
    setModalOpen(true);
  };

  const openEdit = (r: Room) => {
    setEditing(r);
    setForm({
      name: r.name,
      capacity: String(r.capacity || 4),
      location: r.location || "",
      colorHex: r.colorHex || ROOM_COLORS[0].hex,
      iconName: r.iconName || ROOM_ICONS[0].name,
      description: r.description || "",
    });
    setModalOpen(true);
  };

  const setActive = async (r: Room, isActive: boolean) => {
    try {
      const res = await api.put<Reply<Room>>(`/rooms/${r.id}`, { isActive });
      if (res.data.ok) {
        toast.success(isActive ? "Sala activada" : "Sala desactivada");
        await load();
      } else {
        toast.error(res.data.msg || "No fue posible actualizar la sala");
      }
    } catch {
      toast.error("No fue posible actualizar la sala");
    }
  };

  const handleTogglePower = (r: Room) => {
    if (r.isActive) {
      setConfirmingDeactivate(r);
    } else {
      setActive(r, true);
    }
  };

  const confirmDeactivate = async () => {
    if (!confirmingDeactivate || togglingPower) return;
    setTogglingPower(true);
    try {
      await setActive(confirmingDeactivate, false);
      setConfirmingDeactivate(null);
    } finally {
      setTogglingPower(false);
    }
  };

  const handleSubmit = async (e?: FormEvent) => {
    if (e) e.preventDefault();
    if (!form.name.trim()) {
      toast.error("Indique el nombre de la sala");
      return;
    }
    const cap = parseInt(form.capacity, 10);
    if (!Number.isInteger(cap) || cap < 1) {
      toast.error("Indique una capacidad valida");
      return;
    }
    setSubmitting(true);
    try {
      const body: Record<string, unknown> = {
        name: form.name.trim(),
        colorHex: form.colorHex,
        iconName: form.iconName,
        description: form.description.trim() || null,
        capacity: cap,
        location: form.location.trim() || null,
      };

      const res = editing
        ? await api.put<Reply<Room>>(`/rooms/${editing.id}`, body)
        : await api.post<Reply<Room>>(`/rooms`, body);
      if (!res.data.ok) {
        toast.error(res.data.msg || "No fue posible guardar");
        return;
      }
      toast.success(editing ? "Sala actualizada" : "Sala creada");
      setModalOpen(false);
      await load();
    } catch (e: unknown) {
      const errObj = e as { response?: { data?: { msg?: string } } };
      toast.error(errObj?.response?.data?.msg || "No fue posible guardar");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <ProtectedRoute requireRole="admin">
      <div>
        <PageHeader
          title="Salas"
          description="Cree, edite o desactive las salas disponibles."
          actions={
            <Button variant="primary" onClick={openCreate}>
              <Plus className="h-4 w-4" />
              Nueva sala
            </Button>
          }
        />

        {loading && rooms.length === 0 ? (
          <TableSkeleton rows={5} columns={5} />
        ) : !loading && rooms.length === 0 ? (
          <div className="rounded-xl border border-dashed border-gray-300 bg-white">
            <EmptyState
              icon={Building2}
              title="Sin salas registradas"
              description="Cree la primera sala para empezar a recibir reservaciones."
              action={
                <Button variant="primary" onClick={openCreate}>
                  <Plus className="h-4 w-4" />
                  Nueva sala
                </Button>
              }
            />
          </div>
        ) : (
          <>
            {/* Mobile: cards */}
            <ul className="space-y-2 md:hidden">
              {rooms.map((r) => {
                const Icon = getRoomIcon(r.iconName);
                const color = getRoomColor(r.colorHex);
                return (
                  <li
                    key={r.id}
                    className="rounded-lg border border-gray-200 bg-white p-3 shadow-sm"
                  >
                    <div className="flex items-start gap-3">
                      <span
                        className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg"
                        style={{ backgroundColor: `${color}26` }}
                        aria-hidden="true"
                      >
                        <Icon className="h-5 w-5" style={{ color }} />
                      </span>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-start justify-between gap-2">
                          <div className="min-w-0 flex-1">
                            <div className="text-sm font-semibold text-gray-900 wrap-break-word">
                              {r.name}
                            </div>
                            <div className="mt-0.5 flex items-center gap-1 text-xs text-gray-500">
                              <Users className="h-3 w-3" aria-hidden="true" />
                              <span>Capacidad {r.capacity}</span>
                              {r.location && (
                                <>
                                  <span className="mx-1" aria-hidden="true">·</span>
                                  <MapPin className="h-3 w-3" aria-hidden="true" />
                                  <span className="truncate">{r.location}</span>
                                </>
                              )}
                            </div>
                          </div>
                          <span
                            className={
                              "shrink-0 rounded-full px-2 py-0.5 text-[10px] font-medium " +
                              (r.isActive
                                ? "bg-emerald-50 text-emerald-700"
                                : "bg-gray-100 text-gray-600")
                            }
                          >
                            {r.isActive ? "Activa" : "Inactiva"}
                          </span>
                        </div>
                        {r.description && (
                          <p className="mt-2 line-clamp-2 text-xs text-gray-600 wrap-break-word">
                            {r.description}
                          </p>
                        )}
                        <div className="mt-3 flex gap-2 border-t border-gray-100 pt-2">
                          <button
                            type="button"
                            onClick={() => openEdit(r)}
                            className="inline-flex flex-1 items-center justify-center gap-1 rounded-md border border-gray-200 bg-white px-3 py-1.5 text-xs font-medium text-gray-700 hover:bg-gray-50"
                            aria-label={`Editar sala: ${r.name}`}
                          >
                            <Edit2 className="h-3 w-3" aria-hidden="true" />
                            Editar
                          </button>
                          <button
                            type="button"
                            onClick={() => handleTogglePower(r)}
                            className={
                              "inline-flex flex-1 items-center justify-center gap-1 rounded-md border px-3 py-1.5 text-xs font-medium " +
                              (r.isActive
                                ? "border-red-200 bg-white text-millenium-red hover:bg-red-50"
                                : "border-emerald-200 bg-white text-millenium-green hover:bg-emerald-50")
                            }
                            aria-label={
                              r.isActive
                                ? `Desactivar sala: ${r.name}`
                                : `Activar sala: ${r.name}`
                            }
                          >
                            <Power className="h-3 w-3" aria-hidden="true" />
                            {r.isActive ? "Desactivar" : "Activar"}
                          </button>
                        </div>
                      </div>
                    </div>
                  </li>
                );
              })}
            </ul>

            {/* Desktop: tabla */}
            <div className="hidden overflow-x-auto rounded-xl border border-gray-200 bg-white shadow-sm md:block">
            <table className="min-w-full text-base">
              <thead className="bg-gray-50 text-left text-gray-500">
                <tr>
                  <th scope="col" className="px-4 py-3 text-sm font-semibold uppercase tracking-wide">
                    Sala
                  </th>
                  <th scope="col" className="px-4 py-3 text-sm font-semibold uppercase tracking-wide">
                    Capacidad
                  </th>
                  <th scope="col" className="px-4 py-3 text-sm font-semibold uppercase tracking-wide">
                    Ubicación
                  </th>
                  <th scope="col" className="px-4 py-3 text-sm font-semibold uppercase tracking-wide">
                    Estado
                  </th>
                  <th scope="col" className="px-4 py-3"><span className="sr-only">Acciones</span></th>
                </tr>
              </thead>
              <tbody>
                {rooms.map((r) => {
                    const Icon = getRoomIcon(r.iconName);
                    const color = getRoomColor(r.colorHex);
                    return (
                      <tr
                        key={r.id}
                        className="border-t border-gray-100 transition hover:bg-gray-50"
                      >
                        <td className="px-4 py-3">
                          <div className="flex min-w-0 items-center gap-2">
                            <span
                              className="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-lg"
                              style={{ backgroundColor: `${color}26` }}
                            >
                              <Icon
                                className="h-5 w-5"
                                style={{ color }}
                              />
                            </span>
                            <div className="min-w-0 flex-1">
                              <div className="flex items-center gap-2">
                                <span
                                  className="truncate font-medium text-gray-900"
                                  title={r.name}
                                >
                                  {r.name}
                                </span>
                              </div>
                              {r.description && (
                                <p
                                  className="line-clamp-2 text-xs text-gray-500"
                                  title={r.description}
                                >
                                  {r.description}
                                </p>
                              )}
                            </div>
                          </div>
                        </td>
                        <td className="px-4 py-3 text-gray-700">
                          <span className="inline-flex items-center gap-1.5">
                            <Users className="h-4 w-4 text-gray-400" />
                            {r.capacity}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-gray-700">
                          {r.location ? (
                            <span className="inline-flex items-center gap-1.5">
                              <MapPin className="h-4 w-4 text-gray-400" />
                              {r.location}
                            </span>
                          ) : (
                            <span className="text-gray-500">—</span>
                          )}
                        </td>
                        <td className="px-4 py-3">
                          <span
                            className={
                              "rounded-full px-2.5 py-1 text-xs font-semibold " +
                              (r.isActive
                                ? "bg-green-100 text-millenium-green"
                                : "bg-gray-100 text-gray-500")
                            }
                          >
                            {r.isActive ? "Activa" : "Inactiva"}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-right">
                          <div className="flex justify-end gap-1">
                            <button
                              type="button"
                              onClick={() => openEdit(r)}
                              className="flex h-11 w-11 items-center justify-center rounded-md text-gray-500 transition hover:bg-gray-100 hover:text-millenium-blue focus:outline-none focus:ring-2 focus:ring-millenium-blue focus:ring-offset-1"
                              aria-label={`Editar sala: ${r.name}`}
                            >
                              <Edit2 className="h-5 w-5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => handleTogglePower(r)}
                              className={
                                "flex h-11 w-11 items-center justify-center rounded-md transition focus:outline-none focus:ring-2 focus:ring-millenium-blue focus:ring-offset-1 " +
                                (r.isActive
                                  ? "text-gray-500 hover:bg-red-50 hover:text-millenium-red"
                                  : "text-gray-500 hover:bg-green-50 hover:text-millenium-green")
                              }
                              aria-label={
                                r.isActive
                                  ? `Desactivar sala: ${r.name}`
                                  : `Activar sala: ${r.name}`
                              }
                            >
                              <Power className="h-5 w-5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
              </tbody>
            </table>
            </div>
          </>
        )}

        <Modal
          open={modalOpen}
          title={editing ? "Editar sala" : "Nueva sala"}
          size="lg"
          onClose={() => setModalOpen(false)}
          footer={
            <>
              <Button variant="outline" onClick={() => setModalOpen(false)}>
                Cancelar
              </Button>
              <Button
                variant="primary"
                loading={submitting}
                onClick={() => handleSubmit()}
              >
                Guardar
              </Button>
            </>
          }
        >
          <form
            onSubmit={handleSubmit}
            className="flex flex-col gap-5"
          >
            <div>
              <Input
                label="Nombre"
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                maxLength={40}
                required
              />
              <p className="mt-1 text-right text-xs text-gray-500 tabular-nums">
                {form.name.length}/40
              </p>
            </div>

            <Input
              label="Capacidad"
              type="number"
              inputMode="numeric"
              min={1}
              value={form.capacity}
              onChange={(e) =>
                setForm({ ...form, capacity: e.target.value })
              }
              required
            />
            <Input
              label="Ubicación / piso"
              value={form.location}
              onChange={(e) =>
                setForm({ ...form, location: e.target.value })
              }
              placeholder="Ej.: Segundo piso"
            />

            {/* Color picker */}
            <div>
              <span className="label">Color</span>
              <div className="flex flex-wrap gap-2">
                {ROOM_COLORS.map((c) => {
                  const active = form.colorHex === c.hex;
                  return (
                    <button
                      key={c.hex}
                      type="button"
                      onClick={() => setForm({ ...form, colorHex: c.hex })}
                      className={
                        "h-8 w-8 rounded-full border-2 transition focus:outline-none focus:ring-2 focus:ring-millenium-blue/40 focus:ring-offset-1 " +
                        (active
                          ? "scale-110 border-gray-900"
                          : "border-gray-200 hover:border-gray-400")
                      }
                      style={{ backgroundColor: c.hex }}
                      aria-label={c.name}
                      aria-pressed={active}
                      title={c.name}
                    />
                  );
                })}
              </div>
            </div>

            {/* Icon picker */}
            <div>
              <span className="label">Icono</span>
              <div className="grid grid-cols-5 gap-2 sm:grid-cols-10">
                {ROOM_ICONS.map(({ name, component: Icon }) => {
                  const active = form.iconName === name;
                  return (
                    <button
                      key={name}
                      type="button"
                      onClick={() => setForm({ ...form, iconName: name })}
                      className={
                        "flex h-10 w-10 items-center justify-center rounded-lg border transition focus:outline-none focus:ring-2 focus:ring-millenium-blue/40 focus:ring-offset-1 " +
                        (active
                          ? "border-millenium-blue bg-millenium-blue/10 text-millenium-blue"
                          : "border-gray-200 text-gray-600 hover:border-gray-400")
                      }
                      aria-label={name}
                      aria-pressed={active}
                      title={name}
                    >
                      <Icon className="h-5 w-5" />
                    </button>
                  );
                })}
              </div>
            </div>

            <div>
              <Textarea
                label="Descripción"
                value={form.description}
                onChange={(e) =>
                  setForm({ ...form, description: e.target.value })
                }
                maxLength={200}
                rows={3}
                placeholder="Opcional. Hasta 200 caracteres."
              />
              <p className="mt-1 text-right text-xs text-gray-500 tabular-nums">
                {form.description.length}/200
              </p>
            </div>

            {/* Vista previa */}
            <div className="rounded-lg border border-dashed border-gray-300 bg-gray-50 p-3">
              <div className="label">Vista previa</div>
              <div className="flex items-center gap-2">
                {(() => {
                  const PreviewIcon = getRoomIcon(form.iconName);
                  const previewColor = getRoomColor(form.colorHex);
                  return (
                    <span
                      className="inline-flex h-9 w-9 items-center justify-center rounded-lg"
                      style={{ backgroundColor: `${previewColor}26` }}
                    >
                      <PreviewIcon
                        className="h-5 w-5"
                        style={{ color: previewColor }}
                      />
                    </span>
                  );
                })()}
                <span className="font-medium text-gray-900">
                  {form.name || "Nombre de la sala"}
                </span>
              </div>
              {form.description && (
                <p className="mt-2 text-sm text-gray-600">{form.description}</p>
              )}
            </div>
          </form>
        </Modal>

        <Modal
          open={!!confirmingDeactivate}
          title={
            confirmingDeactivate
              ? `¿Desactivar ${confirmingDeactivate.name}?`
              : undefined
          }
          onClose={() => setConfirmingDeactivate(null)}
          actions={
            <>
              <Button
                variant="outline"
                onClick={() => setConfirmingDeactivate(null)}
                disabled={togglingPower}
              >
                Cancelar
              </Button>
              <Button
                variant="danger"
                loading={togglingPower}
                onClick={confirmDeactivate}
              >
                Sí, desactivar
              </Button>
            </>
          }
        >
          <p className="text-base text-gray-700">
            Esta sala dejará de estar disponible para nuevas reuniones. Las
            reuniones existentes no se cancelan automáticamente.
          </p>
        </Modal>
      </div>
    </ProtectedRoute>
  );
}
