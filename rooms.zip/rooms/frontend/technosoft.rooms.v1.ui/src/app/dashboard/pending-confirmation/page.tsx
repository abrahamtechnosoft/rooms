"use client";

import { useCallback, useEffect, useState } from "react";
import { AlertCircle, CheckCircle, Clock } from "lucide-react";
import api from "@/lib/api";
import { toast } from "@/lib/toastHelpers";
import EmptyState from "@/components/EmptyState";
import PageHeader from "@/components/layout/PageHeader";
import { fmtDateTime, fmtTime } from "@/lib/dates";
import type { Reply } from "@/types";

interface PendingItem {
  id: number;
  title: string;
  startsAt: string;
  endsAt: string;
  requestedAt: string | null;
  roomName: string | null;
  roomColor: string | null;
}

function formatRelativeFromNow(iso: string): string {
  const target = new Date(iso).getTime();
  const now = Date.now();
  const diffMs = now - target;
  const diffMin = Math.round(diffMs / 60000);
  if (diffMin < 1) return "hace unos segundos";
  if (diffMin === 1) return "hace 1 minuto";
  if (diffMin < 60) return `hace ${diffMin} minutos`;
  const diffH = Math.round(diffMin / 60);
  if (diffH === 1) return "hace 1 hora";
  return `hace ${diffH} horas`;
}

export default function PendingConfirmationPage() {
  const [items, setItems] = useState<PendingItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [confirmingId, setConfirmingId] = useState<number | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await api.get<Reply<PendingItem[]>>(
        "/reservations/pending-confirmation"
      );
      setItems(res.data.obj || []);
    } catch {
      toast.error("No fue posible cargar las reuniones pendientes");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  async function handleConfirm(id: number) {
    if (confirmingId) return;
    setConfirmingId(id);
    try {
      const res = await api.post<Reply<unknown>>(
        `/reservations/${id}/confirm-usage`
      );
      if (res.data.ok) {
        toast.success(res.data.msg || "Uso confirmado");
        await load();
      } else {
        toast.error(res.data.msg || "No fue posible confirmar");
      }
    } catch (e: unknown) {
      const errObj = e as { response?: { data?: { msg?: string } } };
      toast.error(
        errObj?.response?.data?.msg || "No fue posible confirmar el uso"
      );
    } finally {
      setConfirmingId(null);
    }
  }

  return (
    <div>
      <PageHeader
        title="Reuniones pendientes de confirmar"
        description="Estas reuniones están en curso pero nadie marcó asistencia. Por favor confirma si las estás usando."
      />

      {loading ? (
        <div className="space-y-3">
          {[1, 2, 3].map((i) => (
            <div
              key={i}
              className="h-32 animate-pulse rounded-lg bg-gray-100"
            />
          ))}
        </div>
      ) : items.length === 0 ? (
        <div className="rounded-xl border border-dashed border-gray-300 bg-white">
          <EmptyState
            icon={CheckCircle}
            title="No hay reuniones pendientes"
            description="Todas tus reuniones en curso ya están confirmadas o tienen asistencia marcada."
          />
        </div>
      ) : (
        <div className="space-y-3">
          {items.map((item) => (
            <div
              key={item.id}
              className="flex min-h-30 flex-col rounded-lg border border-amber-200 bg-white p-4 sm:min-h-40"
            >
              <div className="flex items-start gap-3">
                <AlertCircle className="mt-0.5 h-5 w-5 shrink-0 text-amber-600" />
                <div className="min-w-0 flex-1">
                  <h3 className="font-semibold text-gray-900">{item.title}</h3>
                  <p className="mt-0.5 line-clamp-2 wrap-break-word text-sm text-gray-600">
                    {item.roomColor && (
                      <span style={{ color: item.roomColor }}>● </span>
                    )}
                    {item.roomName || "Sala"} ·{" "}
                    {fmtDateTime(item.startsAt)} - {fmtTime(item.endsAt)}
                  </p>
                  <p className="mt-1 flex items-center gap-1 text-xs text-gray-500">
                    <Clock className="h-3 w-3" />
                    Iniciada {formatRelativeFromNow(item.startsAt)} · Sin
                    asistencia marcada
                  </p>
                </div>
              </div>

              <div className="mt-auto pt-4">
                <button
                  type="button"
                  onClick={() => handleConfirm(item.id)}
                  disabled={confirmingId === item.id}
                  className="inline-flex items-center gap-2 rounded-lg bg-millenium-blue px-4 py-2 text-sm font-medium text-white transition hover:bg-millenium-blue/90 disabled:cursor-not-allowed disabled:opacity-50"
                >
                  <CheckCircle className="h-4 w-4" />
                  {confirmingId === item.id
                    ? "Confirmando..."
                    : "Confirmar uso"}
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
