"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { Search, SearchX, Users } from "lucide-react";
import { toast } from "@/lib/toastHelpers";
import api from "@/lib/api";
import { useBackendPolling } from "@/hooks/useBackendPolling";
import { matchesSearch } from "@/lib/stringHelpers";
import type { Department, Person, Reply } from "@/types";
import PageHeader from "@/components/layout/PageHeader";
import PersonCard from "@/components/PersonCard";
import PersonDetailDrawer from "@/components/PersonDetailDrawer";
import EmptyState from "@/components/EmptyState";
import PeopleGridSkeleton from "@/components/skeletons/PeopleGridSkeleton";
import Pagination from "@/components/ui/Pagination";

const ITEMS_PER_PAGE = 30;

type StatusFilter = "all" | "available" | "in_meeting" | "soon";

interface FilterChipProps {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
}

function FilterChip({ active, onClick, children }: FilterChipProps) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={active}
      className={
        "inline-flex shrink-0 items-center whitespace-nowrap rounded-full px-3 py-1.5 text-sm font-medium transition " +
        (active
          ? "bg-millenium-blue text-white"
          : "border border-gray-200 bg-white text-gray-700 hover:border-gray-300")
      }
    >
      {children}
    </button>
  );
}

export default function PeoplePage() {
  const [people, setPeople] = useState<Person[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [loading, setLoading] = useState(false);
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState<StatusFilter>("all");
  const [filterDept, setFilterDept] = useState<number | null>(null);
  const [openId, setOpenId] = useState<number | null>(null);
  const [currentPage, setCurrentPage] = useState(1);

  useEffect(() => {
    let cancelled = false;
    api
      .get<Reply<Department[]>>("/departments")
      .then((res) => {
        if (cancelled) return;
        setDepartments(res.data.obj || []);
      })
      .catch(() => {
        if (!cancelled) setDepartments([]);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await api.get<Reply<Person[]>>("/people");
      setPeople(res.data.obj || []);
    } catch {
      toast.error("No fue posible cargar los colaboradores");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  useBackendPolling(load, 60_000, []);

  const counts = useMemo(() => {
    let available = 0;
    let inMeeting = 0;
    let soon = 0;
    for (const p of people) {
      if (p.status.kind === "in_meeting") inMeeting++;
      else if (p.status.kind === "soon") soon++;
      else available++;
    }
    return { total: people.length, available, inMeeting, soon };
  }, [people]);

  const filtered = useMemo(() => {
    const q = search.trim();
    return people.filter((p) => {
      if (filter !== "all") {
        if (filter === "available" && p.status.kind !== "available")
          return false;
        if (filter === "in_meeting" && p.status.kind !== "in_meeting")
          return false;
        if (filter === "soon" && p.status.kind !== "soon") return false;
      }
      if (filterDept !== null) {
        if (p.departmentId !== filterDept) return false;
      }
      if (q) {
        if (!matchesSearch(p.fullName, q) && !matchesSearch(p.email, q)) {
          return false;
        }
      }
      return true;
    });
  }, [people, search, filter, filterDept]);

  useEffect(() => {
    setCurrentPage(1);
  }, [search, filter, filterDept]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / ITEMS_PER_PAGE));
  const safePage = Math.min(currentPage, totalPages);
  const paginated = filtered.slice(
    (safePage - 1) * ITEMS_PER_PAGE,
    safePage * ITEMS_PER_PAGE
  );

  return (
    <>
      <PageHeader
        title="Colaboradores"
        description="Vea quién está disponible y qué reuniones tienen agendadas."
      />

      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-2">
          <FilterChip
            active={filter === "all"}
            onClick={() => setFilter("all")}
          >
            Todos ({counts.total})
          </FilterChip>
          <FilterChip
            active={filter === "available"}
            onClick={() => setFilter("available")}
          >
            Sin reuniones ({counts.available})
          </FilterChip>
          <FilterChip
            active={filter === "in_meeting"}
            onClick={() => setFilter("in_meeting")}
          >
            En reunión ({counts.inMeeting})
          </FilterChip>
          <FilterChip
            active={filter === "soon"}
            onClick={() => setFilter("soon")}
          >
            Reunión próxima ({counts.soon})
          </FilterChip>
        </div>

        <div className="relative min-w-50 max-w-xs flex-1">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Buscar por nombre o correo"
            aria-label="Buscar colaboradores"
            className="w-full rounded-lg border border-gray-300 bg-white py-2 pl-10 pr-3 text-sm focus:border-millenium-blue focus:outline-none focus:ring-2 focus:ring-millenium-blue/20"
          />
        </div>
      </div>

      {departments.length > 0 && (
        <div
          className="mb-4 -mx-4 overflow-x-auto px-4 sm:mx-0 sm:px-0"
          aria-label="Filtrar por departamento"
        >
        <div className="flex items-center gap-2 whitespace-nowrap pb-1 sm:flex-wrap">
          <button
            type="button"
            onClick={() => setFilterDept(null)}
            aria-pressed={filterDept === null}
            className={
              "inline-flex shrink-0 items-center whitespace-nowrap rounded-full px-3 py-1 text-xs font-medium transition " +
              (filterDept === null
                ? "bg-millenium-blue text-white"
                : "border border-gray-200 bg-white text-gray-700 hover:border-gray-300")
            }
          >
            Todos los departamentos
          </button>
          {departments.map((d) => {
            const active = filterDept === d.id;
            return (
              <button
                key={d.id}
                type="button"
                onClick={() => setFilterDept(active ? null : d.id)}
                aria-pressed={active}
                className={
                  "inline-flex shrink-0 items-center gap-1.5 whitespace-nowrap rounded-full px-3 py-1 text-xs font-medium transition " +
                  (active ? "text-white" : "border bg-white text-gray-700 hover:border-gray-300")
                }
                style={
                  active
                    ? { backgroundColor: d.colorHex || "#475569" }
                    : { borderColor: "#e5e7eb" }
                }
              >
                <span
                  className="inline-block h-1.5 w-1.5 rounded-full"
                  style={{ backgroundColor: d.colorHex || "#475569" }}
                />
                {d.name}
              </button>
            );
          })}
        </div>
        </div>
      )}

      {loading && people.length === 0 ? (
        <PeopleGridSkeleton count={8} />
      ) : filtered.length === 0 ? (
        <div className="rounded-xl border border-dashed border-gray-300 bg-white">
          {search.trim() || filter !== "all" || filterDept !== null ? (
            <EmptyState
              icon={SearchX}
              title="Sin colaboradores"
              description="Intente con otro término de búsqueda o limpie los filtros."
              action={
                <button
                  type="button"
                  onClick={() => {
                    setSearch("");
                    setFilter("all");
                    setFilterDept(null);
                  }}
                  className="text-sm font-medium text-millenium-blue hover:underline"
                >
                  Limpiar filtros
                </button>
              }
            />
          ) : (
            <EmptyState
              icon={Users}
              title="Sin colaboradores"
              description="No hay otros colaboradores disponibles por ahora."
            />
          )}
        </div>
      ) : (
        <>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {paginated.map((p) => (
              <PersonCard
                key={p.id}
                person={p}
                onClick={() => setOpenId(p.id)}
              />
            ))}
          </div>
          <Pagination
            currentPage={safePage}
            totalPages={totalPages}
            onPageChange={setCurrentPage}
            totalItems={filtered.length}
            itemsPerPage={ITEMS_PER_PAGE}
          />
          <div className="pb-8" />
        </>
      )}

      <PersonDetailDrawer
        personId={openId}
        onClose={() => setOpenId(null)}
      />
    </>
  );
}
