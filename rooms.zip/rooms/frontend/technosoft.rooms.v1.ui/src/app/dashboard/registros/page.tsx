"use client";

import { useCallback, useEffect, useState } from "react";
import { ClipboardList, Search } from "lucide-react";
import api from "@/lib/api";
import { toast } from "@/lib/toastHelpers";
import type { Reply } from "@/types";
import PageHeader from "@/components/layout/PageHeader";
import Pagination from "@/components/ui/Pagination";
import EmptyState from "@/components/EmptyState";
import TableSkeleton from "@/components/skeletons/TableSkeleton";
import Avatar from "@/components/Avatar";
import { useAuthStore } from "@/store/authStore";

const PAGE_SIZE = 20;

interface HistoryItem {
  id: number;
  reservationId: number;
  actionType: string;
  actionAt: string;
  details: Record<string, unknown> | null;
  actionById: number;
  actionByName: string | null;
  actionByEmail: string;
  actionByAvatarUrl: string | null;
  reservationTitle: string;
  reservationStartsAt: string;
  reservationType: string;
  reservationStatus: string;
}

interface HistoryResponse {
  items: HistoryItem[];
  total: number;
  page: number;
  pageSize: number;
  hasMore: boolean;
}

const ACTION_OPTIONS: Array<{ value: string; label: string }> = [
  { value: "", label: "Todas las acciones" },
  { value: "created", label: "Creación" },
  { value: "rescheduled", label: "Reagendado" },
  { value: "room_changed", label: "Cambio de sala" },
  { value: "title_changed", label: "Título actualizado" },
  { value: "link_changed", label: "Enlace actualizado" },
  { value: "modality_changed", label: "Cambio de modalidad" },
  { value: "cancelled", label: "Cancelación" },
  { value: "cancelled_in_progress", label: "Cancelación en curso" },
  { value: "ended_early", label: "Terminada antes" },
  { value: "participant_cancelled", label: "Participante canceló" },
  { value: "invitation_accepted", label: "Invitación aceptada" },
  { value: "invitation_rejected", label: "Invitación rechazada" },
];

function actionLabel(action: string): string {
  const found = ACTION_OPTIONS.find((o) => o.value === action);
  return found && found.value ? found.label : action;
}

function formatDateTime(iso: string): string {
  const d = new Date(iso);
  return d.toLocaleString("es", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

function ActionChip({ type }: { type: string }) {
  const palette: Record<string, string> = {
    created: "bg-green-50 text-green-700 border-green-200",
    rescheduled: "bg-blue-50 text-blue-700 border-blue-200",
    room_changed: "bg-blue-50 text-blue-700 border-blue-200",
    title_changed: "bg-gray-50 text-gray-700 border-gray-200",
    link_changed: "bg-gray-50 text-gray-700 border-gray-200",
    modality_changed: "bg-blue-50 text-blue-700 border-blue-200",
    cancelled: "bg-red-50 text-red-700 border-red-200",
    cancelled_in_progress: "bg-red-50 text-red-700 border-red-200",
    ended_early: "bg-amber-50 text-amber-700 border-amber-200",
    participant_cancelled: "bg-orange-50 text-orange-700 border-orange-200",
    invitation_accepted: "bg-green-50 text-green-700 border-green-200",
    invitation_rejected: "bg-orange-50 text-orange-700 border-orange-200",
  };
  const cls = palette[type] || "bg-gray-50 text-gray-700 border-gray-200";
  return (
    <span
      className={`inline-flex items-center rounded-full border px-2 py-0.5 text-xs font-medium ${cls}`}
    >
      {actionLabel(type)}
    </span>
  );
}

export default function RegistrosPage() {
  const user = useAuthStore((s) => s.user);
  const isAdmin = user?.role === "admin";

  const [items, setItems] = useState<HistoryItem[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(true);

  const [search, setSearch] = useState("");
  const [action, setAction] = useState("");

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await api.get<Reply<HistoryResponse>>(
        "/reservations/history",
        {
          params: {
            page,
            pageSize: PAGE_SIZE,
            search: search.trim() || undefined,
            action: action || undefined,
          },
        }
      );
      const data = res.data.obj;
      if (data) {
        setItems(data.items);
        setTotal(data.total);
      } else {
        setItems([]);
        setTotal(0);
      }
    } catch {
      toast.error("No fue posible cargar los registros");
      setItems([]);
      setTotal(0);
    } finally {
      setLoading(false);
    }
  }, [page, search, action]);

  useEffect(() => {
    load();
  }, [load]);

  // Reset a página 1 al cambiar cualquier filtro.
  useEffect(() => {
    setPage(1);
  }, [search, action]);

  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));

  return (
    <div>
      <PageHeader
        title={isAdmin ? "Registros del sistema" : "Mi actividad"}
        description={
          isAdmin
            ? "Historial completo de acciones en reuniones."
            : "Tus acciones y eventos relacionados con tus reuniones."
        }
      />

      <div className="mb-4 flex flex-wrap items-center gap-2">
        <div className="relative max-w-sm flex-1">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Buscar por título o usuario"
            className="w-full rounded-lg border border-gray-300 bg-white py-2 pl-10 pr-3 text-sm focus:border-millenium-blue focus:outline-none focus:ring-2 focus:ring-millenium-blue/20"
          />
        </div>
        <select
          value={action}
          onChange={(e) => setAction(e.target.value)}
          className="rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm focus:border-millenium-blue focus:outline-none focus:ring-2 focus:ring-millenium-blue/20"
        >
          {ACTION_OPTIONS.map((o) => (
            <option key={o.value} value={o.value}>
              {o.label}
            </option>
          ))}
        </select>
      </div>

      {loading ? (
        <TableSkeleton rows={8} columns={4} />
      ) : items.length === 0 ? (
        <div className="rounded-xl border border-dashed border-gray-300 bg-white">
          <EmptyState
            icon={ClipboardList}
            title="Sin registros"
            description={
              search || action
                ? "No hay eventos que coincidan con los filtros."
                : isAdmin
                  ? "Aún no hay actividad registrada."
                  : "Aún no tienes actividad registrada."
            }
          />
        </div>
      ) : (
        <>
          {/* Mobile: cards */}
          <ul className="space-y-2 md:hidden">
            {items.map((item) => (
              <li
                key={item.id}
                className="rounded-lg border border-gray-200 bg-white p-3 shadow-sm"
              >
                <div className="mb-2 flex items-start justify-between gap-2">
                  <div className="min-w-0 flex-1">
                    <div className="text-xs text-gray-500">
                      {formatDateTime(item.actionAt)}
                    </div>
                    <div className="mt-0.5 text-sm font-semibold text-gray-900 wrap-break-word">
                      {item.reservationTitle}
                    </div>
                  </div>
                  <ActionChip type={item.actionType} />
                </div>
                <div className="flex items-center gap-2 border-t border-gray-100 pt-2">
                  <Avatar
                    name={item.actionByName}
                    email={item.actionByEmail}
                    avatarUrl={item.actionByAvatarUrl}
                    size="sm"
                    className="h-6 w-6"
                  />
                  <span className="truncate text-xs text-gray-700">
                    {item.actionByName || item.actionByEmail}
                  </span>
                </div>
              </li>
            ))}
          </ul>

          {/* Desktop: tabla */}
          <div className="hidden overflow-x-auto rounded-lg border border-gray-200 bg-white md:block">
            <table className="w-full min-w-[640px]">
              <thead className="border-b border-gray-200 bg-gray-50">
                <tr>
                  <th scope="col" className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-600">
                    Fecha
                  </th>
                  <th scope="col" className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-600">
                    Acción
                  </th>
                  <th scope="col" className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-600">
                    Reunión
                  </th>
                  <th scope="col" className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-600">
                    Por
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {items.map((item) => (
                  <tr key={item.id} className="h-14 hover:bg-gray-50">
                    <td className="whitespace-nowrap px-4 text-sm text-gray-600">
                      {formatDateTime(item.actionAt)}
                    </td>
                    <td className="px-4 text-sm">
                      <ActionChip type={item.actionType} />
                    </td>
                    <td className="max-w-md truncate px-4 text-sm text-gray-900">
                      {item.reservationTitle}
                    </td>
                    <td className="px-4 text-sm">
                      <div className="flex items-center gap-2">
                        <Avatar
                          name={item.actionByName}
                          email={item.actionByEmail}
                          avatarUrl={item.actionByAvatarUrl}
                          size="sm"
                          className="h-6 w-6"
                        />
                        <span className="truncate text-gray-700">
                          {item.actionByName || item.actionByEmail}
                        </span>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <Pagination
            currentPage={page}
            totalPages={totalPages}
            onPageChange={setPage}
            totalItems={total}
            itemsPerPage={PAGE_SIZE}
          />
        </>
      )}
    </div>
  );
}
