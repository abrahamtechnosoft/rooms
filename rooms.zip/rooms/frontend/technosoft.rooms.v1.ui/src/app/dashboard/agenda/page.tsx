"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { Bell, Plus, StickyNote } from "lucide-react";
import api from "@/lib/api";
import { toast } from "@/lib/toastHelpers";
import { useAuthStore } from "@/store/authStore";
import EmptyState from "@/components/EmptyState";
import NoteCard from "@/components/NoteCard";
import NoteFormModal from "@/components/NoteFormModal";
import ReminderFormModal from "@/components/agenda/ReminderFormModal";
import NotificationPermissionBanner from "@/components/agenda/NotificationPermissionBanner";
import { fmtDateTime } from "@/lib/dates";
import { emitWidgetEvent } from "@/lib/widgetEvents";
import type {
  NoteVisibility,
  Reply,
  UserNote,
  UserReminder,
} from "@/types";

export default function AgendaPage() {
  const { user } = useAuthStore();
  const currentUserId = user?.id ?? null;
  const currentUserDeptId = user?.departmentId ?? null;

  const [reminders, setReminders] = useState<UserReminder[]>([]);
  const [notes, setNotes] = useState<UserNote[]>([]);
  const [loadingReminders, setLoadingReminders] = useState(true);
  const [loadingNotes, setLoadingNotes] = useState(true);
  const [creatingReminder, setCreatingReminder] = useState(false);
  const [editingReminder, setEditingReminder] = useState<UserReminder | null>(
    null
  );
  const [creatingNote, setCreatingNote] = useState<NoteVisibility | null>(null);
  const [editingNote, setEditingNote] = useState<UserNote | null>(null);
  const [noteTab, setNoteTab] = useState<NoteVisibility>("personal");

  const loadReminders = useCallback(async () => {
    setLoadingReminders(true);
    try {
      const r = await api.get<Reply<UserReminder[]>>("/reminders");
      setReminders(r.data.obj || []);
    } catch {
      toast.error("No fue posible cargar los recordatorios");
    } finally {
      setLoadingReminders(false);
    }
  }, []);

  const loadNotes = useCallback(async () => {
    setLoadingNotes(true);
    try {
      const r = await api.get<Reply<UserNote[]>>("/notes");
      setNotes(r.data.obj || []);
    } catch {
      toast.error("No fue posible cargar las notas");
    } finally {
      setLoadingNotes(false);
    }
  }, []);

  useEffect(() => {
    loadReminders();
    loadNotes();
  }, [loadReminders, loadNotes]);

  const pendingReminders = useMemo(
    () =>
      reminders
        .filter((r) => !r.isDone)
        .sort(
          (a, b) =>
            new Date(a.remindAt).getTime() - new Date(b.remindAt).getTime()
        ),
    [reminders]
  );

  const filteredNotes = useMemo(
    () =>
      notes.filter((n) =>
        noteTab === "personal"
          ? n.visibility === "personal"
          : n.visibility === "department"
      ),
    [notes, noteTab]
  );

  return (
    <div className="flex h-full flex-col">
      <div className="mb-4">
        <h1 className="text-2xl font-bold tracking-tight text-gray-900">
          Agenda
        </h1>
        <p className="mt-0.5 text-sm text-gray-500">
          Tus recordatorios y notas personales.
        </p>
      </div>

      <div className="mb-4">
        <NotificationPermissionBanner />
      </div>

      <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
        {/* Recordatorios */}
        <section className="rounded-lg border border-gray-200 bg-white">
          <div className="flex flex-col gap-2 border-b border-gray-100 px-4 py-3 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex items-center gap-2">
              <Bell className="h-4 w-4 text-amber-500" aria-hidden="true" />
              <h2 className="text-base font-semibold text-gray-900">
                Recordatorios
              </h2>
              <span className="text-xs text-gray-500">
                ({pendingReminders.length})
              </span>
            </div>
            <button
              type="button"
              onClick={() => setCreatingReminder(true)}
              className="inline-flex items-center justify-center gap-1 self-end rounded-md bg-millenium-blue px-2.5 py-1.5 text-xs font-medium text-white transition hover:opacity-90 sm:self-auto"
              title="Nuevo recordatorio"
            >
              <Plus className="h-3 w-3" aria-hidden="true" />
              Nuevo
            </button>
          </div>
          <div className="p-3">
            {loadingReminders ? (
              <div className="space-y-2">
                <div className="h-12 animate-pulse rounded bg-gray-100" />
                <div className="h-12 animate-pulse rounded bg-gray-100" />
              </div>
            ) : pendingReminders.length === 0 ? (
              <EmptyState
                icon={Bell}
                title="Sin recordatorios"
                description="Crea el primero con el botón Nuevo."
                compact
              />
            ) : (
              <ul className="divide-y divide-gray-100">
                {pendingReminders.map((r) => (
                  <ReminderRow
                    key={r.reminderId}
                    reminder={r}
                    onEdit={() => setEditingReminder(r)}
                    onChanged={loadReminders}
                  />
                ))}
              </ul>
            )}
          </div>
        </section>

        {/* Notas */}
        <section className="rounded-lg border border-gray-200 bg-white">
          <div className="flex flex-col gap-2 border-b border-gray-100 px-4 py-3 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex items-center gap-2">
              <StickyNote className="h-4 w-4 text-millenium-blue" aria-hidden="true" />
              <h2 className="text-base font-semibold text-gray-900">Notas</h2>
              <span className="text-xs text-gray-500">
                ({filteredNotes.length})
              </span>
            </div>
            <div className="flex items-center justify-end gap-2 sm:justify-start">
              <div
                role="tablist"
                aria-label="Filtro de notas"
                className="flex rounded-md bg-gray-100 p-0.5"
              >
                <button
                  type="button"
                  role="tab"
                  id="notes-personal-tab"
                  aria-selected={noteTab === "personal"}
                  aria-controls="notes-personal-panel"
                  tabIndex={noteTab === "personal" ? 0 : -1}
                  onClick={() => setNoteTab("personal")}
                  onKeyDown={(e) => {
                    if (e.key === "ArrowRight" || e.key === "ArrowLeft") {
                      e.preventDefault();
                      if (currentUserDeptId) setNoteTab("department");
                    }
                  }}
                  className={
                    "rounded px-2.5 py-1.5 text-xs font-medium transition-colors sm:py-1 " +
                    (noteTab === "personal"
                      ? "bg-white text-gray-900 shadow-sm"
                      : "text-gray-500 hover:text-gray-700")
                  }
                >
                  Mis
                </button>
                <button
                  type="button"
                  role="tab"
                  id="notes-department-tab"
                  aria-selected={noteTab === "department"}
                  aria-controls="notes-department-panel"
                  tabIndex={noteTab === "department" ? 0 : -1}
                  onClick={() => setNoteTab("department")}
                  onKeyDown={(e) => {
                    if (e.key === "ArrowRight" || e.key === "ArrowLeft") {
                      e.preventDefault();
                      setNoteTab("personal");
                    }
                  }}
                  disabled={!currentUserDeptId}
                  className={
                    "rounded px-2.5 py-1.5 text-xs font-medium transition-colors disabled:cursor-not-allowed disabled:opacity-40 sm:py-1 " +
                    (noteTab === "department"
                      ? "bg-white text-gray-900 shadow-sm"
                      : "text-gray-500 hover:text-gray-700")
                  }
                  title={
                    !currentUserDeptId
                      ? "Sin departamento asignado"
                      : undefined
                  }
                >
                  Departamento
                </button>
              </div>
              <button
                type="button"
                onClick={() => setCreatingNote(noteTab)}
                disabled={noteTab === "department" && !currentUserDeptId}
                className="inline-flex items-center gap-1 whitespace-nowrap rounded-md bg-millenium-blue px-2.5 py-1.5 text-xs font-medium text-white transition hover:opacity-90 disabled:cursor-not-allowed disabled:opacity-50"
                title="Nueva nota"
              >
                <Plus className="h-3 w-3" aria-hidden="true" />
                Nueva
              </button>
            </div>
          </div>
          <div
            role="tabpanel"
            id={
              noteTab === "personal"
                ? "notes-personal-panel"
                : "notes-department-panel"
            }
            aria-labelledby={
              noteTab === "personal"
                ? "notes-personal-tab"
                : "notes-department-tab"
            }
            className="space-y-2 p-3"
          >
            {loadingNotes ? (
              <>
                <div className="h-20 animate-pulse rounded bg-gray-100" />
                <div className="h-20 animate-pulse rounded bg-gray-100" />
              </>
            ) : filteredNotes.length === 0 ? (
              <EmptyState
                icon={StickyNote}
                title={
                  noteTab === "personal"
                    ? "Sin notas personales"
                    : "Sin notas del área"
                }
                description={
                  noteTab === "department" && !currentUserDeptId
                    ? "Pide a un administrador que te asigne un departamento."
                    : "Crea la primera con el botón Nueva."
                }
                compact
              />
            ) : (
              filteredNotes.map((n) => (
                <NoteCard
                  key={n.noteId}
                  note={n}
                  isOwn={n.authorId === currentUserId}
                  showAuthor={noteTab === "department"}
                  onEdit={() => setEditingNote(n)}
                  onChanged={loadNotes}
                />
              ))
            )}
          </div>
        </section>
      </div>

      {(creatingReminder || editingReminder) && (
        <ReminderFormModal
          reminder={editingReminder}
          onSaved={() => {
            setCreatingReminder(false);
            setEditingReminder(null);
            loadReminders();
          }}
          onCancel={() => {
            setCreatingReminder(false);
            setEditingReminder(null);
          }}
        />
      )}

      {(creatingNote || editingNote) && (
        <NoteFormModal
          note={editingNote}
          defaultVisibility={
            creatingNote ?? (editingNote ? editingNote.visibility : "personal")
          }
          canCreateDept={!!currentUserDeptId}
          onSaved={() => {
            setCreatingNote(null);
            setEditingNote(null);
            loadNotes();
          }}
          onCancel={() => {
            setCreatingNote(null);
            setEditingNote(null);
          }}
        />
      )}
    </div>
  );
}

function ReminderRow({
  reminder,
  onEdit,
  onChanged,
}: {
  reminder: UserReminder;
  onEdit: () => void;
  onChanged: () => void;
}) {
  const [busy, setBusy] = useState(false);
  const handleDone = async () => {
    if (busy) return;
    setBusy(true);
    try {
      await api.put(`/reminders/${reminder.reminderId}`, { isDone: true });
      onChanged();
      emitWidgetEvent("reminders:changed");
    } catch {
      toast.error("No fue posible marcar como hecho");
    } finally {
      setBusy(false);
    }
  };
  const handleDelete = async () => {
    if (busy) return;
    setBusy(true);
    try {
      await api.delete(`/reminders/${reminder.reminderId}`);
      onChanged();
      emitWidgetEvent("reminders:changed");
    } catch {
      toast.error("No fue posible eliminar");
    } finally {
      setBusy(false);
    }
  };
  return (
    <li className="group flex items-start gap-3 py-2.5">
      <Bell className="mt-0.5 h-4 w-4 shrink-0 text-amber-500" />
      <div className="min-w-0 flex-1">
        <div className="text-sm font-medium text-gray-900">{reminder.title}</div>
        {reminder.content && (
          <div className="mt-0.5 whitespace-pre-wrap text-xs text-gray-600">
            {reminder.content}
          </div>
        )}
        <div className="mt-1 text-xs text-gray-500 tabular-nums">
          {fmtDateTime(reminder.remindAt)}
        </div>
      </div>
      <div className="flex shrink-0 items-center gap-1 opacity-100 transition-opacity md:opacity-0 md:group-hover:opacity-100 md:group-focus-within:opacity-100">
        <button
          type="button"
          onClick={handleDone}
          disabled={busy}
          className="rounded px-2 py-1 text-xs font-medium text-green-700 hover:bg-green-50 disabled:opacity-50"
        >
          Hecho
        </button>
        <button
          type="button"
          onClick={onEdit}
          disabled={busy}
          className="rounded px-2 py-1 text-xs font-medium text-gray-600 hover:bg-gray-100 disabled:opacity-50"
        >
          Editar
        </button>
        <button
          type="button"
          onClick={handleDelete}
          disabled={busy}
          className="rounded px-2 py-1 text-xs font-medium text-millenium-red hover:bg-red-50 disabled:opacity-50"
        >
          Eliminar
        </button>
      </div>
    </li>
  );
}
