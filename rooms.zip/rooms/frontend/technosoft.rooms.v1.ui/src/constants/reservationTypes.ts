export const RESERVATION_TYPES = {
  PHYSICAL: "physical",
  VIRTUAL: "virtual",
  EXTERNAL: "external",
  OFFICE: "office",
} as const;

export type ReservationType =
  (typeof RESERVATION_TYPES)[keyof typeof RESERVATION_TYPES];

export const EXTERNAL_SUBTYPES = {
  CLIENT: "client",
  EVENT: "event",
  TRAINING: "training",
  OTHER: "other",
} as const;

export type ExternalSubtype =
  (typeof EXTERNAL_SUBTYPES)[keyof typeof EXTERNAL_SUBTYPES];

export const EXTERNAL_SUBTYPE_LABELS: Record<ExternalSubtype, string> = {
  client: "Reunión con cliente",
  event: "Evento / Conferencia",
  training: "Capacitación externa",
  other: "Otro",
};

export const EXTERNAL_SUBTYPE_ORDER: ExternalSubtype[] = [
  "client",
  "event",
  "training",
  "other",
];

export const VIRTUAL_PLATFORMS = ["meet", "zoom", "teams", "other"] as const;
export type VirtualPlatform = (typeof VIRTUAL_PLATFORMS)[number];

export const VIRTUAL_PLATFORM_LABELS: Record<VirtualPlatform, string> = {
  meet: "Google Meet",
  zoom: "Zoom",
  teams: "Microsoft Teams",
  other: "Otra plataforma",
};
