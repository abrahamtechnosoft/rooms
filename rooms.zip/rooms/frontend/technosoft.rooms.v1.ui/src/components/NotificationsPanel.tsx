"use client";

import { Fragment, useEffect, useMemo, useRef } from "react";
import {
  BellOff,
  Calendar,
  CheckCircle,
  Clock,
  Edit,
  FileText,
  MessageSquare,
  Paperclip,
  Reply as ReplyIcon,
  UserPlus,
  XCircle,
} from "lucide-react";
import type { AppNotification, NotificationType } from "@/types";
import EmptyState from "@/components/EmptyState";

interface Props {
  notifications: AppNotification[];
  loading: boolean;
  onClose: () => void;
  onItemClick: (n: AppNotification) => void;
  onMarkAllRead?: () => void;
}

function iconFor(type: NotificationType) {
  switch (type) {
    case "invited":
      return <UserPlus className="h-5 w-5 text-millenium-green" />;
    case "rescheduled":
      return <Clock className="h-5 w-5 text-orange-500" />;
    case "updated":
      return <Edit className="h-5 w-5 text-millenium-blue" />;
    case "cancelled":
      return <XCircle className="h-5 w-5 text-millenium-red" />;
    case "participant_cancelled":
      return <XCircle className="h-5 w-5 text-orange-500" />;
    case "attachment_added":
      return <Paperclip className="h-5 w-5 text-gray-500" />;
    case "invitation_blocked":
      return <Calendar className="h-5 w-5 text-amber-600" />;
    case "invitation_responded":
      return <CheckCircle className="h-5 w-5 text-millenium-blue" />;
    case "note_added":
      return <MessageSquare className="h-5 w-5 text-millenium-blue" />;
    case "note_reply":
      return <ReplyIcon className="h-5 w-5 text-millenium-blue" />;
    case "summary_updated":
      return <FileText className="h-5 w-5 text-millenium-green" />;
    default:
      return <Edit className="h-5 w-5 text-gray-400" />;
  }
}

function formatRelativeTime(iso: string): string {
  const date = new Date(iso);
  const diffMs = Date.now() - date.getTime();
  const diffMin = Math.floor(diffMs / 60000);
  const diffHr = Math.floor(diffMin / 60);
  const diffDay = Math.floor(diffHr / 24);

  if (diffMin < 1) return "Hace un momento";
  if (diffMin < 60)
    return `Hace ${diffMin} ${diffMin === 1 ? "minuto" : "minutos"}`;
  if (diffHr < 24) return `Hace ${diffHr} ${diffHr === 1 ? "hora" : "horas"}`;
  if (diffDay < 7) return `Hace ${diffDay} ${diffDay === 1 ? "día" : "días"}`;
  return date.toLocaleDateString("es", { day: "numeric", month: "short" });
}

export default function NotificationsPanel({
  notifications,
  loading,
  onClose,
  onItemClick,
  onMarkAllRead,
}: Props) {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const onClickOutside = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        onClose();
      }
    };
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    document.addEventListener("mousedown", onClickOutside);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("mousedown", onClickOutside);
      document.removeEventListener("keydown", onKey);
    };
  }, [onClose]);

  // No leídas primero (por createdAt desc), luego leídas (por readAt desc).
  const ordered = useMemo(() => {
    return [...notifications].sort((a, b) => {
      if (a.isRead !== b.isRead) return a.isRead ? 1 : -1;
      if (!a.isRead && !b.isRead) {
        return (
          new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
        );
      }
      return (
        new Date(b.readAt || b.createdAt).getTime() -
        new Date(a.readAt || a.createdAt).getTime()
      );
    });
  }, [notifications]);

  const firstReadIdx = ordered.findIndex((n) => n.isRead);

  return (
    <div
      ref={ref}
      role="menu"
      className="absolute right-0 z-50 mt-2 max-h-[28rem] w-80 overflow-y-auto rounded-xl border border-gray-200 bg-white shadow-xl sm:w-96"
    >
      <div className="border-b border-gray-100 px-4 py-3">
        <p className="text-base font-semibold text-gray-900">Notificaciones</p>
      </div>

      {loading && notifications.length === 0 ? (
        <ul className="divide-y divide-gray-100">
          {[0, 1, 2].map((i) => (
            <li
              key={i}
              className="flex items-start gap-3 px-4 py-3"
            >
              <span className="h-5 w-5 shrink-0 rounded-full animate-shimmer" />
              <div className="min-w-0 flex-1 space-y-1.5">
                <span className="block h-3.5 w-3/4 animate-shimmer" />
                <span className="block h-3 w-1/2 animate-shimmer" />
                <span className="block h-2.5 w-16 animate-shimmer" />
              </div>
            </li>
          ))}
        </ul>
      ) : notifications.length === 0 ? (
        <EmptyState
          icon={BellOff}
          title="Sin notificaciones"
          description="Le avisaremos cuando haya algo nuevo."
        />
      ) : (
        <ul>
          {ordered.map((n, idx) => (
            <Fragment key={n.id}>
              {idx === firstReadIdx && firstReadIdx > 0 && (
                <li className="bg-gray-50 px-4 py-1.5 text-xs uppercase tracking-wide text-gray-400">
                  Leídas
                </li>
              )}
              <li className="animate-fadeIn">
                <button
                  type="button"
                  role="menuitem"
                  onClick={() => onItemClick(n)}
                  className={
                    "flex w-full items-start gap-3 px-4 py-3 text-left transition hover:bg-gray-50 focus:bg-gray-100 focus:outline-none " +
                    (!n.isRead ? "bg-blue-50/40" : "opacity-70")
                  }
                >
                  <span className="mt-0.5 shrink-0">{iconFor(n.type)}</span>
                  <span className="min-w-0 flex-1">
                    <span
                      className={
                        "block text-sm " +
                        (n.isRead
                          ? "text-gray-700"
                          : "font-medium text-gray-900")
                      }
                    >
                      {n.title}
                    </span>
                    {n.body && (
                      <span className="mt-0.5 block truncate text-xs text-gray-600">
                        {n.body}
                      </span>
                    )}
                    <span className="mt-1 block text-xs text-gray-400">
                      {formatRelativeTime(n.createdAt)}
                    </span>
                  </span>
                  {!n.isRead && (
                    <span
                      className="mt-1.5 h-2 w-2 shrink-0 rounded-full bg-millenium-blue"
                      aria-hidden
                    />
                  )}
                </button>
              </li>
            </Fragment>
          ))}
        </ul>
      )}

      {onMarkAllRead && notifications.some((n) => !n.isRead) && (
        <button
          type="button"
          onClick={onMarkAllRead}
          className="w-full border-t border-gray-100 px-3 py-2 text-sm text-gray-500 transition hover:bg-gray-50 hover:text-gray-900 focus:bg-gray-50 focus:outline-none"
        >
          Marcar todas como leídas
        </button>
      )}
    </div>
  );
}
