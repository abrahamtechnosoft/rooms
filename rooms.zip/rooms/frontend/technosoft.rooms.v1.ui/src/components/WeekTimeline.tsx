"use client";

import { useMemo, useState } from "react";
import { Plus } from "lucide-react";
import type { Reservation } from "@/types";
import {
  computeOverlapLayout,
  type OverlapItem,
  type OverlapLayout,
} from "@/lib/timelineLayout";
import OverflowPopover from "@/components/OverflowPopover";
import OverlapGroup from "@/components/OverlapGroup";
import { effectiveEndsAt } from "@/lib/reservationStatus";
import { useNowTick } from "@/hooks/useNowTick";
import { useAuthStore } from "@/store/authStore";

interface SlotPick {
  date: string;
  hour: number;
  minute: number;
}

interface Props {
  startOfWeek: Date;
  reservations: Reservation[];
  /** Cuando es false, oculta sabado y domingo. Default false. */
  showWeekends?: boolean;
  onReservationClick: (r: Reservation) => void;
  onEmptySlotClick?: (slot: SlotPick) => void;
}

const OPEN_HOUR = 8;
const CLOSE_HOUR = 17;
const TOTAL_HOURS = CLOSE_HOUR - OPEN_HOUR;
const TOTAL_MINUTES = TOTAL_HOURS * 60;
const SLOT_MIN = 30;
const TOTAL_SLOTS = TOTAL_MINUTES / SLOT_MIN;
const HOUR_HEIGHT_PX = 140;

const pad = (n: number) => String(n).padStart(2, "0");

const sameDay = (a: Date, b: Date) =>
  a.getFullYear() === b.getFullYear() &&
  a.getMonth() === b.getMonth() &&
  a.getDate() === b.getDate();

const pctFromHours = (h: number) =>
  ((Math.max(OPEN_HOUR, Math.min(CLOSE_HOUR, h)) - OPEN_HOUR) / TOTAL_HOURS) *
  100;

const DAY_LABELS = ["Lun", "Mar", "Mié", "Jue", "Vie", "Sáb", "Dom"];

interface GroupedItems {
  groupId: string;
  items: OverlapItem[];
}

function groupByGroupId(layout: OverlapLayout): GroupedItems[] {
  const map = new Map<string, OverlapItem[]>();
  for (const it of layout.items) {
    const arr = map.get(it.groupId);
    if (arr) arr.push(it);
    else map.set(it.groupId, [it]);
  }
  return Array.from(map.entries()).map(([groupId, items]) => ({
    groupId,
    items,
  }));
}

export default function WeekTimeline({
  startOfWeek,
  reservations,
  showWeekends = false,
  onReservationClick,
  onEmptySlotClick,
}: Props) {
  const me = useAuthStore((s) => s.user);
  const currentUserId = me?.id ?? null;

  const numDays = showWeekends ? 7 : 5;

  const days = useMemo(() => {
    const out: Date[] = [];
    for (let i = 0; i < numDays; i++) {
      const d = new Date(startOfWeek);
      d.setDate(d.getDate() + i);
      d.setHours(0, 0, 0, 0);
      out.push(d);
    }
    return out;
  }, [startOfWeek, numDays]);

  // Tick local cada 1s: línea "ahora" suave en la vista semanal.
  const now = useNowTick(1000);
  const nowH = now.getHours() + now.getMinutes() / 60;
  const showNowLine =
    days.some((d) => sameDay(d, now)) && nowH >= OPEN_HOUR && nowH <= CLOSE_HOUR;
  const nowPercent = pctFromHours(nowH);
  const nowLabel = `${pad(now.getHours())}:${pad(now.getMinutes())}`;
  const todayIndex = days.findIndex((d) => sameDay(d, now));

  // Reuniones agrupadas por día visible. Si `showWeekends=false`, las que
  // caigan en sabado o domingo NO se agrupan y por tanto NO se renderizan
  // en el calendario semanal (siguen disponibles en Mis Reuniones).
  const meetingsByDay = useMemo(() => {
    const buckets: Reservation[][] = Array.from({ length: numDays }, () => []);
    for (const r of reservations) {
      if (r.status !== "active") continue;
      const start = new Date(r.startsAt);
      for (let i = 0; i < numDays; i++) {
        if (sameDay(start, days[i])) {
          buckets[i].push(r);
          break;
        }
      }
    }
    return buckets;
  }, [reservations, days, numDays]);

  const layoutByDay = useMemo(
    () =>
      meetingsByDay.map((day) =>
        computeOverlapLayout(day, currentUserId, {
          openHour: OPEN_HOUR,
          closeHour: CLOSE_HOUR,
        })
      ),
    [meetingsByDay, currentUserId]
  );

  const groupedByDay = useMemo(
    () => layoutByDay.map((layout) => groupByGroupId(layout)),
    [layoutByDay]
  );

  const [overflowPopover, setOverflowPopover] = useState<{
    meetings: Reservation[];
    anchorRect: DOMRect;
  } | null>(null);

  const HALF_STEPS = TOTAL_HOURS * 2;
  const labelMarks = Array.from({ length: HALF_STEPS }, (_, i) => {
    const hour = OPEN_HOUR + Math.floor(i / 2);
    const minute = (i % 2) * 30;
    return {
      label: `${pad(hour)}:${pad(minute)}`,
      pct: (i / HALF_STEPS) * 100,
      isHour: minute === 0,
    };
  });
  labelMarks.push({
    label: `${pad(CLOSE_HOUR)}:00`,
    pct: 100,
    isHour: true,
  });

  const hourLines = Array.from({ length: TOTAL_HOURS + 1 }, (_, i) => ({
    pct: (i / TOTAL_HOURS) * 100,
  }));

  return (
    <div
      className="flex h-full flex-col overflow-hidden rounded-xl border border-gray-200 bg-white shadow-sm"
      style={{ minHeight: `${HOUR_HEIGHT_PX * TOTAL_HOURS + 160}px` }}
    >
      {/* Header sticky con días */}
      <div className="sticky top-0 z-30 grid shrink-0 border-b border-gray-200 bg-white"
           style={{ gridTemplateColumns: `5rem repeat(${numDays}, minmax(0, 1fr))` }}>
        <div className="border-r border-gray-200 px-2 py-3" />
        {days.map((d, i) => {
          const isToday = sameDay(d, now);
          return (
            <div
              key={i}
              className={
                "flex flex-col items-center justify-center gap-0.5 border-r border-gray-200 px-3 py-3 last:border-r-0 " +
                (isToday ? "bg-millenium-blue/10" : "")
              }
            >
              <span
                className={
                  "text-xs font-semibold uppercase tracking-wide " +
                  (isToday ? "text-millenium-blue" : "text-gray-500")
                }
              >
                {DAY_LABELS[i]}
              </span>
              <span
                className={
                  "text-lg font-bold leading-none tabular-nums " +
                  (isToday ? "text-millenium-blue" : "text-gray-900")
                }
              >
                {d.getDate()}
              </span>
            </div>
          );
        })}
      </div>

      <div className="flex min-h-0 flex-1 overflow-auto">
        <div
          className="relative grid w-full min-w-160"
          style={{
            gridTemplateColumns: `5rem repeat(${numDays}, minmax(0, 1fr))`,
            minHeight: `${HOUR_HEIGHT_PX * TOTAL_HOURS}px`,
          }}
        >
          {/* Columna de horas */}
          <div className="relative border-r border-gray-200 pt-4 pb-8">
            {labelMarks.map((m) => (
              <span
                key={m.label}
                className={
                  "absolute right-2 -mt-1 leading-none tabular-nums " +
                  (m.isHour
                    ? "text-sm font-semibold text-gray-700"
                    : "text-xs text-gray-500")
                }
                style={{ top: `calc(1rem + ${m.pct}% * (100% - 3rem) / 100%)` }}
              >
                {m.label}
              </span>
            ))}
          </div>

          {/* Columnas de días */}
          {days.map((d, dayIdx) => {
            const dayMeetings = meetingsByDay[dayIdx];
            const groups = groupedByDay[dayIdx];
            const ymd = `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
            const isToday = sameDay(d, now);

            return (
              <div
                key={dayIdx}
                className={
                  "relative border-r border-gray-200 last:border-r-0 " +
                  (isToday ? "bg-millenium-blue/2.5" : "")
                }
              >
                {/* Grilla interior posicionada absoluta */}
                <div
                  className="relative h-full w-full"
                  style={{ paddingTop: "1rem", paddingBottom: "2rem" }}
                >
                  <div className="relative h-full w-full">
                    {/* Líneas de hora */}
                    {hourLines.map((l, i) => (
                      <div
                        key={i}
                        className="absolute left-0 right-0 z-0 border-t border-gray-200"
                        style={{ top: `${l.pct}%` }}
                      />
                    ))}

                    {/* Slots vacíos clickeables */}
                    {onEmptySlotClick &&
                      Array.from({ length: TOTAL_SLOTS }, (_, idx) => {
                        const hour = OPEN_HOUR + Math.floor(idx / 2);
                        const minute = (idx % 2) * SLOT_MIN;
                        const slotStart = new Date(d);
                        slotStart.setHours(hour, minute, 0, 0);
                        const slotEnd = new Date(
                          slotStart.getTime() + SLOT_MIN * 60000
                        );

                        const occupied = dayMeetings.some((r) => {
                          const rs = new Date(r.startsAt);
                          const re = new Date(effectiveEndsAt(r));
                          return rs < slotEnd && re > slotStart;
                        });
                        const inPast = slotStart <= now;
                        if (occupied || inPast) return null;

                        const top = (idx / TOTAL_SLOTS) * 100;
                        const height = 100 / TOTAL_SLOTS;
                        const time = `${pad(hour)}:${pad(minute)}`;

                        return (
                          <button
                            type="button"
                            key={idx}
                            onClick={() =>
                              onEmptySlotClick({
                                date: ymd,
                                hour,
                                minute,
                              })
                            }
                            className="group absolute inset-x-0.5 z-0 flex cursor-pointer items-center justify-center rounded transition hover:bg-millenium-blue/5"
                            style={{ top: `${top}%`, height: `${height}%` }}
                            title={`Agendar reunión a las ${time}`}
                            aria-label={`Agendar reunión a las ${time}`}
                          >
                            <span className="pointer-events-none flex items-center text-millenium-blue/0 transition group-hover:text-millenium-blue/70">
                              <Plus className="h-3 w-3" />
                            </span>
                          </button>
                        );
                      })}

                    {/* Grupos de solape (cada uno maneja su hover y chip overflow) */}
                    {groups.map((g) => (
                      <OverlapGroup
                        key={g.groupId}
                        items={g.items}
                        now={now}
                        hourHeightPx={HOUR_HEIGHT_PX}
                        largeMaxAvatars={4}
                        onReservationClick={onReservationClick}
                        onOverflowClick={(hidden, anchorRect) =>
                          setOverflowPopover({
                            meetings: hidden,
                            anchorRect,
                          })
                        }
                      />
                    ))}
                  </div>
                </div>
              </div>
            );
          })}

          {/* Línea "ahora" cruzando los días visibles, solo si la semana actual está visible */}
          {showNowLine && todayIndex >= 0 && (
            <div
              className="pointer-events-none absolute z-20"
              style={{
                left: "5rem",
                right: 0,
                top: `calc(1rem + ${nowPercent}% * (100% - 3rem) / 100%)`,
              }}
            >
              <div className="relative w-full">
                <span
                  className="absolute z-30 rounded bg-millenium-red px-2 py-0.5 text-xs font-bold tabular-nums text-white shadow-sm"
                  style={{ left: "-4.25rem", top: "-0.65rem" }}
                >
                  {nowLabel}
                </span>
                <div
                  className="absolute -left-1 h-2 w-2 rounded-full bg-millenium-red/80 ring-2 ring-white"
                  style={{ top: "-3px" }}
                />
                <div className="h-px w-full bg-millenium-red/70 mix-blend-multiply" />
              </div>
            </div>
          )}
        </div>
      </div>

      {overflowPopover && (
        <OverflowPopover
          meetings={overflowPopover.meetings}
          anchorRect={overflowPopover.anchorRect}
          onMeetingClick={onReservationClick}
          onClose={() => setOverflowPopover(null)}
        />
      )}
    </div>
  );
}
