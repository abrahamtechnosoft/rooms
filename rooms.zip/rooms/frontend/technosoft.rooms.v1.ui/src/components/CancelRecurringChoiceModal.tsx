"use client";

import { useState } from "react";
import { AlertTriangle, Loader2, X } from "lucide-react";

interface Props {
  onClose: () => void;
  onConfirm: (choice: "instance" | "series", reason: string) => void | Promise<void>;
  loading: boolean;
}

const MAX_REASON = 300;

export default function CancelRecurringChoiceModal({
  onClose,
  onConfirm,
  loading,
}: Props) {
  const [choice, setChoice] = useState<"instance" | "series" | null>(null);
  const [reason, setReason] = useState("");

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4"
      onClick={loading ? undefined : onClose}
    >
      <div
        className="flex max-h-[90vh] w-full max-w-md flex-col rounded-xl bg-white shadow-xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex shrink-0 items-start gap-3 border-b border-gray-200 p-5">
          <div className="rounded-full bg-amber-50 p-2">
            <AlertTriangle className="h-5 w-5 text-amber-600" />
          </div>
          <div className="flex-1">
            <h3 className="font-semibold text-gray-900">
              Cancelar reunión recurrente
            </h3>
            <p className="mt-1 text-sm text-gray-600">
              Esta reunión es parte de una serie. ¿Qué quieres cancelar?
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            disabled={loading}
            className="rounded p-1 text-gray-400 transition hover:bg-gray-100 hover:text-gray-700 disabled:opacity-50"
            aria-label="Cerrar"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto">
          <div className="space-y-2 p-4">
          <button
            type="button"
            onClick={() => setChoice("instance")}
            disabled={loading}
            className={
              "w-full rounded-lg border p-3 text-left transition focus:outline-none focus:ring-2 focus:ring-millenium-blue/40 " +
              (choice === "instance"
                ? "border-millenium-blue bg-blue-50"
                : "border-gray-200 hover:border-gray-300")
            }
          >
            <p className="text-sm font-medium text-gray-900">
              Solo esta reunión
            </p>
            <p className="mt-0.5 text-xs text-gray-500">
              Solo esta fecha se cancela. La serie sigue corriendo.
            </p>
          </button>

          <button
            type="button"
            onClick={() => setChoice("series")}
            disabled={loading}
            className={
              "w-full rounded-lg border p-3 text-left transition focus:outline-none focus:ring-2 focus:ring-millenium-red/40 " +
              (choice === "series"
                ? "border-millenium-red bg-red-50"
                : "border-gray-200 hover:border-gray-300")
            }
          >
            <p className="text-sm font-medium text-gray-900">Toda la serie</p>
            <p className="mt-0.5 text-xs text-gray-500">
              Se cancelarán esta reunión y todas las futuras de la serie.
            </p>
          </button>
          </div>

          {choice && (
            <div className="border-t border-gray-200 p-4">
              <label
                htmlFor="cancel-recurring-reason"
                className="mb-1 block text-xs font-medium text-gray-700"
              >
                Motivo (opcional)
              </label>
              <textarea
                id="cancel-recurring-reason"
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                maxLength={MAX_REASON}
                rows={2}
                className="w-full resize-none rounded border border-gray-300 px-3 py-2 text-sm focus:border-millenium-blue focus:outline-none focus:ring-2 focus:ring-millenium-blue/20"
              />
              <p className="mt-1 text-right text-xs text-gray-500 tabular-nums">
                {reason.length}/{MAX_REASON}
              </p>
            </div>
          )}
        </div>

        <div className="flex shrink-0 justify-end gap-2 border-t border-gray-200 p-3">
          <button
            type="button"
            onClick={onClose}
            disabled={loading}
            className="rounded px-3 py-1.5 text-sm text-gray-500 transition hover:text-gray-900 disabled:opacity-50"
          >
            Volver
          </button>
          <button
            type="button"
            onClick={() => choice && onConfirm(choice, reason.trim())}
            disabled={!choice || loading}
            className={
              "inline-flex items-center gap-2 rounded px-3 py-1.5 text-sm font-medium text-white transition disabled:opacity-50 " +
              (choice === "series"
                ? "bg-millenium-red hover:bg-millenium-red/90"
                : "bg-millenium-blue hover:bg-millenium-blue/90")
            }
          >
            {loading && <Loader2 className="h-3.5 w-3.5 animate-spin" />}
            {loading
              ? "Cancelando..."
              : choice === "series"
                ? "Cancelar serie completa"
                : "Cancelar esta reunión"}
          </button>
        </div>
      </div>
    </div>
  );
}
