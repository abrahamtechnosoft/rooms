"use client";

import { initialsOf } from "@/lib/strings";

type Size = "sm" | "md" | "lg" | "xl";

interface Props {
  name?: string | null;
  email?: string | null;
  avatarUrl?: string | null;
  size?: Size;
  className?: string;
  /**
   * Si es true, NO aplica el preset de tamaño asociado a `size`. El alto,
   * ancho y tamaño de fuente vienen 100% del `className` recibido. Sirve
   * cuando el caller (ej. `AvatarStack`) controla el sizing con clases
   * personalizadas y no quiere que el default `h-8 w-8` pelée contra ellas.
   */
  noDefaultSize?: boolean;
}

const sizeCls: Record<Size, string> = {
  sm: "h-8 w-8 text-sm",
  md: "h-10 w-10 text-base",
  lg: "h-12 w-12 text-lg",
  xl: "h-16 w-16 text-xl",
};

function resolveAvatarUrl(avatarUrl: string): string {
  if (/^https?:\/\//.test(avatarUrl)) return avatarUrl;
  if (avatarUrl.startsWith("data:")) return avatarUrl;
  const apiUrl = process.env.NEXT_PUBLIC_API_URL || "http://localhost:4000/api";
  const origin = apiUrl.replace(/\/api\/?$/, "");
  return `${origin}${avatarUrl}`;
}

export default function Avatar({
  name,
  email,
  avatarUrl,
  size = "md",
  className = "",
  noDefaultSize,
}: Props) {
  const alt = name || email || "Avatar";
  const sizeClasses = noDefaultSize ? "" : sizeCls[size];

  if (avatarUrl) {
    return (
      // eslint-disable-next-line @next/next/no-img-element
      <img
        src={resolveAvatarUrl(avatarUrl)}
        alt={alt}
        className={`shrink-0 rounded-full object-cover ${sizeClasses} ${className}`.trim()}
      />
    );
  }

  return (
    <div
      className={`flex shrink-0 items-center justify-center rounded-full bg-millenium-blue font-semibold text-white ${sizeClasses} ${className}`.trim()}
      aria-label={alt}
    >
      {initialsOf(name, email)}
    </div>
  );
}
