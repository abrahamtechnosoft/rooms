"use client";

import type { RoomAvailability } from "@/hooks/useRoomAvailability";

const pad = (n: number) => String(n).padStart(2, "0");
const fmtHora = (d: Date) => `${pad(d.getHours())}:${pad(d.getMinutes())}`;

interface Props {
  availability: RoomAvailability;
}

export default function RoomStatusChip({ availability }: Props) {
  if (availability.status === "occupied" && availability.occupiedUntil) {
    return (
      <span className="inline-flex shrink-0 items-center gap-1.5 rounded-full bg-millenium-red/10 px-2 py-1 text-xs font-medium text-millenium-red">
        <span className="relative inline-flex h-1.5 w-1.5">
          <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-millenium-red opacity-75" />
          <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-millenium-red" />
        </span>
        Ocupada hasta {fmtHora(availability.occupiedUntil)}
      </span>
    );
  }

  if (
    availability.status === "soon" &&
    typeof availability.minutesUntilNext === "number"
  ) {
    return (
      <span className="inline-flex shrink-0 items-center gap-1.5 rounded-full bg-yellow-100 px-2 py-1 text-xs font-medium text-yellow-800">
        <span
          className="h-1.5 w-1.5 rounded-full bg-yellow-500"
          aria-hidden="true"
        />
        Próxima en {availability.minutesUntilNext} min
      </span>
    );
  }

  return (
    <span className="inline-flex shrink-0 items-center gap-1.5 rounded-full bg-millenium-green/10 px-2 py-1 text-xs font-medium text-millenium-green">
      <span
        className="h-1.5 w-1.5 rounded-full bg-millenium-green"
        aria-hidden="true"
      />
      Libre
    </span>
  );
}
