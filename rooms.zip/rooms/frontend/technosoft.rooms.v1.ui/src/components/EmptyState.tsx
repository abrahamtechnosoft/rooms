"use client";

import { LucideIcon } from "lucide-react";
import { ReactNode } from "react";
import { motion } from "framer-motion";

interface Props {
  icon: LucideIcon;
  title: string;
  description?: string;
  /** Variante existente: nodo de accion arbitrario. */
  action?: ReactNode;
  /** Variante compacta: boton de texto con onClick. */
  ctaLabel?: string;
  onCta?: () => void;
  className?: string;
  /** Si true, layout chico apto para widgets (sin padding grande). */
  compact?: boolean;
  animate?: boolean;
}

export default function EmptyState({
  icon: Icon,
  title,
  description,
  action,
  ctaLabel,
  onCta,
  className = "",
  compact = false,
  animate = true,
}: Props) {
  const padding = compact ? "px-3 py-6" : "px-4 py-12";
  const iconWrap = compact ? "p-3" : "h-12 w-12";
  const iconSize = "h-6 w-6";

  const Container = animate ? motion.div : "div";
  const containerProps = animate
    ? {
        initial: { opacity: 0, y: 8 },
        animate: { opacity: 1, y: 0 },
        transition: { duration: 0.3 },
      }
    : {};

  return (
    <Container
      {...containerProps}
      className={
        "flex flex-col items-center justify-center text-center " +
        padding +
        " " +
        className
      }
    >
      <div
        className={
          "mb-2 flex items-center justify-center rounded-full bg-gray-100 " +
          iconWrap
        }
      >
        <Icon className={`${iconSize} text-gray-400`} />
      </div>
      <h3 className="mb-0.5 text-sm font-semibold text-gray-700">{title}</h3>
      {description && (
        <p
          className={
            compact
              ? "max-w-[220px] text-[11px] text-gray-400"
              : "max-w-sm text-sm text-gray-500"
          }
        >
          {description}
        </p>
      )}
      {ctaLabel && onCta && (
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            onCta();
          }}
          className="mt-3 text-xs font-medium text-millenium-blue transition hover:underline"
        >
          {ctaLabel}
        </button>
      )}
      {action && <div className="mt-4">{action}</div>}
    </Container>
  );
}
