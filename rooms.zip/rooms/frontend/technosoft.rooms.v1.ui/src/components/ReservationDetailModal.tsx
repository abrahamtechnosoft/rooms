"use client";

import {
  ComponentType,
  ReactNode,
  useCallback,
  useEffect,
  useState,
} from "react";
import { useRouter } from "next/navigation";
import {
  Briefcase,
  Building2,
  CheckCircle,
  ChevronDown,
  ChevronUp,
  Clock,
  ExternalLink,
  FileText,
  Globe,
  History,
  Link as LinkIcon,
  LogOut,
  Mail,
  Map as MapIcon,
  MapPin,
  NotebookPen,
  Paperclip,
  Pencil,
  Phone,
  Repeat,
  Square,
  Tag,
  Trash2,
  UserX,
  Users,
  Video,
  X,
  XCircle,
} from "lucide-react";
import { toast } from "@/lib/toastHelpers";
import type {
  Reply,
  Reservation,
  ReservationHistoryEntry,
  UserPickerItem,
} from "@/types";
import {
  EXTERNAL_SUBTYPE_LABELS,
  VIRTUAL_PLATFORM_LABELS,
} from "@/constants/reservationTypes";
import { isValidUrl } from "@/lib/urlValidator";
import api from "@/lib/api";
import { useBackendPolling } from "@/hooks/useBackendPolling";
import { fmtDate, fmtTime } from "@/lib/dates";
import { getReservationStatus } from "@/lib/reservationStatus";
import { getRoomColor, getRoomIcon } from "@/lib/roomIcons";
import { useAuthStore } from "@/store/authStore";
import { useNotificationStore } from "@/store/notificationStore";
import ReservationStatusBadge from "@/components/ReservationStatusBadge";
import Avatar from "@/components/Avatar";
import AttendanceList from "@/components/AttendanceList";
import AttachmentsList from "@/components/AttachmentsList";
import NotesList from "@/components/NotesList";
import SummarySection from "@/components/SummarySection";
import PersonDetailDrawer from "@/components/PersonDetailDrawer";
import CancelRecurringChoiceModal from "@/components/CancelRecurringChoiceModal";
import SeriesDetailsModal from "@/components/SeriesDetailsModal";
import ModalDetailSkeleton from "@/components/skeletons/ModalDetailSkeleton";
import Button from "@/components/ui/Button";
import Modal from "@/components/ui/Modal";
import Textarea from "@/components/ui/Textarea";

const EXTERNAL_COLOR = "#27AE60";

interface ExternalGuest {
  guestId: number;
  email: string;
  displayName: string | null;
  notified: boolean;
  notifiedAt: string | null;
  addedAt: string;
}

interface Props {
  reservation: Reservation | null;
  roomCapacity?: number;
  canCancel?: boolean;
  /**
   * Llamado tras una cancelacion exitosa para que el padre refresque la lista.
   * El modal hace la llamada HTTP con el motivo y luego invoca este callback.
   */
  onCancel?: (r: Reservation) => void | Promise<void>;
  onClose: () => void;
}

interface IconProps {
  className?: string;
}

interface SectionRowProps {
  icon: ComponentType<IconProps>;
  label: string;
  children: ReactNode;
}

function SectionRow({ icon: Icon, label, children }: SectionRowProps) {
  return (
    <div className="border-t border-gray-100 pt-3 first:border-t-0 first:pt-0">
      <div className="mb-1.5 flex items-center gap-2">
        <Icon className="h-4 w-4 text-gray-400" />
        <p className="text-xs font-medium uppercase tracking-wide text-gray-500">
          {label}
        </p>
      </div>
      <div className="pl-6">{children}</div>
    </div>
  );
}

function formatChange(h: ReservationHistoryEntry): string {
  switch (h.changeType) {
    case "rescheduled":
      return `Reagendado de ${h.oldValue} a ${h.newValue}`;
    case "room_changed":
      return `Sala cambiada de ${h.oldValue} a ${h.newValue}`;
    case "title_changed":
      return "Título actualizado";
    case "link_changed":
      return h.newValue
        ? "Enlace de reunión actualizado"
        : "Enlace de reunión eliminado";
    case "modality_changed":
      return `Modalidad cambiada de ${h.oldValue} a ${h.newValue}`;
    case "participant_cancelled":
      return `${h.oldValue || "Un colaborador"} canceló su participación`;
    case "cancelled":
      return "Reunión cancelada";
    case "cancelled_in_progress":
      return "Reunión cancelada en curso";
    case "ended_early":
      return `Reunión terminada antes (${h.oldValue} → ${h.newValue})`;
    default:
      return "Cambio registrado";
  }
}

function formatRelativeTime(iso: string): string {
  const date = new Date(iso);
  const diffMs = Date.now() - date.getTime();
  const diffMin = Math.floor(diffMs / 60000);
  const diffHr = Math.floor(diffMin / 60);
  const diffDay = Math.floor(diffHr / 24);

  if (diffMin < 1) return "Hace un momento";
  if (diffMin < 60)
    return `Hace ${diffMin} ${diffMin === 1 ? "minuto" : "minutos"}`;
  if (diffHr < 24) return `Hace ${diffHr} ${diffHr === 1 ? "hora" : "horas"}`;
  if (diffDay < 7) return `Hace ${diffDay} ${diffDay === 1 ? "día" : "días"}`;
  return date.toLocaleDateString("es", { day: "numeric", month: "short" });
}

function formatDurationBetween(startIso: string, endIso: string): string {
  const ms =
    new Date(endIso).getTime() - new Date(startIso).getTime();
  const mins = Math.max(0, Math.round(ms / 60000));
  if (mins < 60) return `${mins} ${mins === 1 ? "minuto" : "minutos"}`;
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  if (m === 0) return `${h} ${h === 1 ? "hora" : "horas"}`;
  return `${h} h ${m} min`;
}

export default function ReservationDetailModal({
  reservation,
  roomCapacity,
  canCancel,
  onCancel,
  onClose,
}: Props) {
  const router = useRouter();
  const [detail, setDetail] = useState<Reservation | null>(null);
  const [history, setHistory] = useState<ReservationHistoryEntry[]>([]);
  const [showCancelDialog, setShowCancelDialog] = useState(false);
  const [cancelReason, setCancelReason] = useState("");
  const [cancelling, setCancelling] = useState(false);
  const [showDeleteSeriesDialog, setShowDeleteSeriesDialog] = useState(false);
  const [deletingSeries, setDeletingSeries] = useState(false);
  const [showAllCollaborators, setShowAllCollaborators] = useState(false);
  const [personDrawerId, setPersonDrawerId] = useState<number | null>(null);
  const [showLeaveDialog, setShowLeaveDialog] = useState(false);
  const [leaveReason, setLeaveReason] = useState("");
  const [acceptLeave, setAcceptLeave] = useState(false);
  const [leaving, setLeaving] = useState(false);

  // G1 — Terminar antes
  const [showEndEarlyDialog, setShowEndEarlyDialog] = useState(false);
  const [endEarlyReason, setEndEarlyReason] = useState("");
  const [endingEarly, setEndingEarly] = useState(false);

  // C2 — Recurrencia: modal de detalles de la serie.
  const [showSeriesModal, setShowSeriesModal] = useState(false);

  const me = useAuthStore((s) => s.user);
  const setUnreadCount = useNotificationStore((s) => s.setUnreadCount);

  // Al abrir el modal, marcar como leídas las notificaciones asociadas a esta
  // reunión y re-sincronizar el contador.
  useEffect(() => {
    if (!reservation) return;
    api
      .patch(`/notifications/by-reservation/${reservation.id}/read`)
      .then(() =>
        api
          .get<Reply<{ count: number }>>("/notifications/unread-count")
          .then((res) => setUnreadCount(res.data.obj?.count || 0))
          .catch(() => {})
      )
      .catch(() => {});
  }, [reservation?.id, setUnreadCount]);

  useEffect(() => {
    setShowCancelDialog(false);
    setCancelReason("");
    setCancelling(false);
    setShowAllCollaborators(false);
    setPersonDrawerId(null);
    setShowLeaveDialog(false);
    setLeaveReason("");
    setAcceptLeave(false);
    setLeaving(false);
    setShowEndEarlyDialog(false);
    setEndEarlyReason("");
    setEndingEarly(false);
    setShowSeriesModal(false);
  }, [reservation?.id]);

  useEffect(() => {
    if (!reservation) {
      setDetail(null);
      return;
    }
    let cancelled = false;
    api
      .get<Reply<Reservation>>(`/reservations/${reservation.id}`)
      .then((res) => {
        if (!cancelled) setDetail(res.data.obj || null);
      })
      .catch(() => {
        if (!cancelled) setDetail(null);
      });
    return () => {
      cancelled = true;
    };
  }, [reservation]);

  // Polling 30s mientras el modal esté abierto: el badge "En curso" y otros
  // estados (terminada antes, cancelada) deben verse frescos.
  const refreshDetail = useCallback(async () => {
    if (!reservation) return;
    try {
      const res = await api.get<Reply<Reservation>>(
        `/reservations/${reservation.id}`
      );
      if (res.data.obj) setDetail(res.data.obj);
    } catch {
      /* ignorar */
    }
  }, [reservation]);
  useBackendPolling(
    refreshDetail,
    30_000,
    [reservation?.id]
  );

  const effective = detail || reservation;
  const isPublicView = !!detail?.publicView;
  const participants: UserPickerItem[] = detail?.participants || [];
  const activeCollaborators = participants.filter(
    (p) => (p.status ?? "active") === "active"
  );
  const cancelledCollaborators = participants.filter(
    (p) => p.status === "cancelled"
  );

  const [externalGuests, setExternalGuests] = useState<ExternalGuest[]>([]);

  useEffect(() => {
    if (!reservation) {
      setHistory([]);
      return;
    }
    if (isPublicView) {
      setHistory([]);
      return;
    }
    let cancelled = false;
    api
      .get<Reply<ReservationHistoryEntry[]>>(
        `/reservations/${reservation.id}/history`
      )
      .then((res) => {
        if (!cancelled) {
          const all = res.data.obj || [];
          const filtered = all.filter(
            (h) =>
              h.changeType !== "cancelled" &&
              h.changeType !== "cancelled_in_progress"
          );
          setHistory(filtered);
        }
      })
      .catch(() => {
        if (!cancelled) setHistory([]);
      });
    return () => {
      cancelled = true;
    };
  }, [reservation, isPublicView]);

  // Cargar invitados externos (G5). Backend protege con membresía/organizador.
  useEffect(() => {
    if (!reservation || isPublicView) {
      setExternalGuests([]);
      return;
    }
    let cancelled = false;
    api
      .get<Reply<ExternalGuest[]>>(
        `/reservations/${reservation.id}/external-guests`
      )
      .then((res) => {
        if (!cancelled) setExternalGuests(res.data.obj || []);
      })
      .catch(() => {
        if (!cancelled) setExternalGuests([]);
      });
    return () => {
      cancelled = true;
    };
  }, [reservation, isPublicView]);

  if (!reservation || !effective) return null;

  const status = getReservationStatus(effective);
  const showCancel =
    canCancel &&
    (status === "upcoming" || status === "live") &&
    !isPublicView;
  const isInProgressCancel = status === "live";
  const canEdit = !!canCancel && status === "upcoming" && !isPublicView;

  const isParticipantActive =
    !!me &&
    !isPublicView &&
    effective.createdBy !== me.id &&
    participants.some(
      (p) => p.id === me.id && (p.status ?? "active") === "active"
    );
  const canLeave =
    isParticipantActive && (status === "upcoming" || status === "live");
  const isInProgressLeave = status === "live";

  // G2 — Asistencia: organizador/admin, durante la reunión y hasta 24h después.
  const isOrganizerOrAdmin =
    !!me &&
    !isPublicView &&
    (effective.createdBy === me.id || me.role === "admin");
  const nowMs = Date.now();
  const startsMs = new Date(effective.startsAt).getTime();
  const endsMs = new Date(effective.endsAt).getTime();
  const canMarkAttendance =
    isOrganizerOrAdmin &&
    effective.status === "active" &&
    nowMs >= startsMs &&
    nowMs <= endsMs + 24 * 60 * 60 * 1000;

  // G3 — Notas: visibles para organizador + colaboradores activos + admin.
  const canSeeNotes =
    !isPublicView &&
    !!me &&
    (effective.createdBy === me.id ||
      me.role === "admin" ||
      participants.some(
        (p) => p.id === me.id && (p.status ?? "active") === "active"
      ));
  // Cualquier participante activo + organizador puede agregar notas y resumen.
  // Admin sin participación no puede escribir, pero sí ver.
  const canEditNotes =
    !isPublicView &&
    !!me &&
    (effective.createdBy === me.id ||
      participants.some(
        (p) => p.id === me.id && (p.status ?? "active") === "active"
      ));

  // G5 — Ver invitados externos: organizador + colaboradores activos + admin.
  const canSeeGuests = canSeeNotes;

  // G1 — Terminar antes: solo organizador/admin, reunión activa y EN CURSO,
  // que no haya sido ya terminada antes.
  const canEndEarly =
    isOrganizerOrAdmin &&
    effective.status === "active" &&
    !effective.endedEarly &&
    nowMs >= startsMs &&
    nowMs < endsMs;

  const handleReschedule = () => {
    if (!reservation) return;
    router.push(`/dashboard/reservations/new?editId=${reservation.id}`);
    onClose();
  };

  const handleLeave = async () => {
    if (
      leaving ||
      leaveReason.trim().length < 5 ||
      !acceptLeave ||
      !reservation
    )
      return;
    setLeaving(true);
    try {
      const res = await api.post<Reply<{ reservationId: number }>>(
        `/reservations/${reservation.id}/leave`,
        { reason: leaveReason.trim() }
      );
      if (res.data.ok) {
        toast.success(res.data.msg || "Saliste de la reunión");
        setShowLeaveDialog(false);
        setLeaveReason("");
        setAcceptLeave(false);
        onClose();
      } else {
        toast.error(res.data.msg || "No fue posible salir de la reunión");
      }
    } catch (e: unknown) {
      const errObj = e as { response?: { data?: { msg?: string } } };
      toast.error(
        errObj?.response?.data?.msg || "No fue posible salir de la reunión"
      );
    } finally {
      setLeaving(false);
    }
  };

  const handleEndEarly = async () => {
    if (endingEarly || !reservation) return;
    setEndingEarly(true);
    try {
      const res = await api.post<Reply<{ id: number; endedAt: string }>>(
        `/reservations/${reservation.id}/end-early`,
        { reason: endEarlyReason.trim() || null }
      );
      if (res.data.ok) {
        toast.success(res.data.msg || "Reunión terminada");
        setShowEndEarlyDialog(false);
        setEndEarlyReason("");
        // Refrescamos el detalle local actualizando los campos.
        setDetail((prev) =>
          prev
            ? {
                ...prev,
                endedEarly: true,
                endedAt: res.data.obj?.endedAt || new Date().toISOString(),
                endedById: me?.id ?? null,
                endedByName: me?.fullName ?? null,
                endEarlyReason: endEarlyReason.trim() || null,
              }
            : prev
        );
        if (onCancel) await onCancel(reservation);
      } else {
        toast.error(
          res.data.msg || "No fue posible terminar la reunión"
        );
      }
    } catch (e: unknown) {
      const errObj = e as { response?: { data?: { msg?: string } } };
      toast.error(
        errObj?.response?.data?.msg || "No fue posible terminar la reunión"
      );
    } finally {
      setEndingEarly(false);
    }
  };

  const handleConfirmCancel = async () => {
    if (cancelling || !reservation) return;
    setCancelling(true);
    try {
      const res = await api.delete<Reply<{ id: number; inProgress: boolean }>>(
        `/reservations/${reservation.id}`,
        { data: { reason: cancelReason.trim() } }
      );
      if (res.data.ok) {
        toast.success(res.data.msg || "Reunión cancelada");
        setShowCancelDialog(false);
        setCancelReason("");
        if (onCancel) await onCancel(reservation);
      } else {
        toast.error(res.data.msg || "No fue posible cancelar la reunión");
      }
    } catch (e: unknown) {
      const errObj = e as { response?: { data?: { msg?: string } } };
      toast.error(
        errObj?.response?.data?.msg || "No fue posible cancelar la reunión"
      );
    } finally {
      setCancelling(false);
    }
  };

  const isVirtual = effective.type === "virtual";
  const isExternal = effective.type === "external";
  const isOffice = effective.type === "office";
  const roomColor = isOffice
    ? "#E67E22"
    : isExternal
      ? EXTERNAL_COLOR
      : isVirtual
        ? "#8B5CF6"
        : getRoomColor(effective.roomColor);
  const RoomIcon = isOffice
    ? Briefcase
    : isExternal
      ? MapPin
      : isVirtual
        ? Globe
        : getRoomIcon(effective.roomIcon);

  // Sólo renderizamos footer de acciones si hay al menos una visible.
  const hasFooterActions = canEdit || canLeave || showCancel || canEndEarly;

  return (
    <Modal
      open={!!reservation}
      onClose={onClose}
      size="lg"
      actions={
        hasFooterActions ? (
          <>
            {canEdit && (
              <Button variant="outline" onClick={handleReschedule}>
                <Pencil className="h-4 w-4" aria-hidden="true" />
                Reagendar
              </Button>
            )}
            {canLeave && (
              <Button
                variant="outline"
                onClick={() => setShowLeaveDialog(true)}
              >
                <LogOut className="h-4 w-4" aria-hidden="true" />
                Salir de la reunión
              </Button>
            )}
            {canEndEarly && (
              <Button
                variant="outline"
                onClick={() => setShowEndEarlyDialog(true)}
              >
                <Square className="h-4 w-4" aria-hidden="true" />
                Terminar ahora
              </Button>
            )}
            {showCancel && (
              <Button
                variant="danger"
                onClick={() => setShowCancelDialog(true)}
              >
                <X className="h-4 w-4" aria-hidden="true" />
                Cancelar reunión
              </Button>
            )}
            {effective.recurringSeriesId &&
              canCancel &&
              status === "upcoming" && (
                <Button
                  variant="outline"
                  onClick={() => setShowDeleteSeriesDialog(true)}
                  className="!border-red-200 !text-millenium-red hover:!bg-red-50"
                >
                  <Trash2 className="h-4 w-4" />
                  Eliminar serie completa
                </Button>
              )}
          </>
        ) : null
      }
    >
      {!detail ? (
        <ModalDetailSkeleton />
      ) : (
        <div key={`detail-${detail.id}`} className="animate-fadeIn">
      {/* Header propio: icono coloreado + título + status + organizador clickeable */}
      <div className="mb-4 flex items-start gap-3">
        <span
          className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg"
          style={{ backgroundColor: `${roomColor}26`, color: roomColor }}
        >
          <RoomIcon className="h-5 w-5" />
        </span>
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-2">
            <h2 className="text-xl font-bold text-gray-900 wrap-break-word leading-tight">
              {effective.title}
            </h2>
            <ReservationStatusBadge status={status} />
          </div>
          <p className="mt-1 flex items-center gap-1.5 text-sm text-gray-600">
            Organizada por
            <button
              type="button"
              onClick={() => setPersonDrawerId(effective.createdBy)}
              className="inline-flex items-center gap-1.5 rounded hover:underline focus:outline-none focus-visible:ring-1 focus-visible:ring-millenium-blue/40"
            >
              <Avatar
                name={effective.userFullName}
                email={effective.userEmail}
                avatarUrl={effective.userAvatarUrl}
                size="sm"
                className="h-5 w-5"
              />
              <span className="font-medium text-gray-900">
                {effective.userFullName || effective.userEmail}
              </span>
            </button>
          </p>
        </div>
        <button
          type="button"
          onClick={onClose}
          className="-mr-1 -mt-1 shrink-0 rounded-md p-2 text-gray-500 hover:bg-gray-100 hover:text-gray-700 focus:outline-none focus:ring-2 focus:ring-millenium-blue/40 focus:ring-offset-1"
          aria-label="Cerrar"
        >
          <X className="h-5 w-5" aria-hidden="true" />
        </button>
      </div>

      {/* C2 — Banner morado si esta reunión pertenece a una serie recurrente */}
      {effective.recurringSeriesId && (
        <div className="animate-fadeIn mb-4 rounded-lg border border-purple-200 bg-purple-50 p-3">
          <div className="mb-1 flex flex-wrap items-center gap-2">
            <Repeat className="h-4 w-4 text-purple-700" />
            <span className="text-sm font-medium text-purple-900">
              Reunión recurrente
            </span>
            {effective.isException && (
              <span className="rounded bg-amber-50 px-2 py-0.5 text-xs text-amber-700">
                Modificada de la serie
              </span>
            )}
          </div>
          <p className="text-xs text-purple-800">
            {effective.series?.title
              ? `Instancia de la serie "${effective.series.title}".`
              : "Esta es una instancia de una serie."}
            <button
              type="button"
              onClick={() => setShowSeriesModal(true)}
              className="ml-1 rounded underline transition hover:text-purple-900 focus:outline-none focus-visible:ring-2 focus-visible:ring-purple-700/40"
            >
              Ver serie completa
            </button>
          </p>
        </div>
      )}

      {/* G1 — Banner amarillo si la reunión terminó antes (y no fue cancelada) */}
      {effective.endedEarly && effective.status !== "cancelled" && (
        <div
          className="animate-fadeIn mb-4 rounded-lg border border-yellow-200 bg-yellow-50 p-3"
          role="alert"
        >
          <div className="flex items-start gap-2">
            <Square className="mt-0.5 h-5 w-5 shrink-0 text-yellow-700" />
            <div className="min-w-0 flex-1">
              <p className="text-sm font-medium text-yellow-900">
                Reunión terminada antes de tiempo
                {effective.endedByName && (
                  <span className="font-normal text-yellow-700">
                    {" "}
                    por {effective.endedByName}
                  </span>
                )}
                {effective.endedAt && (
                  <span className="font-normal text-yellow-700">
                    {" · finalizó a las "}
                    {fmtTime(effective.endedAt)}
                  </span>
                )}
              </p>
              {effective.endEarlyReason && (
                <p className="mt-1 text-sm italic text-yellow-800">
                  Motivo: &ldquo;{effective.endEarlyReason}&rdquo;
                </p>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Banner de cancelación */}
      {effective.status === "cancelled" && (
        <div
          className="animate-fadeIn mb-4 rounded-lg border border-red-200 bg-red-50 p-3"
          role="alert"
        >
          <div className="flex items-start gap-2">
            <XCircle className="mt-0.5 h-5 w-5 shrink-0 text-millenium-red" />
            <div className="min-w-0 flex-1">
              <p className="text-sm font-medium text-red-900">
                Reunión cancelada
                {effective.cancelledByName && (
                  <span className="font-normal text-red-700">
                    {" "}
                    por {effective.cancelledByName}
                  </span>
                )}
                {effective.cancelledAt && (
                  <span className="font-normal text-red-700">
                    {" · "}
                    {formatRelativeTime(effective.cancelledAt)}
                  </span>
                )}
              </p>
              {effective.cancelReason && (
                <p className="mt-1 text-sm text-red-800">
                  Motivo:{" "}
                  <span className="italic">
                    &ldquo;{effective.cancelReason}&rdquo;
                  </span>
                </p>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Secciones */}
      <div className="flex flex-col gap-3">
        <SectionRow icon={Clock} label="Horario">
          <p className="text-sm text-gray-900">
            <span className="capitalize">{fmtDate(effective.startsAt)}</span>
            <span className="text-gray-500"> · </span>
            <span className="tabular-nums">
              {fmtTime(effective.startsAt)} – {fmtTime(effective.endsAt)}
            </span>
            <span className="text-gray-500">
              {" "}
              ({formatDurationBetween(effective.startsAt, effective.endsAt)})
            </span>
          </p>
        </SectionRow>

        <SectionRow
          icon={RoomIcon}
          label={
            isOffice
              ? "Oficina"
              : isExternal
                ? "Ubicación"
                : isVirtual
                  ? "Modalidad"
                  : "Sala"
          }
        >
          {isOffice ? (
            <div>
              <p className="text-sm font-medium text-gray-900">
                {effective.officeName || "Oficina del departamento"}
              </p>
              <p className="mt-0.5 text-xs text-gray-500">
                Oficina del organizador
              </p>
            </div>
          ) : isExternal ? (
            <div>
              <p className="text-sm font-medium text-gray-900">
                Fuera de oficina
              </p>
              {effective.externalAddress && (
                <p className="mt-0.5 whitespace-pre-wrap text-sm text-gray-600">
                  {effective.externalAddress}
                </p>
              )}
            </div>
          ) : isVirtual ? (
            <p className="text-sm font-medium text-gray-900">
              {effective.virtualPlatform
                ? `Reunión virtual · ${VIRTUAL_PLATFORM_LABELS[effective.virtualPlatform]}`
                : "Reunión virtual"}
            </p>
          ) : (
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-sm font-medium text-gray-900">
                {effective.roomName}
              </span>
              {typeof roomCapacity === "number" && (
                <span className="text-sm text-gray-500">
                  · Capacidad {roomCapacity}
                </span>
              )}
            </div>
          )}
        </SectionRow>

        {isExternal && (
          <SectionRow icon={Tag} label="Tipo de actividad">
            <p className="text-sm text-gray-700">
              {EXTERNAL_SUBTYPE_LABELS[effective.externalSubtype || "other"]}
            </p>
          </SectionRow>
        )}

        {isExternal && effective.externalCompany && (
          <SectionRow icon={Building2} label="Empresa o lugar">
            <p className="text-sm text-gray-700">{effective.externalCompany}</p>
          </SectionRow>
        )}

        {isExternal &&
          effective.externalMapsUrl &&
          isValidUrl(effective.externalMapsUrl) && (
            <SectionRow icon={MapIcon} label="Enlace a Maps">
              <a
                href={effective.externalMapsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex min-w-0 max-w-full items-center gap-1 truncate text-sm text-millenium-green hover:underline"
              >
                <ExternalLink className="h-3.5 w-3.5 shrink-0" />
                <span className="truncate">{effective.externalMapsUrl}</span>
              </a>
            </SectionRow>
          )}

        {isExternal && effective.externalContact && (
          <SectionRow icon={Phone} label="Contacto">
            <p className="text-sm text-gray-700">{effective.externalContact}</p>
          </SectionRow>
        )}

        {isVirtual && effective.virtualPlatform && (
          <SectionRow icon={Video} label="Plataforma">
            <p className="text-sm text-gray-700">
              {VIRTUAL_PLATFORM_LABELS[effective.virtualPlatform]}
            </p>
          </SectionRow>
        )}

        {isVirtual && effective.meetingLink && (
          <SectionRow icon={LinkIcon} label="Enlace">
            <div className="flex flex-wrap items-center gap-2">
              <a
                href={effective.meetingLink}
                target="_blank"
                rel="noopener noreferrer"
                className="min-w-0 flex-1 truncate text-sm text-millenium-blue hover:underline"
              >
                {effective.meetingLink}
              </a>
              {status !== "cancelled" && (
                <a
                  href={effective.meetingLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 rounded-lg bg-millenium-blue px-3 py-1.5 text-sm font-medium text-white transition hover:bg-[#1f2c3a] focus:outline-none focus:ring-2 focus:ring-millenium-blue/40"
                >
                  <ExternalLink className="h-4 w-4" />
                  Unirse
                </a>
              )}
            </div>
          </SectionRow>
        )}

        {effective.description && (
          <SectionRow icon={FileText} label="Descripción">
            <p className="whitespace-pre-wrap text-sm text-gray-700">
              {effective.description}
            </p>
          </SectionRow>
        )}

        {activeCollaborators.length > 0 &&
          (() => {
            const visibleCollaborators = showAllCollaborators
              ? activeCollaborators
              : activeCollaborators.slice(0, 3);
            const hiddenCount = activeCollaborators.length - 3;
            const isMeOrganizer =
              !!me && effective.createdBy === me.id;
            const pendingCount = activeCollaborators.filter(
              (p) => p.invitationStatus === "pending"
            ).length;
            return (
              <SectionRow
                icon={Users}
                label={`Colaboradores (${activeCollaborators.length})${
                  pendingCount > 0 ? ` · ${pendingCount} pendientes` : ""
                }`}
              >
                <div className="flex flex-wrap gap-2">
                  {visibleCollaborators.map((p) => {
                    const status = p.invitationStatus;
                    const dim =
                      status === "pending" || status === "rejected";
                    return (
                      <div
                        key={p.id}
                        className="inline-flex items-center gap-1.5"
                      >
                        <button
                          type="button"
                          onClick={() => setPersonDrawerId(p.id)}
                          title={p.email}
                          className={
                            "inline-flex items-center gap-2 rounded-full px-2.5 py-1 text-sm transition focus:outline-none focus:ring-2 focus:ring-millenium-blue/40 focus:ring-offset-1 " +
                            (dim
                              ? "bg-gray-100 text-gray-600 hover:bg-gray-200"
                              : "bg-millenium-blue/10 text-millenium-blue hover:bg-millenium-blue/20")
                          }
                        >
                          <Avatar
                            name={p.fullName || p.email}
                            email={p.email}
                            avatarUrl={p.avatarUrl}
                            size="sm"
                          />
                          <span className="font-medium">
                            {p.fullName || p.email}
                          </span>
                        </button>
                        {status === "pending" && (
                          <span
                            className="inline-flex items-center gap-1 rounded-full bg-amber-50 px-2 py-0.5 text-[11px] text-amber-700"
                            title={
                              isMeOrganizer && p.invitationBlockedByName
                                ? `Bloqueo: ${p.invitationBlockedByName}`
                                : "Pendiente de respuesta"
                            }
                          >
                            <Clock className="h-3 w-3" aria-hidden="true" />
                            Pendiente
                            {isMeOrganizer && p.invitationBlockedByName && (
                              <span className="text-amber-700/80">
                                · {p.invitationBlockedByName}
                              </span>
                            )}
                          </span>
                        )}
                        {status === "rejected" && (
                          <span
                            className="inline-flex items-center gap-1 rounded-full bg-gray-100 px-2 py-0.5 text-[11px] text-gray-600"
                            title={
                              isMeOrganizer && p.invitationBlockedByName
                                ? `Rechazó · Bloqueo: ${p.invitationBlockedByName}`
                                : "Rechazó la invitación"
                            }
                          >
                            <X className="h-3 w-3" aria-hidden="true" />
                            Rechazó
                          </span>
                        )}
                        {status === "accepted" && (
                          <span
                            className="inline-flex items-center gap-1 rounded-full bg-emerald-50 px-2 py-0.5 text-[11px] text-emerald-700"
                            title="Aceptó la invitación"
                          >
                            <CheckCircle className="h-3 w-3" aria-hidden="true" />
                            Aceptó
                          </span>
                        )}
                      </div>
                    );
                  })}
                </div>
                {!showAllCollaborators && hiddenCount > 0 && (
                  <button
                    type="button"
                    onClick={() => setShowAllCollaborators(true)}
                    className="mt-2 inline-flex items-center gap-1 rounded text-sm font-medium text-millenium-blue hover:underline focus:outline-none focus:ring-2 focus:ring-millenium-blue/40 focus:ring-offset-1"
                  >
                    <ChevronDown className="h-4 w-4" aria-hidden="true" />
                    Ver todos ({activeCollaborators.length})
                  </button>
                )}
                {showAllCollaborators && activeCollaborators.length > 3 && (
                  <button
                    type="button"
                    onClick={() => setShowAllCollaborators(false)}
                    className="mt-2 inline-flex items-center gap-1 rounded text-sm font-medium text-millenium-blue hover:underline focus:outline-none focus:ring-2 focus:ring-millenium-blue/40 focus:ring-offset-1"
                  >
                    <ChevronUp className="h-4 w-4" aria-hidden="true" />
                    Mostrar menos
                  </button>
                )}
              </SectionRow>
            );
          })()}

        {/* G4 — Cancelaciones de participación visibles */}
        {cancelledCollaborators.length > 0 && (
          <SectionRow
            icon={UserX}
            label={`Cancelaciones (${cancelledCollaborators.length})`}
          >
            <ul className="space-y-2">
              {cancelledCollaborators.map((c) => (
                <li
                  key={c.id}
                  className="flex items-start gap-3 rounded-lg border border-red-100 bg-red-50/60 p-2"
                >
                  <Avatar
                    name={c.fullName || c.email}
                    email={c.email}
                    avatarUrl={c.avatarUrl}
                    noDefaultSize
                    className="h-8 w-8 text-xs opacity-70"
                  />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-medium text-gray-900 line-through">
                      {c.fullName || c.email}
                    </p>
                    {c.cancelledAt && (
                      <p className="mt-0.5 text-xs text-gray-500">
                        Canceló {formatRelativeTime(c.cancelledAt)}
                      </p>
                    )}
                    {c.cancelReason && (
                      <p className="mt-1.5 text-sm italic text-gray-700">
                        &ldquo;{c.cancelReason}&rdquo;
                      </p>
                    )}
                  </div>
                </li>
              ))}
            </ul>
          </SectionRow>
        )}

        {/* G2 — Asistencia (solo organizador/admin durante o hasta 24h después) */}
        {canMarkAttendance && (
          <SectionRow icon={CheckCircle} label="Asistencia">
            <AttendanceList reservationId={effective.id} />
          </SectionRow>
        )}

        {/* G3 — Notas (visibles para organizador + colaboradores activos + admin) */}
        {canSeeNotes && (
          <SectionRow icon={NotebookPen} label="Notas">
            <NotesList
              reservationId={effective.id}
              canEdit={canEditNotes}
              currentUserId={me?.id ?? null}
              isOrganizer={!!me && effective.createdBy === me.id}
              isAdmin={me?.role === "admin"}
            />
          </SectionRow>
        )}

        {/* Resumen colaborativo */}
        {canSeeNotes && (
          <SectionRow icon={FileText} label="Resumen de la reunión">
            <SummarySection
              reservationId={effective.id}
              canEdit={canEditNotes}
            />
          </SectionRow>
        )}

        {/* Archivos adjuntos por URL — visibles para organizador, colaboradores
            activos y admin. Solo participantes activos y el organizador pueden
            agregar enlaces. */}
        {canSeeNotes && (
          <SectionRow icon={Paperclip} label="Adjuntos">
            <AttachmentsList
              reservationId={effective.id}
              currentUserId={me?.id ?? null}
              isOrganizer={!!me && effective.createdBy === me.id}
              canEdit={
                effective.status === "active" &&
                !!me &&
                (effective.createdBy === me.id ||
                  participants.some(
                    (p) =>
                      p.id === me.id && (p.status ?? "active") === "active"
                  ))
              }
            />
          </SectionRow>
        )}

        {/* G5 — Invitados externos */}
        {externalGuests.length > 0 && canSeeGuests && (
          <SectionRow
            icon={Mail}
            label={`Invitados externos (${externalGuests.length})`}
          >
            <ul className="space-y-1.5">
              {externalGuests.map((g) => (
                <li
                  key={g.guestId}
                  className="flex items-center gap-2 text-sm"
                >
                  <Mail className="h-3.5 w-3.5 shrink-0 text-gray-400" />
                  <div className="flex min-w-0 flex-1 items-baseline gap-1.5">
                    <span
                      className="truncate text-gray-900"
                      title={g.displayName || g.email}
                    >
                      {g.displayName || g.email}
                    </span>
                    {g.displayName && (
                      <span
                        className="shrink-0 truncate text-xs text-gray-500"
                        title={g.email}
                      >
                        · {g.email}
                      </span>
                    )}
                  </div>
                  {g.notified ? (
                    <span
                      className="inline-flex shrink-0 items-center gap-1 text-xs text-millenium-green"
                      title="Invitación enviada"
                    >
                      <CheckCircle className="h-3 w-3" />
                      Notificado
                    </span>
                  ) : (
                    <span className="shrink-0 text-xs text-gray-400">
                      Sin notificar
                    </span>
                  )}
                </li>
              ))}
            </ul>
          </SectionRow>
        )}

        {history.length > 0 && (
          <SectionRow
            icon={History}
            label={`Historial (${history.length})`}
          >
            <ul className="space-y-2">
              {history.map((h) => (
                <li
                  key={h.id}
                  className="flex items-start gap-2 text-sm text-gray-600"
                >
                  <Clock className="mt-0.5 h-4 w-4 shrink-0 text-gray-400" />
                  <div className="min-w-0 flex-1">
                    <p>
                      {formatChange(h)}
                      <span className="text-gray-400">
                        {" · "}
                        {h.changedByName || h.changedByEmail}
                      </span>
                    </p>
                    <p className="text-xs text-gray-400">
                      {formatRelativeTime(h.changedAt)}
                    </p>
                  </div>
                </li>
              ))}
            </ul>
          </SectionRow>
        )}
      </div>

      <PersonDetailDrawer
        personId={personDrawerId}
        onClose={() => setPersonDrawerId(null)}
      />

      {/* G1 — Sub-modal: Terminar ahora */}
      <Modal
        open={showEndEarlyDialog}
        onClose={() => {
          if (!endingEarly) {
            setShowEndEarlyDialog(false);
            setEndEarlyReason("");
          }
        }}
        title="Terminar reunión ahora"
        description="La reunión se cerrará inmediatamente. El espacio horario que quede libre podrá usarse para otra reunión. Los participantes serán notificados."
        actions={
          <>
            <Button
              variant="outline"
              onClick={() => {
                setShowEndEarlyDialog(false);
                setEndEarlyReason("");
              }}
              disabled={endingEarly}
            >
              No terminar
            </Button>
            <Button
              variant="primary"
              loading={endingEarly}
              disabled={endingEarly}
              onClick={handleEndEarly}
            >
              Sí, terminar reunión
            </Button>
          </>
        }
      >
        <div className="space-y-3">
          <Textarea
            label="Motivo (opcional)"
            value={endEarlyReason}
            onChange={(e) => setEndEarlyReason(e.target.value)}
            placeholder="Ej.: Terminamos los temas pendientes antes de lo esperado"
            maxLength={300}
            rows={3}
          />
          <p className="text-right text-xs text-gray-500 tabular-nums">
            {endEarlyReason.length}/300
          </p>
        </div>
      </Modal>

      {showCancelDialog && effective.recurringSeriesId && (
        <CancelRecurringChoiceModal
          loading={cancelling}
          onClose={() => {
            if (!cancelling) setShowCancelDialog(false);
          }}
          onConfirm={async (choice, reasonChosen) => {
            if (!reservation || cancelling) return;
            setCancelling(true);
            try {
              if (choice === "instance") {
                const res = await api.delete<Reply<unknown>>(
                  `/reservations/${reservation.id}`,
                  { data: { reason: reasonChosen } }
                );
                if (res.data.ok) {
                  toast.success(res.data.msg || "Reunión cancelada");
                } else {
                  toast.error(
                    res.data.msg || "No fue posible cancelar la reunión"
                  );
                  return;
                }
              } else {
                const res = await api.delete<Reply<unknown>>(
                  `/recurring-series/${effective.recurringSeriesId}`,
                  { data: { reason: reasonChosen } }
                );
                if (res.data.ok) {
                  toast.success(res.data.msg || "Serie cancelada");
                } else {
                  toast.error(res.data.msg || "No fue posible cancelar la serie");
                  return;
                }
              }
              setShowCancelDialog(false);
              if (onCancel) await onCancel(reservation);
            } catch (e: unknown) {
              const errObj = e as { response?: { data?: { msg?: string } } };
              toast.error(
                errObj?.response?.data?.msg ||
                  "No fue posible cancelar la reunión"
              );
            } finally {
              setCancelling(false);
            }
          }}
        />
      )}

      <Modal
        open={showCancelDialog && !effective.recurringSeriesId}
        onClose={() => {
          if (!cancelling) {
            setShowCancelDialog(false);
            setCancelReason("");
          }
        }}
        title={
          isInProgressCancel
            ? "Cancelar reunión en curso"
            : "Cancelar reunión"
        }
        description={
          (() => {
            const partCount = activeCollaborators.length;
            const title = effective.title;
            const base = `Vas a cancelar "${title}".`;
            if (partCount === 0) {
              return base;
            }
            return `${base} Se notificará a ${partCount} ${partCount === 1 ? "participante" : "participantes"} por correo.`;
          })()
        }
        actions={
          <>
            <Button
              variant="outline"
              onClick={() => {
                setShowCancelDialog(false);
                setCancelReason("");
              }}
              disabled={cancelling}
            >
              Volver
            </Button>
            <Button
              variant="danger"
              loading={cancelling}
              disabled={cancelling}
              onClick={handleConfirmCancel}
            >
              {cancelling ? "Cancelando..." : "Cancelar reunión"}
            </Button>
          </>
        }
      >
        <div className="space-y-3">
          <Textarea
            label="Motivo (opcional)"
            value={cancelReason}
            onChange={(e) => setCancelReason(e.target.value)}
            placeholder={
              isInProgressCancel
                ? "Ej.: Surgió un imprevisto urgente..."
                : "Ej.: El tema se resolvió por correo..."
            }
            maxLength={300}
            rows={3}
          />
          <p className="text-right text-xs text-gray-500 tabular-nums">
            {cancelReason.trim().length}/300
          </p>

          <p className="rounded border border-amber-200 bg-amber-50 px-2.5 py-2 text-xs text-amber-700">
            Esta acción no se puede deshacer. La reunión quedará marcada como
            cancelada en el registro.
          </p>
        </div>
      </Modal>

      <Modal
        open={showLeaveDialog}
        onClose={() => {
          if (!leaving) {
            setShowLeaveDialog(false);
            setLeaveReason("");
            setAcceptLeave(false);
          }
        }}
        title={
          isInProgressLeave
            ? "Salir de una reunión en curso"
            : "Salir de la reunión"
        }
        description={
          isInProgressLeave
            ? "Esta reunión está en curso. Tu salida se notificará al organizador inmediatamente."
            : "Tu cancelación se notificará al organizador y a los demás colaboradores."
        }
        actions={
          <>
            <Button
              variant="outline"
              onClick={() => {
                setShowLeaveDialog(false);
                setLeaveReason("");
                setAcceptLeave(false);
              }}
              disabled={leaving}
            >
              No salir
            </Button>
            <Button
              variant="danger"
              loading={leaving}
              disabled={
                leaveReason.trim().length < 5 || !acceptLeave || leaving
              }
              onClick={handleLeave}
            >
              Sí, salir
            </Button>
          </>
        }
      >
        <div className="space-y-3">
          <Textarea
            label="Motivo"
            value={leaveReason}
            onChange={(e) => setLeaveReason(e.target.value)}
            placeholder={
              isInProgressLeave
                ? "Ej.: Surgió un imprevisto urgente..."
                : "Ej.: Tengo otra reunión a esa hora..."
            }
            maxLength={300}
            rows={3}
            required
          />
          <p className="text-xs text-gray-500 tabular-nums">
            Mínimo 5 caracteres. {leaveReason.trim().length}/300
          </p>

          <label className="flex cursor-pointer items-start gap-2">
            <input
              type="checkbox"
              checked={acceptLeave}
              onChange={(e) => setAcceptLeave(e.target.checked)}
              className="mt-1 h-4 w-4 rounded border-gray-300 text-millenium-red focus:ring-millenium-red"
            />
            <span className="text-sm text-gray-700">
              Entiendo que mi salida será notificada al organizador y a los
              demás colaboradores.
            </span>
          </label>
        </div>
      </Modal>

      {showSeriesModal && effective.recurringSeriesId && (
        <SeriesDetailsModal
          seriesId={effective.recurringSeriesId}
          onClose={() => setShowSeriesModal(false)}
        />
      )}

      {showDeleteSeriesDialog && effective.recurringSeriesId && (
        <ConfirmDeleteSeriesModal
          seriesId={effective.recurringSeriesId}
          submitting={deletingSeries}
          onCancel={() => {
            if (!deletingSeries) setShowDeleteSeriesDialog(false);
          }}
          onConfirm={async () => {
            const sid = effective.recurringSeriesId;
            if (!sid) return;
            setDeletingSeries(true);
            try {
              const res = await api.post<Reply<unknown>>(
                `/recurring-series/${sid}/delete-permanent`
              );
              if (!res.data.ok) {
                toast.error(
                  res.data.msg || "No fue posible eliminar la serie"
                );
                return;
              }
              toast.success(res.data.msg || "Serie eliminada");
              setShowDeleteSeriesDialog(false);
              if (onCancel) await onCancel(reservation);
            } catch (e: unknown) {
              const errObj = e as { response?: { data?: { msg?: string } } };
              toast.error(
                errObj?.response?.data?.msg ||
                  "No fue posible eliminar la serie"
              );
            } finally {
              setDeletingSeries(false);
            }
          }}
        />
      )}
        </div>
      )}
    </Modal>
  );
}

function ConfirmDeleteSeriesModal({
  submitting,
  onConfirm,
  onCancel,
}: {
  seriesId: number;
  submitting: boolean;
  onConfirm: () => void;
  onCancel: () => void;
}) {
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape" && !submitting) onCancel();
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [submitting, onCancel]);

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="delete-series-title"
      className="fixed inset-0 z-[60] flex items-center justify-center bg-black/40 p-4 backdrop-blur-sm"
      onClick={(e) => {
        if (e.target === e.currentTarget && !submitting) onCancel();
      }}
    >
      <div className="flex max-h-[90vh] w-full max-w-md flex-col overflow-hidden rounded-xl bg-white shadow-2xl">
        <div className="shrink-0 border-b px-5 py-4">
          <h3 id="delete-series-title" className="text-base font-semibold text-gray-900">
            Eliminar serie completa
          </h3>
        </div>
        <div className="flex-1 space-y-2 overflow-y-auto p-5 text-sm text-gray-700">
          <p>
            Se eliminarán{" "}
            <span className="font-semibold">
              todas las instancias futuras
            </span>{" "}
            de esta serie recurrente.
          </p>
          <p>Las reuniones pasadas se mantienen como historial.</p>
          <p className="font-medium text-millenium-red">
            Esta acción no se puede deshacer.
          </p>
        </div>
        <div className="flex shrink-0 justify-end gap-2 border-t bg-gray-50 px-5 py-3">
          <button
            type="button"
            onClick={onCancel}
            disabled={submitting}
            className="rounded-md border bg-white px-3 py-1.5 text-sm font-medium text-gray-700 hover:bg-gray-50 disabled:opacity-50"
          >
            Cancelar
          </button>
          <button
            type="button"
            onClick={onConfirm}
            disabled={submitting}
            className="rounded-md bg-millenium-red px-3 py-1.5 text-sm font-medium text-white hover:opacity-90 disabled:opacity-50"
          >
            {submitting ? "Eliminando..." : "Eliminar serie"}
          </button>
        </div>
      </div>
    </div>
  );
}
