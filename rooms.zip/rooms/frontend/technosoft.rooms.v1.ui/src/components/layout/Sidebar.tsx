"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  Building2,
  CalendarClock,
  CalendarDays,
  ClipboardList,
  Home,
  Network,
  Plus,
  Users,
  type LucideIcon,
} from "lucide-react";
import { useAuthStore } from "@/store/authStore";
import { useNotificationStore } from "@/store/notificationStore";

export interface NavItem {
  href: string;
  label: string;
  icon: LucideIcon;
  admin?: boolean;
}

export const navItems: NavItem[] = [
  { href: "/dashboard", label: "Inicio", icon: Home },
  { href: "/dashboard/reservations", label: "Mis Reuniones", icon: CalendarDays },
  { href: "/dashboard/agenda", label: "Agenda", icon: CalendarClock },
  { href: "/dashboard/reservations/new", label: "Nueva Reunión", icon: Plus },
  { href: "/dashboard/people", label: "Colaboradores", icon: Users },
  { href: "/dashboard/registros", label: "Registros", icon: ClipboardList },
  { href: "/dashboard/rooms", label: "Salas", icon: Building2, admin: true },
  { href: "/dashboard/users", label: "Usuarios", icon: Users, admin: true },
  {
    href: "/dashboard/admin/departments",
    label: "Departamentos",
    icon: Network,
    admin: true,
  },
];

interface NavProps {
  onItemClick?: () => void;
}

export function SidebarNav({ onItemClick }: NavProps) {
  const pathname = usePathname();
  const user = useAuthStore((s) => s.user);
  const unreadCount = useNotificationStore((s) => s.unreadCount);
  const isAdmin = user?.role === "admin";
  const visible = navItems.filter((i) => !i.admin || isAdmin);

  return (
    <nav className="flex flex-col gap-0.5 px-3 py-4">
      {visible.map((item) => {
        const Icon = item.icon;
        const active = pathname === item.href;
        const showDot =
          item.href === "/dashboard/reservations" && unreadCount > 0;
        return (
          <Link
            key={item.href}
            href={item.href}
            onClick={onItemClick}
            className={[
              "flex items-center gap-2.5 rounded-md px-2.5 py-1.5 text-sm font-medium transition-colors",
              active
                ? "border border-gray-200 bg-white text-gray-900 shadow-sm"
                : "border border-transparent text-gray-600 hover:bg-white/70 hover:text-gray-900",
            ].join(" ")}
          >
            <Icon className="h-4 w-4 shrink-0" />
            <span className="flex-1">{item.label}</span>
            {showDot && (
              <span
                className="h-2 w-2 rounded-full bg-millenium-red"
                aria-label="Hay notificaciones nuevas"
              />
            )}
          </Link>
        );
      })}
    </nav>
  );
}

export default function Sidebar() {
  return (
    <aside className="hidden w-60 shrink-0 flex-col border-r border-gray-200 bg-gray-50/60 md:flex">
      <SidebarNav />
    </aside>
  );
}
