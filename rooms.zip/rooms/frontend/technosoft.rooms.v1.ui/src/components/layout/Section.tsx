import { ReactNode } from "react";

interface Props {
  label: string;
  trailing?: ReactNode;
  children: ReactNode;
  className?: string;
}

export default function Section({ label, trailing, children, className = "" }: Props) {
  return (
    <section
      className={
        "rounded-xl border border-gray-200 bg-white p-5 shadow-sm " + className
      }
    >
      <div className="mb-4 flex items-center justify-between gap-3">
        <h2 className="text-sm font-medium uppercase tracking-wide text-gray-500">
          {label}
        </h2>
        {trailing}
      </div>
      {children}
    </section>
  );
}
