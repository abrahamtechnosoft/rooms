interface Props {
  size?: number;
  withText?: boolean;
  className?: string;
}

export default function MilleniumLogo({ size = 72, withText = true, className = "" }: Props) {
  return (
    <div className={`flex flex-col items-center ${className}`}>
      <svg
        width={size}
        height={size * 0.7}
        viewBox="0 0 120 84"
        xmlns="http://www.w3.org/2000/svg"
        aria-label="Corporacion Millenium"
      >
        {/* M izquierda */}
        <polygon points="6,72 6,12 22,12 36,42 50,12 66,12 66,72 54,72 54,30 40,60 32,60 18,30 18,72" fill="#2C3E50" />
        {/* triangulos rojo / verde / azul entre las dos M */}
        <polygon points="68,12 80,12 74,28" fill="#C0392B" />
        <polygon points="74,28 86,12 80,40" fill="#27AE60" />
        <polygon points="80,40 92,12 86,40" fill="#2C3E50" />
        {/* M derecha */}
        <polygon points="60,72 60,12 76,12 90,42 104,12 120,12 120,72 108,72 108,30 94,60 86,60 72,30 72,72" fill="#2C3E50" opacity="0.0" />
      </svg>
      {withText && (
        <div className="mt-2 text-center">
          <div className="text-xs font-bold tracking-[0.18em] text-millenium-blue">
            CORPORACION
          </div>
          <div className="-mt-0.5 text-base font-bold tracking-[0.24em] text-millenium-blue">
            MILLENIUM
          </div>
        </div>
      )}
    </div>
  );
}
