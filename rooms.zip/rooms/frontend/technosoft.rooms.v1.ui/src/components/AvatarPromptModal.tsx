"use client";

import { ChangeEvent, useEffect, useRef, useState } from "react";
import { Camera, Loader2, X } from "lucide-react";
import api from "@/lib/api";
import { toast } from "@/lib/toastHelpers";
import { resizeImage } from "@/lib/images";
import { useAuthStore } from "@/store/authStore";
import type { Reply } from "@/types";

interface Props {
  onSkip: () => void;
  onUploaded: () => void;
}

const ACCEPTED_TYPES = ["image/jpeg", "image/png", "image/webp"];

/**
 * Modal sugerido (no obligatorio) que se muestra una sola vez por usuario
 * cuando no tiene foto y aún no se le ha preguntado. Si elige "Continuar sin
 * foto" se marca `avatar_prompt_seen = 1` y no vuelve a aparecer.
 */
export default function AvatarPromptModal({ onSkip, onUploaded }: Props) {
  const setAvatarUrl = useAuthStore((s) => s.setAvatarUrl);
  const refreshMe = useAuthStore((s) => s.refreshMe);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [processing, setProcessing] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [dismissing, setDismissing] = useState(false);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape" && !uploading && !processing && !dismissing) {
        handleSkip();
      }
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [uploading, processing, dismissing]);

  async function handleSkip() {
    if (uploading || processing) return;
    setDismissing(true);
    try {
      await api.post<Reply<unknown>>("/users/me/dismiss-avatar-prompt");
    } catch {
      // si falla, cerramos igual; el flag se intentará la próxima vez
    } finally {
      await refreshMe();
      setDismissing(false);
      onSkip();
    }
  }

  async function handleFileChange(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!ACCEPTED_TYPES.includes(file.type)) {
      toast.error("Formato no soportado. Usa JPG, PNG o WebP.");
      if (fileInputRef.current) fileInputRef.current.value = "";
      return;
    }
    if (file.size > 2 * 1024 * 1024) {
      toast.error("La imagen pesa demasiado. Máximo 2 MB.");
      if (fileInputRef.current) fileInputRef.current.value = "";
      return;
    }

    setProcessing(true);
    try {
      const dataUrl = await resizeImage(file, 256);
      setPreview(dataUrl);
    } catch {
      toast.error("No fue posible procesar la imagen");
    } finally {
      setProcessing(false);
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  }

  async function handleUpload() {
    if (!preview || uploading) return;
    setUploading(true);
    try {
      const res = await api.post<Reply<{ avatarUrl: string }>>(
        "/users/me/avatar",
        { dataUrl: preview }
      );
      if (!res.data.ok || !res.data.obj) {
        toast.error(res.data.msg || "No fue posible guardar la foto");
        return;
      }
      setAvatarUrl(res.data.obj.avatarUrl);
      try {
        await api.post("/users/me/dismiss-avatar-prompt");
      } catch {
        // no bloqueante
      }
      // El avatar aparece de inmediato en el navbar, sin toast.
      await refreshMe();
      onUploaded();
    } catch (e: unknown) {
      const errObj = e as { response?: { data?: { msg?: string } } };
      toast.error(
        errObj?.response?.data?.msg || "No fue posible guardar la foto"
      );
    } finally {
      setUploading(false);
    }
  }

  const busy = uploading || dismissing;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="avatar-prompt-title"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4"
    >
      <div className="flex max-h-[90vh] w-full max-w-md flex-col overflow-y-auto rounded-xl bg-white p-6 shadow-2xl">
        <div className="mb-2 flex justify-end">
          <button
            type="button"
            onClick={handleSkip}
            disabled={busy}
            className="rounded p-1 text-gray-400 transition hover:bg-gray-100 hover:text-gray-700 disabled:opacity-50"
            aria-label="Cerrar"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="mb-5 text-center">
          <div className="mx-auto mb-3 flex h-20 w-20 items-center justify-center overflow-hidden rounded-full bg-gray-100">
            {preview ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img
                src={preview}
                alt="Vista previa"
                className="h-full w-full object-cover"
              />
            ) : (
              <Camera className="h-8 w-8 text-gray-400" />
            )}
          </div>
          <h2 id="avatar-prompt-title" className="text-xl font-semibold text-gray-900">
            ¿Subir foto de perfil?
          </h2>
          <p className="mt-1 text-sm text-gray-600">
            Una foto ayuda a tus colaboradores a identificarte rápido en
            reuniones e invitaciones.
          </p>
          <p className="mt-2 text-xs italic text-gray-400">
            Si prefieres, puedes hacerlo después desde tu perfil.
          </p>
        </div>

        <input
          ref={fileInputRef}
          type="file"
          accept="image/jpeg,image/png,image/webp"
          onChange={handleFileChange}
          className="hidden"
        />

        <div className="space-y-2">
          {!preview ? (
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              disabled={processing || busy}
              className="inline-flex w-full items-center justify-center gap-2 rounded-lg bg-millenium-blue px-4 py-2.5 text-sm font-medium text-white transition hover:bg-millenium-blue/90 focus:outline-none focus:ring-2 focus:ring-millenium-blue/40 disabled:opacity-50"
            >
              {processing ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Procesando...
                </>
              ) : (
                "Subir foto"
              )}
            </button>
          ) : (
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setPreview(null)}
                disabled={busy}
                className="flex-1 rounded-lg border border-gray-300 px-4 py-2.5 text-sm font-medium text-gray-700 transition hover:bg-gray-50 disabled:opacity-50"
              >
                Cambiar
              </button>
              <button
                type="button"
                onClick={handleUpload}
                disabled={busy}
                className="inline-flex flex-1 items-center justify-center gap-2 rounded-lg bg-millenium-blue px-4 py-2.5 text-sm font-medium text-white transition hover:bg-millenium-blue/90 focus:outline-none focus:ring-2 focus:ring-millenium-blue/40 disabled:opacity-50"
              >
                {uploading ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    Guardando...
                  </>
                ) : (
                  "Guardar esta foto"
                )}
              </button>
            </div>
          )}

          <button
            type="button"
            onClick={handleSkip}
            disabled={busy}
            className="w-full py-2 text-sm text-gray-500 transition hover:text-gray-700 disabled:opacity-50"
          >
            Continuar sin foto
          </button>
        </div>
      </div>
    </div>
  );
}
