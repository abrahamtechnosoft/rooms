"use client";

import { useEffect, useState } from "react";
import {
  DndContext,
  DragOverlay,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  type DragEndEvent,
  type DragStartEvent,
} from "@dnd-kit/core";
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  rectSortingStrategy,
} from "@dnd-kit/sortable";
import { motion } from "framer-motion";
import { Check, Pencil, RotateCcw } from "lucide-react";
import api from "@/lib/api";
import { toast } from "@/lib/toastHelpers";
import DaySingleTimeline from "@/components/DaySingleTimeline";
import SortableWidget from "./SortableWidget";
import WidgetNotes from "./widgets/WidgetNotes";
import WidgetPinned from "./widgets/WidgetPinned";
import WidgetReminders from "./widgets/WidgetReminders";
import WidgetNextMeeting from "./widgets/WidgetNextMeeting";
import WidgetRoomsStatus from "./widgets/WidgetRoomsStatus";
import type { Reply, Reservation } from "@/types";

type WidgetId =
  | "next-meeting"
  | "rooms-status"
  | "pinned"
  | "notes"
  | "reminders";

const DEFAULT_ORDER: WidgetId[] = [
  "next-meeting",
  "rooms-status",
  "pinned",
  "notes",
  "reminders",
];

const VALID_WIDGETS = new Set<WidgetId>(DEFAULT_ORDER);

const FULL_WIDTH_WIDGETS = new Set<WidgetId>([
  "next-meeting",
  "notes",
  "reminders",
]);

interface SlotPick {
  date: string;
  hour: number;
  minute: number;
}

interface Props {
  date: string;
  meetings: Reservation[];
  currentUserId: number | null;
  currentUserDeptId: number | null;
  readOnly?: boolean;
  onReservationClick: (r: Reservation) => void;
  onEmptyClick?: (slot: SlotPick) => void;
}

function sanitizeOrder(input: unknown): WidgetId[] | null {
  if (!Array.isArray(input)) return null;
  const known: WidgetId[] = [];
  const seen = new Set<WidgetId>();
  for (const v of input) {
    if (typeof v === "string" && VALID_WIDGETS.has(v as WidgetId)) {
      const id = v as WidgetId;
      if (!seen.has(id)) {
        seen.add(id);
        known.push(id);
      }
    }
  }
  if (known.length === 0) return null;
  // Agregar los que falten al final.
  for (const def of DEFAULT_ORDER) {
    if (!seen.has(def)) known.push(def);
  }
  return known;
}

export default function DashboardLayout(props: Props) {
  const [order, setOrder] = useState<WidgetId[]>(DEFAULT_ORDER);
  const [editing, setEditing] = useState(false);
  const [snapshot, setSnapshot] = useState<WidgetId[]>(DEFAULT_ORDER);
  const [activeId, setActiveId] = useState<WidgetId | null>(null);

  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 8 } }),
    useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates })
  );

  useEffect(() => {
    let cancelled = false;
    api
      .get<Reply<{ order?: WidgetId[] | null }>>("/dashboard/layout")
      .then((res) => {
        if (cancelled) return;
        const saved = sanitizeOrder(res.data?.obj?.order);
        if (saved) setOrder(saved);
      })
      .catch(() => {
        // silencioso: usar default
      });
    return () => {
      cancelled = true;
    };
  }, []);

  const handleDragStart = (event: DragStartEvent) => {
    setActiveId(event.active.id as WidgetId);
  };

  const handleDragEnd = (event: DragEndEvent) => {
    setActiveId(null);
    const { active, over } = event;
    if (!over || active.id === over.id) return;
    setOrder((items) => {
      const oldIdx = items.indexOf(active.id as WidgetId);
      const newIdx = items.indexOf(over.id as WidgetId);
      if (oldIdx < 0 || newIdx < 0) return items;
      return arrayMove(items, oldIdx, newIdx);
    });
  };

  const handleDragCancel = () => {
    setActiveId(null);
  };

  const handleStartEdit = () => {
    setSnapshot([...order]);
    setEditing(true);
  };

  const handleCancel = () => {
    setOrder([...snapshot]);
    setEditing(false);
  };

  const handleResetDefault = () => {
    setOrder([...DEFAULT_ORDER]);
  };

  const handleSave = async () => {
    try {
      await api.put("/dashboard/layout", { order });
      toast.success("Orden guardado");
    } catch {
      toast.error("No fue posible guardar el orden");
    }
    setEditing(false);
  };

  const renderWidget = (id: WidgetId) => {
    switch (id) {
      case "next-meeting":
        return <WidgetNextMeeting />;
      case "rooms-status":
        return <WidgetRoomsStatus />;
      case "pinned":
        return <WidgetPinned />;
      case "notes":
        if (props.currentUserId == null) return null;
        return (
          <WidgetNotes
            currentUserId={props.currentUserId}
            currentUserDeptId={props.currentUserDeptId}
          />
        );
      case "reminders":
        return <WidgetReminders />;
    }
  };

  return (
    <div className="space-y-3">
      {/* Toolbar de orden */}
      <div className="flex items-center justify-end gap-2">
        {editing ? (
          <>
            <button
              type="button"
              onClick={handleResetDefault}
              className="inline-flex items-center gap-1 rounded-md border border-gray-300 bg-white px-2.5 py-1.5 text-xs font-medium text-gray-700 transition-colors hover:bg-gray-50"
            >
              <RotateCcw className="h-3.5 w-3.5" aria-hidden="true" />
              Restaurar
            </button>
            <button
              type="button"
              onClick={handleCancel}
              className="rounded-md border border-gray-300 bg-white px-2.5 py-1.5 text-xs font-medium text-gray-700 transition-colors hover:bg-gray-50"
            >
              Cancelar
            </button>
            <button
              type="button"
              onClick={handleSave}
              className="inline-flex items-center gap-1 rounded-md bg-millenium-blue px-3 py-1.5 text-xs font-medium text-white transition-opacity hover:opacity-90"
            >
              <Check className="h-3.5 w-3.5" aria-hidden="true" /> Guardar
            </button>
          </>
        ) : (
          <button
            type="button"
            onClick={handleStartEdit}
            className="inline-flex items-center gap-1 rounded-md border border-gray-300 bg-white px-2.5 py-1.5 text-xs font-medium text-gray-700 transition-colors hover:bg-gray-50"
          >
            <Pencil className="h-3.5 w-3.5" aria-hidden="true" /> Editar orden
          </button>
        )}
      </div>

      {/* Layout principal */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-12">
        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.25, ease: "easeOut" }}
          className="lg:col-span-7"
        >
          <div className="overflow-hidden rounded-lg border border-gray-200 bg-white">
            <DaySingleTimeline
              date={props.date}
              meetings={props.meetings}
              currentUserId={props.currentUserId}
              readOnly={props.readOnly}
              onReservationClick={props.onReservationClick}
              onEmptyClick={props.onEmptyClick}
            />
          </div>
        </motion.div>

        <div className="lg:col-span-5">
          <DndContext
            sensors={sensors}
            collisionDetection={closestCenter}
            onDragStart={handleDragStart}
            onDragEnd={handleDragEnd}
            onDragCancel={handleDragCancel}
          >
            <SortableContext items={order} strategy={rectSortingStrategy}>
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                {order.map((id) => (
                  <SortableWidget
                    key={id}
                    id={id}
                    isEditing={editing}
                    className={FULL_WIDTH_WIDGETS.has(id) ? "sm:col-span-2" : ""}
                  >
                    {renderWidget(id)}
                  </SortableWidget>
                ))}
              </div>
            </SortableContext>

            <DragOverlay
              dropAnimation={{
                duration: 250,
                easing: "cubic-bezier(0.18, 0.67, 0.6, 1.22)",
              }}
            >
              {activeId ? (
                <div className="h-70 cursor-grabbing overflow-hidden rounded-lg border-2 border-millenium-blue bg-white shadow-2xl">
                  {renderWidget(activeId)}
                </div>
              ) : null}
            </DragOverlay>
          </DndContext>
        </div>
      </div>
    </div>
  );
}
