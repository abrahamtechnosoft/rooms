"use client";

import { useCallback, useEffect, useState } from "react";
import { StickyNote } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import api from "@/lib/api";
import { onWidgetEvent } from "@/lib/widgetEvents";
import WidgetShell from "../WidgetShell";
import EmptyState from "@/components/EmptyState";
import Skeleton from "@/components/Skeleton";
import NoteFormModal from "@/components/NoteFormModal";
import type { NoteVisibility, Reply, UserNote } from "@/types";

const ICON_COLOR = "#2C3E50";

interface Props {
  currentUserId: number;
  currentUserDeptId: number | null;
}

export default function WidgetNotes({
  currentUserId,
  currentUserDeptId,
}: Props) {
  const [notes, setNotes] = useState<UserNote[]>([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState<NoteVisibility>("personal");
  const [creating, setCreating] = useState(false);
  const [editing, setEditing] = useState<UserNote | null>(null);

  const load = useCallback(async () => {
    try {
      const r = await api.get<Reply<UserNote[]>>("/notes");
      setNotes(r.data.obj || []);
    } catch {
      // silencioso
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
    const offEvt = onWidgetEvent("notes:changed", load);
    const onFocus = () => load();
    window.addEventListener("focus", onFocus);
    return () => {
      offEvt();
      window.removeEventListener("focus", onFocus);
    };
  }, [load]);

  const filtered = notes.filter((n) =>
    tab === "personal"
      ? n.visibility === "personal"
      : n.visibility === "department"
  );

  if (loading) {
    return (
      <WidgetShell
        title="Notas"
        icon={StickyNote}
        iconColor={ICON_COLOR}
        isEmpty={false}
      >
        {() => (
          <div className="space-y-2 p-2">
            <Skeleton className="h-16 rounded" />
            <Skeleton className="h-16 rounded" />
          </div>
        )}
      </WidgetShell>
    );
  }

  return (
    <>
      <WidgetShell
        title="Notas"
        icon={StickyNote}
        iconColor={ICON_COLOR}
        href="/dashboard/agenda"
        onCreate={() => setCreating(true)}
        isEmpty={filtered.length === 0}
        emptyState={
          <EmptyState
            icon={StickyNote}
            title={
              tab === "personal"
                ? "Sin notas personales"
                : "Sin notas del area"
            }
            description="Click para crear una"
            compact
          />
        }
        headerExtras={
          <div className="flex items-center gap-0.5 rounded-full bg-gray-100 p-0.5">
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                setTab("personal");
              }}
              className={
                "rounded-full px-2.5 py-1.5 text-xs font-medium transition-colors sm:py-1 " +
                (tab === "personal"
                  ? "bg-white shadow-sm"
                  : "text-gray-600 hover:text-gray-900")
              }
            >
              Mis
            </button>
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                setTab("department");
              }}
              disabled={!currentUserDeptId}
              className={
                "rounded-full px-2.5 py-1.5 text-xs font-medium transition-colors disabled:opacity-30 sm:py-1 " +
                (tab === "department"
                  ? "bg-white shadow-sm"
                  : "text-gray-600 hover:text-gray-900")
              }
              title={!currentUserDeptId ? "Sin departamento asignado" : undefined}
            >
              Depto
            </button>
          </div>
        }
      >
        {() => (
          <div className="scrollbar-thin h-full overflow-y-auto overscroll-contain p-2">
            <div className="space-y-1.5">
              <AnimatePresence initial={false}>
                {filtered.map((n) => (
                  <motion.div
                    key={n.noteId}
                    layout
                    initial={{ opacity: 0, scale: 0.95, y: -6 }}
                    animate={{ opacity: 1, scale: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.95, x: -10 }}
                    transition={{ duration: 0.18 }}
                    onClick={() => {
                      if (n.authorId === currentUserId) setEditing(n);
                    }}
                    className={
                      "rounded-md p-2 text-xs shadow-sm transition-shadow " +
                      (n.authorId === currentUserId
                        ? "cursor-pointer hover:shadow-md"
                        : "")
                    }
                    style={{ backgroundColor: n.colorHex }}
                  >
                    {n.title && (
                      <div className="mb-0.5 truncate font-semibold">
                        {n.title}
                      </div>
                    )}
                    <div className="max-h-16 overflow-y-auto whitespace-pre-wrap wrap-break-word leading-snug">
                      {n.content}
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          </div>
        )}
      </WidgetShell>

      {(creating || editing) && (
        <NoteFormModal
          note={editing}
          defaultVisibility={tab}
          canCreateDept={!!currentUserDeptId}
          onSaved={() => {
            setCreating(false);
            setEditing(null);
            load();
          }}
          onCancel={() => {
            setCreating(false);
            setEditing(null);
          }}
        />
      )}
    </>
  );
}
