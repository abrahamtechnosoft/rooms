"use client";

import { useEffect, useMemo, useState } from "react";
import { Building2 } from "lucide-react";
import { motion } from "framer-motion";
import api from "@/lib/api";
import { useNowTick } from "@/hooks/useNowTick";
import { endOfDayIso, startOfDayIso, today } from "@/lib/dates";
import WidgetShell from "../WidgetShell";
import EmptyState from "@/components/EmptyState";
import Skeleton from "@/components/Skeleton";
import type { Reply, Reservation, Room } from "@/types";

const ICON_COLOR = "#8B5CF6";

interface RoomStatus {
  roomId: number;
  roomName: string;
  isBusy: boolean;
  currentTitle: string | null;
}

export default function WidgetRoomsStatus() {
  const [rooms, setRooms] = useState<Room[]>([]);
  const [reservations, setReservations] = useState<Reservation[]>([]);
  const [loading, setLoading] = useState(true);
  const now = useNowTick(60_000);

  useEffect(() => {
    let cancelled = false;
    const ymd = today();
    const load = () => {
      Promise.all([
        api.get<Reply<Room[]>>("/rooms"),
        api.get<Reply<Reservation[]>>("/reservations", {
          params: { from: startOfDayIso(ymd), to: endOfDayIso(ymd) },
        }),
      ])
        .then(([rRes, resvRes]) => {
          if (cancelled) return;
          setRooms((rRes.data.obj || []).filter((r) => r.isActive));
          setReservations(resvRes.data.obj || []);
        })
        .catch(() => {
          // silencioso
        })
        .finally(() => {
          if (!cancelled) setLoading(false);
        });
    };
    load();
    const id = setInterval(load, 60_000);
    return () => {
      cancelled = true;
      clearInterval(id);
    };
  }, []);

  const statuses: RoomStatus[] = useMemo(() => {
    const nowMs = now.getTime();
    return rooms.map((room) => {
      const current = reservations.find(
        (r) =>
          r.status === "active" &&
          !r.endedEarly &&
          r.roomId === room.id &&
          new Date(r.startsAt).getTime() <= nowMs &&
          new Date(r.endsAt).getTime() > nowMs
      );
      return {
        roomId: room.id,
        roomName: room.name,
        isBusy: !!current,
        currentTitle: current?.title ?? null,
      };
    });
  }, [rooms, reservations, now]);

  if (loading) {
    return (
      <WidgetShell
        title="Salas ahora"
        icon={Building2}
        iconColor={ICON_COLOR}
        isEmpty={false}
      >
        {() => (
          <div className="space-y-1.5 p-2">
            <Skeleton className="h-8 rounded" />
            <Skeleton className="h-8 rounded" />
            <Skeleton className="h-8 rounded" />
          </div>
        )}
      </WidgetShell>
    );
  }

  return (
    <WidgetShell
      title="Salas ahora"
      icon={Building2}
      iconColor={ICON_COLOR}
      isEmpty={statuses.length === 0}
      emptyState={
        <EmptyState
          icon={Building2}
          title="Sin salas activas"
          description="Pide a un administrador que active salas."
          compact
        />
      }
    >
      {() => (
        <div className="scrollbar-thin h-full overflow-y-auto overscroll-contain p-2">
          <ul className="space-y-0.5">
            {statuses.map((s) => (
              <motion.li
                key={s.roomId}
                layout
                className="flex items-center gap-2 rounded-md px-2 py-1.5 transition-colors hover:bg-gray-50"
              >
                <motion.span
                  aria-hidden="true"
                  className="h-2 w-2 shrink-0 rounded-full"
                  style={{
                    backgroundColor: s.isBusy ? "#C0392B" : "#27AE60",
                  }}
                  animate={s.isBusy ? { scale: [1, 1.3, 1] } : undefined}
                  transition={
                    s.isBusy
                      ? { repeat: Infinity, duration: 2 }
                      : { duration: 0 }
                  }
                />
                <div className="min-w-0 flex-1">
                  <div className="truncate text-xs font-medium">
                    {s.roomName}
                  </div>
                  {s.isBusy && s.currentTitle && (
                    <div className="truncate text-[11px] text-gray-500">
                      {s.currentTitle}
                    </div>
                  )}
                </div>
                <span className="shrink-0 text-[11px] font-medium text-gray-500">
                  {s.isBusy ? "Ocupada" : "Libre"}
                </span>
              </motion.li>
            ))}
          </ul>
        </div>
      )}
    </WidgetShell>
  );
}
