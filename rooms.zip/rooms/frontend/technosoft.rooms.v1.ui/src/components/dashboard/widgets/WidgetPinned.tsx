"use client";

import { useCallback, useEffect, useState } from "react";
import { Pin } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import api from "@/lib/api";
import { onWidgetEvent } from "@/lib/widgetEvents";
import WidgetShell from "../WidgetShell";
import EmptyState from "@/components/EmptyState";
import Skeleton from "@/components/Skeleton";
import type { Reply, UserNote } from "@/types";

const ICON_COLOR = "#E67E22";

export default function WidgetPinned() {
  const [notes, setNotes] = useState<UserNote[]>([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    try {
      const r = await api.get<Reply<UserNote[]>>("/notes");
      setNotes((r.data.obj || []).filter((n) => n.isPinned));
    } catch {
      // silencioso
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
    const offEvt = onWidgetEvent("notes:changed", load);
    const onFocus = () => load();
    window.addEventListener("focus", onFocus);
    return () => {
      offEvt();
      window.removeEventListener("focus", onFocus);
    };
  }, [load]);

  if (loading) {
    return (
      <WidgetShell
        title="Notas fijadas"
        icon={Pin}
        iconColor={ICON_COLOR}
        isEmpty={false}
      >
        {() => (
          <div className="space-y-2 p-2">
            <Skeleton className="h-14 rounded" />
            <Skeleton className="h-14 rounded" />
          </div>
        )}
      </WidgetShell>
    );
  }

  return (
    <WidgetShell
      title="Notas fijadas"
      icon={Pin}
      iconColor={ICON_COLOR}
      href="/dashboard/agenda"
      isEmpty={notes.length === 0}
      emptyState={
        <EmptyState
          icon={Pin}
          title="Sin notas fijadas"
          description="Fija notas desde el panel de notas para verlas aqui."
          compact
        />
      }
    >
      {() => (
        <div className="scrollbar-thin h-full overflow-y-auto overscroll-contain p-2">
          <div className="space-y-1.5">
            <AnimatePresence initial={false}>
              {notes.map((n) => (
                <motion.div
                  key={n.noteId}
                  layout
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  transition={{ duration: 0.18 }}
                  className="rounded-md p-2 text-xs shadow-sm"
                  style={{ backgroundColor: n.colorHex }}
                >
                  {n.title && (
                    <div className="mb-0.5 font-semibold">{n.title}</div>
                  )}
                  <div className="line-clamp-2 whitespace-pre-wrap wrap-break-word leading-snug">
                    {n.content}
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        </div>
      )}
    </WidgetShell>
  );
}
