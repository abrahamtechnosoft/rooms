"use client";

import { useCallback, useEffect, useState } from "react";
import { Bell, Check, Pencil, Trash2 } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import api from "@/lib/api";
import { toast } from "@/lib/toastHelpers";
import { fmtDateTime } from "@/lib/dates";
import { emitWidgetEvent, onWidgetEvent } from "@/lib/widgetEvents";
import WidgetShell from "../WidgetShell";
import EmptyState from "@/components/EmptyState";
import Skeleton from "@/components/Skeleton";
import ReminderFormModal from "@/components/agenda/ReminderFormModal";
import type { Reply, UserReminder } from "@/types";

const ICON_COLOR = "#F59E0B";

export default function WidgetReminders() {
  const [items, setItems] = useState<UserReminder[]>([]);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const [editing, setEditing] = useState<UserReminder | null>(null);

  const load = useCallback(async () => {
    try {
      const r = await api.get<Reply<UserReminder[]>>("/reminders");
      setItems((r.data.obj || []).filter((x) => !x.isDone));
    } catch {
      // silencioso
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
    const offEvt = onWidgetEvent("reminders:changed", load);
    const onFocus = () => load();
    window.addEventListener("focus", onFocus);
    return () => {
      offEvt();
      window.removeEventListener("focus", onFocus);
    };
  }, [load]);

  const handleDone = async (rem: UserReminder) => {
    try {
      await api.put(`/reminders/${rem.reminderId}`, { isDone: true });
      load();
      emitWidgetEvent("reminders:changed");
    } catch {
      toast.error("No fue posible marcar");
    }
  };
  const handleDelete = async (rem: UserReminder) => {
    try {
      await api.delete(`/reminders/${rem.reminderId}`);
      load();
      emitWidgetEvent("reminders:changed");
    } catch {
      toast.error("No fue posible eliminar");
    }
  };

  if (loading) {
    return (
      <WidgetShell
        title="Recordatorios"
        icon={Bell}
        iconColor={ICON_COLOR}
        isEmpty={false}
      >
        {() => (
          <div className="space-y-2 p-2">
            <Skeleton className="h-12 rounded" />
            <Skeleton className="h-12 rounded" />
          </div>
        )}
      </WidgetShell>
    );
  }

  return (
    <>
      <WidgetShell
        title="Recordatorios"
        icon={Bell}
        iconColor={ICON_COLOR}
        href="/dashboard/agenda"
        onCreate={() => setCreating(true)}
        isEmpty={items.length === 0}
        emptyState={
          <EmptyState
            icon={Bell}
            title="Sin recordatorios"
            description="Click para crear el primero"
            compact
          />
        }
      >
        {() => (
          <div className="scrollbar-thin h-full overflow-y-auto overscroll-contain p-2">
            <div className="space-y-1">
              <AnimatePresence initial={false}>
                {items.map((r) => (
                  <motion.div
                    key={r.reminderId}
                    layout
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 10 }}
                    transition={{ duration: 0.18 }}
                    className="group relative flex items-start gap-2 rounded-md p-2 transition-colors hover:bg-gray-50"
                  >
                    <Bell className="mt-0.5 h-3.5 w-3.5 shrink-0 text-amber-500" aria-hidden="true" />
                    <div className="min-w-0 flex-1 pr-28 sm:pr-16">
                      <div className="truncate text-xs font-medium">
                        {r.title}
                      </div>
                      <div className="text-[11px] text-gray-500 tabular-nums">
                        {fmtDateTime(r.remindAt)}
                      </div>
                    </div>
                    <div className="absolute right-1 top-1 flex gap-1 opacity-100 transition-opacity md:opacity-0 md:group-hover:opacity-100 md:group-focus-within:opacity-100">
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleDone(r);
                        }}
                        className="rounded bg-white p-2 shadow-sm transition-colors hover:bg-green-50 sm:p-1.5"
                        title="Marcar hecho"
                        aria-label="Marcar hecho"
                      >
                        <Check className="h-4 w-4 text-green-600" aria-hidden="true" />
                      </button>
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setEditing(r);
                        }}
                        className="rounded bg-white p-2 shadow-sm transition-colors hover:bg-gray-100 sm:p-1.5"
                        title="Editar"
                        aria-label="Editar recordatorio"
                      >
                        <Pencil className="h-4 w-4 text-gray-500" aria-hidden="true" />
                      </button>
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleDelete(r);
                        }}
                        className="rounded bg-white p-2 shadow-sm transition-colors hover:bg-red-50 sm:p-1.5"
                        title="Eliminar"
                        aria-label="Eliminar recordatorio"
                      >
                        <Trash2 className="h-4 w-4 text-millenium-red" aria-hidden="true" />
                      </button>
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          </div>
        )}
      </WidgetShell>

      {(creating || editing) && (
        <ReminderFormModal
          reminder={editing}
          onSaved={() => {
            setCreating(false);
            setEditing(null);
            load();
          }}
          onCancel={() => {
            setCreating(false);
            setEditing(null);
          }}
        />
      )}
    </>
  );
}
