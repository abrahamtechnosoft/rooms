"use client";

import { useEffect, useMemo, useState } from "react";
import {
  Briefcase,
  Building2,
  Calendar,
  Clock,
  Globe,
  MapPin,
} from "lucide-react";
import { motion } from "framer-motion";
import api from "@/lib/api";
import { fmtTime, isInProgress } from "@/lib/dates";
import { useNowTick } from "@/hooks/useNowTick";
import WidgetShell from "../WidgetShell";
import EmptyState from "@/components/EmptyState";
import Skeleton from "@/components/Skeleton";
import type { Reply, Reservation } from "@/types";

const ICON_COLOR = "#2C3E50";

export default function WidgetNextMeeting() {
  const [meetings, setMeetings] = useState<Reservation[]>([]);
  const [loading, setLoading] = useState(true);
  const now = useNowTick(60_000);

  useEffect(() => {
    let cancelled = false;
    api
      .get<Reply<Reservation[]>>("/reservations/mine")
      .then((r) => {
        if (cancelled) return;
        setMeetings(r.data.obj || []);
      })
      .catch(() => {
        // silencioso
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  const next = useMemo(() => {
    const nowMs = now.getTime();
    return meetings
      .filter((m) => m.status === "active" && !m.endedEarly)
      .filter((m) => new Date(m.endsAt).getTime() > nowMs)
      .sort(
        (a, b) =>
          new Date(a.startsAt).getTime() - new Date(b.startsAt).getTime()
      )[0];
  }, [meetings, now]);

  if (loading) {
    return (
      <WidgetShell
        title="Proxima reunion"
        icon={Calendar}
        iconColor={ICON_COLOR}
        isEmpty={false}
      >
        {() => (
          <div className="p-3">
            <Skeleton className="h-16 rounded" />
          </div>
        )}
      </WidgetShell>
    );
  }

  return (
    <WidgetShell
      title="Proxima reunion"
      icon={Calendar}
      iconColor={ICON_COLOR}
      href="/dashboard/reservations"
      isEmpty={!next}
      emptyState={
        <EmptyState
          icon={Calendar}
          title="Sin proximas reuniones"
          description="Cuando alguien te invite o agendes una, aparecera aqui."
          compact
        />
      }
    >
      {() => {
        if (!next) return null;
        const inProgress = isInProgress(next.startsAt, next.endsAt, now);
        const startsAt = new Date(next.startsAt);
        const diffMs = startsAt.getTime() - now.getTime();
        const diffMin = Math.round(diffMs / 60000);
        const TypeIcon =
          next.type === "physical"
            ? Building2
            : next.type === "office"
              ? Briefcase
              : next.type === "virtual"
                ? Globe
                : MapPin;

        const locationLabel =
          next.type === "office"
            ? next.officeName || "Oficina del departamento"
            : next.type === "physical"
              ? next.roomName ?? ""
              : "";

        let when: string;
        if (inProgress) {
          when = "En curso";
        } else if (diffMin < 60) {
          when = `En ${Math.max(1, diffMin)} min`;
        } else if (diffMin < 60 * 24) {
          when = `En ${Math.floor(diffMin / 60)} h ${diffMin % 60} min`;
        } else {
          when = fmtTime(next.startsAt);
        }

        return (
          <motion.div
            initial={{ opacity: 0, y: 4 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.2 }}
            className="flex h-full flex-col justify-center p-4"
          >
            <div className="flex items-start gap-3">
              <TypeIcon
                className="mt-0.5 h-5 w-5 shrink-0"
                style={{ color: ICON_COLOR }}
                aria-hidden="true"
              />
              <div className="min-w-0 flex-1">
                <div
                  className={
                    "text-[11px] font-semibold uppercase tracking-wide " +
                    (inProgress ? "text-millenium-red" : "text-gray-500")
                  }
                >
                  {when}
                </div>
                <div className="mt-0.5 truncate text-base font-semibold text-gray-900">
                  {next.title}
                </div>
                <div className="mt-1 flex items-center gap-1 text-xs text-gray-500 tabular-nums">
                  <Clock className="h-3 w-3" aria-hidden="true" />
                  {fmtTime(next.startsAt)} - {fmtTime(next.endsAt)}
                  {locationLabel ? ` - ${locationLabel}` : ""}
                </div>
              </div>
            </div>
          </motion.div>
        );
      }}
    </WidgetShell>
  );
}
