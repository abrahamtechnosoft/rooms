"use client";

import { type ReactNode } from "react";
import { useRouter } from "next/navigation";
import { Plus, type LucideIcon } from "lucide-react";

interface Props {
  title: string;
  icon: LucideIcon;
  iconColor?: string;
  href?: string;
  onCreate?: () => void;
  emptyState?: ReactNode;
  isEmpty: boolean;
  headerExtras?: ReactNode;
  children: () => ReactNode;
}

const DEFAULT_ICON_COLOR = "#6B7280";

// Carcasa comun. Header fijo, body con scroll interno (si el contenido excede
// el alto fijo del WidgetWrapper). Sin color personalizable ni modo edicion:
// el dashboard pasa a layout CSS grid nativo y los iconos usan color fijo.
export default function WidgetShell({
  title,
  icon: Icon,
  iconColor = DEFAULT_ICON_COLOR,
  href,
  onCreate,
  emptyState,
  isEmpty,
  headerExtras,
  children,
}: Props) {
  const router = useRouter();

  const handleHeaderClick = () => {
    if (href) router.push(href);
  };

  const handleEmptyClick = () => {
    if (onCreate) onCreate();
  };

  return (
    <div className="flex h-full w-full flex-col">
      <div className="flex shrink-0 items-center justify-between gap-2 border-b border-gray-200 px-3 py-2">
        <button
          type="button"
          onClick={handleHeaderClick}
          disabled={!href}
          className={
            "flex min-w-0 flex-1 items-center gap-2 text-left transition-colors " +
            (href
              ? "cursor-pointer hover:opacity-80"
              : "cursor-default")
          }
          title={href ? "Abrir Agenda" : undefined}
        >
          <Icon
            className="h-4 w-4 shrink-0"
            style={{ color: iconColor }}
            aria-hidden="true"
          />
          <span className="truncate text-sm font-semibold text-gray-900">
            {title}
          </span>
        </button>
        <div
          className="flex shrink-0 items-center gap-1"
          onClick={(e) => e.stopPropagation()}
        >
          {headerExtras}
          {onCreate && !isEmpty && (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onCreate();
              }}
              className="rounded-md p-1.5 text-gray-500 transition-colors hover:bg-gray-100 hover:text-gray-700"
              title="Crear"
              aria-label="Crear"
            >
              <Plus className="h-4 w-4" aria-hidden="true" />
            </button>
          )}
        </div>
      </div>

      <div className="min-h-0 flex-1 overflow-hidden">
        {isEmpty ? (
          <div
            onClick={handleEmptyClick}
            className={
              "flex h-full w-full items-center justify-center px-4 py-6 transition-colors " +
              (onCreate
                ? "cursor-pointer hover:bg-gray-50/60"
                : "")
            }
          >
            {emptyState ?? (
              <div className="text-center">
                <p className="text-sm font-medium text-gray-500">Sin items</p>
                {onCreate && (
                  <p className="mt-1 text-xs text-gray-400">Click para crear</p>
                )}
              </div>
            )}
          </div>
        ) : (
          <div className="h-full w-full">{children()}</div>
        )}
      </div>
    </div>
  );
}
