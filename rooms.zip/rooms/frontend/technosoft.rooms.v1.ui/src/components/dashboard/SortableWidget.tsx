"use client";

import { useSortable } from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import { GripVertical } from "lucide-react";

interface Props {
  id: string;
  isEditing: boolean;
  className?: string;
  children: React.ReactNode;
}

export default function SortableWidget({
  id,
  isEditing,
  className = "",
  children,
}: Props) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id, disabled: !isEditing });

  const style: React.CSSProperties = {
    transform: CSS.Transform.toString(transform),
    transition,
  };

  return (
    <div
      ref={setNodeRef}
      style={style}
      className={
        "relative h-70 overflow-hidden rounded-lg border border-gray-200 bg-white shadow-sm transition-opacity " +
        (isEditing ? "ring-2 ring-millenium-blue/30 " : "") +
        (isDragging ? "opacity-30 " : "opacity-100 ") +
        className
      }
    >
      {isEditing && (
        <button
          type="button"
          {...attributes}
          {...listeners}
          aria-label="Arrastrar para reordenar"
          className="absolute right-1 top-1 z-20 cursor-grab touch-none rounded bg-white/95 p-1.5 shadow-sm backdrop-blur-sm transition-colors hover:bg-gray-50 active:cursor-grabbing"
        >
          <GripVertical className="h-4 w-4 text-gray-500" aria-hidden="true" />
        </button>
      )}
      <div className="h-full w-full">{children}</div>
    </div>
  );
}
