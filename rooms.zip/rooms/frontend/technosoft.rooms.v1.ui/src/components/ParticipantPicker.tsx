"use client";

import { useEffect, useRef, useState } from "react";
import { Info, Mail, Plus, Users, X } from "lucide-react";
import api from "@/lib/api";
import { useAuthStore } from "@/store/authStore";
import Avatar from "@/components/Avatar";
import type { Reply, UserPickerItem } from "@/types";

interface Props {
  value: UserPickerItem[];
  onChange: (next: UserPickerItem[]) => void;
  disabled?: boolean;
  /**
   * IDs de usuarios que ya están incluidos por otra vía (típicamente,
   * por estar en un departamento invitado). Se muestran en el dropdown
   * en gris y no se pueden volver a seleccionar.
   */
  alreadyIncludedIds?: Set<number>;
  /** Razón mostrada bajo el usuario gris en el dropdown. */
  alreadyIncludedReason?: string;
}

const hasNameOf = (u: UserPickerItem) =>
  !!(u.fullName && u.fullName.trim().length > 0);

export default function ParticipantPicker({
  value,
  onChange,
  disabled,
  alreadyIncludedIds,
  alreadyIncludedReason = "Ya incluido",
}: Props) {
  const me = useAuthStore((s) => s.user);
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<UserPickerItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [highlight, setHighlight] = useState(0);

  const inputRef = useRef<HTMLInputElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function onClickOutside(e: MouseEvent) {
      if (
        containerRef.current &&
        !containerRef.current.contains(e.target as Node)
      ) {
        setOpen(false);
      }
    }
    document.addEventListener("mousedown", onClickOutside);
    return () => document.removeEventListener("mousedown", onClickOutside);
  }, []);

  useEffect(() => {
    if (!open) return;
    let cancelled = false;
    const t = setTimeout(async () => {
      setLoading(true);
      try {
        const res = await api.get<Reply<UserPickerItem[]>>("/users/picker", {
          params: { q: query },
        });
        if (cancelled) return;
        const list = res.data.obj || [];
        // Excluye al propio usuario y a los ya seleccionados (que se ven como
        // chips arriba). Los `alreadyIncludedIds` SÍ se muestran en el dropdown
        // pero deshabilitados, para que el usuario entienda por qué no puede
        // agregarlos.
        const filtered = list.filter(
          (u) => u.id !== me?.id && !value.some((v) => v.id === u.id)
        );
        setResults(filtered);
        setHighlight(0);
      } catch {
        if (!cancelled) setResults([]);
      } finally {
        if (!cancelled) setLoading(false);
      }
    }, 200);
    return () => {
      cancelled = true;
      clearTimeout(t);
    };
  }, [query, open, value, me]);

  const isAlreadyIncluded = (id: number): boolean =>
    !!alreadyIncludedIds && alreadyIncludedIds.has(id);

  const add = (user: UserPickerItem) => {
    if (isAlreadyIncluded(user.id)) return;
    onChange([...value, user]);
    setQuery("");
    setOpen(false);
    inputRef.current?.blur();
  };

  const reopen = () => {
    setOpen(true);
    setQuery("");
    inputRef.current?.focus();
  };

  const remove = (id: number) => {
    onChange(value.filter((u) => u.id !== id));
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Backspace" && query === "" && value.length > 0) {
      remove(value[value.length - 1].id);
    } else if (e.key === "Enter" && results.length > 0) {
      e.preventDefault();
      add(results[highlight] || results[0]);
    } else if (e.key === "ArrowDown" && results.length > 0) {
      e.preventDefault();
      setHighlight((h) => Math.min(h + 1, results.length - 1));
    } else if (e.key === "ArrowUp" && results.length > 0) {
      e.preventDefault();
      setHighlight((h) => Math.max(h - 1, 0));
    } else if (e.key === "Escape") {
      setOpen(false);
      inputRef.current?.blur();
    }
  };

  return (
    <div ref={containerRef} className="relative">
      <div
        className={
          "flex flex-wrap items-center gap-2 rounded-lg border border-gray-300 bg-white p-2 min-h-[44px] transition focus-within:border-millenium-blue focus-within:ring-2 focus-within:ring-millenium-blue/20 " +
          (disabled ? "cursor-not-allowed opacity-60" : "cursor-text")
        }
        onClick={() => {
          if (disabled) return;
          setOpen(true);
          inputRef.current?.focus();
        }}
      >
        {value.map((u) => {
          const hasName = hasNameOf(u);
          const hasPhoto = !!u.avatarUrl;
          const displayText = hasName ? u.fullName : u.email;
          const alsoInDept = isAlreadyIncluded(u.id);
          return (
            <span
              key={u.id}
              className="inline-flex max-w-full items-center gap-2 rounded-full bg-millenium-blue/10 px-2.5 py-1 text-sm text-millenium-blue"
            >
              {hasName || hasPhoto ? (
                <Avatar
                  name={u.fullName || u.email}
                  email={u.email}
                  avatarUrl={u.avatarUrl}
                  size="sm"
                />
              ) : (
                <span
                  className="inline-flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-millenium-blue/20"
                  aria-hidden="true"
                >
                  <Mail className="h-3.5 w-3.5" />
                </span>
              )}
              <span className="max-w-[180px] truncate font-medium">
                {displayText}
              </span>
              {alsoInDept && (
                <span
                  className="inline-flex items-center text-amber-600"
                  title="También vía departamento"
                  aria-label="También vía departamento"
                >
                  <Info className="h-3.5 w-3.5" />
                </span>
              )}
              {!disabled && (
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    remove(u.id);
                  }}
                  className="rounded-full text-millenium-blue/70 transition hover:text-millenium-red focus:outline-none focus:ring-2 focus:ring-millenium-blue/40 focus:ring-offset-1"
                  aria-label={`Quitar ${displayText}`}
                >
                  <X className="h-3.5 w-3.5" />
                </button>
              )}
            </span>
          );
        })}

        <input
          ref={inputRef}
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onFocus={() => setOpen(true)}
          onKeyDown={handleKeyDown}
          placeholder={value.length === 0 ? "Buscar por nombre o correo" : ""}
          className="min-w-[120px] flex-1 border-0 bg-transparent text-base outline-none placeholder:text-gray-400 disabled:cursor-not-allowed"
          disabled={disabled}
        />
      </div>

      {open && !disabled && (
        <div className="absolute z-30 mt-1 w-full max-h-48 overflow-y-auto rounded-lg border border-gray-200 bg-white shadow-lg">
          {loading ? (
            <div className="p-4 text-center text-sm text-gray-500">
              Buscando...
            </div>
          ) : query.length > 0 && results.length === 0 ? (
            <div className="p-4 text-center text-sm text-gray-500">
              <p>
                Sin resultados para{" "}
                <span className="font-medium text-gray-700">
                  &ldquo;{query}&rdquo;
                </span>
              </p>
              <p className="mt-1 text-xs">Intente con otro nombre o correo</p>
            </div>
          ) : query.length === 0 && results.length === 0 ? (
            <div className="p-4 text-center text-sm text-gray-500">
              Escriba para buscar personas
            </div>
          ) : (
            <>
              {query.length > 0 && results.length > 0 && (
                <div className="border-b border-gray-100 px-3 py-1.5 text-xs uppercase tracking-wide text-gray-500">
                  {results.length}{" "}
                  {results.length === 1 ? "resultado" : "resultados"}
                </div>
              )}
              <ul>
                {results.map((u, idx) => {
                  const hasName = hasNameOf(u);
                  const hasPhoto = !!u.avatarUrl;
                  const includedByDept = isAlreadyIncluded(u.id);
                  return (
                    <li key={u.id}>
                      <button
                        type="button"
                        onMouseEnter={() => setHighlight(idx)}
                        onClick={() => add(u)}
                        disabled={includedByDept}
                        aria-disabled={includedByDept}
                        className={
                          "flex w-full items-center gap-3 px-3 py-2 text-left transition " +
                          (includedByDept
                            ? "cursor-not-allowed opacity-60"
                            : idx === highlight
                              ? "bg-gray-100"
                              : "hover:bg-gray-50")
                        }
                      >
                        {hasName || hasPhoto ? (
                          <Avatar
                            name={u.fullName || u.email}
                            email={u.email}
                            avatarUrl={u.avatarUrl}
                            size="sm"
                          />
                        ) : (
                          <span
                            className="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-gray-200 text-gray-500"
                            aria-hidden="true"
                          >
                            <Mail className="h-4 w-4" />
                          </span>
                        )}
                        <span className="min-w-0 flex-1">
                          {hasName ? (
                            <>
                              <span className="block truncate text-sm font-medium text-gray-900">
                                {u.fullName}
                              </span>
                              <span className="block truncate text-xs text-gray-500">
                                {u.email}
                              </span>
                            </>
                          ) : (
                            <span className="block truncate text-sm text-gray-900">
                              {u.email}
                            </span>
                          )}
                          {includedByDept && (
                            <span className="mt-0.5 flex items-center gap-1 text-xs text-amber-600">
                              <Info className="h-3 w-3 shrink-0" />
                              {alreadyIncludedReason}
                            </span>
                          )}
                        </span>
                      </button>
                    </li>
                  );
                })}
              </ul>
            </>
          )}
        </div>
      )}

      {value.length > 0 && !open && !disabled && (
        <button
          type="button"
          onClick={reopen}
          className="mt-2 inline-flex items-center gap-1.5 rounded text-sm font-medium text-millenium-blue hover:underline focus:outline-none focus:ring-2 focus:ring-millenium-blue/40 focus:ring-offset-1"
        >
          <Plus className="h-4 w-4" />
          Agregar otro colaborador
        </button>
      )}

      <p className="mt-1.5 flex items-center gap-1.5 text-sm text-gray-500">
        <Users className="h-4 w-4 shrink-0" />
        {value.length === 0
          ? "Los colaboradores reciben un correo con la información de la reunión."
          : `${value.length} ${
              value.length === 1 ? "colaborador" : "colaboradores"
            } serán notificados por correo.`}
      </p>
    </div>
  );
}
