"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import {
  addDays,
  addMonths,
  endOfMonth,
  format,
  isSameDay,
  startOfMonth,
  subMonths,
} from "date-fns";
import { es } from "date-fns/locale";
import { ChevronLeft, ChevronRight, X } from "lucide-react";

interface Props {
  open: boolean;
  value: string; // YYYY-MM-DD
  minDate: Date;
  maxDate: Date;
  onChange: (yyyymmdd: string) => void;
  onClose: () => void;
}

const pad = (n: number) => String(n).padStart(2, "0");

const toIso = (d: Date): string =>
  `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;

const WEEKDAYS = ["Dom", "Lun", "Mar", "Mié", "Jue", "Vie", "Sáb"];

const parseLocalYmd = (ymd: string): Date => {
  const [y, m, d] = ymd.split("-").map((v) => parseInt(v, 10));
  return new Date(y, (m || 1) - 1, d || 1);
};

export default function DatePopover({
  open,
  value,
  minDate,
  maxDate,
  onChange,
  onClose,
}: Props) {
  const selectedDate = useMemo(() => parseLocalYmd(value), [value]);

  const [viewMonth, setViewMonth] = useState<Date>(startOfMonth(selectedDate));
  const [focused, setFocused] = useState<Date>(selectedDate);

  const dialogRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (open) {
      setViewMonth(startOfMonth(selectedDate));
      setFocused(selectedDate);
    }
  }, [open, selectedDate]);

  useEffect(() => {
    if (!open) return;
    const handler = (e: MouseEvent) => {
      if (dialogRef.current && !dialogRef.current.contains(e.target as Node)) {
        onClose();
      }
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, [open, onClose]);

  useEffect(() => {
    if (!open) return;
    const inRange = (d: Date) =>
      d.getTime() >= minDate.getTime() && d.getTime() <= maxDate.getTime();

    const handler = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        e.preventDefault();
        onClose();
        return;
      }
      if (e.key === "Enter") {
        e.preventDefault();
        if (inRange(focused)) {
          onChange(toIso(focused));
          onClose();
        }
        return;
      }
      let delta = 0;
      if (e.key === "ArrowLeft") delta = -1;
      else if (e.key === "ArrowRight") delta = 1;
      else if (e.key === "ArrowUp") delta = -7;
      else if (e.key === "ArrowDown") delta = 7;
      if (delta !== 0) {
        e.preventDefault();
        let next = addDays(focused, delta);
        if (next.getTime() < minDate.getTime()) next = minDate;
        if (next.getTime() > maxDate.getTime()) next = maxDate;
        setFocused(next);
        if (
          next.getMonth() !== viewMonth.getMonth() ||
          next.getFullYear() !== viewMonth.getFullYear()
        ) {
          setViewMonth(startOfMonth(next));
        }
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [open, focused, viewMonth, minDate, maxDate, onChange, onClose]);

  if (!open) return null;

  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const monthStart = viewMonth;
  const monthEnd = endOfMonth(monthStart);
  const startDow = monthStart.getDay();
  const calStart = addDays(monthStart, -startDow);

  const cells: Date[] = [];
  for (let i = 0; i < 42; i++) {
    cells.push(addDays(calStart, i));
  }

  const minMonth = startOfMonth(minDate);
  const maxMonth = startOfMonth(maxDate);
  const canPrev = monthStart.getTime() > minMonth.getTime();
  const canNext = monthStart.getTime() < maxMonth.getTime();

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/30 p-4"
      role="dialog"
      aria-label="Seleccionar fecha"
    >
      <div
        ref={dialogRef}
        className="w-full max-w-sm rounded-2xl border border-gray-200 bg-white p-5 shadow-xl"
      >
        <div className="mb-4 flex items-center justify-between">
          <button
            type="button"
            onClick={() => canPrev && setViewMonth(subMonths(monthStart, 1))}
            disabled={!canPrev}
            aria-label="Mes anterior"
            className={
              "rounded-md p-1.5 transition focus:outline-none focus:ring-2 focus:ring-millenium-blue/40 focus:ring-offset-1 " +
              (canPrev
                ? "text-gray-700 hover:bg-gray-100"
                : "cursor-not-allowed text-gray-300")
            }
          >
            <ChevronLeft className="h-4 w-4" />
          </button>
          <h3 className="text-base font-semibold capitalize text-gray-900">
            {format(monthStart, "MMMM yyyy", { locale: es })}
          </h3>
          <div className="flex items-center gap-1">
            <button
              type="button"
              onClick={() => canNext && setViewMonth(addMonths(monthStart, 1))}
              disabled={!canNext}
              aria-label="Mes siguiente"
              className={
                "rounded-md p-1.5 transition focus:outline-none focus:ring-2 focus:ring-millenium-blue/40 focus:ring-offset-1 " +
                (canNext
                  ? "text-gray-700 hover:bg-gray-100"
                  : "cursor-not-allowed text-gray-300")
              }
            >
              <ChevronRight className="h-4 w-4" />
            </button>
            <button
              type="button"
              onClick={onClose}
              aria-label="Cerrar"
              className="rounded-md p-1.5 text-gray-500 hover:bg-gray-100 hover:text-gray-700 focus:outline-none focus:ring-2 focus:ring-millenium-blue/40 focus:ring-offset-1"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>

        <div className="mb-1 grid grid-cols-7 gap-1 text-center">
          {WEEKDAYS.map((wd) => (
            <div
              key={wd}
              className="text-xs font-medium uppercase tracking-wide text-gray-500"
            >
              {wd}
            </div>
          ))}
        </div>

        <div className="grid grid-cols-7 gap-1">
          {cells.map((d, i) => {
            const inMonth = d.getMonth() === monthStart.getMonth();
            const inRange =
              d.getTime() >= minDate.getTime() &&
              d.getTime() <= maxDate.getTime();
            const isSelected = isSameDay(d, selectedDate);
            const isFocused = isSameDay(d, focused);
            const isToday = isSameDay(d, today);
            const disabled = !inMonth || !inRange;

            let cls =
              "flex h-9 w-9 items-center justify-center text-sm tabular-nums transition ";
            if (isSelected) {
              cls += "rounded-full bg-millenium-blue font-semibold text-white";
            } else if (disabled) {
              cls += "cursor-not-allowed text-gray-300";
            } else if (isToday) {
              cls +=
                "rounded-full border-2 border-millenium-blue font-semibold text-millenium-blue hover:bg-millenium-blue/10";
            } else {
              cls += "rounded-full text-gray-700 hover:bg-millenium-blue/10";
            }
            if (isFocused && !isSelected && !disabled) {
              cls += " ring-2 ring-millenium-blue/40";
            }

            return (
              <button
                type="button"
                key={i}
                disabled={disabled}
                onClick={() => {
                  if (disabled) return;
                  onChange(toIso(d));
                  onClose();
                }}
                onMouseEnter={() => {
                  if (!disabled) setFocused(d);
                }}
                className={cls}
                aria-label={format(d, "EEEE d 'de' MMMM yyyy", { locale: es })}
                aria-pressed={isSelected}
                tabIndex={isFocused ? 0 : -1}
              >
                {d.getDate()}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
