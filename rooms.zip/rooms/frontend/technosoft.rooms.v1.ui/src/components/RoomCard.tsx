"use client";

import { Room } from "@/types";
import Button from "./ui/Button";

interface Props {
  room: Room;
  onEdit?: (r: Room) => void;
  onToggle?: (r: Room) => void;
}

export default function RoomCard({ room, onEdit, onToggle }: Props) {
  return (
    <div className="card flex flex-col gap-2">
      <div className="flex items-start justify-between gap-3">
        <div>
          <h3 className="text-lg font-bold text-millenium-blue">{room.name}</h3>
          <p className="text-base text-millenium-dark">Capacidad: {room.capacity}</p>
          {room.location && (
            <p className="text-base text-millenium-gray">{room.location}</p>
          )}
        </div>
        <span
          className={
            "rounded-full px-2.5 py-1 text-xs font-semibold " +
            (room.isActive
              ? "bg-green-100 text-millenium-green"
              : "bg-gray-100 text-millenium-gray")
          }
        >
          {room.isActive ? "Activa" : "Inactiva"}
        </span>
      </div>
      {(onEdit || onToggle) && (
        <div className="mt-2 flex flex-wrap justify-end gap-2">
          {onEdit && (
            <Button variant="outline" onClick={() => onEdit(room)}>
              Editar
            </Button>
          )}
          {onToggle && (
            <Button
              variant={room.isActive ? "danger" : "success"}
              onClick={() => onToggle(room)}
            >
              {room.isActive ? "Desactivar" : "Activar"}
            </Button>
          )}
        </div>
      )}
    </div>
  );
}
