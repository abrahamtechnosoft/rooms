"use client";

import type { ReactNode } from "react";
import { Briefcase, LayoutGrid, MapPin, Video } from "lucide-react";
import type { Room } from "@/types";
import type { ChipFilter } from "@/types/filters";
import { getRoomColor, getRoomIcon } from "@/lib/roomIcons";

const OFFICE_COLOR = "#E67E22";
const VIRTUAL_COLOR = "#8B5CF6";
const EXTERNAL_COLOR = "#27AE60";
const ALL_COLOR = "#2C3E50";

interface Props {
  rooms: Room[];
  activeChip: ChipFilter;
  onChange: (next: ChipFilter) => void;
}

export default function FilterChips({ rooms, activeChip, onChange }: Props) {
  const activeRooms = rooms.filter((r) => r.isActive);

  return (
    <div className="flex flex-wrap items-center gap-2">
      <Chip
        active={activeChip.kind === "all"}
        onClick={() => onChange({ kind: "all" })}
        icon={<LayoutGrid className="h-3.5 w-3.5" />}
        color={ALL_COLOR}
        label="Todas"
      />
      {activeRooms.map((r) => {
        const Icon = getRoomIcon(r.iconName);
        const color = getRoomColor(r.colorHex);
        const isActive =
          activeChip.kind === "room" && activeChip.roomId === r.id;
        return (
          <Chip
            key={r.id}
            active={isActive}
            onClick={() => onChange({ kind: "room", roomId: r.id })}
            icon={<Icon className="h-3.5 w-3.5" />}
            color={color}
            label={r.name}
          />
        );
      })}
      <Chip
        active={activeChip.kind === "office"}
        onClick={() => onChange({ kind: "office" })}
        icon={<Briefcase className="h-3.5 w-3.5" />}
        color={OFFICE_COLOR}
        label="Oficinas"
      />
      <Chip
        active={activeChip.kind === "virtual"}
        onClick={() => onChange({ kind: "virtual" })}
        icon={<Video className="h-3.5 w-3.5" />}
        color={VIRTUAL_COLOR}
        label="Virtuales"
      />
      <Chip
        active={activeChip.kind === "external"}
        onClick={() => onChange({ kind: "external" })}
        icon={<MapPin className="h-3.5 w-3.5" />}
        color={EXTERNAL_COLOR}
        label="Fuera de oficina"
      />
    </div>
  );
}

function Chip({
  active,
  onClick,
  icon,
  color,
  label,
}: {
  active: boolean;
  onClick: () => void;
  icon: ReactNode;
  color: string;
  label: string;
}) {
  if (active) {
    return (
      <button
        type="button"
        onClick={onClick}
        aria-pressed={true}
        className="inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-medium text-white shadow-sm transition-colors"
        style={{ backgroundColor: color }}
      >
        {icon}
        {label}
      </button>
    );
  }
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={false}
      className="inline-flex items-center gap-1.5 rounded-full border bg-white px-3 py-1.5 text-xs font-medium transition-colors hover:bg-gray-50"
      style={{ borderColor: color, color }}
    >
      {icon}
      {label}
    </button>
  );
}
