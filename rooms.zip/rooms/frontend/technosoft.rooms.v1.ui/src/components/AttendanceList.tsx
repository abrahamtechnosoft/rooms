"use client";

import { useEffect, useState } from "react";
import { Check, X } from "lucide-react";
import { toast } from "@/lib/toastHelpers";
import api from "@/lib/api";
import Avatar from "@/components/Avatar";
import type { Reply } from "@/types";

export interface AttendanceItem {
  userId: number;
  fullName: string | null;
  email: string;
  avatarUrl?: string | null;
  attendanceId?: number | null;
  attended?: boolean | null;
  absenceReason?: string | null;
  autoJustified?: boolean;
  invitationStatus?:
    | "auto_accepted"
    | "pending"
    | "accepted"
    | "rejected";
  markedAt?: string | null;
}

interface Props {
  reservationId: number;
  onChange?: () => void;
}

const MAX_REASON = 300;

export default function AttendanceList({ reservationId, onChange }: Props) {
  const [items, setItems] = useState<AttendanceItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [editingUserId, setEditingUserId] = useState<number | null>(null);
  const [editingReason, setEditingReason] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const load = async () => {
    setLoading(true);
    try {
      const res = await api.get<Reply<AttendanceItem[]>>(
        `/reservations/${reservationId}/attendance`
      );
      setItems(res.data.obj || []);
    } catch {
      // Silencioso
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [reservationId]);

  async function markAttendance(
    userId: number,
    attended: boolean,
    reason?: string
  ) {
    if (submitting) return;
    setSubmitting(true);
    try {
      const res = await api.post<Reply<unknown>>(
        `/reservations/${reservationId}/attendance`,
        {
          userId,
          attended,
          absenceReason: reason || null,
        }
      );
      if (!res.data.ok) {
        toast.error(res.data.msg || "No fue posible registrar la asistencia");
        return;
      }
      await load();
      setEditingUserId(null);
      setEditingReason("");
      onChange?.();
      toast.success("Asistencia registrada");
    } catch (e: unknown) {
      const errObj = e as { response?: { data?: { msg?: string } } };
      toast.error(
        errObj?.response?.data?.msg ||
          "No fue posible registrar la asistencia"
      );
    } finally {
      setSubmitting(false);
    }
  }

  if (loading && items.length === 0) {
    return (
      <p className="py-2 text-sm text-gray-500">Cargando colaboradores…</p>
    );
  }

  if (items.length === 0) {
    return (
      <p className="py-2 text-sm text-gray-500">
        Sin colaboradores activos.
      </p>
    );
  }

  return (
    <ul className="space-y-2">
      {items.map((item) => {
        const isEditing = editingUserId === item.userId;
        const status =
          item.attended === true
            ? "attended"
            : item.attended === false
              ? "absent"
              : "pending";
        return (
          <li
            key={item.userId}
            className="rounded-lg border border-gray-100 bg-white p-2"
          >
            <div className="flex items-start gap-3">
              <Avatar
                name={item.fullName}
                email={item.email}
                avatarUrl={item.avatarUrl}
                noDefaultSize
                className="h-8 w-8 text-xs"
              />
              <div className="min-w-0 flex-1">
                <p
                  className="truncate text-sm font-medium text-gray-900"
                  title={item.fullName || item.email}
                >
                  {item.fullName || item.email}
                </p>
                {status === "absent" && item.absenceReason && (
                  <p className="mt-0.5 line-clamp-2 text-xs italic text-gray-500">
                    {item.autoJustified ? "" : "Motivo: "}
                    {item.absenceReason}
                  </p>
                )}
                {status === "pending" && (
                  <p className="text-xs text-gray-400">
                    Sin registrar
                    {item.invitationStatus === "pending" && (
                      <span className="ml-1 italic text-gray-500">
                        (justificación automática disponible)
                      </span>
                    )}
                  </p>
                )}
                {status === "attended" && (
                  <p className="text-xs font-medium text-millenium-green">
                    Asistió
                  </p>
                )}
              </div>

              <div className="flex shrink-0 items-center gap-1">
                <button
                  type="button"
                  onClick={() => markAttendance(item.userId, true)}
                  disabled={submitting}
                  className={
                    "rounded p-2.5 transition focus:outline-none focus-visible:ring-2 focus-visible:ring-millenium-blue/40 disabled:opacity-50 sm:p-2 " +
                    (status === "attended"
                      ? "bg-millenium-green/10 text-millenium-green"
                      : "text-gray-500 hover:bg-gray-100 hover:text-gray-700")
                  }
                  aria-label="Marcar como asistió"
                  title="Asistió"
                >
                  <Check className="h-4 w-4" aria-hidden="true" />
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setEditingUserId(item.userId);
                    setEditingReason(item.absenceReason || "");
                  }}
                  disabled={submitting}
                  className={
                    "rounded p-2.5 transition focus:outline-none focus-visible:ring-2 focus-visible:ring-millenium-blue/40 disabled:opacity-50 sm:p-2 " +
                    (status === "absent"
                      ? "bg-millenium-red/10 text-millenium-red"
                      : "text-gray-500 hover:bg-gray-100 hover:text-gray-700")
                  }
                  aria-label="Marcar como no asistió"
                  title="No asistió"
                >
                  <X className="h-4 w-4" aria-hidden="true" />
                </button>
              </div>
            </div>

            {isEditing && (
              <div className="mt-3 rounded-md border border-gray-200 bg-gray-50 p-2">
                <p className="mb-1 text-xs font-medium text-gray-700">
                  Motivo de ausencia (opcional)
                </p>
                <textarea
                  value={editingReason}
                  onChange={(e) => setEditingReason(e.target.value)}
                  maxLength={MAX_REASON}
                  rows={2}
                  placeholder="Ej.: Tuvo emergencia"
                  className="w-full rounded border border-gray-300 px-2 py-1.5 text-sm focus:border-millenium-blue focus:outline-none focus:ring-2 focus:ring-millenium-blue/20"
                />
                <p className="mt-1 text-right text-xs text-gray-500 tabular-nums">
                  {editingReason.length}/{MAX_REASON}
                </p>
                <div className="mt-2 flex justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setEditingUserId(null);
                      setEditingReason("");
                    }}
                    className="text-xs text-gray-600 hover:text-gray-900"
                  >
                    Cancelar
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      markAttendance(item.userId, false, editingReason.trim())
                    }
                    disabled={submitting}
                    className="rounded bg-millenium-red px-2 py-1 text-xs font-medium text-white transition hover:bg-millenium-red/90 disabled:opacity-50"
                  >
                    Guardar
                  </button>
                </div>
              </div>
            )}
          </li>
        );
      })}
    </ul>
  );
}
