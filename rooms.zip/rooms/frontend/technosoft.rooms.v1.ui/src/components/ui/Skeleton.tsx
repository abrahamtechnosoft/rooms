type Props = {
  className?: string;
  count?: number;
};

export function Skeleton({ className = "", count = 1 }: Props) {
  return (
    <>
      {Array.from({ length: count }).map((_, i) => (
        <div
          key={i}
          className={`animate-pulse rounded-lg bg-gray-200 ${className}`.trim()}
          aria-hidden="true"
        />
      ))}
    </>
  );
}

export default Skeleton;
