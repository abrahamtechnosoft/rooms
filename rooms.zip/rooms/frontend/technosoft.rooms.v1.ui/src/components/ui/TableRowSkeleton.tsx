interface Props {
  columns?: number;
  rows?: number;
}

export function TableRowSkeleton({ columns = 4, rows = 5 }: Props) {
  return (
    <>
      {Array.from({ length: rows }).map((_, r) => (
        <tr key={r} className="border-t border-gray-100">
          {Array.from({ length: columns }).map((_, c) => (
            <td key={c} className="px-4 py-3">
              <div
                className="h-4 w-full max-w-[150px] animate-pulse rounded bg-gray-200"
                aria-hidden="true"
              />
            </td>
          ))}
        </tr>
      ))}
    </>
  );
}

export default TableRowSkeleton;
