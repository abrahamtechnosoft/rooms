"use client";

import { SelectHTMLAttributes, forwardRef, ReactNode } from "react";

interface Props extends SelectHTMLAttributes<HTMLSelectElement> {
  label?: string;
  children: ReactNode;
}

const Select = forwardRef<HTMLSelectElement, Props>(function Select(
  { label, className = "", id, children, ...rest },
  ref
) {
  const selectId = id || rest.name;
  return (
    <div className="w-full">
      {label && (
        <label htmlFor={selectId} className="label">
          {label}
        </label>
      )}
      <select ref={ref} id={selectId} className={`input ${className}`.trim()} {...rest}>
        {children}
      </select>
    </div>
  );
});

export default Select;
