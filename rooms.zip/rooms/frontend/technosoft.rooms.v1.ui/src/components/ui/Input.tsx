"use client";

import { InputHTMLAttributes, ReactNode, forwardRef } from "react";

interface Props extends InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  hint?: string;
  leadingIcon?: ReactNode;
}

const Input = forwardRef<HTMLInputElement, Props>(function Input(
  { label, hint, leadingIcon, className = "", id, ...rest },
  ref
) {
  const inputId = id || rest.name;
  const inputCls = `input ${leadingIcon ? "pl-10" : ""} ${className}`.trim();
  return (
    <div className="w-full">
      {label && (
        <label htmlFor={inputId} className="label">
          {label}
        </label>
      )}
      <div className="relative">
        {leadingIcon && (
          <span className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-gray-400">
            {leadingIcon}
          </span>
        )}
        <input ref={ref} id={inputId} className={inputCls} {...rest} />
      </div>
      {hint && <p className="mt-1 text-xs text-millenium-gray">{hint}</p>}
    </div>
  );
});

export default Input;
