"use client";

import { ReactNode } from "react";

interface Props {
  label: string;
  value: ReactNode;
  icon?: ReactNode;
  hint?: string;
}

export default function ReadonlyField({ label, value, icon, hint }: Props) {
  return (
    <div className="w-full">
      <label className="label">{label}</label>
      <div className="flex items-center gap-2 rounded-lg border border-gray-200 bg-gray-50 px-3.5 py-2.5 text-base text-gray-700">
        {icon && <span className="shrink-0 text-gray-400">{icon}</span>}
        <span className="min-w-0 truncate">{value}</span>
        {hint && (
          <span className="ml-auto shrink-0 text-sm text-gray-500">{hint}</span>
        )}
      </div>
    </div>
  );
}
