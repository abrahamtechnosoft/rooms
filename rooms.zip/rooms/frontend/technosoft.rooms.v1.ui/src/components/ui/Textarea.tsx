"use client";

import { TextareaHTMLAttributes, forwardRef } from "react";

interface Props extends TextareaHTMLAttributes<HTMLTextAreaElement> {
  label?: string;
  hint?: string;
}

const Textarea = forwardRef<HTMLTextAreaElement, Props>(function Textarea(
  { label, hint, className = "", id, rows = 3, ...rest },
  ref
) {
  const inputId = id || rest.name;
  return (
    <div className="w-full">
      {label && (
        <label htmlFor={inputId} className="label">
          {label}
        </label>
      )}
      <textarea
        ref={ref}
        id={inputId}
        rows={rows}
        className={`input ${className}`.trim()}
        {...rest}
      />
      {hint && <p className="mt-1 text-xs text-millenium-gray">{hint}</p>}
    </div>
  );
});

export default Textarea;
