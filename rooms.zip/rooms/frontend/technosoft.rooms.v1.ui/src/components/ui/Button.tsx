"use client";

import { ButtonHTMLAttributes, forwardRef } from "react";
import { Loader2 } from "lucide-react";

type Variant = "primary" | "success" | "danger" | "outline" | "ghost" | "link";

interface Props extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  loading?: boolean;
}

const Button = forwardRef<HTMLButtonElement, Props>(function Button(
  { variant = "primary", loading, className = "", children, disabled, ...rest },
  ref
) {
  const cls =
    variant === "link"
      ? `inline-flex items-center gap-1 text-sm font-medium text-millenium-blue transition hover:underline disabled:cursor-not-allowed disabled:text-gray-400 disabled:no-underline ${className}`.trim()
      : `btn btn-${variant} ${className}`.trim();
  return (
    <button ref={ref} className={cls} disabled={loading || disabled} {...rest}>
      {loading && <Loader2 className="h-4 w-4 animate-spin" />}
      {children}
    </button>
  );
});

export default Button;
