"use client";

import { ReactNode, useEffect, useId } from "react";
import { X } from "lucide-react";

interface Props {
  open: boolean;
  title?: string;
  description?: string;
  onClose: () => void;
  children?: ReactNode;
  footer?: ReactNode;
  actions?: ReactNode;
  size?: "sm" | "md" | "lg";
  labelledBy?: string;
}

export default function Modal({
  open,
  title,
  description,
  onClose,
  children,
  footer,
  actions,
  size = "md",
  labelledBy,
}: Props) {
  const autoId = useId();
  const titleId = labelledBy || (title ? `${autoId}-title` : undefined);

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    if (open) window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [open, onClose]);

  if (!open) return null;

  const widthCls =
    size === "sm" ? "max-w-sm" : size === "lg" ? "max-w-2xl" : "max-w-md";

  const hasHeader = !!(title || description);
  const trailing = actions ?? footer;

  return (
    <div className="animate-fadeIn fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4 backdrop-blur-sm">
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        className={`animate-scaleIn flex max-h-[90vh] w-full ${widthCls} flex-col overflow-hidden rounded-2xl bg-white shadow-xl`}
      >
        {hasHeader && (
          <div className="flex shrink-0 items-start justify-between gap-3 border-b border-gray-100 px-6 pb-4 pt-6 sm:px-8 sm:pt-7">
            <div className="min-w-0 flex-1">
              {title && (
                <h2
                  id={titleId}
                  className="text-xl font-semibold text-millenium-blue"
                >
                  {title}
                </h2>
              )}
              {description && (
                <p className="mt-1 text-sm text-gray-500">{description}</p>
              )}
            </div>
            <button
              type="button"
              onClick={onClose}
              className="-mr-1 -mt-1 shrink-0 rounded-md p-2 text-gray-500 hover:bg-gray-100 hover:text-gray-700 focus:outline-none focus-visible:ring-2 focus-visible:ring-millenium-blue/40 focus-visible:ring-offset-1"
              aria-label="Cerrar"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        )}

        {children && (
          <div
            className={
              "min-h-0 flex-1 overflow-y-auto px-6 sm:px-8 " +
              (hasHeader ? "py-4" : "pb-6 pt-6 sm:pb-8 sm:pt-8")
            }
          >
            {children}
          </div>
        )}

        {trailing && (
          <div className="flex shrink-0 flex-wrap items-center justify-end gap-2 border-t border-gray-100 px-6 py-4 sm:px-8">
            {trailing}
          </div>
        )}
      </div>
    </div>
  );
}
