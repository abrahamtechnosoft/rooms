"use client";

import { useEffect, useState } from "react";
import {
  AlertCircle,
  ExternalLink,
  Paperclip,
  Plus,
  X,
} from "lucide-react";
import { toast } from "@/lib/toastHelpers";
import api from "@/lib/api";
import { getUrlError, isValidUrl } from "@/lib/urlValidator";
import type { Attachment, Reply } from "@/types";

interface Props {
  reservationId: number;
  currentUserId: number | null;
  isOrganizer: boolean;
  canEdit: boolean;
}

const MAX_NAME = 120;
const MAX_URL = 1000;

export default function AttachmentsList({
  reservationId,
  currentUserId,
  isOrganizer,
  canEdit,
}: Props) {
  const [items, setItems] = useState<Attachment[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [name, setName] = useState("");
  const [url, setUrl] = useState("");
  const [submitting, setSubmitting] = useState(false);

  async function load() {
    setLoading(true);
    try {
      const res = await api.get<Reply<Attachment[]>>(
        `/reservations/${reservationId}/attachments`
      );
      setItems(res.data.obj || []);
    } catch {
      // silencioso
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [reservationId]);

  async function handleAdd() {
    const trimmedName = name.trim();
    const trimmedUrl = url.trim();
    if (!trimmedName) {
      toast.error("Falta el nombre del archivo");
      return;
    }
    if (!trimmedUrl || !isValidUrl(trimmedUrl)) {
      toast.error(getUrlError(trimmedUrl, "enlace") || "Enlace inválido");
      return;
    }
    setSubmitting(true);
    try {
      const res = await api.post<Reply<{ id: number }>>(
        `/reservations/${reservationId}/attachments`,
        { name: trimmedName, url: trimmedUrl }
      );
      if (!res.data.ok) {
        toast.error(res.data.msg || "No fue posible agregar el adjunto");
        return;
      }
      // El adjunto aparece en la lista al recargar, no hace falta toast.
      setName("");
      setUrl("");
      setShowForm(false);
      await load();
    } catch (e: unknown) {
      const errObj = e as { response?: { data?: { msg?: string } } };
      toast.error(
        errObj?.response?.data?.msg || "No fue posible agregar el adjunto"
      );
    } finally {
      setSubmitting(false);
    }
  }

  async function handleDelete(att: Attachment) {
    if (typeof window !== "undefined") {
      const ok = window.confirm(`¿Eliminar "${att.name}"?`);
      if (!ok) return;
    }
    try {
      const res = await api.delete<Reply<unknown>>(
        `/reservations/${reservationId}/attachments/${att.id}`
      );
      if (!res.data.ok) {
        toast.error(res.data.msg || "No fue posible eliminar");
        return;
      }
      toast.success(res.data.msg || "Adjunto eliminado");
      await load();
    } catch (e: unknown) {
      const errObj = e as { response?: { data?: { msg?: string } } };
      toast.error(
        errObj?.response?.data?.msg || "No fue posible eliminar"
      );
    }
  }

  function canDelete(att: Attachment): boolean {
    if (isOrganizer) return true;
    return currentUserId != null && att.addedById === currentUserId;
  }

  const urlInvalid = url.trim().length > 0 && !isValidUrl(url);

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between gap-2">
        <h4 className="flex items-center gap-1.5 text-sm font-semibold text-gray-700">
          <Paperclip className="h-4 w-4 text-gray-400" />
          Adjuntos
          {items.length > 0 && (
            <span className="text-xs font-normal text-gray-400">
              ({items.length})
            </span>
          )}
        </h4>
        {canEdit && !showForm && (
          <button
            type="button"
            onClick={() => setShowForm(true)}
            className="inline-flex items-center gap-1 rounded text-xs font-medium text-millenium-blue hover:underline focus:outline-none focus-visible:ring-2 focus-visible:ring-millenium-blue/40 focus-visible:ring-offset-1"
          >
            <Plus className="h-3.5 w-3.5" />
            Agregar enlace
          </button>
        )}
      </div>

      {showForm && (
        <div className="space-y-2 rounded-lg border border-gray-200 bg-gray-50 p-3">
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Ej.: Propuesta cliente XYZ"
            maxLength={MAX_NAME}
            className="w-full rounded border border-gray-300 bg-white px-3 py-1.5 text-sm focus:border-millenium-blue focus:outline-none focus:ring-2 focus:ring-millenium-blue/20"
          />
          <div>
            <input
              type="url"
              inputMode="url"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              placeholder="https://drive.google.com/..."
              maxLength={MAX_URL}
              className={
                "w-full rounded border bg-white px-3 py-1.5 text-sm focus:outline-none focus:ring-2 " +
                (urlInvalid
                  ? "border-millenium-red bg-red-50 focus:ring-millenium-red/40"
                  : "border-gray-300 focus:ring-millenium-blue/20")
              }
            />
            {urlInvalid && (
              <p className="mt-1 flex items-center gap-1 text-xs text-millenium-red">
                <AlertCircle className="h-3 w-3" />
                {getUrlError(url, "enlace")}
              </p>
            )}
          </div>
          <div className="flex justify-end gap-2 pt-1">
            <button
              type="button"
              onClick={() => {
                setShowForm(false);
                setName("");
                setUrl("");
              }}
              className="rounded px-2 py-1 text-xs text-gray-500 hover:bg-gray-100"
            >
              Cancelar
            </button>
            <button
              type="button"
              onClick={handleAdd}
              disabled={
                submitting ||
                name.trim().length === 0 ||
                url.trim().length === 0 ||
                urlInvalid
              }
              className="rounded bg-millenium-blue px-3 py-1 text-xs font-medium text-white transition hover:bg-[#1f2c3a] disabled:cursor-not-allowed disabled:opacity-50"
            >
              {submitting ? "Guardando..." : "Agregar"}
            </button>
          </div>
        </div>
      )}

      {loading ? (
        <p className="text-xs text-gray-400">Cargando adjuntos...</p>
      ) : items.length === 0 ? (
        <p className="py-1 text-xs text-gray-400">Sin enlaces compartidos.</p>
      ) : (
        <ul className="space-y-1">
          {items.map((att) => (
            <li
              key={att.id}
              className="group flex items-center gap-2 rounded p-1.5 transition hover:bg-gray-50"
            >
              <a
                href={att.url}
                target="_blank"
                rel="noopener noreferrer"
                className="flex min-w-0 flex-1 items-center gap-1.5 text-sm text-millenium-blue hover:underline"
                title={att.url}
              >
                <ExternalLink className="h-3.5 w-3.5 shrink-0" />
                <span className="truncate">{att.name}</span>
              </a>
              <span
                className="hidden shrink-0 text-xs text-gray-400 sm:inline"
                title={att.addedByEmail || undefined}
              >
                {att.addedByName}
              </span>
              {canDelete(att) && (
                <button
                  type="button"
                  onClick={() => handleDelete(att)}
                  className="shrink-0 rounded p-2 text-gray-300 opacity-100 transition hover:text-millenium-red focus:opacity-100 sm:p-1 md:opacity-0 md:group-hover:opacity-100"
                  aria-label={`Eliminar adjunto: ${att.name}`}
                >
                  <X className="h-4 w-4" />
                </button>
              )}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
