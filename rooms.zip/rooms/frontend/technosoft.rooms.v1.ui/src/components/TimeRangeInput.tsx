"use client";

import { useEffect, useRef, useState } from "react";
import { AlertCircle, Info } from "lucide-react";
import { toast } from "@/lib/toastHelpers";
import {
  combineDateAndTime,
  formatDurationMins,
  formatHHMM,
  MIN_DURATION_MIN,
  parseTimeInput,
} from "@/lib/timeHelpers";
import { useNowTick } from "@/hooks/useNowTick";

interface Props {
  selectedDate: Date;
  startsAt: Date | null;
  endsAt: Date | null;
  onChange: (startsAt: Date, endsAt: Date) => void;
  /** Mensaje externo (ej. conflicto con otra reunión). Se muestra debajo. */
  conflictMessage?: string | null;
  minHour?: number;
  maxHour?: number;
  /** Duración mínima del rango en minutos (default 15). */
  minDurationMin?: number;
  disabled?: boolean;
  /** Callback opcional: el componente avisa al padre si hay error local. */
  onValidityChange?: (valid: boolean) => void;
}

interface TimeInputProps {
  label: string;
  value: string;
  onSubmit: (newValue: string) => void;
  minHour: number;
  maxHour: number;
  hasError?: boolean;
  disabled?: boolean;
}

/**
 * Input de hora con auto-formato `HH:MM`. Mientras se escribe:
 * - Solo dígitos o `:`.
 * - Se inserta `:` automáticamente después de 2 dígitos.
 * - Se trunca a 5 caracteres.
 * Al perder foco o presionar Enter, se valida y propaga.
 */
function TimeInput({
  label,
  value,
  onSubmit,
  minHour,
  maxHour,
  hasError,
  disabled,
}: TimeInputProps) {
  const [inputValue, setInputValue] = useState(value);
  const previousRawRef = useRef<string>(value);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setInputValue(value);
    previousRawRef.current = value;
  }, [value]);

  function handleChange(raw: string) {
    // Solo dígitos y `:`.
    let cleaned = raw.replace(/[^\d:]/g, "");

    // Auto-insertar `:` después de 2 dígitos cuando el usuario está
    // escribiendo (no al borrar).
    const isTyping = cleaned.length > previousRawRef.current.length;
    if (cleaned.length === 2 && !cleaned.includes(":") && isTyping) {
      cleaned = cleaned + ":";
    }

    // Limitar a 5 chars (HH:MM).
    if (cleaned.length > 5) cleaned = cleaned.slice(0, 5);

    setInputValue(cleaned);
    previousRawRef.current = cleaned;
  }

  function applyInputValue(raw: string) {
    const parsed = parseTimeInput(raw);
    if (!parsed) {
      if (raw && raw !== value) {
        toast.error("Hora no válida");
      }
      setInputValue(value);
      previousRawRef.current = value;
      return;
    }
    if (parsed.hour < minHour || parsed.hour > maxHour) {
      toast.error(
        `Solo entre ${String(minHour).padStart(2, "0")}:00 y ${String(maxHour).padStart(2, "0")}:00`
      );
      setInputValue(value);
      previousRawRef.current = value;
      return;
    }
    const hhmm = `${String(parsed.hour).padStart(2, "0")}:${String(parsed.minute).padStart(2, "0")}`;
    onSubmit(hhmm);
    setInputValue(hhmm);
    previousRawRef.current = hhmm;
  }

  function handleKeyDown(e: React.KeyboardEvent<HTMLInputElement>) {
    if (e.key === "Enter") {
      e.preventDefault();
      applyInputValue(inputValue);
      inputRef.current?.blur();
    } else if (e.key === "Escape") {
      setInputValue(value);
      previousRawRef.current = value;
      inputRef.current?.blur();
    }
  }

  return (
    <div className="relative">
      <label className="mb-1 block text-xs text-gray-500">{label}</label>
      <input
        ref={inputRef}
        type="text"
        inputMode="numeric"
        value={inputValue}
        onChange={(e) => handleChange(e.target.value)}
        onBlur={() => applyInputValue(inputValue)}
        onKeyDown={handleKeyDown}
        placeholder="HH:MM"
        maxLength={5}
        disabled={disabled}
        className={
          "w-24 rounded-lg border px-3 py-2 text-sm font-medium tabular-nums focus:outline-none focus:ring-2 focus:ring-millenium-blue/40 disabled:cursor-not-allowed disabled:opacity-60 " +
          (hasError
            ? "border-millenium-red bg-red-50 text-millenium-red"
            : "border-gray-300 bg-white hover:border-gray-400")
        }
        aria-label={label}
      />
    </div>
  );
}

export default function TimeRangeInput({
  selectedDate,
  startsAt,
  endsAt,
  onChange,
  conflictMessage,
  minHour = 8,
  maxHour = 17,
  minDurationMin = MIN_DURATION_MIN,
  disabled,
  onValidityChange,
}: Props) {
  const now = useNowTick(1000);

  const startsAtStr = startsAt ? formatHHMM(startsAt) : "";
  const endsAtStr = endsAt ? formatHHMM(endsAt) : "";

  const duration =
    startsAt && endsAt
      ? Math.round((endsAt.getTime() - startsAt.getTime()) / 60000)
      : 0;

  // Validaciones instantáneas con tick local.
  const startsInPast = !!startsAt && startsAt.getTime() < now.getTime() - 60_000;
  const endBeforeStart = !!startsAt && !!endsAt && endsAt <= startsAt;
  const tooShort = duration > 0 && duration < minDurationMin;

  const errorMessage =
    startsInPast
      ? "La hora de inicio ya pasó. Ajusta el horario."
      : endBeforeStart
        ? "El fin debe ser después del inicio."
        : tooShort
          ? `La reunión debe durar al menos ${minDurationMin} minutos (actual: ${duration} min).`
          : null;

  const localError = !!errorMessage;
  const validityValid =
    !localError && !!startsAt && !!endsAt && duration >= minDurationMin;

  useEffect(() => {
    onValidityChange?.(validityValid);
  }, [validityValid, onValidityChange]);

  function handleStartChange(newStartStr: string) {
    const [h, m] = newStartStr.split(":").map(Number);
    const newStart = combineDateAndTime(selectedDate, h, m);

    // Sin auto-ajuste pasivo: el usuario decide. Si quedó en pasado, el
    // banner de error se encarga; el chip "Reservar ahora" ofrece el atajo.

    const keepDuration = startsAt && endsAt ? duration : minDurationMin;
    let newEnd = new Date(newStart.getTime() + keepDuration * 60000);

    const maxEnd = combineDateAndTime(selectedDate, maxHour, 0);
    if (newEnd > maxEnd) {
      newEnd = maxEnd;
    }
    onChange(newStart, newEnd);
  }

  function handleEndChange(newEndStr: string) {
    const [h, m] = newEndStr.split(":").map(Number);
    const newEnd = combineDateAndTime(selectedDate, h, m);

    if (!startsAt) {
      const newStart = new Date(newEnd.getTime() - minDurationMin * 60000);
      onChange(newStart, newEnd);
      return;
    }
    onChange(startsAt, newEnd);
  }

  // El chip "Reservar ahora" se renderiza en el header de TimeSlotGrid; ya
  // no es necesario duplicarlo aquí. Mantenemos `now` solo para validar
  // pasados sin marcar rojo a la hora actual exacta.

  return (
    <div className="space-y-2">
      <div className="flex flex-wrap items-end gap-3">
        <TimeInput
          label="Inicio"
          value={startsAtStr}
          onSubmit={handleStartChange}
          minHour={minHour}
          maxHour={maxHour - 1}
          hasError={(startsInPast || endBeforeStart) && !!startsAt}
          disabled={disabled}
        />

        <span className="pb-2 text-sm text-gray-400" aria-hidden="true">
          →
        </span>

        <TimeInput
          label="Fin"
          value={endsAtStr}
          onSubmit={handleEndChange}
          minHour={minHour}
          maxHour={maxHour}
          hasError={tooShort || endBeforeStart}
          disabled={disabled}
        />

        {duration > 0 && (
          <span
            className={
              "pb-2 text-sm " +
              (tooShort
                ? "font-medium text-millenium-red"
                : "text-gray-500")
            }
          >
            ({formatDurationMins(duration)})
          </span>
        )}
      </div>

      <p className="flex items-center gap-1 text-xs text-gray-400">
        <Info className="h-3 w-3 shrink-0" />
        Formato 24h. Mínimo {minDurationMin} minutos de duración.
      </p>

      {errorMessage && (
        <p className="flex items-center gap-1.5 text-xs text-millenium-red">
          <AlertCircle className="h-3.5 w-3.5 shrink-0" />
          {errorMessage}
        </p>
      )}

      {!errorMessage && conflictMessage && (
        <div className="flex items-start gap-1.5 rounded border border-amber-300 bg-amber-50 px-2.5 py-2 text-xs text-amber-700">
          <AlertCircle className="mt-0.5 h-3.5 w-3.5 shrink-0" />
          <span>
            <strong>Atención:</strong> {conflictMessage} Si confirmas y otra
            persona ya tomó el horario, el sistema te avisará.
          </span>
        </div>
      )}
    </div>
  );
}
