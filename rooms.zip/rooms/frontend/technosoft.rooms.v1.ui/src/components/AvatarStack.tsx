"use client";

import Avatar from "@/components/Avatar";
import type { UserPickerItem } from "@/types";

export interface AvatarStackPerson {
  id?: number;
  fullName?: string | null;
  email?: string | null;
  avatarUrl?: string | null;
}

interface Props {
  organizer: AvatarStackPerson;
  collaborators?: AvatarStackPerson[] | UserPickerItem[];
  /** Total visibles (incluyendo organizador y, si aplica, el círculo "+N"). */
  maxVisible?: number;
  /** Clases del avatar individual (controla tamaño y tipografía del "+N"). */
  avatarClassName?: string;
  /** Solapamiento entre avatares (clase Tailwind, ej. "-space-x-2"). */
  stackSpacing?: string;
  /** Grosor del ring blanco que separa los avatares apilados. */
  ringClassName?: string;
}

export default function AvatarStack({
  organizer,
  collaborators,
  maxVisible = 3,
  avatarClassName = "h-5 w-5 text-[10px]",
  stackSpacing = "-space-x-2",
  ringClassName = "ring-2 ring-white",
}: Props) {
  if (maxVisible <= 0) return null;

  const collabList = (collaborators || []) as AvatarStackPerson[];
  const all: AvatarStackPerson[] = [organizer, ...collabList];

  // Si entran todos: mostramos todos sin "+N".
  // Si no entran: dejamos espacio para el "+N" como último ítem.
  const total = all.length;
  const fitsAll = total <= maxVisible;
  const visibleCount = fitsAll ? total : Math.max(0, maxVisible - 1);
  const visible = all.slice(0, visibleCount);
  const extraCount = total - visibleCount;

  return (
    <div className={`flex shrink-0 ${stackSpacing}`}>
      {visible.map((p, idx) => (
        <Avatar
          key={`${p.id ?? "org"}-${idx}`}
          name={p.fullName}
          email={p.email}
          avatarUrl={p.avatarUrl}
          noDefaultSize
          className={`${avatarClassName} ${ringClassName}`}
        />
      ))}

      {extraCount > 0 && (
        <div
          className={`${avatarClassName} ${ringClassName} flex shrink-0 items-center justify-center rounded-full bg-gray-700 font-semibold text-white`}
          title={`${extraCount} ${extraCount === 1 ? "colaborador más" : "colaboradores más"}`}
          aria-label={`${extraCount} ${extraCount === 1 ? "colaborador más" : "colaboradores más"}`}
        >
          +{extraCount}
        </div>
      )}
    </div>
  );
}
