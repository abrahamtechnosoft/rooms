"use client";

import { useMemo, useState } from "react";
import { toast } from "@/lib/toastHelpers";
import api from "@/lib/api";
import type { BlockType, Reply, UserBlock } from "@/types";
import Modal from "@/components/ui/Modal";
import Button from "@/components/ui/Button";
import Input from "@/components/ui/Input";

interface Props {
  block?: UserBlock | null;
  onClose: () => void;
  onSaved: () => void;
}

const DAYS = [
  { value: "1", label: "Lun" },
  { value: "2", label: "Mar" },
  { value: "3", label: "Mié" },
  { value: "4", label: "Jue" },
  { value: "5", label: "Vie" },
  { value: "6", label: "Sáb" },
  { value: "7", label: "Dom" },
];

const MAX_NAME = 80;

function dateOnly(iso?: string | null): string {
  if (!iso) return "";
  return iso.split("T")[0] || "";
}

export default function UserBlockFormModal({
  block,
  onClose,
  onSaved,
}: Props) {
  const isEdit = !!block;
  const [name, setName] = useState(block?.name || "");
  const [blockType, setBlockType] = useState<BlockType>(
    block?.blockType || "recurring"
  );
  const [selectedDays, setSelectedDays] = useState<Set<string>>(
    new Set(
      block?.daysOfWeek?.split(",").filter(Boolean) || ["1", "2", "3", "4", "5"]
    )
  );
  const [startTime, setStartTime] = useState(block?.startTime || "12:00");
  const [endTime, setEndTime] = useState(block?.endTime || "13:00");
  const [startDate, setStartDate] = useState(dateOnly(block?.startAt));
  const [endDate, setEndDate] = useState(dateOnly(block?.endAt));
  const [submitting, setSubmitting] = useState(false);

  function toggleDay(d: string) {
    setSelectedDays((prev) => {
      const next = new Set(prev);
      if (next.has(d)) next.delete(d);
      else next.add(d);
      return next;
    });
  }

  const daysCsv = useMemo(
    () =>
      [...selectedDays]
        .map((d) => parseInt(d, 10))
        .filter((n) => Number.isInteger(n) && n >= 1 && n <= 7)
        .sort((a, b) => a - b)
        .join(","),
    [selectedDays]
  );

  async function handleSubmit() {
    const trimmedName = name.trim();
    if (!trimmedName) {
      toast.error("Falta el nombre");
      return;
    }
    if (trimmedName.length > MAX_NAME) {
      toast.error(`El nombre no puede superar ${MAX_NAME} caracteres`);
      return;
    }

    const payload: Record<string, unknown> = {
      name: trimmedName,
      blockType,
    };

    if (blockType === "recurring") {
      if (selectedDays.size === 0) {
        toast.error("Selecciona al menos un día");
        return;
      }
      if (startTime >= endTime) {
        toast.error("La hora de inicio debe ser anterior a la de fin");
        return;
      }
      payload.daysOfWeek = daysCsv;
      payload.startTime = startTime;
      payload.endTime = endTime;
    } else {
      if (!startDate || !endDate) {
        toast.error("Selecciona las fechas");
        return;
      }
      if (startDate > endDate) {
        toast.error("La fecha de inicio debe ser anterior a la fin");
        return;
      }
      payload.startAt = new Date(`${startDate}T00:00:00`).toISOString();
      payload.endAt = new Date(`${endDate}T23:59:59`).toISOString();
    }

    setSubmitting(true);
    try {
      if (isEdit && block) {
        const res = await api.patch<Reply<unknown>>(
          `/users/me/blocks/${block.id}`,
          payload
        );
        if (!res.data.ok) {
          toast.error(res.data.msg || "No fue posible guardar");
          return;
        }
        toast.success(res.data.msg || "Bloqueo actualizado");
      } else {
        const res = await api.post<Reply<{ id: number }>>(
          "/users/me/blocks",
          payload
        );
        if (!res.data.ok) {
          toast.error(res.data.msg || "No fue posible guardar");
          return;
        }
        toast.success(res.data.msg || "Bloqueo creado");
      }
      onSaved();
    } catch (e: unknown) {
      const errObj = e as { response?: { data?: { msg?: string } } };
      toast.error(
        errObj?.response?.data?.msg || "No fue posible guardar"
      );
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Modal
      open={true}
      onClose={() => {
        if (!submitting) onClose();
      }}
      title={isEdit ? "Editar bloqueo" : "Nuevo bloqueo"}
      description={
        isEdit
          ? "Ajusta tu bloqueo personal."
          : "Define un horario o rango donde no aceptas reuniones automáticamente."
      }
      size="md"
      actions={
        <>
          <Button
            variant="outline"
            onClick={onClose}
            disabled={submitting}
          >
            Cancelar
          </Button>
          <Button
            variant="primary"
            onClick={handleSubmit}
            loading={submitting}
            disabled={submitting}
          >
            {isEdit ? "Guardar cambios" : "Crear"}
          </Button>
        </>
      }
    >
      <div className="space-y-4">
        <div>
          <Input
            label="Nombre"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Ej.: Almuerzo, Focus time, Incapacidad"
            maxLength={MAX_NAME}
          />
          <p className="mt-1 text-right text-xs text-gray-500 tabular-nums">
            {name.length}/{MAX_NAME}
          </p>
        </div>

        {!isEdit && (
          <div>
            <label className="mb-1.5 block text-sm font-medium text-gray-700">
              Tipo
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setBlockType("recurring")}
                className={
                  "rounded-lg border p-3 text-left text-sm transition " +
                  (blockType === "recurring"
                    ? "border-millenium-blue bg-millenium-blue/5 font-medium text-millenium-blue"
                    : "border-gray-200 hover:border-gray-300")
                }
              >
                Recurrente
                <p className="mt-1 text-xs font-normal text-gray-500">
                  Días y horas fijas
                </p>
              </button>
              <button
                type="button"
                onClick={() => setBlockType("one_time")}
                className={
                  "rounded-lg border p-3 text-left text-sm transition " +
                  (blockType === "one_time"
                    ? "border-millenium-blue bg-millenium-blue/5 font-medium text-millenium-blue"
                    : "border-gray-200 hover:border-gray-300")
                }
              >
                Puntual
                <p className="mt-1 text-xs font-normal text-gray-500">
                  Rango de fechas
                </p>
              </button>
            </div>
          </div>
        )}

        {blockType === "recurring" ? (
          <>
            <div>
              <label className="mb-1.5 block text-sm font-medium text-gray-700">
                Días
              </label>
              <div className="grid grid-cols-7 gap-1">
                {DAYS.map((d) => {
                  const active = selectedDays.has(d.value);
                  return (
                    <button
                      key={d.value}
                      type="button"
                      onClick={() => toggleDay(d.value)}
                      className={
                        "rounded p-2 text-xs transition " +
                        (active
                          ? "bg-millenium-blue font-medium text-white"
                          : "bg-gray-100 text-gray-600 hover:bg-gray-200")
                      }
                      aria-pressed={active}
                    >
                      {d.label}
                    </button>
                  );
                })}
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label
                  htmlFor="block-start-time"
                  className="mb-1.5 block text-sm font-medium text-gray-700"
                >
                  Inicio
                </label>
                <input
                  id="block-start-time"
                  type="time"
                  value={startTime}
                  onChange={(e) => setStartTime(e.target.value)}
                  className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:border-millenium-blue focus:outline-none focus:ring-2 focus:ring-millenium-blue/20"
                />
              </div>
              <div>
                <label
                  htmlFor="block-end-time"
                  className="mb-1.5 block text-sm font-medium text-gray-700"
                >
                  Fin
                </label>
                <input
                  id="block-end-time"
                  type="time"
                  value={endTime}
                  onChange={(e) => setEndTime(e.target.value)}
                  className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:border-millenium-blue focus:outline-none focus:ring-2 focus:ring-millenium-blue/20"
                />
              </div>
            </div>
          </>
        ) : (
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label
                htmlFor="block-start-date"
                className="mb-1.5 block text-sm font-medium text-gray-700"
              >
                Desde
              </label>
              <input
                id="block-start-date"
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:border-millenium-blue focus:outline-none focus:ring-2 focus:ring-millenium-blue/20"
              />
            </div>
            <div>
              <label
                htmlFor="block-end-date"
                className="mb-1.5 block text-sm font-medium text-gray-700"
              >
                Hasta
              </label>
              <input
                id="block-end-date"
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:border-millenium-blue focus:outline-none focus:ring-2 focus:ring-millenium-blue/20"
              />
            </div>
          </div>
        )}
      </div>
    </Modal>
  );
}
