"use client";

import { useMemo, useState } from "react";
import { Plus } from "lucide-react";
import type { Reservation } from "@/types";
import {
  computeOverlapLayout,
  type OverlapItem,
  type OverlapLayout,
} from "@/lib/timelineLayout";
import OverflowPopover from "@/components/OverflowPopover";
import OverlapGroup from "@/components/OverlapGroup";
import { effectiveEndsAt } from "@/lib/reservationStatus";
import { useNowTick } from "@/hooks/useNowTick";

interface SlotPick {
  date: string;
  hour: number;
  minute: number;
}

interface Props {
  /** Fecha en formato YYYY-MM-DD (timezone local). */
  date: string;
  /** Reuniones del dia, ya filtradas por chips + departamento. */
  meetings: Reservation[];
  currentUserId: number | null;
  readOnly?: boolean;
  onReservationClick: (r: Reservation) => void;
  onEmptyClick?: (slot: SlotPick) => void;
}

const OPEN_HOUR = 8;
const CLOSE_HOUR = 17;
const TOTAL_HOURS = CLOSE_HOUR - OPEN_HOUR;
const TOTAL_MINUTES = TOTAL_HOURS * 60;
const SLOT_MIN = 30;
const TOTAL_SLOTS = TOTAL_MINUTES / SLOT_MIN;
const HOUR_HEIGHT_PX = 140;
const HOURS_COL_WIDTH_PX = 64;

const pad = (n: number) => String(n).padStart(2, "0");

const localDate = (date: string, h: number, m: number): Date => {
  const [y, mo, d] = date.split("-").map((v) => parseInt(v, 10));
  return new Date(y, (mo || 1) - 1, d || 1, h, m, 0, 0);
};

const pctFromHours = (h: number): number =>
  ((Math.max(OPEN_HOUR, Math.min(CLOSE_HOUR, h)) - OPEN_HOUR) / TOTAL_HOURS) *
  100;

interface GroupedItems {
  groupId: string;
  items: OverlapItem[];
}

function groupByGroupId(layout: OverlapLayout): GroupedItems[] {
  const map = new Map<string, OverlapItem[]>();
  for (const it of layout.items) {
    const arr = map.get(it.groupId);
    if (arr) arr.push(it);
    else map.set(it.groupId, [it]);
  }
  return Array.from(map.entries()).map(([groupId, items]) => ({
    groupId,
    items,
  }));
}

/**
 * Vista diaria con UNA sola columna que mezcla TODAS las reuniones del dia
 * (fisicas + virtuales + externas) ordenadas por hora. El componente NO
 * filtra por tipo o sala — eso lo hace el padre via chips.
 */
export default function DaySingleTimeline({
  date,
  meetings,
  currentUserId,
  readOnly = false,
  onReservationClick,
  onEmptyClick,
}: Props) {
  const now = useNowTick(60_000);
  const dayReservations = useMemo(
    () =>
      meetings.filter(
        (r) =>
          r.status === "active" &&
          new Date(r.startsAt).toDateString() ===
            localDate(date, 12, 0).toDateString()
      ),
    [meetings, date]
  );

  const isToday =
    now.toDateString() === localDate(date, 12, 0).toDateString();
  const nowH = now.getHours() + now.getMinutes() / 60;
  const showNowLine = isToday && nowH >= OPEN_HOUR && nowH <= CLOSE_HOUR;
  const nowPercent = pctFromHours(nowH);
  const nowLabel = `${pad(now.getHours())}:${pad(now.getMinutes())}`;

  const layout = useMemo(
    () =>
      computeOverlapLayout(dayReservations, currentUserId, {
        openHour: OPEN_HOUR,
        closeHour: CLOSE_HOUR,
      }),
    [dayReservations, currentUserId]
  );

  const groups = useMemo(() => groupByGroupId(layout), [layout]);

  const [overflowPopover, setOverflowPopover] = useState<{
    meetings: Reservation[];
    anchorRect: DOMRect;
  } | null>(null);

  const HALF_STEPS = TOTAL_HOURS * 2;
  const labelMarks = Array.from({ length: HALF_STEPS }, (_, i) => {
    const hour = OPEN_HOUR + Math.floor(i / 2);
    const minute = (i % 2) * 30;
    return {
      label: `${pad(hour)}:${pad(minute)}`,
      pct: (i / HALF_STEPS) * 100,
      isHour: minute === 0,
    };
  });
  labelMarks.push({
    label: `${pad(CLOSE_HOUR)}:00`,
    pct: 100,
    isHour: true,
  });

  const hourLines = Array.from({ length: TOTAL_HOURS + 1 }, (_, i) => ({
    pct: (i / TOTAL_HOURS) * 100,
  }));

  const allowEmptyClick = !readOnly && !!onEmptyClick;

  return (
    <div className="rounded-xl border border-gray-200 bg-white shadow-sm">
      <div
        className="relative grid"
        style={{
          gridTemplateColumns: `${HOURS_COL_WIDTH_PX}px 1fr`,
          height: `${HOUR_HEIGHT_PX * TOTAL_HOURS + 32}px`,
          paddingTop: "1rem",
          paddingBottom: "1rem",
        }}
      >
        {/* Columna de horas */}
        <div className="relative border-r border-gray-100 bg-white">
          <div className="relative h-full w-full">
            {labelMarks.map((m) => (
              <span
                key={m.label}
                className={
                  "absolute right-2 -mt-1 leading-none tabular-nums " +
                  (m.isHour
                    ? "text-sm font-semibold text-gray-700"
                    : "text-xs text-gray-500")
                }
                style={{ top: `${m.pct}%` }}
              >
                {m.label}
              </span>
            ))}
          </div>
        </div>

        {/* Lane unica del dia */}
        <div className="relative">
          <div className="relative h-full w-full">
            {/* Lineas horarias */}
            {hourLines.map((l, i) => (
              <div
                key={i}
                className="absolute left-0 right-0 z-0 border-t border-gray-200"
                style={{ top: `${l.pct}%` }}
              />
            ))}

            {/* Slots vacios clickeables */}
            {allowEmptyClick &&
              Array.from({ length: TOTAL_SLOTS }, (_, idx) => {
                const hour = OPEN_HOUR + Math.floor(idx / 2);
                const minute = (idx % 2) * SLOT_MIN;
                const slotStart = localDate(date, hour, minute);
                const slotEnd = new Date(
                  slotStart.getTime() + SLOT_MIN * 60000
                );
                const occupied = dayReservations.some((r) => {
                  const rs = new Date(r.startsAt);
                  const re = new Date(effectiveEndsAt(r));
                  return rs < slotEnd && re > slotStart;
                });
                const inPast = slotStart <= now;
                if (occupied || inPast) return null;
                const top = (idx / TOTAL_SLOTS) * 100;
                const height = 100 / TOTAL_SLOTS;
                const time = `${pad(hour)}:${pad(minute)}`;
                return (
                  <button
                    type="button"
                    key={idx}
                    onClick={() =>
                      onEmptyClick!({ date, hour, minute })
                    }
                    className="group absolute inset-x-1 z-0 flex cursor-pointer items-center justify-center rounded transition hover:bg-millenium-blue/5"
                    style={{ top: `${top}%`, height: `${height}%` }}
                    title={`Agendar a las ${time}`}
                    aria-label={`Agendar a las ${time}`}
                  >
                    <span className="pointer-events-none flex items-center gap-1 text-xs text-millenium-blue/40 transition md:text-millenium-blue/0 md:group-hover:text-millenium-blue/70">
                      <Plus className="h-3 w-3" />
                      Agendar aquí
                    </span>
                  </button>
                );
              })}

            {/* Grupos de solape */}
            {groups.map((g) => (
              <OverlapGroup
                key={g.groupId}
                items={g.items}
                now={now}
                hourHeightPx={HOUR_HEIGHT_PX}
                largeMaxAvatars={5}
                edgePx={2}
                onReservationClick={onReservationClick}
                onOverflowClick={(hidden, anchorRect) =>
                  setOverflowPopover({ meetings: hidden, anchorRect })
                }
              />
            ))}

            {/* Linea ahora */}
            {showNowLine && (
              <div
                className="pointer-events-none absolute inset-x-0 z-20 animate-[fadeIn_180ms_ease-out]"
                style={{ top: `${nowPercent}%` }}
              >
                <div className="relative w-full">
                  <span
                    className="absolute z-30 rounded bg-millenium-red px-2 py-0.5 text-xs font-bold tabular-nums text-white shadow-sm"
                    style={{ left: "-3.75rem", top: "-0.65rem" }}
                  >
                    {nowLabel}
                  </span>
                  <div
                    className="absolute -left-1 h-2 w-2 rounded-full bg-millenium-red/80 ring-2 ring-white"
                    style={{ top: "-3px" }}
                  />
                  <div className="h-px w-full bg-millenium-red/70 mix-blend-multiply" />
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {overflowPopover && (
        <OverflowPopover
          meetings={overflowPopover.meetings}
          anchorRect={overflowPopover.anchorRect}
          onMeetingClick={onReservationClick}
          onClose={() => setOverflowPopover(null)}
        />
      )}
    </div>
  );
}
