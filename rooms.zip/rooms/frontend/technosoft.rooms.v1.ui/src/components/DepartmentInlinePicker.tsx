"use client";

import { useEffect, useRef, useState } from "react";
import { ChevronDown } from "lucide-react";
import api from "@/lib/api";
import { toast } from "@/lib/toastHelpers";
import type { Department, Reply } from "@/types";

interface Props {
  userId: number;
  currentDepartmentId: number | null;
  currentDepartmentName: string | null;
  currentDepartmentColor: string | null;
  departments: Department[];
  onUpdated: () => void;
}

export default function DepartmentInlinePicker({
  userId,
  currentDepartmentId,
  currentDepartmentName,
  currentDepartmentColor,
  departments,
  onUpdated,
}: Props) {
  const [open, setOpen] = useState(false);
  const [updating, setUpdating] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    function handleClick(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        setOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClick);
    return () => document.removeEventListener("mousedown", handleClick);
  }, [open]);

  async function handleSelect(deptId: number | null) {
    if (deptId === currentDepartmentId) {
      setOpen(false);
      return;
    }
    setUpdating(true);
    setOpen(false);
    try {
      const res = await api.patch<Reply<unknown>>(
        `/users/${userId}/department`,
        { departmentId: deptId }
      );
      if (res.data.ok) {
        toast.success(res.data.msg || "Departamento actualizado");
        onUpdated();
      } else {
        toast.error(res.data.msg || "No fue posible actualizar");
      }
    } catch (e: unknown) {
      const errObj = e as { response?: { data?: { msg?: string } } };
      toast.error(
        errObj?.response?.data?.msg ||
          "No fue posible actualizar el departamento"
      );
    } finally {
      setUpdating(false);
    }
  }

  const buttonStyle = currentDepartmentColor
    ? {
        color: currentDepartmentColor,
        backgroundColor: `${currentDepartmentColor}1A`,
      }
    : { color: "#6b7280" };

  return (
    <div ref={ref} className="relative inline-block">
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        disabled={updating}
        aria-haspopup="listbox"
        aria-expanded={open}
        className="inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-medium transition hover:opacity-80 focus:outline-none focus:ring-2 focus:ring-millenium-blue/40 disabled:cursor-wait disabled:opacity-60"
        style={buttonStyle}
      >
        {currentDepartmentName ? (
          <>
            <span
              className="inline-block h-1.5 w-1.5 rounded-full"
              style={{
                backgroundColor: currentDepartmentColor || "#6b7280",
              }}
            />
            <span className="truncate">{currentDepartmentName}</span>
          </>
        ) : (
          <span className="text-gray-400">Sin departamento</span>
        )}
        <ChevronDown className="h-3 w-3" />
      </button>

      {open && (
        <div
          role="listbox"
          className="absolute left-0 top-full z-30 mt-1 min-w-[220px] max-h-64 overflow-y-auto rounded-lg border border-gray-200 bg-white py-1 shadow-lg"
        >
          <button
            type="button"
            role="option"
            aria-selected={currentDepartmentId === null}
            onClick={() => handleSelect(null)}
            className={
              "flex w-full items-center gap-2 px-3 py-2 text-left text-sm transition hover:bg-gray-50 " +
              (currentDepartmentId === null
                ? "bg-gray-50 font-medium text-gray-700"
                : "text-gray-500")
            }
          >
            <span className="inline-block h-2 w-2 rounded-full bg-gray-300" />
            Sin departamento
          </button>
          {departments
            .filter((d) => d.isActive)
            .map((d) => {
              const selected = currentDepartmentId === d.id;
              return (
                <button
                  key={d.id}
                  type="button"
                  role="option"
                  aria-selected={selected}
                  onClick={() => handleSelect(d.id)}
                  className={
                    "flex w-full items-center gap-2 px-3 py-2 text-left text-sm transition hover:bg-gray-50 " +
                    (selected ? "bg-gray-50 font-medium" : "")
                  }
                >
                  <span
                    className="inline-block h-2 w-2 rounded-full"
                    style={{ backgroundColor: d.colorHex || "#6b7280" }}
                  />
                  <span className="truncate">{d.name}</span>
                </button>
              );
            })}
        </div>
      )}
    </div>
  );
}
