"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { Clock } from "lucide-react";
import { toast } from "@/lib/toastHelpers";
import api from "@/lib/api";
import type { Reply } from "@/types";
import { useNowTick } from "@/hooks/useNowTick";
import { useBackendPolling } from "@/hooks/useBackendPolling";
import { MIN_DURATION_MIN } from "@/lib/timeHelpers";

interface OccupiedRange {
  reservationId: number;
  startsAt: string;
  endsAt: string;
  title?: string;
}

interface AvailabilityResponse {
  date: string;
  roomId: number;
  ranges: OccupiedRange[];
}

interface Props {
  roomId: number;
  /** YYYY-MM-DD en hora local del usuario. */
  date: string;
  /** Selección actual del form (para resaltar el slot azul). */
  selectedStart: Date | null;
  selectedEnd: Date | null;
  /** En modo edición, excluir la reserva propia del listado de ocupados. */
  excludeReservationId?: number;
  /**
   * Click "inicio": cuando no hay selección o el clic está en o antes del
   * inicio actual (reset). El padre debe encargarse de calcular el fin por
   * defecto y de recortar al cierre del día.
   */
  onSelectStart: (start: Date) => void;
  /**
   * Click "fin": cuando hay un inicio seleccionado y el clic está después.
   * El padre debe encargarse de recortar al cierre del día.
   */
  onSelectEnd?: (end: Date) => void;
  minHour?: number;
  maxHour?: number;
}

const pad = (n: number) => String(n).padStart(2, "0");

const localDate = (date: string, h: number, m: number): Date => {
  const [y, mo, d] = date.split("-").map((v) => parseInt(v, 10));
  return new Date(y, (mo || 1) - 1, d || 1, h, m, 0, 0);
};

const isoToYmd = (d: Date): string =>
  `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;

// Los slots pasados se filtran de la lista antes de renderizar, por eso ya no
// existe el estado "past" — el grid sólo muestra slots actuales/futuros.
type SlotState =
  | { kind: "free" }
  | { kind: "occupied"; title?: string }
  | { kind: "selected" }
  | { kind: "inRange" };

export default function TimeSlotGrid({
  roomId,
  date,
  selectedStart,
  selectedEnd,
  excludeReservationId,
  onSelectStart,
  onSelectEnd,
  minHour = 8,
  maxHour = 17,
}: Props) {
  const [ranges, setRanges] = useState<OccupiedRange[]>([]);
  const [loading, setLoading] = useState(false);

  // Tick de 1s para el chip "Reservar ahora". El cómputo pesado (slots) usa
  // `nowMinute` que solo cambia al cruzar el minuto, así que re-renderear cada
  // segundo no recalcula la grilla.
  const now = useNowTick(1000);
  const nowMinuteEpoch = Math.floor(now.getTime() / 60000);
  const nowMinute = useMemo(
    () => new Date(nowMinuteEpoch * 60000),
    [nowMinuteEpoch]
  );

  const isToday = date === isoToYmd(now);

  // Slots cada 30 min desde minHour. Se incluye también maxHour (17:00) como
  // slot final útil solo para fijar el fin de la reunión.
  // Si la fecha es HOY, se omiten los slots cuyo fin ya pasó.
  const slots = useMemo(() => {
    const out: {
      hour: number;
      minute: number;
      start: Date;
      end: Date;
      label: string;
      isLast: boolean;
    }[] = [];
    for (let h = minHour; h <= maxHour; h++) {
      for (const m of [0, 30]) {
        if (h === maxHour && m > 0) break;
        const start = localDate(date, h, m);
        const end = new Date(start.getTime() + 30 * 60000);
        if (isToday && end <= nowMinute) continue;
        out.push({
          hour: h,
          minute: m,
          start,
          end,
          label: `${pad(h)}:${pad(m)}`,
          isLast: h === maxHour && m === 0,
        });
      }
    }
    return out;
  }, [date, minHour, maxHour, isToday, nowMinute]);

  const fetchAvailability = useCallback(async () => {
    if (!roomId || !date) return;
    setLoading(true);
    try {
      const res = await api.get<Reply<AvailabilityResponse>>(
        `/rooms/${roomId}/availability`,
        {
          params: {
            date,
            excludeReservationId: excludeReservationId || undefined,
          },
        }
      );
      if (res.data.ok && res.data.obj) {
        setRanges(res.data.obj.ranges || []);
      } else {
        setRanges([]);
      }
    } catch {
      setRanges([]);
    } finally {
      setLoading(false);
    }
  }, [roomId, date, excludeReservationId]);

  // Fetch inicial + al cambiar deps.
  useEffect(() => {
    fetchAvailability();
  }, [fetchAvailability]);

  // Polling 5s con pausa por visibilitychange. Errores silenciosos.
  useBackendPolling(
    fetchAvailability,
    5_000,
    [roomId, date, excludeReservationId],
    { silentOnError: true }
  );

  const getSlotState = useCallback(
    (slot: { start: Date; end: Date }): SlotState => {
      // 1. SELECCIONADO / EN RANGO — se evalúa antes que ocupado para que la
      //    selección activa siempre se vea aunque coincida con un ocupado.
      if (selectedStart && selectedEnd && isoToYmd(selectedStart) === date) {
        const slotStart = slot.start.getTime();
        const slotEnd = slot.end.getTime();
        const selStart = selectedStart.getTime();
        const selEnd = selectedEnd.getTime();
        const overlaps = slotEnd > selStart && slotStart < selEnd;
        if (overlaps) {
          const isFirstSlot = slotStart <= selStart && slotEnd > selStart;
          const isLastSlot = slotStart < selEnd && slotEnd >= selEnd;
          if (isFirstSlot || isLastSlot) return { kind: "selected" };
          return { kind: "inRange" };
        }
      }
      // 2. OCUPADO — slots pasados ya están filtrados, así que aquí solo queda
      //    decidir entre ocupado y libre.
      for (const r of ranges) {
        const rs = new Date(r.startsAt);
        const re = new Date(r.endsAt);
        if (rs < slot.end && re > slot.start) {
          return { kind: "occupied", title: r.title };
        }
      }
      return { kind: "free" };
    },
    [ranges, selectedStart, selectedEnd, date]
  );

  // Devuelve el "minuto del día" del inicio actual (-1 si no aplica al día).
  function currentStartMin(): number {
    if (!selectedStart || isoToYmd(selectedStart) !== date) return -1;
    return selectedStart.getHours() * 60 + selectedStart.getMinutes();
  }

  /**
   * Enruta el clic a inicio o fin según el estado actual. Tabla de decisión:
   * - sin inicio: el slot es el nuevo inicio. Bloqueamos el slot 17:00.
   * - clic > inicio: el slot pasa a ser el fin (valida duración mínima).
   * - clic ≤ inicio: reset; el slot es el nuevo inicio. Bloqueamos 17:00.
   */
  function routeClick(slotMin: number, time: Date, isLast: boolean) {
    const selStartMin = currentStartMin();

    if (selStartMin < 0) {
      if (isLast) {
        toast.info(
          `Selecciona primero una hora de inicio antes de las ${pad(maxHour)}:00`
        );
        return;
      }
      onSelectStart(time);
      return;
    }

    if (slotMin > selStartMin) {
      const dur = slotMin - selStartMin;
      if (dur < MIN_DURATION_MIN) {
        toast.info(
          `La reunión debe durar al menos ${MIN_DURATION_MIN} minutos`
        );
        return;
      }
      onSelectEnd?.(time);
      return;
    }

    // Click en o antes del inicio actual → reset.
    if (isLast) {
      toast.info(
        `Selecciona primero una hora de inicio antes de las ${pad(maxHour)}:00`
      );
      return;
    }
    onSelectStart(time);
  }

  function handleSlotClick(
    slot: { start: Date; hour: number; minute: number; isLast: boolean },
    state: SlotState
  ) {
    if (state.kind === "occupied") {
      toast.error("Ese horario está ocupado");
      return;
    }
    const slotMin = slot.hour * 60 + slot.minute;
    routeClick(slotMin, slot.start, slot.isLast);
  }

  function handleNowClick() {
    const fresh = new Date();
    fresh.setSeconds(0, 0);
    const freshMin = fresh.getHours() * 60 + fresh.getMinutes();
    routeClick(freshMin, fresh, false);
  }

  const currentTimeDisplay = `${pad(now.getHours())}:${pad(now.getMinutes())}`;

  // El chip solo aparece si la fecha es HOY y queda margen para que la reunión
  // dure al menos `MIN_DURATION_MIN` antes del cierre.
  const canReserveNow = useMemo(() => {
    if (!isToday) return false;
    const nowMin = now.getHours() * 60 + now.getMinutes();
    return nowMin <= maxHour * 60 - MIN_DURATION_MIN;
  }, [isToday, now, maxHour]);

  return (
    <div className="mt-3">
      <div className="mb-2 flex flex-wrap items-center justify-between gap-2">
        <span className="text-sm font-medium text-gray-700">
          Disponibilidad de la sala
        </span>
        <div className="flex items-center gap-2">
          {loading && (
            <span className="text-[10px] uppercase tracking-wide text-gray-400">
              Actualizando…
            </span>
          )}
          {canReserveNow && (
            <button
              type="button"
              onClick={handleNowClick}
              className="inline-flex items-center gap-1.5 rounded-full bg-millenium-blue px-3 py-1 text-xs font-medium text-white shadow-sm transition hover:bg-millenium-blue/90 focus:outline-none focus:ring-2 focus:ring-millenium-blue/40"
              title="Usar la hora actual como inicio o fin"
            >
              <Clock className="h-3.5 w-3.5" />
              Reservar ahora ({currentTimeDisplay})
            </button>
          )}
        </div>
      </div>

      {slots.length === 0 ? (
        <div className="flex flex-col items-center justify-center rounded-lg border border-dashed border-gray-300 bg-white py-8 text-center">
          <Clock className="mb-2 h-8 w-8 text-gray-300" />
          <p className="text-sm text-gray-500">
            No hay horarios disponibles hoy
          </p>
          <p className="mt-1 text-xs text-gray-400">
            Seleccione mañana u otra fecha futura.
          </p>
        </div>
      ) : (
        <div
          role="group"
          aria-label="Slots de horario disponibles"
          className="grid grid-cols-2 gap-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6"
        >
          {slots.map((slot) => {
            const state = getSlotState(slot);
            const isClickable =
              state.kind === "free" ||
              state.kind === "selected" ||
              state.kind === "inRange";
            const baseClasses =
              "flex items-center justify-center rounded-lg border px-3 py-2 text-sm tabular-nums transition select-none";

            let stateClasses = "";
            let title = `Disponible — ${slot.label}`;
            switch (state.kind) {
              case "free":
                stateClasses =
                  "border-gray-300 bg-white text-gray-700 cursor-pointer hover:border-millenium-blue hover:bg-millenium-blue/5";
                break;
              case "selected":
                stateClasses =
                  "border-millenium-blue bg-millenium-blue text-white font-bold cursor-pointer";
                title = `Inicio o fin seleccionado — ${slot.label}`;
                break;
              case "inRange":
                stateClasses =
                  "border-blue-300 bg-blue-100 text-blue-700 cursor-pointer";
                title = `En tu rango — ${slot.label}`;
                break;
              case "occupied":
                stateClasses =
                  "border-red-300 bg-red-100 text-red-700 cursor-not-allowed";
                title = state.title
                  ? `Ocupado — ${slot.label} · ${state.title}`
                  : `Ocupado — ${slot.label}`;
                break;
            }

            return (
              <button
                type="button"
                key={slot.label}
                onClick={() => handleSlotClick(slot, state)}
                className={`${baseClasses} ${stateClasses}`}
                title={title}
                aria-label={title}
                aria-disabled={!isClickable}
              >
                {slot.label}
              </button>
            );
          })}
        </div>
      )}

      {/* Leyenda y ayuda. */}
      {slots.length > 0 && (
        <>
          <div className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-1.5 text-xs text-gray-500">
            <span className="inline-flex items-center gap-1.5">
              <span className="inline-block h-3 w-3 rounded border border-gray-300 bg-white" />
              Libre
            </span>
            <span className="inline-flex items-center gap-1.5">
              <span className="inline-block h-3 w-3 rounded border border-millenium-blue bg-millenium-blue" />
              Inicio o fin
            </span>
            <span className="inline-flex items-center gap-1.5">
              <span className="inline-block h-3 w-3 rounded border border-blue-300 bg-blue-100" />
              En rango
            </span>
            <span className="inline-flex items-center gap-1.5">
              <span className="inline-block h-3 w-3 rounded border border-red-300 bg-red-100" />
              Ocupado
            </span>
          </div>
          <p className="mt-2 text-xs text-gray-500">
            Toca una hora para fijar el inicio. Toca otra hora más tarde para
            fijar el fin.
          </p>
        </>
      )}
    </div>
  );
}
