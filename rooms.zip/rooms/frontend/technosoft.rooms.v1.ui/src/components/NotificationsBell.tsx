"use client";

import { useCallback, useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Bell } from "lucide-react";
import api from "@/lib/api";
import { useNotificationStore } from "@/store/notificationStore";
import NotificationsPanel from "@/components/NotificationsPanel";
import { useBackendPolling } from "@/hooks/useBackendPolling";
import type {
  AppNotification,
  NotificationsListResponse,
  Reply,
} from "@/types";

export default function NotificationsBell() {
  const router = useRouter();
  const unreadCount = useNotificationStore((s) => s.unreadCount);
  const setUnreadCount = useNotificationStore((s) => s.setUnreadCount);
  const decrementUnread = useNotificationStore((s) => s.decrementUnread);

  const [open, setOpen] = useState(false);
  const [items, setItems] = useState<AppNotification[]>([]);
  const [loadingList, setLoadingList] = useState(false);

  const fetchCount = useCallback(async () => {
    try {
      const res = await api.get<Reply<{ count: number }>>(
        "/notifications/unread-count"
      );
      setUnreadCount(res.data.obj?.count || 0);
    } catch {
      /* ignorar fallos transitorios */
    }
  }, [setUnreadCount]);

  useEffect(() => {
    fetchCount();
  }, [fetchCount]);

  // Polling 30s. Pausa en background. Re-fetch al volver.
  useBackendPolling(fetchCount, 30_000, []);

  const handleOpen = async () => {
    setOpen(true);
    setLoadingList(true);
    try {
      const res = await api.get<Reply<NotificationsListResponse>>(
        "/notifications"
      );
      const data = res.data.obj;
      setItems(data?.items || []);
      if (data) setUnreadCount(data.unreadCount);
    } catch {
      /* ignorar */
    } finally {
      setLoadingList(false);
    }
  };

  const handleItemClick = async (n: AppNotification) => {
    setOpen(false);
    if (!n.isRead) {
      try {
        await api.patch(`/notifications/${n.id}/read`);
        decrementUnread();
        setItems((prev) =>
          prev.map((item) =>
            item.id === n.id ? { ...item, isRead: true } : item
          )
        );
      } catch {
        /* ignorar */
      }
    }
    if (n.reservationId) {
      router.push(`/dashboard/reservations?focus=${n.reservationId}`);
    } else {
      router.push("/dashboard/reservations");
    }
  };

  const handleMarkAllRead = async () => {
    try {
      await api.patch("/notifications/read-all");
      setUnreadCount(0);
      setItems((prev) =>
        prev.map((item) => ({
          ...item,
          isRead: true,
          readAt: item.readAt || new Date().toISOString(),
        }))
      );
    } catch {
      /* ignorar */
    }
  };

  return (
    <div className="relative">
      <button
        type="button"
        onClick={() => (open ? setOpen(false) : handleOpen())}
        className="relative flex h-10 w-10 items-center justify-center rounded-full transition hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-millenium-blue/40"
        aria-label="Notificaciones"
        aria-haspopup="menu"
        aria-expanded={open}
      >
        <Bell className="h-5 w-5 text-gray-600" />
        {unreadCount > 0 && (
          <span className="absolute right-1 top-1 inline-flex h-[18px] min-w-[18px] items-center justify-center rounded-full bg-millenium-red px-1 text-xs font-bold text-white">
            {unreadCount > 9 ? "9+" : unreadCount}
          </span>
        )}
      </button>

      {open && (
        <NotificationsPanel
          notifications={items}
          loading={loadingList}
          onClose={() => setOpen(false)}
          onItemClick={handleItemClick}
          onMarkAllRead={handleMarkAllRead}
        />
      )}
    </div>
  );
}
