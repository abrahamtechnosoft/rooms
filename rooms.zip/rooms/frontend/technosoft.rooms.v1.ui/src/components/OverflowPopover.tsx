"use client";

import { useEffect, useLayoutEffect, useRef, useState } from "react";
import { X } from "lucide-react";
import type { Reservation } from "@/types";
import Avatar from "@/components/Avatar";
import { getRoomColor, getRoomIcon } from "@/lib/roomIcons";

interface Props {
  meetings: Reservation[];
  anchorRect: DOMRect;
  onMeetingClick: (m: Reservation) => void;
  onClose: () => void;
}

const POPOVER_WIDTH = 288; // 18rem
const POPOVER_MAX_HEIGHT = 320; // 20rem
const VIEWPORT_MARGIN = 16;

const pad = (n: number) => String(n).padStart(2, "0");
const fmtHora = (iso: string) => {
  const d = new Date(iso);
  return `${pad(d.getHours())}:${pad(d.getMinutes())}`;
};

export default function OverflowPopover({
  meetings,
  anchorRect,
  onMeetingClick,
  onClose,
}: Props) {
  const popoverRef = useRef<HTMLDivElement>(null);
  // Posición tentativa inicial: justo debajo del anchor. Se corrige tras medir.
  const [pos, setPos] = useState<{ top: number; left: number }>(() => ({
    top: anchorRect.bottom + 4,
    left: Math.min(
      anchorRect.left,
      window.innerWidth - POPOVER_WIDTH - VIEWPORT_MARGIN
    ),
  }));

  useLayoutEffect(() => {
    const el = popoverRef.current;
    if (!el) return;
    const h = el.getBoundingClientRect().height;
    let top = anchorRect.bottom + 4;
    // Si no entra abajo, posicionar arriba.
    if (top + h + VIEWPORT_MARGIN > window.innerHeight) {
      const above = anchorRect.top - h - 4;
      top = above >= VIEWPORT_MARGIN ? above : VIEWPORT_MARGIN;
    }
    let left = anchorRect.left;
    if (left + POPOVER_WIDTH + VIEWPORT_MARGIN > window.innerWidth) {
      left = window.innerWidth - POPOVER_WIDTH - VIEWPORT_MARGIN;
    }
    if (left < VIEWPORT_MARGIN) left = VIEWPORT_MARGIN;
    setPos({ top, left });
  }, [anchorRect]);

  useEffect(() => {
    function handleClick(e: MouseEvent) {
      const target = e.target as HTMLElement | null;
      if (target && target.closest("[data-overflow-popover]")) return;
      onClose();
    }
    function handleKey(e: KeyboardEvent) {
      if (e.key === "Escape") onClose();
    }
    document.addEventListener("mousedown", handleClick);
    document.addEventListener("keydown", handleKey);
    return () => {
      document.removeEventListener("mousedown", handleClick);
      document.removeEventListener("keydown", handleKey);
    };
  }, [onClose]);

  const headerTime = meetings.length > 0 ? fmtHora(meetings[0].startsAt) : "";

  return (
    <div
      ref={popoverRef}
      data-overflow-popover
      role="dialog"
      aria-label="Lista de reuniones solapadas"
      className="animate-fadeIn fixed z-50 flex flex-col overflow-hidden rounded-lg border border-gray-200 bg-white shadow-lg"
      style={{
        top: pos.top,
        left: pos.left,
        width: POPOVER_WIDTH,
        maxHeight: POPOVER_MAX_HEIGHT,
      }}
    >
      <div className="sticky top-0 z-10 flex items-center justify-between gap-2 border-b border-gray-100 bg-white px-3 py-2">
        <span className="text-xs font-medium uppercase tracking-wide text-gray-700">
          {meetings.length}{" "}
          {meetings.length === 1 ? "reunión" : "reuniones"}
          {headerTime ? ` · ${headerTime}` : ""}
        </span>
        <button
          type="button"
          onClick={onClose}
          className="rounded text-gray-400 transition hover:text-gray-600 focus:outline-none focus:ring-2 focus:ring-millenium-blue/40"
          aria-label="Cerrar"
        >
          <X className="h-4 w-4" />
        </button>
      </div>

      <ul className="min-h-0 flex-1 overflow-y-auto py-1">
        {meetings.map((m) => {
          const color = getRoomColor(m.roomColor);
          const Icon = getRoomIcon(m.roomIcon);
          return (
            <li key={m.id}>
              <button
                type="button"
                onClick={() => {
                  onMeetingClick(m);
                  onClose();
                }}
                className="flex w-full items-center gap-2 px-3 py-2 text-left transition hover:bg-gray-50 focus:bg-gray-100 focus:outline-none"
              >
                <Avatar
                  name={m.userFullName}
                  email={m.userEmail}
                  avatarUrl={m.userAvatarUrl}
                  size="sm"
                  className="h-7 w-7 text-[11px]"
                />
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-1.5">
                    <Icon
                      className="h-3 w-3 shrink-0"
                      style={{ color }}
                    />
                    <span
                      className="truncate text-sm font-medium text-gray-900"
                      title={m.title}
                    >
                      {m.title}
                    </span>
                  </div>
                  <div
                    className="truncate text-xs text-gray-500"
                    title={m.userFullName || m.userEmail || ""}
                  >
                    {m.userFullName || m.userEmail} · {fmtHora(m.startsAt)} –{" "}
                    {fmtHora(m.endsAt)}
                  </div>
                  <div
                    className="truncate text-xs text-gray-400"
                    title={m.roomName || ""}
                  >
                    {m.type === "virtual"
                      ? "Reunión virtual"
                      : m.type === "external"
                        ? `Fuera de oficina${m.externalAddress ? " · " + m.externalAddress : ""}`
                        : m.roomName}
                  </div>
                </div>
              </button>
            </li>
          );
        })}
      </ul>
    </div>
  );
}
