"use client";

import {
  Briefcase,
  Building2,
  Clock,
  ExternalLink,
  Globe,
  MapPin,
  MessageSquare,
  Paperclip,
  Repeat,
  User,
  Video,
} from "lucide-react";
import { format, parseISO } from "date-fns";
import { es } from "date-fns/locale";
import type { Reservation } from "@/types";
import { fmtTime, formatDuration } from "@/lib/dates";
import {
  getReservationStatus,
  type ReservationVisualStatus,
} from "@/lib/reservationStatus";
import ReservationStatusBadge from "@/components/ReservationStatusBadge";
import { getRoomColor, getRoomIcon } from "@/lib/roomIcons";
import { describeRecurringPattern } from "@/lib/recurringPatternLabel";

const EXTERNAL_COLOR = "#27AE60";
const OFFICE_COLOR = "#E67E22";

interface Props {
  reservation: Reservation;
  currentUserId?: number | null;
  onOpen?: (r: Reservation) => void;
  status?: ReservationVisualStatus;
}

const isSameDay = (a: Date, b: Date) =>
  a.getFullYear() === b.getFullYear() &&
  a.getMonth() === b.getMonth() &&
  a.getDate() === b.getDate();


export default function ReservationCard({
  reservation,
  currentUserId,
  onOpen,
  status: statusProp,
}: Props) {
  const status = statusProp ?? getReservationStatus(reservation);

  const start = parseISO(reservation.startsAt);
  const end = parseISO(reservation.endsAt);

  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const tomorrow = new Date(today);
  tomorrow.setDate(today.getDate() + 1);

  const startMidnight = new Date(start);
  startMidnight.setHours(0, 0, 0, 0);

  const isToday = isSameDay(startMidnight, today);
  const isTomorrow = isSameDay(startMidnight, tomorrow);

  const dayShort = format(start, "EEE", { locale: es }).toUpperCase();
  const dayNum = format(start, "d", { locale: es });
  const monthShort = format(start, "MMM", { locale: es });

  const durationMin = Math.max(
    0,
    Math.round((end.getTime() - start.getTime()) / 60000)
  );

  const isOwn =
    currentUserId !== undefined &&
    currentUserId !== null &&
    reservation.createdBy === currentUserId;

  const dim = status === "past" || status === "cancelled";
  const cancelled = status === "cancelled";

  const isVirtual = reservation.type === "virtual";
  const isExternal = reservation.type === "external";
  const isOffice = reservation.type === "office";
  const roomColor = isOffice
    ? OFFICE_COLOR
    : isExternal
      ? EXTERNAL_COLOR
      : isVirtual
        ? "#8B5CF6"
        : getRoomColor(reservation.roomColor);
  const RoomIcon = isOffice
    ? Briefcase
    : isExternal
      ? MapPin
      : isVirtual
        ? Globe
        : getRoomIcon(reservation.roomIcon);

  // El borde izquierdo siempre toma el color de la sala. Cancelled/Past
  // mantienen el color pero con opacidad reducida.
  const cardCls =
    "flex w-full cursor-pointer flex-col gap-4 rounded-xl border border-l-4 border-gray-200 bg-white p-5 text-left transition-all hover:shadow-md md:flex-row md:items-start md:gap-5 " +
    (dim ? " opacity-70" : "");

  const titleCls = cancelled
    ? "text-base font-semibold text-gray-500 line-through"
    : dim
      ? "text-base font-semibold text-gray-600"
      : "text-base font-semibold text-gray-900";

  // Tile (fecha)
  const tileCls =
    "flex h-16 w-16 shrink-0 flex-col items-center justify-center rounded-xl border " +
    (isToday
      ? "border-2 border-millenium-blue bg-millenium-blue/5"
      : isTomorrow
        ? "border-2 border-millenium-green bg-white"
        : "border-gray-200 bg-white");

  const dayNumCls =
    "text-2xl font-bold leading-none " +
    (isToday ? "text-millenium-blue" : "text-gray-900");

  return (
    <div
      role="button"
      tabIndex={0}
      onClick={() => onOpen && onOpen(reservation)}
      onKeyDown={(e) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          onOpen && onOpen(reservation);
        }
      }}
      className={"relative " + cardCls}
      style={{ borderLeftColor: roomColor }}
    >
      {/* Zona 1 — Tile de fecha */}
      <div className={tileCls}>
        <span className="text-xs font-semibold uppercase tracking-wide text-millenium-blue">
          {dayShort}
        </span>
        <span className={dayNumCls}>{dayNum}</span>
        <span className="text-xs text-gray-500">{monthShort}</span>
      </div>

      {/* Zona 2 — Contenido */}
      <div className="min-w-0 flex-1">
        {/* Chips de tipo + rol */}
        <div className="mb-1 flex flex-wrap items-center gap-1.5">
          <span
            className={
              "inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-medium " +
              (isOffice
                ? "bg-orange-50 text-orange-700"
                : isExternal
                  ? "bg-green-50 text-millenium-green"
                  : isVirtual
                    ? "bg-purple-50 text-purple-700"
                    : "bg-blue-50 text-millenium-blue")
            }
          >
            {isOffice ? (
              <Briefcase className="h-3 w-3" />
            ) : isExternal ? (
              <MapPin className="h-3 w-3" />
            ) : isVirtual ? (
              <Video className="h-3 w-3" />
            ) : (
              <Building2 className="h-3 w-3" />
            )}
            {isOffice
              ? "Oficina"
              : isExternal
                ? "Externa"
                : isVirtual
                  ? "Virtual"
                  : "Sala"}
          </span>
          <span className="inline-flex items-center gap-1 text-xs text-gray-500">
            {isOwn ? "Organizador" : "Invitado"}
          </span>
          {reservation.recurringSeriesId && (
            <span
              className="inline-flex items-center gap-1 rounded-full bg-purple-50 px-2 py-0.5 text-xs font-medium text-purple-700"
              title={
                reservation.isException
                  ? "Recurrente · esta instancia fue modificada"
                  : "Reunión recurrente"
              }
            >
              <Repeat className="h-3 w-3" />
              Recurrente
              {reservation.isException && (
                <span className="ml-1 text-amber-700">· Modificada</span>
              )}
            </span>
          )}
        </div>

        <h3
          className={"line-clamp-2 wrap-break-word " + titleCls}
          title={reservation.title}
        >
          {reservation.title}
        </h3>
        {reservation.recurringSeriesId && (
          <p className="mt-0.5 truncate text-xs italic text-gray-500">
            {start.getTime() < Date.now()
              ? "Última ocurrencia"
              : "Próxima ocurrencia"}{" "}
            · {describeRecurringPattern(reservation)}
          </p>
        )}
        <p className="mt-1 text-sm text-gray-700 tabular-nums">
          {fmtTime(reservation.startsAt)} - {fmtTime(reservation.endsAt)}{" "}
          <span className="text-gray-400">·</span> {formatDuration(durationMin)}
        </p>
        <p className="mt-1 flex items-center gap-1.5 text-sm text-gray-700">
          <RoomIcon
            className="h-4 w-4 shrink-0"
            style={{ color: roomColor }}
          />
          <span
            className="truncate"
            title={
              isOffice
                ? reservation.officeName || "Oficina del departamento"
                : isExternal
                  ? `Fuera de oficina${
                      reservation.externalCompany
                        ? ` · ${reservation.externalCompany}`
                        : reservation.externalAddress
                          ? ` · ${reservation.externalAddress}`
                          : ""
                    }`
                  : isVirtual
                    ? "Reunión virtual"
                    : reservation.roomName || ""
            }
          >
            {isOffice
              ? reservation.officeName || "Oficina del departamento"
              : isExternal
                ? `Fuera de oficina${
                    reservation.externalCompany
                      ? ` · ${reservation.externalCompany}`
                      : reservation.externalAddress
                        ? ` · ${reservation.externalAddress}`
                        : ""
                  }`
                : isVirtual
                  ? "Reunión virtual"
                  : reservation.roomName}
          </span>
        </p>
        {!isOwn && (
          <p className="mt-1 flex items-center gap-1.5 text-xs text-gray-500">
            <User className="h-3.5 w-3.5 shrink-0" />
            <span
              className="truncate"
              title={`Organizada por ${reservation.userFullName}`}
            >
              Organizada por {reservation.userFullName}
            </span>
          </p>
        )}
        <div className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1">
          {!!reservation.attachmentsCount && reservation.attachmentsCount > 0 && (
            <span
              className="inline-flex items-center gap-1 text-xs text-gray-500"
              title={`${reservation.attachmentsCount} ${
                reservation.attachmentsCount === 1 ? "adjunto" : "adjuntos"
              }`}
            >
              <Paperclip className="h-3 w-3 shrink-0" />
              {reservation.attachmentsCount}
            </span>
          )}
          {!!reservation.notesCount && reservation.notesCount > 0 && (
            <span
              className="inline-flex items-center gap-1 text-xs text-gray-500"
              title={`${reservation.notesCount} ${
                reservation.notesCount === 1 ? "nota" : "notas"
              }`}
            >
              <MessageSquare className="h-3 w-3 shrink-0" />
              {reservation.notesCount}
            </span>
          )}
          {isOwn &&
            !!reservation.pendingResponsesCount &&
            reservation.pendingResponsesCount > 0 && (
              <span
                className="inline-flex items-center gap-1 text-xs text-amber-600"
                title="Colaboradores pendientes de responder por bloqueo personal"
              >
                <Clock className="h-3 w-3 shrink-0" />
                {reservation.pendingResponsesCount} pendientes
              </span>
            )}
        </div>
        {reservation.description && (
          <p
            className="mt-1 line-clamp-2 text-xs text-gray-600"
            title={reservation.description}
          >
            {reservation.description}
          </p>
        )}
        {isVirtual &&
          reservation.meetingLink &&
          !dim && (
            <a
              href={reservation.meetingLink}
              target="_blank"
              rel="noopener noreferrer"
              onClick={(e) => e.stopPropagation()}
              className="mt-2 inline-flex items-center gap-1.5 text-sm font-medium text-millenium-blue hover:underline focus:outline-none focus:ring-2 focus:ring-millenium-blue/40 focus:ring-offset-1"
            >
              <ExternalLink className="h-4 w-4" />
              Unirse a la reunión
            </a>
          )}
      </div>

      {/* Zona 3 — Estado */}
      <div className="flex shrink-0 items-center justify-end md:flex-col md:items-end md:justify-start md:gap-3">
        <ReservationStatusBadge status={status} size="md" />
      </div>
    </div>
  );
}
