"use client";

import type { CSSProperties } from "react";
import { Briefcase, Clock, Paperclip, Repeat } from "lucide-react";
import type { Reservation } from "@/types";
import {
  getBlockStyles,
  getReservationStatus,
} from "@/lib/reservationStatus";
import { getRoomColor, getRoomIcon } from "@/lib/roomIcons";
import AvatarStack from "@/components/AvatarStack";

const OFFICE_COLOR = "#E67E22";

interface Props {
  reservation: Reservation;
  /** Altura real del bloque en pixeles. Decide layout large/medium/compact. */
  heightPx: number;
  /**
   * Ancho real del bloque en pixeles. Junto con `heightPx`, decide la
   * variante: si una de las dos dimensiones es chica, cae a medium o
   * compact para preservar legibilidad en cards solapadas estrechas.
   */
  widthPx: number;
  /** Estilos absolutos de posicionamiento (top/height/left/width). */
  positionStyle: CSSProperties;
  /**
   * Cuántos avatares visibles renderiza el bloque large.
   * - Vista diaria (más ancha): 5 (organizador + 4 colaboradores).
   * - Vista semanal (columna estrecha): 4 (organizador + 3 colaboradores).
   * El render medium siempre usa 3.
   */
  largeMaxAvatars?: number;
  /**
   * "Ahora" tickeado por el padre (`useNowTick(1000)`). Si se pasa, el badge
   * "En curso" aparece/desaparece al segundo exacto. Si no se pasa, se evalúa
   * solo al montar/re-render.
   */
  now?: Date;
  /**
   * Cuando es true (porque otra card hermana del mismo grupo de solape esta
   * en hover), el bloque reduce la cantidad de avatares para no desbordar.
   */
  shrunk?: boolean;
  onOpen: (r: Reservation) => void;
}

const pad = (n: number) => String(n).padStart(2, "0");
const fmt = (iso: string) => {
  const d = new Date(iso);
  return `${pad(d.getHours())}:${pad(d.getMinutes())}`;
};

type Size = "large" | "medium" | "compact";

function pickSize(heightPx: number, widthPx: number): Size {
  // Ambas dimensiones deben cumplir para subir de variante. Si una falla,
  // cae a la siguiente. Esto garantiza que una card solapada al 50% del
  // carril (ancho chico) caiga en compact aunque su altura sea generosa.
  if (heightPx >= 80 && widthPx >= 180) return "large";
  if (heightPx >= 40 && widthPx >= 110) return "medium";
  return "compact";
}

export default function TimelineBlock({
  reservation,
  heightPx,
  widthPx,
  positionStyle,
  largeMaxAvatars = 4,
  now,
  shrunk = false,
  onOpen,
}: Props) {
  // Cuando el bloque esta encogido (hermana de una card con hover), reducimos
  // los avatares visibles para que el AvatarStack no desborde el contenedor.
  const effectiveLargeMaxAvatars = shrunk ? 1 : largeMaxAvatars;
  const effectiveMediumMaxAvatars = shrunk ? 1 : 3;
  // `now` se recalcula cada segundo en el timeline padre (useNowTick), así que
  // el status y los estilos se evalúan en cada render → la transición
  // upcoming → live → past ocurre en vivo sin recargar.
  const evalDate = now ?? new Date();
  const status = getReservationStatus(reservation, evalDate);
  const isLive = status === "live";

  // "Termina pronto" — chip cuando faltan ≤5 min para que termine la reunión
  // y está en curso. El status real (cancelled/ended_early) se respeta.
  const minutesToEnd = isLive
    ? (new Date(reservation.endsAt).getTime() - evalDate.getTime()) / 60000
    : 0;
  const isEndingSoon = isLive && minutesToEnd > 0 && minutesToEnd <= 5;

  const isOffice = reservation.type === "office";
  const roomColor = isOffice ? OFFICE_COLOR : getRoomColor(reservation.roomColor);
  const Icon = isOffice ? Briefcase : getRoomIcon(reservation.roomIcon);
  const styles = getBlockStyles(reservation, evalDate, roomColor);
  const tone = {
    bg: styles.backgroundColor,
    border: styles.borderColor,
    titleColor: styles.textColorClass,
    metaColor: styles.subtextColorClass,
    opacity: styles.opacityClass,
    titleExtra: styles.titleClass,
    iconTint: styles.iconColor,
  };

  const size = pickSize(heightPx, widthPx);

  const activeCollaborators = (reservation.participants || []).filter(
    (p) => p.status === "active" || !p.status
  );
  const organizer = {
    id: reservation.createdBy,
    fullName: reservation.userFullName,
    email: reservation.userEmail,
    avatarUrl: reservation.userAvatarUrl,
  };

  const containerClasses = [
    "absolute z-10 flex flex-col overflow-hidden rounded-lg text-left",
    "cursor-pointer transition-shadow hover:shadow-md focus:outline-none focus-visible:ring-2 focus-visible:ring-millenium-blue focus-visible:ring-offset-1",
    "border border-gray-200 border-l-4",
    tone.opacity,
  ]
    .filter(Boolean)
    .join(" ");

  const containerStyle: CSSProperties = {
    minHeight: "20px",
    backgroundColor: tone.bg,
    borderLeftColor: tone.border,
    ...positionStyle,
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLDivElement>) => {
    if (e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      onOpen(reservation);
    }
  };

  const horaInicio = fmt(reservation.startsAt);

  // === LARGE (≥80px) — 2 líneas: (icono + título · hora + badge) / (avatares) ===
  if (size === "large") {
    return (
      <div
        role="button"
        tabIndex={0}
        onClick={() => onOpen(reservation)}
        onKeyDown={handleKeyDown}
        title={`${reservation.title} · ${horaInicio}`}
        className={`${containerClasses} justify-between ${widthPx < 220 ? "gap-1.5 p-2" : "gap-2 p-3"}`}
        style={containerStyle}
      >
        {/* Línea 1 — icono + título + · hora + badge */}
        <div className="flex w-full items-start justify-between gap-2">
          <span
            className={`flex min-w-0 flex-1 items-baseline gap-1.5 leading-tight ${tone.titleColor}`}
          >
            <Icon
              className="h-4 w-4 shrink-0 translate-y-0.5"
              style={{ color: tone.iconTint }}
            />
            <span
              className={`truncate text-sm font-semibold ${tone.titleExtra}`}
            >
              {reservation.title}
            </span>
            <span className="shrink-0 text-xs tabular-nums text-gray-500">
              · {horaInicio}
            </span>
            {reservation.recurringSeriesId && (
              <Repeat
                className="h-3 w-3 shrink-0 translate-y-0.5 text-purple-600"
                aria-label="Reunión recurrente"
              >
                <title>Reunión recurrente</title>
              </Repeat>
            )}
            {!!reservation.attachmentsCount && reservation.attachmentsCount > 0 && (
              <Paperclip
                className="h-3 w-3 shrink-0 translate-y-0.5 text-gray-400"
                aria-label={`${reservation.attachmentsCount} adjuntos`}
              />
            )}
          </span>
          {isLive && (
            <span className="inline-flex shrink-0 items-center gap-1.5 leading-tight">
              {isEndingSoon ? (
                <span
                  className="inline-flex items-center gap-1 rounded bg-amber-50 px-1.5 py-0.5 text-xs font-medium text-amber-700"
                  title={`Termina en ${Math.ceil(minutesToEnd)} min`}
                >
                  <Clock className="h-3 w-3" />
                  Termina pronto
                </span>
              ) : (
                <span className="inline-flex items-center gap-1 text-xs font-medium text-millenium-red">
                  <span className="relative inline-flex h-1.5 w-1.5">
                    <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-millenium-red opacity-75" />
                    <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-millenium-red" />
                  </span>
                  En curso
                </span>
              )}
            </span>
          )}
        </div>

        {/* Línea 2 — avatares apilados */}
        <AvatarStack
          organizer={organizer}
          collaborators={activeCollaborators}
          maxVisible={effectiveLargeMaxAvatars}
          avatarClassName="h-7 w-7 text-[12px]"
          stackSpacing="-space-x-2"
          ringClassName="ring-2 ring-white"
        />
      </div>
    );
  }

  // === MEDIUM (40-79px) === — MISMA estructura de 2 líneas que large.
  if (size === "medium") {
    return (
      <div
        role="button"
        tabIndex={0}
        onClick={() => onOpen(reservation)}
        onKeyDown={handleKeyDown}
        title={`${reservation.title} · ${horaInicio}`}
        className={`${containerClasses} justify-between ${widthPx < 150 ? "gap-1 px-1.5 py-1.5" : "gap-1.5 px-2.5 py-2"}`}
        style={containerStyle}
      >
        {/* Línea 1 — icono + título + · hora + dot rojo si en curso */}
        <div className="flex w-full items-center justify-between gap-1.5">
          <span
            className={`flex min-w-0 flex-1 items-baseline gap-1 leading-tight ${tone.titleColor}`}
          >
            <Icon
              className="h-3.5 w-3.5 shrink-0 translate-y-0.5"
              style={{ color: tone.iconTint }}
            />
            <span
              className={`truncate text-xs font-semibold ${tone.titleExtra}`}
            >
              {reservation.title}
            </span>
            <span className="shrink-0 text-[10px] tabular-nums text-gray-500">
              · {horaInicio}
            </span>
            {reservation.recurringSeriesId && (
              <Repeat
                className="h-2.5 w-2.5 shrink-0 translate-y-0.5 text-purple-600"
                aria-label="Reunión recurrente"
              >
                <title>Reunión recurrente</title>
              </Repeat>
            )}
            {!!reservation.attachmentsCount && reservation.attachmentsCount > 0 && (
              <Paperclip
                className="h-2.5 w-2.5 shrink-0 translate-y-0.5 text-gray-400"
                aria-label={`${reservation.attachmentsCount} adjuntos`}
              />
            )}
          </span>
          {isLive && (
            isEndingSoon ? (
              <span
                className="inline-flex shrink-0 items-center gap-0.5 rounded bg-amber-50 px-1 py-0.5 text-[10px] font-medium text-amber-700"
                title={`Termina en ${Math.ceil(minutesToEnd)} min`}
              >
                <Clock className="h-2.5 w-2.5" />
                Termina pronto
              </span>
            ) : (
              <span className="relative inline-flex h-1.5 w-1.5 shrink-0">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-millenium-red opacity-75" />
                <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-millenium-red" />
              </span>
            )
          )}
        </div>

        {/* Línea 2 — avatares apilados */}
        <AvatarStack
          organizer={organizer}
          collaborators={activeCollaborators}
          maxVisible={effectiveMediumMaxAvatars}
          avatarClassName="h-6 w-6 text-[11px]"
          stackSpacing="-space-x-1.5"
          ringClassName="ring-1 ring-white"
        />
      </div>
    );
  }

  // === COMPACT — cards estrechas (solape) o muy cortas. 1 linea con
  //     icono + titulo (flex-1 truncate) + hora + dot live opcional.
  //     No muestra recurrente ni paperclip — no hay espacio.
  return (
    <div
      role="button"
      tabIndex={0}
      onClick={() => onOpen(reservation)}
      onKeyDown={handleKeyDown}
      title={`${reservation.title} · ${horaInicio}`}
      className={`${containerClasses} items-center gap-1 px-1.5 py-1`}
      style={containerStyle}
    >
      <div className="flex w-full min-w-0 items-center gap-1">
        <Icon
          className="h-3 w-3 shrink-0"
          style={{ color: tone.iconTint }}
        />
        <span
          className={`min-w-0 flex-1 truncate text-[11px] font-semibold leading-tight ${tone.titleColor} ${tone.titleExtra}`}
        >
          {reservation.title}
        </span>
        <span className="shrink-0 text-[10px] tabular-nums text-gray-500">
          {horaInicio}
        </span>
        {isLive && !isEndingSoon && (
          <span className="relative inline-flex h-1.5 w-1.5 shrink-0">
            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-millenium-red opacity-75" />
            <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-millenium-red" />
          </span>
        )}
      </div>
    </div>
  );
}
