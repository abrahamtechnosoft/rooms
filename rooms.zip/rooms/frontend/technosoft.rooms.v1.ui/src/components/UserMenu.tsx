"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { ChevronDown, LogOut, Settings, User as UserIcon } from "lucide-react";
import { useAuthStore } from "@/store/authStore";
import Avatar from "@/components/Avatar";

export default function UserMenu() {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const router = useRouter();
  const user = useAuthStore((s) => s.user);
  const logout = useAuthStore((s) => s.logout);

  useEffect(() => {
    const onClickOutside = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    document.addEventListener("mousedown", onClickOutside);
    return () => document.removeEventListener("mousedown", onClickOutside);
  }, []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setOpen(false);
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, []);

  if (!user) return null;

  const roleLabel = user.role === "admin" ? "Administrador" : "Empleado";

  const handleLogout = () => {
    setOpen(false);
    logout();
    router.replace("/login");
  };

  return (
    <div ref={ref} className="relative">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className="flex items-center gap-2 rounded-full p-1 pr-2 transition hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-millenium-blue/40 focus:ring-offset-1"
        aria-label="Menú de usuario"
        aria-expanded={open}
      >
        <Avatar
          name={user.fullName}
          email={user.email}
          avatarUrl={user.avatarUrl}
          size="md"
        />
        <ChevronDown
          className={
            "h-4 w-4 text-gray-500 transition-transform " +
            (open ? "rotate-180" : "")
          }
        />
      </button>

      {open && (
        <div className="absolute right-0 z-50 mt-2 w-72 overflow-hidden rounded-xl border border-gray-200 bg-white shadow-xl">
          <div className="border-b border-gray-100 p-5">
            <div className="flex items-center gap-3">
              <Avatar
                name={user.fullName}
                email={user.email}
                avatarUrl={user.avatarUrl}
                size="lg"
              />
              <div className="min-w-0">
                <p className="truncate text-base font-semibold text-gray-900">
                  {user.fullName}
                </p>
                <p className="truncate text-sm text-gray-500">{user.email}</p>
                <p className="mt-0.5 text-sm text-gray-500">
                  Rol: {roleLabel}
                </p>
              </div>
            </div>
          </div>

          <div className="py-1">
            <Link
              href="/dashboard/profile"
              onClick={() => setOpen(false)}
              className="flex items-center gap-3 px-4 py-2.5 text-base text-gray-700 transition hover:bg-gray-50"
            >
              <UserIcon className="h-5 w-5" />
              Mi perfil
            </Link>
            <div
              className="flex items-center gap-3 px-4 py-2.5 text-base text-gray-500"
              aria-disabled="true"
              title="Próximamente"
            >
              <Settings className="h-5 w-5" />
              Configuración
              <span className="ml-auto text-xs font-semibold uppercase tracking-wide text-gray-500">
                Próximamente
              </span>
            </div>
          </div>

          <div className="border-t border-gray-100 py-1">
            <button
              type="button"
              onClick={handleLogout}
              className="flex w-full items-center gap-3 px-4 py-2.5 text-base text-millenium-red transition hover:bg-red-50"
            >
              <LogOut className="h-5 w-5" />
              Cerrar sesión
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
