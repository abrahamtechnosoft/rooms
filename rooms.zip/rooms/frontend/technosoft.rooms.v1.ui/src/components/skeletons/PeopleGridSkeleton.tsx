interface Props {
  count?: number;
}

export default function PeopleGridSkeleton({ count = 8 }: Props) {
  return (
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
      {Array.from({ length: count }).map((_, i) => (
        <div
          key={i}
          className="rounded-lg border border-gray-200 bg-white p-4 shadow-sm"
        >
          <div className="flex flex-col items-center gap-2 text-center">
            <span className="h-16 w-16 rounded-full animate-shimmer" />
            <span className="mt-2 block h-4 w-24 animate-shimmer" />
            <span className="block h-3 w-32 animate-shimmer" />
            <span className="mt-1 block h-3 w-20 animate-shimmer" />
          </div>
        </div>
      ))}
    </div>
  );
}
