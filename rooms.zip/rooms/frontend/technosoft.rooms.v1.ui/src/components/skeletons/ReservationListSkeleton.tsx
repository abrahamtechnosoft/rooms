interface Props {
  count?: number;
}

export default function ReservationListSkeleton({ count = 5 }: Props) {
  return (
    <div className="space-y-3">
      {Array.from({ length: count }).map((_, i) => (
        <div
          key={i}
          className="rounded-lg border border-gray-200 bg-white p-4 shadow-sm"
        >
          <div className="flex items-start gap-3">
            <span className="h-10 w-10 shrink-0 rounded-lg animate-shimmer" />
            <div className="min-w-0 flex-1 space-y-2">
              <span className="block h-4 w-3/4 animate-shimmer" />
              <span className="block h-3 w-1/2 animate-shimmer" />
              <div className="flex gap-2 pt-1">
                <span className="h-5 w-5 rounded-full animate-shimmer" />
                <span className="h-5 w-5 rounded-full animate-shimmer" />
                <span className="h-5 w-5 rounded-full animate-shimmer" />
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
