export default function ModalDetailSkeleton() {
  return (
    <div className="space-y-4">
      <div className="flex items-start gap-3">
        <span className="h-10 w-10 shrink-0 rounded-lg animate-shimmer" />
        <div className="min-w-0 flex-1 space-y-2">
          <span className="block h-5 w-3/4 animate-shimmer" />
          <span className="block h-3 w-1/2 animate-shimmer" />
        </div>
      </div>
      <div className="space-y-3 border-t border-gray-100 pt-3">
        {[0, 1, 2, 3].map((i) => (
          <div key={i}>
            <span className="mb-1.5 block h-3 w-16 animate-shimmer" />
            <span className="block h-4 w-2/3 animate-shimmer" />
          </div>
        ))}
      </div>
    </div>
  );
}
