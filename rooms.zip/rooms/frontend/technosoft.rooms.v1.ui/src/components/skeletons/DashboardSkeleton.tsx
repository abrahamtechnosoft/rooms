/**
 * Skeleton del dashboard. Imita la grilla de salas + carriles con bloques de
 * reunión "fantasma" para que la página no aparezca "primero vacía, luego
 * llena".
 */
export default function DashboardSkeleton() {
  return (
    <div className="grid min-h-0 flex-1 grid-cols-1 gap-4 md:grid-cols-2 md:gap-6 xl:grid-cols-3 xl:gap-6">
      {[0, 1, 2].map((i) => (
        <div
          key={i}
          className="overflow-hidden rounded-xl border border-gray-200 bg-white shadow-sm"
        >
          {/* Header de sala */}
          <div className="border-b border-l-4 border-gray-200 bg-gray-50/60 p-5 md:p-6">
            <div className="mb-2 flex items-center gap-2">
              <span className="h-6 w-6 animate-shimmer" />
              <span className="h-5 w-32 animate-shimmer" />
            </div>
            <span className="block h-3 w-48 animate-shimmer" />
          </div>

          {/* Carril con líneas horarias y "bloque" fantasma */}
          <div className="relative p-4">
            <div className="space-y-4">
              {Array.from({ length: 9 }).map((_, j) => (
                <div key={j} className="flex items-center gap-3">
                  <span className="block h-3 w-10 animate-shimmer" />
                  <span className="block h-px flex-1 bg-gray-100" />
                </div>
              ))}
            </div>
            {/* Bloque de reunión fantasma */}
            <div
              className="pointer-events-none absolute left-16 right-4 h-20 animate-shimmer"
              style={{ top: "30%" }}
            />
            <div
              className="pointer-events-none absolute left-16 right-4 h-12 animate-shimmer"
              style={{ top: "65%" }}
            />
          </div>
        </div>
      ))}
    </div>
  );
}
