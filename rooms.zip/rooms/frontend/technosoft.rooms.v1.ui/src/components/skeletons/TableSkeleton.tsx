interface Props {
  rows?: number;
  columns?: number;
}

export default function TableSkeleton({ rows = 8, columns = 5 }: Props) {
  const widthPct = `${100 / columns}%`;
  return (
    <div className="overflow-hidden rounded-lg border border-gray-200 bg-white shadow-sm">
      <div className="border-b border-gray-200 bg-gray-50 px-4 py-3">
        <div className="flex gap-4">
          {Array.from({ length: columns }).map((_, i) => (
            <span
              key={i}
              className="block h-3 animate-shimmer"
              style={{ width: widthPct }}
            />
          ))}
        </div>
      </div>
      <div className="divide-y divide-gray-100">
        {Array.from({ length: rows }).map((_, i) => (
          <div key={i} className="flex items-center gap-4 px-4 py-3">
            {Array.from({ length: columns }).map((_, j) => (
              <span
                key={j}
                className="block h-4 animate-shimmer"
                style={{ width: widthPct }}
              />
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}
