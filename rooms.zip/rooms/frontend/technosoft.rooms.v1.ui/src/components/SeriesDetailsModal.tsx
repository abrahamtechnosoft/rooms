"use client";

import { useEffect, useState } from "react";
import { Calendar, Clock, Loader2, Repeat, X } from "lucide-react";
import api from "@/lib/api";
import { fmtDate, fmtDateShort, fmtTime } from "@/lib/dates";
import type {
  RecurringSeriesInstance,
  RecurringSeriesSummary,
  Reply,
} from "@/types";

interface Props {
  seriesId: number;
  onClose: () => void;
}

const DAY_LABELS: Record<string, string> = {
  "1": "Lunes",
  "2": "Martes",
  "3": "Miércoles",
  "4": "Jueves",
  "5": "Viernes",
  "6": "Sábado",
  "7": "Domingo",
};

function describeRecurrence(series: RecurringSeriesSummary): string {
  if (series.pattern === "monthly") {
    return `Mensual, día ${series.dayOfMonth ?? "?"}`;
  }

  const days = (series.daysOfWeek || "")
    .split(",")
    .map((d) => d.trim())
    .filter(Boolean)
    .sort();
  const freq = series.frequencyWeeks || 1;

  if (days.length === 7) {
    return freq === 1
      ? "Todos los días"
      : `Todos los días, cada ${freq} semanas`;
  }
  if (days.length === 5 && days.join(",") === "1,2,3,4,5") {
    return freq === 1
      ? "Días hábiles (L-V)"
      : `Días hábiles (L-V), cada ${freq} semanas`;
  }
  if (days.length === 2 && days.join(",") === "6,7") {
    return freq === 1
      ? "Fines de semana"
      : `Fines de semana, cada ${freq} semanas`;
  }

  const labelStr = days.map((d) => DAY_LABELS[d] || d).join(", ");
  if (!labelStr) return freq === 1 ? "Semanal" : `Cada ${freq} semanas`;
  return freq === 1
    ? `Semanal: ${labelStr}`
    : `Cada ${freq} semanas: ${labelStr}`;
}

export default function SeriesDetailsModal({ seriesId, onClose }: Props) {
  const [series, setSeries] = useState<RecurringSeriesSummary | null>(null);
  const [instances, setInstances] = useState<RecurringSeriesInstance[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    Promise.all([
      api.get<Reply<RecurringSeriesSummary>>(`/recurring-series/${seriesId}`),
      api.get<Reply<RecurringSeriesInstance[]>>(
        `/recurring-series/${seriesId}/instances`
      ),
    ])
      .then(([sRes, iRes]) => {
        if (cancelled) return;
        setSeries(sRes.data.obj || null);
        setInstances(iRes.data.obj || []);
      })
      .catch((e) => {
        if (cancelled) return;
        const errObj = e as { response?: { data?: { msg?: string } } };
        setError(errObj?.response?.data?.msg || "No fue posible cargar la serie");
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [seriesId]);

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="series-details-title"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4"
      onClick={onClose}
    >
      <div
        className="flex max-h-[90vh] w-full max-w-2xl flex-col rounded-xl bg-white shadow-xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between border-b border-gray-200 p-4">
          <div className="flex items-center gap-2">
            <Repeat className="h-5 w-5 text-purple-700" aria-hidden="true" />
            <h3 id="series-details-title" className="font-semibold text-gray-900">Detalles de la serie</h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded p-1 text-gray-400 transition hover:bg-gray-100 hover:text-gray-700"
            aria-label="Cerrar"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="flex-1 space-y-4 overflow-y-auto p-4">
          {loading ? (
            <div className="flex items-center justify-center py-12 text-gray-400">
              <Loader2 className="h-6 w-6 animate-spin" />
            </div>
          ) : error || !series ? (
            <p className="py-8 text-center text-sm text-millenium-red">
              {error || "No se pudo cargar la serie"}
            </p>
          ) : (
            <>
              <div>
                <h4 className="text-lg font-semibold text-gray-900">
                  {series.title}
                </h4>
                {series.description && (
                  <p className="mt-1 text-sm text-gray-600">
                    {series.description}
                  </p>
                )}
                {!series.isActive && (
                  <p className="mt-2 inline-flex items-center gap-1 rounded-full bg-red-50 px-2 py-0.5 text-xs text-millenium-red">
                    Serie cancelada
                  </p>
                )}
              </div>

              <div className="grid grid-cols-2 gap-3 text-sm">
                <div>
                  <p className="text-xs text-gray-500">Recurrencia</p>
                  <p className="font-medium text-gray-900">
                    {describeRecurrence(series)}
                  </p>
                </div>
                <div>
                  <p className="text-xs text-gray-500">Horario</p>
                  <p className="font-medium text-gray-900 tabular-nums">
                    {series.startTime} – {series.endTime}
                  </p>
                </div>
                <div>
                  <p className="text-xs text-gray-500">Desde</p>
                  <p className="font-medium text-gray-900">
                    {fmtDateShort(series.seriesStartDate)}
                  </p>
                </div>
                <div>
                  <p className="text-xs text-gray-500">Hasta</p>
                  <p className="font-medium text-gray-900">
                    {fmtDateShort(series.seriesEndDate)}
                  </p>
                </div>
                {series.roomName && (
                  <div className="col-span-2">
                    <p className="text-xs text-gray-500">Sala</p>
                    <p className="font-medium text-gray-900">
                      {series.roomName}
                    </p>
                  </div>
                )}
                <div className="col-span-2">
                  <p className="text-xs text-gray-500">Creada por</p>
                  <p className="font-medium text-gray-900">
                    {series.createdByName || "—"}
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2 rounded-lg border border-gray-200 bg-gray-50 p-3 text-center text-xs sm:grid-cols-5">
                <div>
                  <p className="text-gray-500">Total</p>
                  <p className="text-base font-semibold text-gray-900">
                    {series.stats.total}
                  </p>
                </div>
                <div>
                  <p className="text-gray-500">Próximas</p>
                  <p className="text-base font-semibold text-millenium-blue">
                    {series.stats.upcoming}
                  </p>
                </div>
                <div>
                  <p className="text-gray-500">Pasadas</p>
                  <p className="text-base font-semibold text-gray-700">
                    {series.stats.past}
                  </p>
                </div>
                <div>
                  <p className="text-gray-500">Canceladas</p>
                  <p className="text-base font-semibold text-millenium-red">
                    {series.stats.cancelled}
                  </p>
                </div>
                <div>
                  <p className="text-gray-500">Modificadas</p>
                  <p className="text-base font-semibold text-amber-700">
                    {series.stats.exceptions}
                  </p>
                </div>
              </div>

              <div>
                <p className="mb-2 text-sm font-semibold text-gray-700">
                  Instancias ({instances.length})
                </p>
                {instances.length === 0 ? (
                  <p className="text-sm italic text-gray-500">
                    Sin instancias.
                  </p>
                ) : (
                  <ul className="max-h-60 space-y-1 overflow-y-auto rounded border border-gray-200">
                    {instances.map((inst) => (
                      <li
                        key={inst.id}
                        className="flex items-center justify-between border-b border-gray-100 px-3 py-2 text-sm last:border-b-0"
                      >
                        <div className="flex min-w-0 items-center gap-2">
                          <Calendar className="h-3.5 w-3.5 shrink-0 text-gray-400" />
                          <span className="truncate text-gray-900">
                            {fmtDate(inst.startsAt)}
                          </span>
                        </div>
                        <div className="flex shrink-0 items-center gap-2 text-xs">
                          <span className="flex items-center gap-1 tabular-nums text-gray-500">
                            <Clock className="h-3 w-3" />
                            {fmtTime(inst.startsAt)} – {fmtTime(inst.endsAt)}
                          </span>
                          {inst.status === "cancelled" && (
                            <span className="rounded-full bg-red-50 px-2 py-0.5 text-millenium-red">
                              Cancelada
                            </span>
                          )}
                          {inst.isException && inst.status !== "cancelled" && (
                            <span className="rounded-full bg-amber-50 px-2 py-0.5 text-amber-700">
                              Modificada
                            </span>
                          )}
                        </div>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
