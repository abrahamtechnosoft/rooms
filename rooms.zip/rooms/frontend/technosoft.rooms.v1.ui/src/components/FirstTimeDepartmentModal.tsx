"use client";

import { useEffect, useState } from "react";
import { AlertCircle, Loader2 } from "lucide-react";
import api from "@/lib/api";
import { toast } from "@/lib/toastHelpers";
import type { Department, Reply } from "@/types";
import { useAuthStore } from "@/store/authStore";

interface Props {
  onSelected: () => void;
}

/**
 * Modal obligatorio que se muestra una sola vez por usuario al iniciar
 * sesión sin departamento. NO tiene botón de cerrar ni X — el usuario
 * debe elegir su departamento. Una vez seleccionado, el endpoint del
 * backend rechaza modificaciones posteriores desde este flujo (solo un
 * admin podrá cambiarlo).
 */
export default function FirstTimeDepartmentModal({ onSelected }: Props) {
  const refreshMe = useAuthStore((s) => s.refreshMe);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [selected, setSelected] = useState<number | null>(null);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    let cancelled = false;
    api
      .get<Reply<Department[]>>("/departments")
      .then((res) => {
        if (cancelled) return;
        setDepartments(res.data.obj || []);
      })
      .catch(() => {
        if (!cancelled) setDepartments([]);
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  async function handleConfirm() {
    if (!selected) {
      toast.error("Selecciona un departamento");
      return;
    }
    setSubmitting(true);
    try {
      const res = await api.put<Reply<unknown>>("/auth/me", {
        departmentId: selected,
      });
      if (!res.data.ok) {
        toast.error(res.data.msg || "No fue posible guardar");
        return;
      }
      // El modal se cierra y el dashboard aparece — sin toast.
      await refreshMe();
      onSelected();
    } catch (e: unknown) {
      const errObj = e as { response?: { data?: { msg?: string } } };
      toast.error(
        errObj?.response?.data?.msg || "No fue posible guardar"
      );
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="first-time-dept-title"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4"
    >
      <div className="flex max-h-[90vh] w-full max-w-md flex-col overflow-y-auto rounded-xl bg-white p-6 shadow-2xl">
        <h2 id="first-time-dept-title" className="text-xl font-semibold text-gray-900">
          Selecciona tu departamento
        </h2>
        <p className="mt-2 text-sm text-gray-600">
          Para continuar, elige el departamento al que perteneces.
        </p>
        <p className="mt-2 flex items-start gap-1.5 rounded border border-amber-200 bg-amber-50 px-2.5 py-2 text-xs text-amber-700">
          <AlertCircle className="mt-0.5 h-3.5 w-3.5 shrink-0" />
          <span>
            <strong>Solo podrás hacerlo una vez.</strong> Después tendrás que
            pedirle al administrador que lo cambie.
          </span>
        </p>

        <div className="mt-4 max-h-72 space-y-2 overflow-y-auto pr-1">
          {loading ? (
            <div className="flex items-center justify-center py-8 text-gray-400">
              <Loader2 className="h-5 w-5 animate-spin" />
            </div>
          ) : departments.length === 0 ? (
            <p className="py-6 text-center text-sm text-gray-500">
              No hay departamentos disponibles. Contacta al administrador.
            </p>
          ) : (
            departments.map((d) => (
              <button
                key={d.id}
                type="button"
                onClick={() => setSelected(d.id)}
                disabled={submitting}
                className={
                  "flex w-full items-center gap-3 rounded-lg border p-3 text-left transition " +
                  (selected === d.id
                    ? "border-millenium-blue bg-millenium-blue/5"
                    : "border-gray-200 hover:border-gray-300")
                }
              >
                <span
                  className="h-3 w-3 shrink-0 rounded-full"
                  style={{ backgroundColor: d.colorHex || "#6b7280" }}
                />
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-medium text-gray-900">
                    {d.name}
                  </p>
                  {d.description && (
                    <p className="truncate text-xs text-gray-500">
                      {d.description}
                    </p>
                  )}
                </div>
              </button>
            ))
          )}
        </div>

        <button
          type="button"
          onClick={handleConfirm}
          disabled={!selected || submitting || departments.length === 0}
          className="mt-5 inline-flex w-full items-center justify-center gap-2 rounded-lg bg-millenium-blue px-4 py-2.5 text-sm font-medium text-white transition hover:bg-millenium-blue/90 focus:outline-none focus:ring-2 focus:ring-millenium-blue/40 disabled:cursor-not-allowed disabled:opacity-50"
        >
          {submitting ? (
            <>
              <Loader2 className="h-4 w-4 animate-spin" />
              Guardando...
            </>
          ) : (
            "Confirmar selección"
          )}
        </button>
      </div>
    </div>
  );
}
