"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import Link from "next/link";
import {
  AlertCircle,
  Briefcase,
  Building2,
  ChevronDown,
  ChevronUp,
  Globe,
  MapPin,
  Paperclip,
} from "lucide-react";
import api from "@/lib/api";
import { useBackendPolling } from "@/hooks/useBackendPolling";
import { useNowTick } from "@/hooks/useNowTick";
import { useLocalStorageBoolean } from "@/hooks/useLocalStorageBoolean";
import type { Reply, Reservation } from "@/types";
import { fmtTime, isInProgress, today } from "@/lib/dates";

const startOfToday = (): string => {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  return d.toISOString();
};
const endOfToday = (): string => {
  const d = new Date();
  d.setHours(23, 59, 59, 999);
  return d.toISOString();
};

export default function MyDayPanel() {
  const [meetings, setMeetings] = useState<Reservation[]>([]);
  const [pendingRequests, setPendingRequests] = useState(0);
  const [pendingConfirmations, setPendingConfirmations] = useState(0);
  const [loading, setLoading] = useState(true);
  const now = useNowTick(60_000);

  // G1 — acordeon persistente. Estado compartido entre diaria y semanal
  // porque el componente se monta una sola vez en el dashboard.
  const [collapsed, setCollapsed] = useLocalStorageBoolean(
    "rooms.todayWidget.collapsed",
    false
  );

  const load = useCallback(async (opts: { silent?: boolean } = {}) => {
    if (!opts.silent) setLoading(true);
    try {
      const [mineRes, reqRes, confRes] = await Promise.all([
        api.get<Reply<Reservation[]>>("/reservations/mine"),
        api
          .get<Reply<unknown[]>>("/reservations/my-requests")
          .catch(() => null),
        api
          .get<Reply<unknown[]>>("/reservations/pending-confirmation")
          .catch(() => null),
      ]);
      const all = mineRes.data.obj || [];
      // Filtrar a las del día de HOY.
      const startMs = new Date(startOfToday()).getTime();
      const endMs = new Date(endOfToday()).getTime();
      const todayMeetings = all.filter((m) => {
        const s = new Date(m.startsAt).getTime();
        return m.status === "active" && s >= startMs && s <= endMs;
      });
      setMeetings(todayMeetings);
      setPendingRequests(reqRes?.data.obj?.length || 0);
      setPendingConfirmations(confRes?.data.obj?.length || 0);
    } catch {
      // silencioso
    } finally {
      if (!opts.silent) setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Polling 60s; refresca silenciosamente.
  useBackendPolling(
    () => load({ silent: true }),
    60_000,
    [],
    { silentOnError: true }
  );

  // G1 — pendientes: activas, no terminadas antes, fin > now.
  // `now` se recalcula cada minuto, asi reuniones que terminan se ocultan
  // automaticamente sin recargar.
  const pendingMeetings = useMemo(() => {
    const nowMs = now.getTime();
    return meetings
      .filter((m) => {
        if (m.status === "cancelled") return false;
        if (m.endedEarly === true) return false;
        const endsMs = new Date(m.endsAt).getTime();
        return endsMs > nowMs;
      })
      .sort(
        (a, b) =>
          new Date(a.startsAt).getTime() - new Date(b.startsAt).getTime()
      );
  }, [meetings, now]);

  const hasAlerts = pendingRequests > 0 || pendingConfirmations > 0;
  const todayYmd = today();
  const pendingCount = pendingMeetings.length;

  return (
    <div className="mb-4 flex flex-col rounded-lg border border-gray-200 bg-white">
      <div className="flex items-center justify-between gap-2 px-4 pt-3 md:px-5">
        <button
          type="button"
          onClick={() => setCollapsed(!collapsed)}
          className="-mx-2 flex flex-1 items-center gap-2 rounded px-2 py-1 text-left transition hover:bg-gray-50"
          aria-expanded={!collapsed}
          aria-controls="today-widget-content"
        >
          <h2 className="text-base font-semibold text-gray-900">
            Mi día de hoy
          </h2>
          {pendingCount > 0 && (
            <span className="inline-flex items-center justify-center rounded-full bg-millenium-blue/10 px-2 py-0.5 text-xs font-medium text-millenium-blue">
              {pendingCount}
            </span>
          )}
          {collapsed ? (
            <ChevronDown className="ml-auto h-4 w-4 text-gray-400" />
          ) : (
            <ChevronUp className="ml-auto h-4 w-4 text-gray-400" />
          )}
        </button>
        <Link
          href={`/dashboard/reservations`}
          className="shrink-0 text-xs font-medium text-millenium-blue transition hover:underline"
        >
          Ver todas →
        </Link>
      </div>

      {!collapsed && (
        <div
          id="today-widget-content"
          className="flex flex-1 flex-col px-4 pb-4 pt-3 md:px-5 md:pb-5"
        >
          {hasAlerts && (
            <div className="mb-3 flex flex-wrap items-center gap-2 rounded-lg border border-amber-200 bg-amber-50 px-3 py-2 text-xs text-amber-900">
              <AlertCircle className="h-3.5 w-3.5 shrink-0 text-amber-600" />
              {pendingRequests > 0 && (
                <Link
                  href="/dashboard/my-requests"
                  className="hover:underline"
                >
                  {pendingRequests}{" "}
                  {pendingRequests === 1
                    ? "solicitud pendiente"
                    : "solicitudes pendientes"}
                </Link>
              )}
              {pendingRequests > 0 && pendingConfirmations > 0 && (
                <span className="text-amber-400">·</span>
              )}
              {pendingConfirmations > 0 && (
                <Link
                  href="/dashboard/pending-confirmation"
                  className="hover:underline"
                >
                  {pendingConfirmations}{" "}
                  {pendingConfirmations === 1
                    ? "confirmación pendiente"
                    : "confirmaciones pendientes"}
                </Link>
              )}
            </div>
          )}

          <div className="flex-1">
            {loading ? (
              <div className="space-y-2">
                {[1, 2, 3].map((i) => (
                  <div
                    key={i}
                    className="h-12 animate-pulse rounded bg-gray-100"
                  />
                ))}
              </div>
            ) : pendingMeetings.length === 0 ? (
              <p className="py-6 text-center text-sm text-gray-400">
                Sin reuniones pendientes hoy
              </p>
            ) : (
              <ul className="space-y-1.5">
                {pendingMeetings.map((m) => {
                  const TypeIcon =
                    m.type === "physical"
                      ? Building2
                      : m.type === "office"
                        ? Briefcase
                        : m.type === "virtual"
                          ? Globe
                          : MapPin;
                  const locationLabel =
                    m.type === "office"
                      ? m.officeName || "Oficina"
                      : m.type === "physical"
                        ? m.roomName ?? ""
                        : "";
                  const inProgress = isInProgress(m.startsAt, m.endsAt, now);
                  return (
                    <li
                      key={m.id}
                      className={
                        "flex items-center gap-3 rounded p-2 transition " +
                        (inProgress
                          ? "border border-blue-200 bg-blue-50"
                          : "hover:bg-gray-50")
                      }
                    >
                      <span
                        className={
                          "flex h-7 w-7 shrink-0 items-center justify-center rounded " +
                          (m.type === "physical"
                            ? "bg-blue-50 text-millenium-blue"
                            : m.type === "office"
                              ? "bg-orange-50 text-orange-600"
                              : m.type === "virtual"
                                ? "bg-purple-50 text-purple-600"
                                : "bg-green-50 text-green-600")
                        }
                      >
                        <TypeIcon className="h-3.5 w-3.5" />
                      </span>
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm font-medium text-gray-900">
                          {m.title}
                          {inProgress && (
                            <span className="ml-2 inline-flex items-center gap-1 text-xs font-normal text-millenium-red">
                              <span className="relative inline-flex h-1.5 w-1.5">
                                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-millenium-red opacity-75" />
                                <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-millenium-red" />
                              </span>
                              En curso
                            </span>
                          )}
                        </p>
                        <p className="truncate text-xs text-gray-500">
                          {fmtTime(m.startsAt)} - {fmtTime(m.endsAt)}
                          {locationLabel ? ` · ${locationLabel}` : ""}
                        </p>
                      </div>
                      {!!m.attachmentsCount && m.attachmentsCount > 0 && (
                        <Paperclip
                          className="h-3 w-3 shrink-0 text-gray-400"
                          aria-label={`${m.attachmentsCount} adjuntos`}
                        />
                      )}
                    </li>
                  );
                })}
              </ul>
            )}
          </div>

          <p className="mt-3 text-right text-xs text-gray-500">
            Hoy {todayYmd}
          </p>
        </div>
      )}
    </div>
  );
}
