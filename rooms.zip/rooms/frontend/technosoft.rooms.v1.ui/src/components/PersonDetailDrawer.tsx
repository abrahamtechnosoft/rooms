"use client";

import { useEffect, useState } from "react";
import { Building2, Clock, Video, X } from "lucide-react";
import api from "@/lib/api";
import Avatar from "@/components/Avatar";
import type { PersonDetail, PersonMeeting, Reply } from "@/types";
import { personDetailStatusUi } from "@/lib/personStatus";

interface Props {
  personId: number | null;
  onClose: () => void;
}

const PAD = (n: number) => String(n).padStart(2, "0");

function fmtHora(iso: string): string {
  const d = new Date(iso);
  return `${PAD(d.getHours())}:${PAD(d.getMinutes())}`;
}

function fmtMeetingWhen(iso: string): string {
  const d = new Date(iso);
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const tomorrow = new Date(today);
  tomorrow.setDate(today.getDate() + 1);

  const startOfDay = new Date(d);
  startOfDay.setHours(0, 0, 0, 0);

  if (startOfDay.getTime() === today.getTime()) return "Hoy";
  if (startOfDay.getTime() === tomorrow.getTime()) return "Mañana";
  return d.toLocaleDateString("es", {
    day: "numeric",
    month: "short",
    weekday: "short",
  });
}

function MeetingCard({ meeting }: { meeting: PersonMeeting }) {
  const isVirtual = meeting.type === "virtual" || !!meeting.roomIsVirtual;
  const isExternal = meeting.type === "external";
  return (
    <li className="rounded-lg border border-gray-200 bg-white p-3">
      <p className="truncate text-sm font-medium text-gray-900">
        {meeting.title}
      </p>
      <p className="mt-0.5 text-xs tabular-nums text-gray-600">
        {fmtMeetingWhen(meeting.startsAt)}
        {" · "}
        {fmtHora(meeting.startsAt)} - {fmtHora(meeting.endsAt)}
      </p>
      <p className="mt-1 flex items-center gap-1.5 text-xs text-gray-500">
        {isVirtual ? (
          <>
            <Video className="h-3.5 w-3.5" />
            Reunión virtual
          </>
        ) : isExternal ? (
          <>
            <Building2 className="h-3.5 w-3.5" />
            {meeting.roomName}
          </>
        ) : (
          <>
            <Building2 className="h-3.5 w-3.5" />
            {meeting.roomName}
          </>
        )}
      </p>
    </li>
  );
}


export default function PersonDetailDrawer({ personId, onClose }: Props) {
  const [data, setData] = useState<PersonDetail | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!personId) {
      setData(null);
      return;
    }
    let cancelled = false;
    setLoading(true);
    api
      .get<Reply<PersonDetail>>(`/people/${personId}`)
      .then((res) => {
        if (!cancelled) setData(res.data.obj || null);
      })
      .catch(() => {
        if (!cancelled) setData(null);
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [personId]);

  useEffect(() => {
    if (personId == null) return;
    const handler = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    document.addEventListener("keydown", handler);
    return () => document.removeEventListener("keydown", handler);
  }, [personId, onClose]);

  if (personId == null) return null;

  const current = data?.meetings.find((m) => m.state === "in_progress");
  const upcoming = (data?.meetings || []).filter(
    (m) => m.state === "upcoming"
  );
  const ui = personDetailStatusUi(data || null);

  return (
    <div
      className="animate-fadeIn fixed inset-0 z-50 bg-black/40 backdrop-blur-sm"
      onClick={onClose}
    >
      <aside
        className="animate-slideInRight ml-auto flex h-full w-full max-w-md flex-col overflow-y-auto bg-white shadow-2xl sm:w-105"
        onClick={(e) => e.stopPropagation()}
        role="dialog"
        aria-modal="true"
        aria-label="Detalle del colaborador"
      >
        <div className="sticky top-0 z-10 flex justify-end border-b border-gray-100 bg-white p-3">
          <button
            type="button"
            onClick={onClose}
            className="rounded-md p-2 text-gray-500 hover:bg-gray-100 hover:text-gray-700 focus:outline-none focus:ring-2 focus:ring-millenium-blue/40 focus:ring-offset-1"
            aria-label="Cerrar"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {loading && !data ? (
          <div className="flex flex-1 items-center justify-center text-base text-gray-500">
            Cargando...
          </div>
        ) : !data ? (
          <div className="flex flex-1 items-center justify-center px-6 text-center text-base text-gray-500">
            No fue posible cargar el detalle del colaborador.
          </div>
        ) : (
          <div className="flex flex-col gap-5 px-6 pb-8 pt-2">
            {/* Header centrado: avatar XL + nombre + email + estado */}
            <div className="flex flex-col items-center gap-3 text-center">
              <Avatar
                name={data.fullName}
                email={data.email}
                avatarUrl={data.avatarUrl}
                size="xl"
                className="h-20 w-20"
              />
              <div>
                <h2 className="text-xl font-bold text-gray-900">
                  {data.fullName || data.email}
                </h2>
                {data.fullName && (
                  <p className="text-sm text-gray-500">{data.email}</p>
                )}
                <p className="text-xs text-gray-400 mt-0.5">
                  {data.role === "admin" ? "Administrador" : "Empleado"}
                </p>

                {/* G4 — Chip prominente del departamento debajo del rol. */}
                {data.departmentName && (
                  <div
                    className="mt-2 inline-flex items-center gap-2 rounded-full px-3 py-1.5"
                    style={{
                      backgroundColor: `${data.departmentColor || "#475569"}15`,
                      color: data.departmentColor || "#475569",
                    }}
                  >
                    <span
                      className="inline-block h-2 w-2 rounded-full"
                      style={{
                        backgroundColor: data.departmentColor || "#475569",
                      }}
                    />
                    <span className="text-sm font-medium">
                      {data.departmentName}
                    </span>
                  </div>
                )}

                <span
                  className={`mt-2 inline-flex items-center gap-1.5 text-sm font-medium ${ui.textColor}`}
                >
                  <span
                    className={`h-2 w-2 rounded-full ${ui.dotCls}`}
                    aria-hidden="true"
                  />
                  {ui.label}
                </span>
              </div>
            </div>

            {/* En reunión ahora */}
            {current && (
              <div className="rounded-lg border border-red-100 bg-red-50 p-3">
                <p className="text-xs font-medium uppercase tracking-wide text-red-700">
                  En reunión ahora
                </p>
                <p className="mt-1 text-sm font-medium text-gray-900">
                  {current.title}
                </p>
                <p className="mt-0.5 text-xs tabular-nums text-gray-600">
                  {fmtHora(current.startsAt)} - {fmtHora(current.endsAt)}
                  {" · "}
                  {current.roomName}
                </p>
              </div>
            )}

            {/* Próximas */}
            <div>
              <p className="label flex items-center gap-2">
                <Clock className="h-4 w-4" />
                Próximas reuniones
              </p>
              {upcoming.length === 0 ? (
                <p className="text-sm text-gray-500">
                  Sin reuniones próximas en los siguientes 7 días.
                </p>
              ) : (
                <ul className="flex flex-col gap-2">
                  {upcoming.map((m) => (
                    <MeetingCard key={m.id} meeting={m} />
                  ))}
                </ul>
              )}
            </div>
          </div>
        )}
      </aside>
    </div>
  );
}
