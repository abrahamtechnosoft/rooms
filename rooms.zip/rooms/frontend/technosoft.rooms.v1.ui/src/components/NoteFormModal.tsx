"use client";

import { useEffect, useState } from "react";
import { Loader2, X } from "lucide-react";
import api from "@/lib/api";
import { toast } from "@/lib/toastHelpers";
import { emitWidgetEvent } from "@/lib/widgetEvents";
import type { NoteVisibility, Reply, UserNote } from "@/types";

const COLORS = ["#FEF3C7", "#FED7AA", "#FBCFE8", "#DBEAFE", "#D1FAE5"];
const COLOR_NAMES: Record<string, string> = {
  "#FEF3C7": "Amarillo",
  "#FED7AA": "Naranja",
  "#FBCFE8": "Rosa",
  "#DBEAFE": "Azul",
  "#D1FAE5": "Verde",
};
const MAX_TITLE = 120;
const MAX_CONTENT = 2000;

interface Props {
  note: UserNote | null;
  defaultVisibility: NoteVisibility;
  canCreateDept: boolean;
  onSaved: () => void;
  onCancel: () => void;
}

export default function NoteFormModal({
  note,
  defaultVisibility,
  canCreateDept,
  onSaved,
  onCancel,
}: Props) {
  const isEdit = note !== null;
  const [visibility, setVisibility] = useState<NoteVisibility>(
    isEdit ? note.visibility : defaultVisibility
  );
  const [title, setTitle] = useState(note?.title ?? "");
  const [content, setContent] = useState(note?.content ?? "");
  const [colorHex, setColorHex] = useState(note?.colorHex ?? COLORS[0]);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if (e.key === "Escape" && !saving) onCancel();
    }
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [saving, onCancel]);

  async function handleSave() {
    if (!content.trim()) {
      toast.error("El contenido es requerido");
      return;
    }
    setSaving(true);
    try {
      if (isEdit && note) {
        await api.put<Reply<{ noteId: number }>>(`/notes/${note.noteId}`, {
          title: title.trim() || null,
          content: content.trim(),
          colorHex,
          isDone: note.isDone,
        });
        toast.success("Nota actualizada");
      } else {
        await api.post<Reply<{ noteId: number }>>("/notes", {
          visibility,
          title: title.trim() || null,
          content: content.trim(),
          colorHex,
        });
        toast.success("Nota creada");
      }
      emitWidgetEvent("notes:changed");
      onSaved();
    } catch (e: unknown) {
      const errObj = e as { response?: { data?: { msg?: string } } };
      toast.error(
        errObj?.response?.data?.msg || "No fue posible guardar la nota"
      );
    } finally {
      setSaving(false);
    }
  }

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="note-modal-title"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4"
      onClick={saving ? undefined : onCancel}
    >
      <div
        className="flex max-h-[90vh] w-full max-w-md flex-col rounded-lg bg-white shadow-xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex shrink-0 items-center justify-between border-b border-gray-200 px-4 py-3">
          <h3
            id="note-modal-title"
            className="text-base font-semibold text-gray-900"
          >
            {isEdit ? "Editar nota" : "Nueva nota"}
          </h3>
          <button
            type="button"
            onClick={onCancel}
            disabled={saving}
            className="rounded p-1 text-gray-400 transition hover:bg-gray-100 hover:text-gray-700 disabled:opacity-50"
            aria-label="Cerrar"
          >
            <X className="h-5 w-5" aria-hidden="true" />
          </button>
        </div>

        <div className="flex-1 space-y-3 overflow-y-auto p-4">
          {!isEdit && (
            <div>
              <label className="mb-1 block text-xs font-medium text-gray-600">
                Visibilidad
              </label>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setVisibility("personal")}
                  className={
                    "flex-1 rounded-md border px-3 py-2 text-sm font-medium transition-colors " +
                    (visibility === "personal"
                      ? "border-millenium-blue bg-millenium-blue/10 text-millenium-blue"
                      : "border-gray-300 text-gray-700 hover:bg-gray-50")
                  }
                >
                  Personal
                </button>
                <button
                  type="button"
                  onClick={() => setVisibility("department")}
                  disabled={!canCreateDept}
                  title={
                    !canCreateDept ? "Sin departamento asignado" : undefined
                  }
                  className={
                    "flex-1 rounded-md border px-3 py-2 text-sm font-medium transition-colors disabled:cursor-not-allowed disabled:opacity-50 " +
                    (visibility === "department"
                      ? "border-millenium-blue bg-millenium-blue/10 text-millenium-blue"
                      : "border-gray-300 text-gray-700 hover:bg-gray-50")
                  }
                >
                  Departamento
                </button>
              </div>
            </div>
          )}

          <div>
            <label
              htmlFor="note-title"
              className="mb-1 block text-xs font-medium text-gray-600"
            >
              Título (opcional)
            </label>
            <input
              id="note-title"
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              maxLength={MAX_TITLE}
              className="w-full rounded-md border border-gray-300 px-3 py-2 text-sm focus:border-millenium-blue focus:outline-none focus:ring-2 focus:ring-millenium-blue/20"
              placeholder="Título corto"
            />
          </div>

          <div>
            <label
              htmlFor="note-content"
              className="mb-1 block text-xs font-medium text-gray-600"
            >
              Contenido
            </label>
            <textarea
              id="note-content"
              value={content}
              onChange={(e) => setContent(e.target.value)}
              maxLength={MAX_CONTENT}
              rows={5}
              className="w-full resize-none rounded-md border border-gray-300 px-3 py-2 text-sm focus:border-millenium-blue focus:outline-none focus:ring-2 focus:ring-millenium-blue/20"
              placeholder="Escribe la nota..."
            />
            <div className="mt-1 text-right text-[11px] text-gray-400 tabular-nums">
              {content.length} / {MAX_CONTENT}
            </div>
          </div>

          <div>
            <label className="mb-1 block text-xs font-medium text-gray-600">
              Color
            </label>
            <div className="flex gap-2">
              {COLORS.map((c) => {
                const active = colorHex === c;
                return (
                  <button
                    key={c}
                    type="button"
                    onClick={() => setColorHex(c)}
                    aria-label={COLOR_NAMES[c] || c}
                    aria-pressed={active}
                    className={
                      "h-8 w-8 rounded-full border-2 transition " +
                      (active
                        ? "border-millenium-blue ring-2 ring-millenium-blue/30"
                        : "border-gray-200 hover:border-gray-300")
                    }
                    style={{ backgroundColor: c }}
                  />
                );
              })}
            </div>
          </div>
        </div>

        <div className="flex shrink-0 justify-end gap-2 border-t border-gray-200 bg-gray-50 px-4 py-3">
          <button
            type="button"
            onClick={onCancel}
            disabled={saving}
            className="rounded-md border border-gray-300 px-3 py-1.5 text-sm font-medium text-gray-700 transition hover:bg-gray-50 disabled:opacity-50"
          >
            Cancelar
          </button>
          <button
            type="button"
            onClick={handleSave}
            disabled={saving || !content.trim()}
            className="inline-flex items-center gap-1.5 rounded-md bg-millenium-blue px-3 py-1.5 text-sm font-medium text-white transition hover:opacity-90 disabled:opacity-50"
          >
            {saving && <Loader2 className="h-3.5 w-3.5 animate-spin" />}
            {saving ? "Guardando..." : "Guardar"}
          </button>
        </div>
      </div>
    </div>
  );
}
