"use client";

import { useEffect, useRef, useState } from "react";
import { SlidersHorizontal, X } from "lucide-react";
import type { Department } from "@/types";

interface Props {
  departments: Department[];
  selectedIds: number[];
  onChange: (ids: number[]) => void;
}

export default function MoreFiltersButton({
  departments,
  selectedIds,
  onChange,
}: Props) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, [open]);

  const toggle = (id: number) => {
    onChange(
      selectedIds.includes(id)
        ? selectedIds.filter((d) => d !== id)
        : [...selectedIds, id]
    );
  };

  const activeDepartments = departments.filter((d) => d.isActive);
  const count = selectedIds.length;

  return (
    <div className="relative" ref={ref}>
      <button
        type="button"
        onClick={() => setOpen(!open)}
        aria-expanded={open}
        className={
          "inline-flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-xs font-medium transition-colors " +
          (count > 0
            ? "border-millenium-blue bg-millenium-blue/10 text-millenium-blue"
            : "border-gray-300 bg-white text-gray-700 hover:bg-gray-50")
        }
      >
        <SlidersHorizontal className="h-3.5 w-3.5" />
        Más filtros
        {count > 0 && (
          <span className="rounded-full bg-millenium-blue px-1.5 py-0.5 text-[10px] text-white">
            {count}
          </span>
        )}
      </button>

      {open && (
        <div
          role="dialog"
          aria-label="Más filtros"
          className="absolute right-0 top-full z-50 mt-2 w-72 overflow-hidden rounded-lg border border-gray-200 bg-white shadow-lg"
        >
          <div className="flex items-center justify-between border-b border-gray-100 px-4 py-3">
            <h3 className="text-sm font-semibold text-gray-900">
              Departamento
            </h3>
            <button
              type="button"
              onClick={() => setOpen(false)}
              className="text-gray-400 hover:text-gray-600"
              aria-label="Cerrar"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
          <div className="max-h-64 space-y-1.5 overflow-y-auto px-4 py-3">
            {activeDepartments.length === 0 ? (
              <div className="text-xs text-gray-400">
                Sin departamentos cargados
              </div>
            ) : (
              activeDepartments.map((d) => (
                <label
                  key={d.id}
                  className="flex cursor-pointer items-center gap-2 text-sm text-gray-700 hover:text-gray-900"
                >
                  <input
                    type="checkbox"
                    checked={selectedIds.includes(d.id)}
                    onChange={() => toggle(d.id)}
                    className="h-4 w-4 rounded border-gray-300 text-millenium-blue focus:ring-millenium-blue"
                  />
                  <span>{d.name}</span>
                </label>
              ))
            )}
          </div>
          {count > 0 && (
            <div className="border-t border-gray-100 px-4 py-2">
              <button
                type="button"
                onClick={() => onChange([])}
                className="text-xs font-medium text-millenium-blue hover:underline"
              >
                Limpiar
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
