"use client";

import { useState } from "react";
import { Zap } from "lucide-react";
import { toast } from "@/lib/toastHelpers";
import api from "@/lib/api";
import type { Reply, Room, UserPickerItem } from "@/types";
import type { RoomAvailability } from "@/hooks/useRoomAvailability";
import Modal from "@/components/ui/Modal";
import Input from "@/components/ui/Input";
import Button from "@/components/ui/Button";
import ParticipantPicker from "@/components/ParticipantPicker";

interface Props {
  room: Room;
  availability: RoomAvailability;
  onReserved: () => void;
}

const PRESETS = [30, 45, 60];
const MAX_TITLE = 60;
const MAX_CUSTOM = 240;
const MIN_CUSTOM = 30;

export default function QuickReserveButton({
  room,
  availability,
  onReserved,
}: Props) {
  const [open, setOpen] = useState(false);
  const [title, setTitle] = useState("");
  const [duration, setDuration] = useState<number>(30);
  const [customDuration, setCustomDuration] = useState<number>(45);
  const [isCustom, setIsCustom] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [participants, setParticipants] = useState<UserPickerItem[]>([]);

  if (!availability.isFreeNow) return null;

  // Máximo disponible: si hay próxima reunión, está limitado por el gap; si
  // no, queda hasta 240 min (4h) o el cierre de oficina (calculado por backend).
  const maxAvailable = availability.minutesUntilNext ?? MAX_CUSTOM;
  // Si no quedan ni 30 min libres no tiene sentido ofrecer reserva rápida.
  if (maxAvailable < MIN_CUSTOM) return null;
  const presets = PRESETS.filter((d) => d <= maxAvailable);

  async function handleSubmit() {
    if (!title.trim()) {
      toast.error("Pon un título a la reunión");
      return;
    }
    const finalDuration = isCustom ? customDuration : duration;
    if (finalDuration < MIN_CUSTOM || finalDuration > MAX_CUSTOM) {
      toast.error(`La reunión debe durar al menos ${MIN_CUSTOM} minutos`);
      return;
    }
    setSubmitting(true);
    try {
      const res = await api.post<
        Reply<{ reservationId: number; participantsNotified?: number }>
      >("/reservations/quick", {
        roomId: room.id,
        title: title.trim(),
        durationMinutes: finalDuration,
        participantIds: participants.map((p) => p.id),
      });
      if (res.data.ok) {
        const notified = res.data.obj?.participantsNotified ?? 0;
        const successMsg =
          notified > 0
            ? `Reunión iniciada. ${notified} ${
                notified === 1
                  ? "colaborador notificado"
                  : "colaboradores notificados"
              } por correo.`
            : res.data.msg || "Reunión iniciada";
        toast.success(successMsg);
        setOpen(false);
        setTitle("");
        setDuration(30);
        setIsCustom(false);
        setParticipants([]);
        onReserved();
      } else {
        toast.error(res.data.msg || "No fue posible iniciar la reunión");
      }
    } catch (e: unknown) {
      const errObj = e as { response?: { data?: { msg?: string } } };
      toast.error(
        errObj?.response?.data?.msg || "No fue posible iniciar la reunión"
      );
    } finally {
      setSubmitting(false);
    }
  }

  const headerDescription =
    typeof availability.minutesUntilNext === "number"
      ? `${room.name} · Disponible por ${availability.minutesUntilNext} min`
      : `${room.name} · Libre ahora`;

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen(true)}
        className="inline-flex items-center gap-1.5 text-xs font-medium text-millenium-blue transition hover:underline"
      >
        <Zap className="h-3.5 w-3.5" />
        Reservar ahora
      </button>

      <Modal
        open={open}
        onClose={() => {
          if (!submitting) {
            setOpen(false);
            setTitle("");
            setIsCustom(false);
            setParticipants([]);
          }
        }}
        title="Reservar ahora"
        description={headerDescription}
        actions={
          <>
            <Button
              variant="outline"
              onClick={() => setOpen(false)}
              disabled={submitting}
            >
              Cancelar
            </Button>
            <Button
              variant="primary"
              onClick={handleSubmit}
              loading={submitting}
              disabled={submitting || !title.trim()}
            >
              <Zap className="h-4 w-4" />
              Iniciar reunión
            </Button>
          </>
        }
      >
        <div className="space-y-4">
          <div>
            <Input
              label="Título"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Ej.: Reunión rápida con Karen"
              maxLength={MAX_TITLE}
              required
              autoFocus
            />
            <p className="mt-1 text-right text-xs text-gray-500 tabular-nums">
              {title.length}/{MAX_TITLE}
            </p>
          </div>

          <div>
            <label className="label">Duración</label>
            <div className="flex flex-wrap gap-2">
              {presets.map((p) => {
                const active = !isCustom && duration === p;
                return (
                  <button
                    key={p}
                    type="button"
                    onClick={() => {
                      setDuration(p);
                      setIsCustom(false);
                    }}
                    aria-pressed={active}
                    className={
                      "rounded-full px-3 py-1.5 text-sm font-medium transition " +
                      (active
                        ? "bg-millenium-blue text-white"
                        : "border border-gray-200 bg-white text-gray-700 hover:border-gray-300")
                    }
                  >
                    {p < 60 ? `${p} min` : "1 hora"}
                  </button>
                );
              })}
              <button
                type="button"
                onClick={() => setIsCustom(true)}
                aria-pressed={isCustom}
                className={
                  "rounded-full px-3 py-1.5 text-sm font-medium transition " +
                  (isCustom
                    ? "bg-millenium-blue text-white"
                    : "border border-gray-200 bg-white text-gray-700 hover:border-gray-300")
                }
              >
                Personalizar
              </button>
            </div>

            {isCustom && (
              <div className="mt-3 flex items-center gap-2">
                <input
                  type="number"
                  inputMode="numeric"
                  min={MIN_CUSTOM}
                  max={maxAvailable}
                  step={5}
                  value={customDuration}
                  onChange={(e) =>
                    setCustomDuration(
                      parseInt(e.target.value) || MIN_CUSTOM
                    )
                  }
                  aria-label="Duración personalizada en minutos"
                  className="w-24 rounded border border-gray-300 px-2 py-1 text-sm focus:border-millenium-blue focus:outline-none focus:ring-2 focus:ring-millenium-blue/20"
                />
                <span className="text-sm text-gray-600">minutos</span>
                <span className="text-xs text-gray-400">
                  ({MIN_CUSTOM}-{maxAvailable})
                </span>
              </div>
            )}
          </div>

          <div>
            <label className="label">Colaboradores (opcional)</label>
            <ParticipantPicker
              value={participants}
              onChange={setParticipants}
            />
          </div>

          <p className="text-xs text-gray-500">
            La reunión empieza ahora. Los colaboradores reciben un correo con
            la información.
          </p>
        </div>
      </Modal>
    </>
  );
}
