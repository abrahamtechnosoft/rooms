"use client";

import { useEffect, useMemo, useState } from "react";
import { Calendar, Repeat } from "lucide-react";
import type { RecurringPattern } from "@/types";

export interface RecurringConfigValue {
  pattern: RecurringPattern;
  daysOfWeek: string | null;
  frequencyWeeks: number | null;
  dayOfMonth: number | null;
  seriesEndDate: string;
}

interface Props {
  initialDate: Date;
  value?: RecurringConfigValue;
  onChange: (value: RecurringConfigValue) => void;
}

const DAYS: { v: string; l: string; name: string }[] = [
  { v: "1", l: "L", name: "Lunes" },
  { v: "2", l: "M", name: "Martes" },
  { v: "3", l: "X", name: "Miércoles" },
  { v: "4", l: "J", name: "Jueves" },
  { v: "5", l: "V", name: "Viernes" },
  { v: "6", l: "S", name: "Sábado" },
  { v: "7", l: "D", name: "Domingo" },
];

const FREQUENCIES: { v: number; label: string }[] = [
  { v: 1, label: "Semanal" },
  { v: 2, label: "Cada 2 semanas" },
  { v: 3, label: "Cada 3 semanas" },
];

const VALID_FREQUENCIES = new Set([1, 2, 3]);

const LABEL_CLASS = "mb-1 block text-xs font-medium text-gray-700";

function toYmd(d: Date): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

export default function RecurringConfig({
  initialDate,
  value,
  onChange,
}: Props) {
  const [pattern, setPattern] = useState<RecurringPattern>(
    value?.pattern || "weekly"
  );
  const [frequencyWeeks, setFrequencyWeeks] = useState<number>(
    value?.frequencyWeeks || 1
  );
  // Default L-V preseleccionados.
  const [selectedDays, setSelectedDays] = useState<Set<string>>(() => {
    if (value?.daysOfWeek) {
      return new Set(value.daysOfWeek.split(",").filter(Boolean));
    }
    return new Set(["1", "2", "3", "4", "5"]);
  });
  const [dayOfMonth, setDayOfMonth] = useState<number>(
    value?.dayOfMonth ?? initialDate.getDate()
  );
  const [endDate, setEndDate] = useState<string>(() => {
    if (value?.seriesEndDate) return value.seriesEndDate;
    const d = new Date(initialDate);
    d.setMonth(d.getMonth() + 1);
    return toYmd(d);
  });

  const minEndDate = useMemo(() => toYmd(initialDate), [initialDate]);
  const maxEndDate = useMemo(() => {
    const max = new Date(initialDate);
    max.setFullYear(max.getFullYear() + 1);
    return toYmd(max);
  }, [initialDate]);

  // Propagar al padre cada vez que cambia el estado interno.
  useEffect(() => {
    const sortedDays = Array.from(selectedDays).sort();
    onChange({
      pattern,
      daysOfWeek:
        pattern === "weekly" && sortedDays.length > 0
          ? sortedDays.join(",")
          : null,
      frequencyWeeks: pattern === "weekly" ? frequencyWeeks : null,
      dayOfMonth: pattern === "monthly" ? dayOfMonth : null,
      seriesEndDate: endDate,
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pattern, frequencyWeeks, selectedDays, dayOfMonth, endDate]);

  function toggleDay(d: string) {
    setSelectedDays((prev) => {
      const next = new Set(prev);
      if (next.has(d)) next.delete(d);
      else next.add(d);
      return next;
    });
  }

  function selectWeekdays() {
    setSelectedDays(new Set(["1", "2", "3", "4", "5"]));
  }
  function selectAllDays() {
    setSelectedDays(new Set(["1", "2", "3", "4", "5", "6", "7"]));
  }
  function selectWeekends() {
    setSelectedDays(new Set(["6", "7"]));
  }

  function selectWeeklyFreq(v: number) {
    setPattern("weekly");
    setFrequencyWeeks(v);
  }

  const sortedDays = useMemo(
    () => Array.from(selectedDays).sort(),
    [selectedDays]
  );
  const hasDaysSelected = sortedDays.length > 0;

  const legacyFrequency =
    pattern === "weekly" && !VALID_FREQUENCIES.has(frequencyWeeks);

  return (
    <div className="space-y-4 rounded-lg border border-blue-200 bg-blue-50 p-4">
      <div className="flex items-center gap-2 text-sm font-semibold text-millenium-blue">
        <Repeat className="h-4 w-4" />
        Configuración de recurrencia
      </div>

      {legacyFrequency && (
        <div className="rounded-md border border-amber-200 bg-amber-50 p-3 text-xs text-amber-800">
          La frecuencia anterior ya no esta disponible. Selecciona una nueva
          para poder guardar los cambios.
        </div>
      )}

      {/* Frecuencia */}
      <div>
        <label className={LABEL_CLASS}>Frecuencia</label>
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 md:grid-cols-5">
          {FREQUENCIES.map((f) => {
            const active = pattern === "weekly" && frequencyWeeks === f.v;
            return (
              <button
                key={f.v}
                type="button"
                onClick={() => selectWeeklyFreq(f.v)}
                aria-pressed={active}
                className={
                  "rounded-md px-2 py-2 text-xs transition focus:outline-none focus:ring-2 focus:ring-millenium-blue/40 " +
                  (active
                    ? "bg-millenium-blue font-medium text-white"
                    : "border border-gray-200 bg-white text-gray-700 hover:bg-gray-50")
                }
              >
                {f.label}
              </button>
            );
          })}
          <button
            type="button"
            onClick={() => setPattern("monthly")}
            aria-pressed={pattern === "monthly"}
            className={
              "rounded-md px-2 py-2 text-xs transition focus:outline-none focus:ring-2 focus:ring-millenium-blue/40 " +
              (pattern === "monthly"
                ? "bg-millenium-blue font-medium text-white"
                : "border border-gray-200 bg-white text-gray-700 hover:bg-gray-50")
            }
          >
            Mensual
          </button>
        </div>
      </div>

      {/* Días (solo weekly) */}
      {pattern === "weekly" && (
        <div>
          <div className="mb-2 flex items-center justify-between">
            <label className={LABEL_CLASS + " mb-0"}>Días</label>
            <div className="flex gap-2 text-xs">
              <button
                type="button"
                onClick={selectWeekdays}
                className="text-millenium-blue hover:underline"
              >
                L-V
              </button>
              <span className="text-gray-500" aria-hidden="true">·</span>
              <button
                type="button"
                onClick={selectAllDays}
                className="text-millenium-blue hover:underline"
              >
                Todos
              </button>
              <span className="text-gray-500" aria-hidden="true">·</span>
              <button
                type="button"
                onClick={selectWeekends}
                className="text-millenium-blue hover:underline"
              >
                Findes
              </button>
            </div>
          </div>
          <div className="grid grid-cols-7 gap-1.5">
            {DAYS.map((d) => {
              const active = selectedDays.has(d.v);
              return (
                <button
                  key={d.v}
                  type="button"
                  onClick={() => toggleDay(d.v)}
                  title={d.name}
                  aria-pressed={active}
                  aria-label={d.name}
                  className={
                    "rounded-full p-2.5 text-sm font-medium transition focus:outline-none focus:ring-2 focus:ring-millenium-blue/40 " +
                    (active
                      ? "bg-millenium-blue text-white shadow-sm"
                      : "border border-gray-200 bg-white text-gray-500 hover:bg-gray-50")
                  }
                >
                  {d.l}
                </button>
              );
            })}
          </div>
          {!hasDaysSelected && (
            <p className="mt-1.5 text-xs text-amber-700">
              Selecciona al menos un día.
            </p>
          )}
        </div>
      )}

      {/* Día del mes (solo monthly) */}
      {pattern === "monthly" && (
        <div>
          <label htmlFor="recurring-day-of-month" className={LABEL_CLASS}>
            Día del mes
          </label>
          <input
            id="recurring-day-of-month"
            type="number"
            inputMode="numeric"
            min={1}
            max={31}
            value={dayOfMonth}
            onChange={(e) =>
              setDayOfMonth(
                Math.max(1, Math.min(31, parseInt(e.target.value, 10) || 1))
              )
            }
            className="w-20 rounded border border-gray-300 px-2 py-1.5 text-sm focus:border-millenium-blue focus:outline-none focus:ring-2 focus:ring-millenium-blue/20 sm:w-24"
            aria-label="Día del mes"
          />
          <p className="mt-1 text-xs text-gray-500">
            Si el mes no tiene este día (por ejemplo 31 en febrero), se omite.
          </p>
        </div>
      )}

      {/* Fecha fin */}
      <div>
        <label htmlFor="recurring-end-date" className={LABEL_CLASS}>
          Repetir hasta
        </label>
        <input
          id="recurring-end-date"
          type="date"
          value={endDate}
          min={minEndDate}
          max={maxEndDate}
          onChange={(e) => setEndDate(e.target.value)}
          className="w-full max-w-xs rounded border border-gray-300 px-2 py-1.5 text-sm focus:border-millenium-blue focus:outline-none focus:ring-2 focus:ring-millenium-blue/20"
        />
        <p className="mt-1 text-xs text-gray-500">
          Máximo 1 año desde la fecha de inicio.
        </p>
      </div>

      {/* Resumen */}
      <div className="flex items-start gap-2 rounded border border-blue-300 bg-white p-2.5 text-xs text-gray-700">
        <Calendar className="mt-0.5 h-3.5 w-3.5 shrink-0 text-millenium-blue" />
        <span>
          <strong>Esta reunión se repetirá:</strong>{" "}
          {buildSummary(pattern, frequencyWeeks, sortedDays, dayOfMonth)}
        </span>
      </div>
    </div>
  );
}

function buildSummary(
  pattern: RecurringPattern,
  frequencyWeeks: number,
  days: string[],
  dayOfMonth: number
): string {
  if (pattern === "monthly") {
    return `el día ${dayOfMonth} de cada mes`;
  }

  const dayLabels: Record<string, string> = {
    "1": "lunes",
    "2": "martes",
    "3": "miércoles",
    "4": "jueves",
    "5": "viernes",
    "6": "sábado",
    "7": "domingo",
  };

  if (days.length === 0) return "selecciona los días primero.";

  if (days.length === 7) {
    return frequencyWeeks === 1
      ? "todos los días"
      : `todos los días, cada ${frequencyWeeks} semanas`;
  }
  if (days.length === 5 && days.join(",") === "1,2,3,4,5") {
    return frequencyWeeks === 1
      ? "de lunes a viernes"
      : `de lunes a viernes, cada ${frequencyWeeks} semanas`;
  }
  if (days.length === 2 && days.join(",") === "6,7") {
    return frequencyWeeks === 1
      ? "sábados y domingos"
      : `sábados y domingos, cada ${frequencyWeeks} semanas`;
  }

  const labels = days.map((d) => dayLabels[d]).join(", ");
  return frequencyWeeks === 1
    ? `los ${labels}`
    : `los ${labels}, cada ${frequencyWeeks} semanas`;
}
