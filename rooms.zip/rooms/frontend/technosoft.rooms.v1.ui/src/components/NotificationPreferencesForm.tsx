"use client";

import { useEffect, useState } from "react";
import { Loader2, Save } from "lucide-react";
import { toast } from "@/lib/toastHelpers";
import api from "@/lib/api";
import type { NotificationPreferences, Reply } from "@/types";

type PrefKey = keyof NotificationPreferences;
type ToggleKey = Exclude<PrefKey, "browserMeetingReminderMinutes">;

interface PrefRow {
  key: ToggleKey;
  label: string;
  description: string;
}

const REMINDER_MINUTES_OPTIONS = [5, 10, 15, 30, 60] as const;

const PREFS: PrefRow[] = [
  {
    key: "emailNewNote",
    label: "Nueva nota agregada",
    description:
      "Recibe un correo cuando alguien agrega una nota en una reunión donde participas.",
  },
  {
    key: "emailNoteReply",
    label: "Respuesta a una nota mía",
    description:
      "Recibe un correo cuando alguien responde a una de tus notas.",
  },
  {
    key: "emailSummaryChange",
    label: "Cambios en el resumen",
    description:
      "Recibe un correo cuando se inicia o se agrega un punto al resumen.",
  },
  {
    key: "emailParticipationCancelled",
    label: "Un colaborador cancela su participación",
    description:
      "Recibe un correo cuando alguien cancela su participación en una reunión organizada por ti.",
  },
  {
    key: "emailReminders",
    label: "Recordatorios antes de la reunión",
    description:
      "Recibe correos recordatorios antes de tus reuniones.",
  },
  {
    key: "emailBlockedInvitation",
    label: "Invitación con bloqueo personal",
    description:
      "Recibe un correo cuando te invitan a una reunión que choca con tus bloqueos.",
  },
  {
    key: "emailAttendanceMarked",
    label: "Asistencia marcada",
    description:
      "Recibe un correo cuando el organizador marca tu asistencia.",
  },
  {
    key: "browserMeetingReminder",
    label: "Aviso del navegador antes de una reunión",
    description:
      "Recibe una notificación del sistema antes de que comience una reunión donde participas.",
  },
  {
    key: "browserReminderDue",
    label: "Aviso del navegador cuando vence un recordatorio",
    description:
      "Recibe una notificación del sistema cuando se cumple la hora de un recordatorio personal.",
  },
];

export default function NotificationPreferencesForm() {
  const [prefs, setPrefs] = useState<NotificationPreferences | null>(null);
  const [original, setOriginal] = useState<NotificationPreferences | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    let cancelled = false;
    api
      .get<Reply<NotificationPreferences>>("/users/me/notification-preferences")
      .then((res) => {
        if (cancelled) return;
        const data = res.data.obj || null;
        setPrefs(data);
        setOriginal(data);
      })
      .catch(() => {
        // silencioso
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  if (loading || !prefs || !original) {
    return <p className="text-sm text-gray-500">Cargando preferencias…</p>;
  }

  const hasChanges =
    PREFS.some((p) => prefs[p.key] !== original[p.key]) ||
    prefs.browserMeetingReminderMinutes !==
      original.browserMeetingReminderMinutes;

  function toggle(key: ToggleKey) {
    setPrefs((prev) => (prev ? { ...prev, [key]: !prev[key] } : prev));
  }

  function setReminderMinutes(minutes: number) {
    setPrefs((prev) =>
      prev ? { ...prev, browserMeetingReminderMinutes: minutes } : prev
    );
  }

  async function handleSave() {
    if (!prefs || saving || !hasChanges) return;
    setSaving(true);
    try {
      const res = await api.put<Reply<NotificationPreferences>>(
        "/users/me/notification-preferences",
        prefs
      );
      if (!res.data.ok || !res.data.obj) {
        toast.error(res.data.msg || "No fue posible guardar las preferencias");
        return;
      }
      setPrefs(res.data.obj);
      setOriginal(res.data.obj);
      toast.success("Preferencias guardadas");
    } catch (e: unknown) {
      const errObj = e as { response?: { data?: { msg?: string } } };
      toast.error(
        errObj?.response?.data?.msg || "No fue posible guardar las preferencias"
      );
    } finally {
      setSaving(false);
    }
  }

  function handleDiscard() {
    if (!original) return;
    setPrefs(original);
  }

  return (
    <div className="space-y-3">
      <ul className="divide-y divide-gray-100">
        {PREFS.map((p) => {
          const checked = !!prefs[p.key];
          const isMeetingReminderRow = p.key === "browserMeetingReminder";
          return (
            <li
              key={p.key}
              className="flex items-start justify-between gap-4 py-3"
            >
              <div className="min-w-0 flex-1">
                <p className="text-sm font-medium text-gray-900">{p.label}</p>
                <p className="mt-0.5 text-xs text-gray-500">{p.description}</p>
                {isMeetingReminderRow && checked && (
                  <div className="mt-2 flex items-center gap-2">
                    <label className="text-xs text-gray-600">
                      Avisar con
                    </label>
                    <select
                      value={prefs.browserMeetingReminderMinutes}
                      onChange={(e) =>
                        setReminderMinutes(parseInt(e.target.value, 10))
                      }
                      className="rounded-md border px-2 py-1 text-xs focus:outline-none focus:ring-2 focus:ring-millenium-blue"
                    >
                      {REMINDER_MINUTES_OPTIONS.map((m) => (
                        <option key={m} value={m}>
                          {m} min de anticipación
                        </option>
                      ))}
                    </select>
                  </div>
                )}
              </div>
              <label className="relative inline-flex shrink-0 cursor-pointer items-center">
                <input
                  type="checkbox"
                  checked={checked}
                  onChange={() => toggle(p.key)}
                  className="peer sr-only"
                />
                <span className="h-6 w-11 rounded-full bg-gray-200 transition peer-checked:bg-millenium-blue" />
                <span className="absolute left-0.5 top-0.5 h-5 w-5 rounded-full bg-white shadow transition peer-checked:translate-x-5" />
              </label>
            </li>
          );
        })}
      </ul>

      <div className="flex items-center justify-end gap-3 pt-2">
        {hasChanges && (
          <button
            type="button"
            onClick={handleDiscard}
            disabled={saving}
            className="text-sm font-medium text-gray-600 transition hover:text-gray-900 focus:outline-none focus:ring-2 focus:ring-millenium-blue/40 focus:ring-offset-1 disabled:opacity-60"
          >
            Descartar
          </button>
        )}
        <button
          type="button"
          onClick={handleSave}
          disabled={!hasChanges || saving}
          className="inline-flex items-center gap-2 rounded-lg bg-millenium-blue px-3 py-1.5 text-sm font-medium text-white transition hover:bg-[#1f2c3a] focus:outline-none focus:ring-2 focus:ring-millenium-blue/40 disabled:opacity-60"
        >
          {saving ? (
            <Loader2 className="h-4 w-4 animate-spin" />
          ) : (
            <Save className="h-4 w-4" />
          )}
          {saving ? "Guardando…" : "Guardar preferencias"}
        </button>
      </div>
    </div>
  );
}
