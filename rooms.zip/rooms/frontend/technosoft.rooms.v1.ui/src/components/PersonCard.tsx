"use client";

import Avatar from "@/components/Avatar";
import type { Person } from "@/types";
import { personStatusUi } from "@/lib/personStatus";

interface Props {
  person: Person;
  onClick: (p: Person) => void;
}

export default function PersonCard({ person, onClick }: Props) {
  const ui = personStatusUi(person);
  const hasName = !!(person.fullName && person.fullName.trim().length > 0);
  const displayName = hasName ? person.fullName : person.email;

  return (
    <button
      type="button"
      onClick={() => onClick(person)}
      className="flex min-h-[210px] flex-col items-center gap-2 rounded-xl border border-gray-200 bg-white p-4 text-center transition hover:border-gray-300 hover:shadow-md focus:outline-none focus-visible:ring-2 focus-visible:ring-millenium-blue/40"
    >
      <div className="relative">
        <Avatar
          name={person.fullName}
          email={person.email}
          avatarUrl={person.avatarUrl}
          size="xl"
        />
        <span
          className={`absolute bottom-0 right-0 h-3 w-3 rounded-full ring-2 ring-white ${ui.dotCls}`}
          aria-hidden="true"
        />
      </div>

      <div className="min-w-0 w-full">
        <h3
          className="truncate text-sm font-semibold text-gray-900"
          title={displayName || undefined}
        >
          {displayName}
        </h3>
        {hasName && (
          <p
            className="truncate text-xs text-gray-500"
            title={person.email}
          >
            {person.email}
          </p>
        )}
      </div>

      {/* G7 — chip del departamento. Reservamos su altura aunque esté vacío
          para que todas las tarjetas tengan la misma altura. */}
      <div className="flex min-h-[22px] items-center justify-center">
        {person.departmentName && (
          <span
            className="inline-flex items-center gap-1 rounded-full px-1.5 py-0.5 text-[10px] font-medium"
            style={{
              backgroundColor: `${person.departmentColor || "#475569"}20`,
              color: person.departmentColor || "#475569",
            }}
            title={person.departmentName}
          >
            <span
              className="inline-block h-1.5 w-1.5 rounded-full"
              style={{ backgroundColor: person.departmentColor || "#475569" }}
            />
            {person.departmentName}
          </span>
        )}
      </div>

      <span className={`mt-auto text-xs font-medium ${ui.textColor}`}>
        {ui.label}
      </span>
    </button>
  );
}
