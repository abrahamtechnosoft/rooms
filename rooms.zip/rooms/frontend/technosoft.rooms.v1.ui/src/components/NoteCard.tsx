"use client";

import { useState } from "react";
import { Pencil, Pin, PinOff, Trash2 } from "lucide-react";
import api from "@/lib/api";
import { toast } from "@/lib/toastHelpers";
import { emitWidgetEvent } from "@/lib/widgetEvents";
import type { Reply, UserNote } from "@/types";

interface Props {
  note: UserNote;
  isOwn: boolean;
  showAuthor: boolean;
  onEdit: () => void;
  onChanged: () => void;
}

function formatRelative(iso: string): string {
  const d = new Date(iso);
  const diffMs = Date.now() - d.getTime();
  const diffMin = Math.floor(diffMs / 60000);
  const diffHr = Math.floor(diffMin / 60);
  const diffDay = Math.floor(diffHr / 24);
  if (diffMin < 1) return "Hace un momento";
  if (diffMin < 60)
    return `Hace ${diffMin} ${diffMin === 1 ? "minuto" : "minutos"}`;
  if (diffHr < 24)
    return `Hace ${diffHr} ${diffHr === 1 ? "hora" : "horas"}`;
  if (diffDay < 7)
    return `Hace ${diffDay} ${diffDay === 1 ? "día" : "días"}`;
  return d.toLocaleDateString("es", { day: "numeric", month: "short" });
}

const TRUNCATE_LENGTH = 180;

export default function NoteCard({
  note,
  isOwn,
  showAuthor,
  onEdit,
  onChanged,
}: Props) {
  const [expanded, setExpanded] = useState(false);
  const [confirming, setConfirming] = useState(false);
  const [busy, setBusy] = useState(false);

  async function toggleDone() {
    if (busy) return;
    setBusy(true);
    try {
      await api.put<Reply<{ noteId: number }>>(`/notes/${note.noteId}`, {
        title: note.title,
        content: note.content,
        colorHex: note.colorHex,
        isDone: !note.isDone,
      });
      onChanged();
      emitWidgetEvent("notes:changed");
    } catch (e: unknown) {
      const errObj = e as { response?: { data?: { msg?: string } } };
      toast.error(
        errObj?.response?.data?.msg || "No fue posible actualizar la nota"
      );
    } finally {
      setBusy(false);
    }
  }

  async function togglePinned() {
    if (busy) return;
    setBusy(true);
    try {
      await api.post<Reply<{ noteId: number; isPinned: boolean }>>(
        `/notes/${note.noteId}/pin`
      );
      onChanged();
      emitWidgetEvent("notes:changed");
    } catch (e: unknown) {
      const errObj = e as { response?: { data?: { msg?: string } } };
      toast.error(
        errObj?.response?.data?.msg || "No fue posible actualizar la nota"
      );
    } finally {
      setBusy(false);
    }
  }

  async function handleDelete() {
    if (busy) return;
    setBusy(true);
    try {
      await api.delete<Reply<{ noteId: number }>>(`/notes/${note.noteId}`);
      toast.success("Nota eliminada");
      onChanged();
      emitWidgetEvent("notes:changed");
    } catch (e: unknown) {
      const errObj = e as { response?: { data?: { msg?: string } } };
      toast.error(
        errObj?.response?.data?.msg || "No fue posible eliminar la nota"
      );
    } finally {
      setBusy(false);
    }
  }

  const contentClass = note.isDone
    ? "text-gray-500 line-through"
    : "text-gray-800";

  const needsTruncate = note.content.length > TRUNCATE_LENGTH;
  const displayContent =
    !needsTruncate || expanded
      ? note.content
      : note.content.slice(0, TRUNCATE_LENGTH) + "…";

  return (
    <div
      className="rounded-lg border border-gray-200 p-3 shadow-sm"
      style={{ backgroundColor: note.colorHex }}
    >
      <div className="flex items-start gap-2">
        <input
          type="checkbox"
          checked={note.isDone}
          onChange={isOwn ? toggleDone : undefined}
          disabled={!isOwn || busy}
          className="mt-0.5 h-4 w-4 shrink-0 rounded border-gray-300 text-millenium-blue focus:ring-millenium-blue disabled:cursor-not-allowed"
          aria-label={note.isDone ? "Marcar como pendiente" : "Marcar como hecha"}
        />
        <div className="min-w-0 flex-1">
          {note.title && (
            <div className={`mb-1 text-sm font-semibold ${contentClass}`}>
              {note.title}
            </div>
          )}
          <div
            className={`whitespace-pre-wrap break-words text-sm ${contentClass}`}
          >
            {displayContent}
          </div>
          {needsTruncate && (
            <button
              type="button"
              onClick={() => setExpanded(!expanded)}
              className="mt-1 text-xs font-medium text-millenium-blue hover:underline"
            >
              {expanded ? "Ver menos" : "Ver más"}
            </button>
          )}

          <div className="mt-2 flex items-center justify-between text-[11px] text-gray-600">
            <span className="truncate">
              {showAuthor && (
                <>
                  <span className="font-medium">{note.authorName}</span>
                  {" · "}
                </>
              )}
              {formatRelative(note.createdAt)}
            </span>
            {isOwn && (
              <div className="flex shrink-0 items-center gap-1">
                {!confirming ? (
                  <>
                    <button
                      type="button"
                      onClick={togglePinned}
                      className="rounded p-2 hover:bg-black/5 sm:p-1.5"
                      title={note.isPinned ? "Desfijar" : "Fijar"}
                      aria-label={note.isPinned ? "Desfijar" : "Fijar"}
                      disabled={busy}
                    >
                      {note.isPinned ? (
                        <PinOff className="h-4 w-4" aria-hidden="true" />
                      ) : (
                        <Pin className="h-4 w-4" aria-hidden="true" />
                      )}
                    </button>
                    <button
                      type="button"
                      onClick={onEdit}
                      className="rounded p-2 hover:bg-black/5 sm:p-1.5"
                      title="Editar"
                      aria-label="Editar"
                      disabled={busy}
                    >
                      <Pencil className="h-4 w-4" aria-hidden="true" />
                    </button>
                    <button
                      type="button"
                      onClick={() => setConfirming(true)}
                      className="rounded p-2 hover:bg-black/5 sm:p-1.5"
                      title="Eliminar"
                      aria-label="Eliminar"
                      disabled={busy}
                    >
                      <Trash2 className="h-4 w-4" aria-hidden="true" />
                    </button>
                  </>
                ) : (
                  <>
                    <button
                      type="button"
                      onClick={handleDelete}
                      className="px-2 py-1 text-xs font-medium text-millenium-red hover:underline"
                      disabled={busy}
                    >
                      Confirmar
                    </button>
                    <button
                      type="button"
                      onClick={() => setConfirming(false)}
                      className="px-2 py-1 text-xs text-gray-600 hover:underline"
                      disabled={busy}
                    >
                      Cancelar
                    </button>
                  </>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
