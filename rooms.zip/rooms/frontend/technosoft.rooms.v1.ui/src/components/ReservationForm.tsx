"use client";

import {
  FormEvent,
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import { useRouter } from "next/navigation";
import { toast } from "@/lib/toastHelpers";
import {
  AlertCircle,
  AlertTriangle,
  ArrowRight,
  Briefcase,
  Building2,
  Check,
  ChevronDown,
  Info,
  Link as LinkIcon,
  Mail,
  MapPin,
  Plus,
  Send,
  Video,
  X,
} from "lucide-react";
import { addDays } from "date-fns";
import api from "@/lib/api";
import { useAuthStore } from "@/store/authStore";
import { useBackendPolling } from "@/hooks/useBackendPolling";
import type {
  Department,
  Reply,
  Reservation,
  ReservationCreateResponse,
  Room,
  UserPickerItem,
} from "@/types";
import {
  EXTERNAL_SUBTYPE_LABELS,
  EXTERNAL_SUBTYPE_ORDER,
  RESERVATION_TYPES,
  VIRTUAL_PLATFORM_LABELS,
  VIRTUAL_PLATFORMS,
  type ExternalSubtype,
  type ReservationType,
  type VirtualPlatform,
} from "@/constants/reservationTypes";
import { getUrlError, isValidUrl } from "@/lib/urlValidator";
import Input from "./ui/Input";
import Textarea from "./ui/Textarea";
import Button from "./ui/Button";
import { Skeleton } from "./ui/Skeleton";
import RoomPickerCards from "./RoomPickerCards";
import DateQuickPicks from "./DateQuickPicks";
import DatePopover from "./DatePopover";
import ParticipantPicker from "./ParticipantPicker";
import Avatar from "./Avatar";
import TimeRangeInput from "./TimeRangeInput";
import TimeSlotGrid from "./TimeSlotGrid";
import Section from "./layout/Section";
import RecurringConfig, {
  type RecurringConfigValue,
} from "./RecurringConfig";
import EditRecurringChoiceModal from "./EditRecurringChoiceModal";
import { Repeat } from "lucide-react";
import {
  fmtLong,
  fmtTime,
  formatDuration,
  parseYmd,
  today,
} from "@/lib/dates";
import {
  combineDateAndTime,
  formatHHMM,
  getNextMultipleOf5Min,
} from "@/lib/timeHelpers";

interface Props {
  initialRoomId?: number;
  initialDate?: string;
  initialStart?: string;
  initialDuration?: number;
  initialVirtual?: boolean;
  redirectOnSuccess?: string;
  onCreated?: (r: Reservation) => void;
  editId?: number;
}

const MIN_TITLE = 2;
const MAX_TITLE = 60;
const MAX_DESCRIPTION = 300;
const MAX_EXTERNAL_ADDRESS = 300;
const MAX_MEETING_LINK = 500;

interface TypeCardProps {
  active: boolean;
  onClick: () => void;
  icon: React.ComponentType<{ className?: string }>;
  color: string;
  title: string;
  subtitle: string;
  disabled?: boolean;
  disabledReason?: string;
}

function TypeCard({
  active,
  onClick,
  icon: Icon,
  color,
  title,
  subtitle,
  disabled,
  disabledReason,
}: TypeCardProps) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      aria-pressed={active}
      title={disabled ? disabledReason : undefined}
      className={
        "flex h-full w-full items-start gap-2 rounded-lg border-2 p-2 text-left transition disabled:cursor-not-allowed disabled:opacity-40 sm:gap-3 sm:p-3 " +
        (active ? "" : "border-gray-200 hover:border-gray-300")
      }
      style={
        active
          ? { borderColor: color, backgroundColor: `${color}0D` }
          : undefined
      }
    >
      <span
        className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg sm:h-10 sm:w-10"
        style={{ backgroundColor: `${color}26`, color }}
      >
        <Icon className="h-4 w-4 sm:h-5 sm:w-5" aria-hidden="true" />
      </span>
      <span className="min-w-0 flex-1">
        <span className="block text-sm font-semibold text-gray-900 wrap-break-word">
          {title}
        </span>
        <span className="mt-0.5 block text-[11px] text-gray-500 sm:text-xs wrap-break-word line-clamp-2 leading-tight">
          {subtitle}
        </span>
      </span>
    </button>
  );
}


const isoToYmd = (iso: string): string => {
  const d = new Date(iso);
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
};

const OPEN_HOUR = 8;
const CLOSE_HOUR = 17;
const MIN_DURATION_MIN = 15;

/**
 * Default inteligente con granularidad de 5 min:
 *  - Hoy: próximo múltiplo de 5 min desde ahora; duración default 30 min.
 *    Si el rango pasaría del cierre laboral, saltamos a mañana 08:00.
 *  - Antes de la apertura: hoy 08:00.
 *  - Fecha futura (cuando el caller no pasa initialDate): mañana 08:00.
 */
function getSmartDefaults(): { startsAt: Date; endsAt: Date; ymd: string } {
  const now = new Date();
  const todayOpen = new Date(now);
  todayOpen.setHours(OPEN_HOUR, 0, 0, 0);
  const todayClose = new Date(now);
  todayClose.setHours(CLOSE_HOUR, 0, 0, 0);

  // Antes de la apertura: 08:00 hoy.
  if (now < todayOpen) {
    const start = new Date(todayOpen);
    const end = new Date(start.getTime() + 30 * 60000);
    const y = start.getFullYear();
    const mo = String(start.getMonth() + 1).padStart(2, "0");
    const d = String(start.getDate()).padStart(2, "0");
    return { startsAt: start, endsAt: end, ymd: `${y}-${mo}-${d}` };
  }

  // Próximo múltiplo de 5 min desde ahora.
  const candidateStart = getNextMultipleOf5Min(now);
  const candidateEnd = new Date(candidateStart.getTime() + 30 * 60000);

  // Si el rango cabe antes del cierre, lo usamos.
  if (candidateEnd <= todayClose) {
    const y = candidateStart.getFullYear();
    const mo = String(candidateStart.getMonth() + 1).padStart(2, "0");
    const d = String(candidateStart.getDate()).padStart(2, "0");
    return {
      startsAt: candidateStart,
      endsAt: candidateEnd,
      ymd: `${y}-${mo}-${d}`,
    };
  }

  // No cabe hoy: saltar a mañana 08:00.
  const tomorrow = new Date(now);
  tomorrow.setDate(tomorrow.getDate() + 1);
  tomorrow.setHours(OPEN_HOUR, 0, 0, 0);
  const tEnd = new Date(tomorrow.getTime() + 30 * 60000);
  const y = tomorrow.getFullYear();
  const mo = String(tomorrow.getMonth() + 1).padStart(2, "0");
  const d = String(tomorrow.getDate()).padStart(2, "0");
  return { startsAt: tomorrow, endsAt: tEnd, ymd: `${y}-${mo}-${d}` };
}

function computeInitialRange(
  initialDate?: string,
  initialStart?: string,
  initialDuration?: number
): { startsAt: Date | null; endsAt: Date | null } {
  if (initialStart && initialDate) {
    const [h, m] = initialStart.split(":").map((v) => parseInt(v, 10));
    if (Number.isInteger(h) && Number.isInteger(m)) {
      const startsAt = combineDateAndTime(parseYmd(initialDate), h, m);
      const durMin =
        initialDuration && initialDuration >= MIN_DURATION_MIN
          ? initialDuration
          : 30;
      const endsAt = new Date(startsAt.getTime() + durMin * 60000);
      // Cap si excede el cierre del día.
      const maxEnd = combineDateAndTime(
        parseYmd(initialDate),
        CLOSE_HOUR,
        0
      );
      return {
        startsAt,
        endsAt: endsAt > maxEnd ? maxEnd : endsAt,
      };
    }
  }
  return { startsAt: null, endsAt: null };
}

export default function ReservationForm({
  initialRoomId,
  initialDate,
  initialStart,
  initialDuration,
  initialVirtual,
  redirectOnSuccess,
  onCreated,
  editId,
}: Props) {
  const router = useRouter();
  const isEditing = !!editId;
  const [loadingEdit, setLoadingEdit] = useState(!!editId);

  const [rooms, setRooms] = useState<Room[]>([]);
  const [roomId, setRoomId] = useState<number | null>(initialRoomId || null);
  const [date, setDate] = useState<string>(initialDate || today());

  const initialRange = useMemo(
    () => computeInitialRange(initialDate, initialStart, initialDuration),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    []
  );
  const [startsAtDate, setStartsAtDate] = useState<Date | null>(
    initialRange.startsAt
  );
  const [endsAtDate, setEndsAtDate] = useState<Date | null>(
    initialRange.endsAt
  );

  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [meetingLink, setMeetingLink] = useState("");
  const [participants, setParticipants] = useState<UserPickerItem[]>([]);
  const [submitting, setSubmitting] = useState(false);

  const [departments, setDepartments] = useState<Department[]>([]);
  const [selectedDepartments, setSelectedDepartments] = useState<Department[]>(
    []
  );
  const [showDeptPicker, setShowDeptPicker] = useState(false);

  // Cache de miembros por departamento + Set agregado de IDs ya incluidos.
  // Se usa tanto para deshabilitar usuarios en el picker de colaboradores
  // como para listar los miembros de cada departamento (lista expandible).
  const [departmentMembersCache, setDepartmentMembersCache] = useState<
    Record<number, UserPickerItem[]>
  >({});
  const [departmentMemberIds, setDepartmentMemberIds] = useState<Set<number>>(
    new Set()
  );
  const [expandedDepts, setExpandedDepts] = useState<Set<number>>(new Set());

  useEffect(() => {
    let cancelled = false;
    api
      .get<Reply<Department[]>>("/departments")
      .then((res) => {
        if (cancelled) return;
        setDepartments((res.data.obj || []).filter((d) => d.isActive));
      })
      .catch(() => {
        if (!cancelled) setDepartments([]);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  // Carga miembros de los departamentos seleccionados (snapshot al momento).
  // Se vuelve a ejecutar cuando cambia la selección — si el usuario quita un
  // departamento, sus miembros se sacan del set y vuelven a estar disponibles
  // en el picker de colaboradores.
  useEffect(() => {
    if (selectedDepartments.length === 0) {
      setDepartmentMembersCache({});
      setDepartmentMemberIds(new Set());
      return;
    }
    let cancelled = false;
    (async () => {
      const cache: Record<number, UserPickerItem[]> = {};
      const allIds = new Set<number>();
      for (const dept of selectedDepartments) {
        try {
          const res = await api.get<Reply<UserPickerItem[]>>(
            `/departments/${dept.id}/members`
          );
          if (cancelled) return;
          const members = res.data.obj || [];
          cache[dept.id] = members;
          for (const m of members) {
            allIds.add(m.id);
          }
        } catch {
          cache[dept.id] = [];
        }
      }
      if (cancelled) return;
      setDepartmentMembersCache(cache);
      setDepartmentMemberIds(allIds);
    })();
    return () => {
      cancelled = true;
    };
  }, [selectedDepartments]);

  function toggleDeptExpanded(deptId: number) {
    setExpandedDepts((prev) => {
      const next = new Set(prev);
      if (next.has(deptId)) next.delete(deptId);
      else next.add(deptId);
      return next;
    });
  }

  // Info de conflicto (debounced). Mantiene `message` para el borde rojo del
  // TimeRangeInput + datos extra para el banner "Usar HH:MM".
  interface ConflictInfo {
    conflict: boolean;
    message?: string;
    conflictingMeeting?: {
      id: number;
      title: string;
      startsAt: string;
      endsAt: string;
      creatorName?: string | null;
    };
    nextFreeSlot?: { startsAt: string; endsAt: string } | null;
  }
  const [conflictInfo, setConflictInfo] = useState<ConflictInfo | null>(null);
  const conflictMessage = conflictInfo?.message ?? null;
  const setConflictMessage = (msg: string | null) =>
    setConflictInfo(msg ? { conflict: true, message: msg } : null);
  const conflictTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Tipo de reunión: physical (en sala), virtual (solo agenda) o external
  // (fuera de oficina con cliente / evento externo).
  const [type, setType] = useState<ReservationType>(
    initialVirtual ? RESERVATION_TYPES.VIRTUAL : RESERVATION_TYPES.PHYSICAL
  );
  const [externalAddress, setExternalAddress] = useState("");
  const [externalSubtype, setExternalSubtype] =
    useState<ExternalSubtype | null>(null);
  const [externalCompany, setExternalCompany] = useState("");
  const [externalMapsUrl, setExternalMapsUrl] = useState("");
  const [externalContact, setExternalContact] = useState("");
  const [virtualPlatform, setVirtualPlatform] =
    useState<VirtualPlatform | null>(null);

  // Recurrencia (solo al crear). Cuando se edita una instancia de serie, el
  // formulario se comporta como edición normal y el modal de elección decide
  // si aplicar a la instancia o a la serie.
  const [isRecurring, setIsRecurring] = useState(false);
  const initialDateAsDate = useMemo(() => {
    return startsAtDate ? new Date(startsAtDate) : parseYmd(date);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  const defaultEndDate = useMemo(() => {
    const d = new Date(initialDateAsDate);
    d.setMonth(d.getMonth() + 1);
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
  }, [initialDateAsDate]);
  const [recurringConfig, setRecurringConfig] = useState<RecurringConfigValue>({
    pattern: "weekly",
    daysOfWeek: "1,2,3,4,5",
    frequencyWeeks: 1,
    dayOfMonth: null,
    seriesEndDate: defaultEndDate,
  });

  // Si la reunión que se está editando pertenece a una serie, guardamos el ID
  // de la serie para mostrar el modal de elección al guardar.
  const [editingSeriesId, setEditingSeriesId] = useState<number | null>(null);
  const [showEditChoice, setShowEditChoice] = useState(false);

  // G5 — Invitados externos (correos a clientes / personas fuera de la empresa).
  interface NewGuest {
    email: string;
    displayName: string;
    sendInvitation: boolean;
  }
  const [externalGuests, setExternalGuests] = useState<NewGuest[]>([]);
  const [newGuestEmail, setNewGuestEmail] = useState("");
  const [newGuestName, setNewGuestName] = useState("");
  const [newGuestSendInvitation, setNewGuestSendInvitation] = useState(true);
  // En modo edición, los invitados ya existentes (con guest_id) se gestionan
  // directamente contra el backend y mostramos como sub-lista solo informativa.
  interface ExistingGuest {
    guestId: number;
    email: string;
    displayName: string | null;
    notified: boolean;
  }
  const [existingGuests, setExistingGuests] = useState<ExistingGuest[]>([]);

  const [loadingRooms, setLoadingRooms] = useState(false);

  const [datePopoverOpen, setDatePopoverOpen] = useState(false);

  const dateRange = useMemo(() => {
    const min = new Date();
    min.setHours(0, 0, 0, 0);
    const max = addDays(min, 30);
    return { min, max };
  }, []);

  // Limpieza de localStorage de la version anterior (toggle Timeline/Lista)
  useEffect(() => {
    if (typeof window !== "undefined") {
      localStorage.removeItem("rooms_time_selector_view");
    }
  }, []);

  useEffect(() => {
    setLoadingRooms(true);
    api
      .get<Reply<Room[]>>("/rooms")
      .then((r) => {
        const active = (r.data.obj || []).filter((x) => x.isActive);
        setRooms(active);
        if (active.length === 0) return;
        const stillValid =
          roomId !== null && active.some((a) => a.id === roomId);
        // Solo preseleccionar sala si el tipo es physical.
        if (
          !stillValid &&
          !isEditing &&
          type === RESERVATION_TYPES.PHYSICAL
        ) {
          setRoomId(active[0].id);
        }
      })
      .catch(() => toast.error("No fue posible cargar las salas"))
      .finally(() => setLoadingRooms(false));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Default inteligente: al crear nuevo (sin prefill ni edición), arrancar en
  // el próximo slot completo de 30 min desde ahora. Si pasa de 16:30, propone
  // mañana 09:00. Los query-params `?date=...&start=HH:MM` se respetan por
  // `computeInitialRange` y bloquean el default aquí.
  const defaultInitedRef = useRef(false);
  useEffect(() => {
    if (defaultInitedRef.current) return;
    if (isEditing) {
      defaultInitedRef.current = true;
      return;
    }
    if (startsAtDate && endsAtDate) {
      // Vino del initialRange (?start=…). Respetamos.
      defaultInitedRef.current = true;
      return;
    }
    const smart = getSmartDefaults();
    setStartsAtDate(smart.startsAt);
    setEndsAtDate(smart.endsAt);
    setDate(smart.ymd);
    defaultInitedRef.current = true;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isEditing]);

  // Al cambiar la fecha (string YYYY-MM-DD), arrastrar startsAt/endsAt al día
  // nuevo respetando la hora elegida.
  const dateChangeGuard = useRef(false);
  useEffect(() => {
    if (!dateChangeGuard.current) {
      dateChangeGuard.current = true;
      return;
    }
    if (!startsAtDate || !endsAtDate) return;
    const targetDate = parseYmd(date);
    const newStart = new Date(targetDate);
    newStart.setHours(
      startsAtDate.getHours(),
      startsAtDate.getMinutes(),
      0,
      0
    );
    const newEnd = new Date(targetDate);
    newEnd.setHours(
      endsAtDate.getHours(),
      endsAtDate.getMinutes(),
      0,
      0
    );
    setStartsAtDate(newStart);
    setEndsAtDate(newEnd);
    setConflictMessage(null);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [date]);

  // Al cambiar la sala o el tipo, limpiar mensaje de conflicto.
  useEffect(() => {
    setConflictMessage(null);
  }, [roomId, type]);

  // Modo edición: precargar la reserva en state.
  useEffect(() => {
    if (!editId) return;
    let cancelled = false;
    api
      .get<Reply<Reservation>>(`/reservations/${editId}`)
      .then((res) => {
        if (cancelled) return;
        const r = res.data.obj;
        if (!r) {
          toast.error("No fue posible cargar la reunión");
          return;
        }
        const startsAtParsed = new Date(r.startsAt);
        const endsAtParsed = new Date(r.endsAt);

        // Saltar el effect que arrastra fecha al cambiar `date` (porque el set
        // de `date` después dispararía un reset del horario).
        dateChangeGuard.current = false;

        setType(r.type);
        if (r.type === RESERVATION_TYPES.EXTERNAL) {
          setExternalAddress(r.externalAddress || "");
          setExternalSubtype(
            (r.externalSubtype as ExternalSubtype | null) || "other"
          );
          setExternalCompany(r.externalCompany || "");
          setExternalMapsUrl(r.externalMapsUrl || "");
          setExternalContact(r.externalContact || "");
          setRoomId(null);
        } else if (r.type === RESERVATION_TYPES.VIRTUAL) {
          setVirtualPlatform(
            (r.virtualPlatform as VirtualPlatform | null) || null
          );
          setRoomId(null);
        } else {
          setRoomId(r.roomId);
        }
        // Cargar invitados externos ya guardados (G5)
        api
          .get<Reply<ExistingGuest[]>>(
            `/reservations/${editId}/external-guests`
          )
          .then((g) => setExistingGuests(g.data.obj || []))
          .catch(() => setExistingGuests([]));
        setDate(isoToYmd(r.startsAt));
        setStartsAtDate(startsAtParsed);
        setEndsAtDate(endsAtParsed);
        setTitle(r.title);
        setDescription(r.description || "");
        setMeetingLink(r.meetingLink || "");
        setParticipants(r.participants || []);
        setEditingSeriesId(r.recurringSeriesId ?? null);
      })
      .catch(() => {
        if (!cancelled) toast.error("No fue posible cargar la reunión");
      })
      .finally(() => {
        if (!cancelled) setLoadingEdit(false);
      });
    return () => {
      cancelled = true;
    };
  }, [editId]);

  const currentUser = useAuthStore((s) => s.user);
  const currentUserDeptId = currentUser?.departmentId ?? null;
  const currentUserOfficeName = currentUser?.officeName ?? null;

  const isPhysical = type === RESERVATION_TYPES.PHYSICAL;
  const isVirtualType = type === RESERVATION_TYPES.VIRTUAL;
  const isExternalType = type === RESERVATION_TYPES.EXTERNAL;
  const isOfficeType = type === RESERVATION_TYPES.OFFICE;

  // Office no admite recurrencia. Si el usuario tenia recurrente y cambia a
  // oficina, apagar el toggle silenciosamente.
  useEffect(() => {
    if (isOfficeType) setIsRecurring(false);
  }, [isOfficeType]);

  const selectedRoom = isPhysical
    ? rooms.find((r) => r.id === roomId) || null
    : null;
  const summaryDate = useMemo(() => fmtLong(parseYmd(date)), [date]);

  // Mostrar la sección de enlace solo si el tipo es virtual.
  const showLinkSection = isVirtualType;

  // startsAt/endsAt ISO derivados del state Date.
  const startsAt = startsAtDate ? startsAtDate.toISOString() : null;
  const endsAt = endsAtDate ? endsAtDate.toISOString() : null;
  const durationMinutes =
    startsAtDate && endsAtDate
      ? Math.round((endsAtDate.getTime() - startsAtDate.getTime()) / 60000)
      : null;

  // Handler de TimeRangeInput. Re-evalúa conflicto (debounced).
  const handleTimeChange = useCallback(
    (s: Date, e: Date) => {
      setStartsAtDate(s);
      setEndsAtDate(e);
      // El effect debajo dispara el chequeo de conflicto al cambiar deps.
    },
    []
  );

  // Handler del grid de slots — clic en slot libre actuando como inicio.
  // Mantiene la duración actual cuando es válida y cabe; si no, usa el mínimo.
  // Recorta el fin al cierre del día (17:00) como tope absoluto.
  const handleAvailabilityClick = useCallback(
    (start: Date) => {
      const dayCloseLocal = combineDateAndTime(
        parseYmd(date),
        CLOSE_HOUR,
        0
      );
      const currentDur =
        startsAtDate && endsAtDate
          ? Math.round(
              (endsAtDate.getTime() - startsAtDate.getTime()) / 60000
            )
          : 0;
      const durMin =
        currentDur >= MIN_DURATION_MIN ? currentDur : MIN_DURATION_MIN;
      let end = new Date(start.getTime() + durMin * 60000);
      if (end > dayCloseLocal) end = dayCloseLocal;
      // Si tras el cap el rango quedara por debajo del mínimo, retroceder el
      // inicio para mantener MIN_DURATION_MIN (sin pasar de la apertura).
      const dayOpenLocal = combineDateAndTime(parseYmd(date), OPEN_HOUR, 0);
      const adjustedDurMs = end.getTime() - start.getTime();
      let adjustedStart = start;
      if (adjustedDurMs < MIN_DURATION_MIN * 60000) {
        const minStart = new Date(
          end.getTime() - MIN_DURATION_MIN * 60000
        );
        adjustedStart = minStart < dayOpenLocal ? dayOpenLocal : minStart;
      }
      setStartsAtDate(adjustedStart);
      setEndsAtDate(end);
    },
    [date, startsAtDate, endsAtDate]
  );

  // Handler del grid — clic en slot posterior al inicio actual (fin del rango).
  // El grid ya validó duración mínima; aquí solo recortamos al cierre del día.
  const handleSelectEnd = useCallback(
    (end: Date) => {
      const dayCloseLocal = combineDateAndTime(parseYmd(date), CLOSE_HOUR, 0);
      const clamped = end > dayCloseLocal ? dayCloseLocal : end;
      setEndsAtDate(clamped);
    },
    [date]
  );

  const showSlotGrid = !!(isPhysical && selectedRoom && date);

  // Re-chequeo de conflicto. Se llama desde el debounce y desde el polling
  // en vivo. Si no hay datos suficientes, limpia el estado.
  const recheckConflict = useCallback(async () => {
    if (!startsAtDate || !endsAtDate) {
      setConflictInfo(null);
      return;
    }
    if (isPhysical && !roomId) {
      setConflictInfo(null);
      return;
    }
    try {
      const params: Record<string, string | number | undefined> = {
        type,
        startsAt: startsAtDate.toISOString(),
        endsAt: endsAtDate.toISOString(),
        excludeReservationId: editId || undefined,
      };
      if (isPhysical && roomId) {
        params.roomId = roomId;
      }
      const res = await api.get<Reply<ConflictInfo>>(
        "/reservations/check-conflict",
        { params }
      );
      if (res.data.ok && res.data.obj?.conflict) {
        setConflictInfo({
          ...res.data.obj,
          message:
            res.data.obj.message || "Hay otra reunión en este horario",
        });
      } else {
        setConflictInfo(null);
      }
    } catch {
      // Silencioso — no queremos toasts en cada vuelta del polling.
    }
  }, [startsAtDate, endsAtDate, roomId, type, isPhysical, editId]);

  // Chequeo de conflicto debounced (400 ms) al cambiar inputs.
  // Para physical chequea overlap de sala + sugerencia.
  // Para virtual/external solo chequea overlap del usuario actual.
  useEffect(() => {
    if (conflictTimerRef.current) {
      clearTimeout(conflictTimerRef.current);
      conflictTimerRef.current = null;
    }
    conflictTimerRef.current = setTimeout(() => {
      recheckConflict();
    }, 400);
    return () => {
      if (conflictTimerRef.current) {
        clearTimeout(conflictTimerRef.current);
      }
    };
  }, [recheckConflict]);

  // Polling en vivo del conflicto mientras el form está abierto. 5s para
  // reuniones physical (queremos detectar a tiempo si otro usuario toma la
  // sala), 30s para virtual/external (menos cambios concurrentes esperados).
  useBackendPolling(
    recheckConflict,
    isPhysical ? 5_000 : 30_000,
    [recheckConflict],
    { silentOnError: true }
  );

  // Bloqueos personales de los invitados: chequear con debounce cuando cambian
  // los participantes, departamentos o el rango. Muestra aviso para que el
  // organizador sepa que esas personas recibirán una petición.
  interface BlockedUserInfo {
    userId: number;
    userName: string;
    blockId: number;
    blockName: string;
  }
  const [blockedUsers, setBlockedUsers] = useState<BlockedUserInfo[]>([]);

  useEffect(() => {
    if (!startsAtDate || !endsAtDate) {
      setBlockedUsers([]);
      return;
    }
    const userIds = [
      ...participants.map((p) => p.id),
      ...Array.from(departmentMemberIds),
    ];
    const uniq = [...new Set(userIds)];
    if (uniq.length === 0) {
      setBlockedUsers([]);
      return;
    }
    const timer = setTimeout(async () => {
      try {
        const res = await api.post<Reply<BlockedUserInfo[]>>(
          "/reservations/check-blocks",
          {
            userIds: uniq,
            startsAt: startsAtDate.toISOString(),
            endsAt: endsAtDate.toISOString(),
          }
        );
        setBlockedUsers(res.data.obj || []);
      } catch {
        // silencioso
      }
    }, 400);
    return () => clearTimeout(timer);
  }, [participants, departmentMemberIds, startsAtDate, endsAtDate]);

  const isValidEmail = (e: string) =>
    /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e.trim());

  const addNewGuest = () => {
    const cleanEmail = newGuestEmail.trim().toLowerCase();
    if (!isValidEmail(cleanEmail)) {
      toast.error("Correo no válido");
      return;
    }
    if (
      externalGuests.some(
        (g) => g.email.toLowerCase() === cleanEmail
      ) ||
      existingGuests.some((g) => g.email.toLowerCase() === cleanEmail)
    ) {
      toast.error("Este correo ya está en la lista");
      return;
    }
    setExternalGuests([
      ...externalGuests,
      {
        email: cleanEmail,
        displayName: newGuestName.trim(),
        sendInvitation: newGuestSendInvitation,
      },
    ]);
    setNewGuestEmail("");
    setNewGuestName("");
    setNewGuestSendInvitation(true);
  };

  const removeNewGuest = (idx: number) => {
    setExternalGuests((prev) => prev.filter((_, i) => i !== idx));
  };

  const removeExistingGuest = async (guestId: number) => {
    if (!editId) return;
    try {
      await api.delete(
        `/reservations/${editId}/external-guests/${guestId}`
      );
      setExistingGuests((prev) =>
        prev.filter((g) => g.guestId !== guestId)
      );
      toast.success("Invitado eliminado");
    } catch (e: unknown) {
      const errObj = e as { response?: { data?: { msg?: string } } };
      toast.error(
        errObj?.response?.data?.msg || "No fue posible eliminar al invitado"
      );
    }
  };

  const titleOk = title.trim().length >= MIN_TITLE;
  const externalAddressOk =
    !isExternalType || externalAddress.trim().length >= 3;
  const externalSubtypeOk = !isExternalType || externalSubtype != null;
  const externalMapsUrlOk =
    !isExternalType || !externalMapsUrl || isValidUrl(externalMapsUrl);
  const meetingLinkOk =
    !isVirtualType || !meetingLink || isValidUrl(meetingLink);
  // El TimeRangeInput nos informa si su valor local es válido (no pasado,
  // duración >= mínimo, fin > inicio). Sin esto, el submit puede mandar valores
  // ya invalidados por el reloj.
  const [timeValid, setTimeValid] = useState(false);
  // Nota: `conflictMessage` ya NO bloquea el submit — solo se muestra como
  // advertencia. El backend valida con UPDLOCK/HOLDLOCK y responde 409 si el
  // horario ya fue tomado (mensaje claro al usuario).
  const canSubmit = !!(
    (!isPhysical || roomId) &&
    startsAt &&
    endsAt &&
    titleOk &&
    externalAddressOk &&
    externalSubtypeOk &&
    externalMapsUrlOk &&
    meetingLinkOk &&
    timeValid
  );

  const missingMsg = isPhysical
    ? "Complete sala, fecha, horario y título"
    : isVirtualType
      ? "Complete fecha, horario y título"
      : "Complete ubicación, fecha, horario y título";

  async function submitWithChoice(choice: "instance" | "future") {
    if (submitting || !startsAtDate || !endsAtDate) return;
    setSubmitting(true);
    try {
      const payload: Record<string, unknown> = {
        title: title.trim(),
        description: description.trim() || null,
        meetingLink: isVirtualType ? meetingLink.trim() || null : null,
        externalAddress: isExternalType ? externalAddress.trim() : null,
      };
      if (choice === "instance") {
        // Edición normal de la instancia (marca is_exception en backend).
        const startsAt = startsAtDate.toISOString();
        const endsAt = endsAtDate.toISOString();
        const instancePayload: Record<string, unknown> = {
          type,
          startsAt,
          endsAt,
          title: title.trim(),
          description: description.trim() || undefined,
          participantIds: participants.map((p) => p.id),
          departmentIds: selectedDepartments.map((d) => d.id),
        };
        if (isPhysical) instancePayload.roomId = roomId;
        else if (isVirtualType) {
          instancePayload.meetingLink = meetingLink.trim() || null;
          instancePayload.virtualPlatform = virtualPlatform;
        } else if (isExternalType) {
          instancePayload.externalAddress = externalAddress.trim();
          instancePayload.externalSubtype = externalSubtype;
          instancePayload.externalCompany = externalCompany.trim() || null;
          instancePayload.externalMapsUrl = externalMapsUrl.trim() || null;
          instancePayload.externalContact = externalContact.trim() || null;
        }
        const r = await api.put<Reply<ReservationCreateResponse>>(
          `/reservations/${editId}`,
          instancePayload
        );
        if (!r.data.ok || !r.data.obj) {
          toast.error(r.data.msg || "No fue posible actualizar la reunión");
          return;
        }
        toast.success(r.data.msg || "Reunión actualizada");
        if (onCreated) onCreated(r.data.obj);
        if (redirectOnSuccess) router.push(redirectOnSuccess);
      } else {
        // Aplicar a la serie desde esta instancia en adelante.
        const r = await api.patch<Reply<{ instancesUpdated: number }>>(
          `/recurring-series/${editingSeriesId}/from-instance/${editId}`,
          payload
        );
        if (!r.data.ok) {
          toast.error(r.data.msg || "No fue posible actualizar la serie");
          return;
        }
        toast.success(r.data.msg || "Serie actualizada");
        if (redirectOnSuccess) router.push(redirectOnSuccess);
      }
    } catch (e: unknown) {
      const errObj = e as { response?: { data?: { msg?: string } } };
      toast.error(
        errObj?.response?.data?.msg || "No fue posible aplicar los cambios"
      );
    } finally {
      setSubmitting(false);
      setShowEditChoice(false);
    }
  }

  const handleSubmit = async (ev: FormEvent) => {
    ev.preventDefault();
    if (submitting) return; // proteccion ante doble click
    if (isExternalType && !externalSubtype) {
      toast.error("Debes elegir el tipo de actividad");
      return;
    }
    if (isExternalType && externalMapsUrl && !isValidUrl(externalMapsUrl)) {
      toast.error(
        getUrlError(externalMapsUrl, "enlace de Maps") ||
          "Enlace de Maps inválido"
      );
      return;
    }
    if (isVirtualType && meetingLink && !isValidUrl(meetingLink)) {
      toast.error(
        getUrlError(meetingLink, "enlace de reunión") ||
          "Enlace de reunión inválido"
      );
      return;
    }
    if (!canSubmit || !startsAt || !endsAt) {
      toast.error(missingMsg);
      return;
    }

    // Editar instancia que pertenece a una serie → preguntar primero.
    if (isEditing && editingSeriesId) {
      setShowEditChoice(true);
      return;
    }

    // Crear serie nueva.
    if (!isEditing && isRecurring) {
      if (recurringConfig.pattern === "weekly") {
        if (!recurringConfig.daysOfWeek) {
          toast.error("Selecciona al menos un día de la semana");
          return;
        }
        if (
          !recurringConfig.frequencyWeeks ||
          ![1, 2, 3].includes(recurringConfig.frequencyWeeks)
        ) {
          toast.error("Selecciona una frecuencia válida");
          return;
        }
      }
      if (recurringConfig.pattern === "monthly" && !recurringConfig.dayOfMonth) {
        toast.error("Indica el día del mes");
        return;
      }
      if (!recurringConfig.seriesEndDate) {
        toast.error("Indica la fecha final de la serie");
        return;
      }
      if (!startsAtDate || !endsAtDate) {
        toast.error(missingMsg);
        return;
      }
      setSubmitting(true);
      try {
        const seriesPayload: Record<string, unknown> = {
          title: title.trim(),
          description: description.trim() || null,
          reservationType: type,
          roomId: isPhysical ? roomId : null,
          meetingLink: isVirtualType ? meetingLink.trim() || null : null,
          externalAddress: isExternalType ? externalAddress.trim() : null,
          pattern: recurringConfig.pattern,
          daysOfWeek: recurringConfig.daysOfWeek,
          frequencyWeeks: recurringConfig.frequencyWeeks,
          dayOfMonth: recurringConfig.dayOfMonth,
          startTime: formatHHMM(startsAtDate),
          endTime: formatHHMM(endsAtDate),
          seriesStartDate: isoToYmd(startsAtDate.toISOString()),
          seriesEndDate: recurringConfig.seriesEndDate,
          participantIds: participants.map((p) => p.id),
          departmentIds: selectedDepartments.map((d) => d.id),
        };
        const r = await api.post<
          Reply<{ seriesId: number; instancesGenerated: number; skipped: number }>
        >("/recurring-series", seriesPayload);
        if (!r.data.ok || !r.data.obj) {
          toast.error(r.data.msg || "No fue posible crear la serie");
          return;
        }
        toast.success(r.data.msg || "Serie creada");
        if (redirectOnSuccess) router.push(redirectOnSuccess);
      } catch (e: unknown) {
        const errObj = e as { response?: { data?: { msg?: string } } };
        toast.error(
          errObj?.response?.data?.msg || "No fue posible crear la serie"
        );
      } finally {
        setSubmitting(false);
      }
      return;
    }

    setSubmitting(true);
    try {
      const payload: Record<string, unknown> = {
        type,
        startsAt,
        endsAt,
        title: title.trim(),
        description: description.trim() || undefined,
        participantIds: participants.map((p) => p.id),
        departmentIds: selectedDepartments.map((d) => d.id),
      };
      if (isPhysical) {
        payload.roomId = roomId;
      } else if (isVirtualType) {
        payload.meetingLink = meetingLink.trim() || null;
        payload.virtualPlatform = virtualPlatform;
      } else if (isExternalType) {
        payload.externalAddress = externalAddress.trim();
        payload.externalSubtype = externalSubtype;
        payload.externalCompany = externalCompany.trim() || null;
        payload.externalMapsUrl = externalMapsUrl.trim() || null;
        payload.externalContact = externalContact.trim() || null;
      }

      const res = isEditing
        ? await api.put<Reply<ReservationCreateResponse>>(
            `/reservations/${editId}`,
            payload
          )
        : await api.post<Reply<ReservationCreateResponse>>(
            "/reservations",
            payload
          );

      if (!res.data.ok || !res.data.obj) {
        toast.error(
          res.data.msg ||
            (isEditing
              ? "No fue posible actualizar la reunión"
              : "No fue posible agendar la reunión")
        );
        return;
      }

      // G5 — Persistir invitados externos nuevos (POST por cada uno).
      const targetId = isEditing ? editId : res.data.obj.id;
      if (targetId && externalGuests.length > 0) {
        for (const g of externalGuests) {
          try {
            await api.post(
              `/reservations/${targetId}/external-guests`,
              {
                email: g.email,
                displayName: g.displayName || null,
                sendInvitation: g.sendInvitation,
              }
            );
          } catch (e: unknown) {
            const errObj = e as { response?: { data?: { msg?: string } } };
            console.warn(
              "[guest add fallo]",
              g.email,
              errObj?.response?.data?.msg
            );
          }
        }
        setExternalGuests([]);
      }

      if (isEditing) {
        toast.success(res.data.msg || "Reunión actualizada");
      } else {
        const notified = res.data.obj.participantsNotified ?? 0;
        const successMsg =
          notified > 0
            ? `Reunión agendada. ${notified} ${
                notified === 1
                  ? "colaborador notificado"
                  : "colaboradores notificados"
              } por correo.`
            : res.data.msg || "Reunión agendada";
        toast.success(successMsg);
      }

      if (typeof window !== "undefined") {
        localStorage.setItem("rooms_hint_dismissed", "1");
      }
      if (onCreated) onCreated(res.data.obj);
      if (redirectOnSuccess) router.push(redirectOnSuccess);
    } catch (e: unknown) {
      const errObj = e as {
        response?: { status?: number; data?: { msg?: string } };
      };
      const status = errObj?.response?.status;
      const msg = errObj?.response?.data?.msg;
      if (status === 409) {
        toast.error(
          msg || "Este horario ya no está disponible. Elija otro."
        );
        // El TimeRangeInput re-chequea automáticamente al ver el conflicto.
        setConflictMessage(msg || "Hay otra reunión en este horario");
      } else if (status === 400) {
        toast.error(msg || "Datos no válidos");
      } else {
        toast.error(
          msg ||
            (isEditing
              ? "No fue posible actualizar la reunión"
              : "No fue posible agendar la reunión")
        );
      }
    } finally {
      setSubmitting(false);
    }
  };

  const selectionRangeLabel =
    startsAt && endsAt
      ? `${fmtTime(startsAt)} - ${fmtTime(endsAt)}`
      : null;

  return (
    <form onSubmit={handleSubmit} className="flex flex-col">
      <fieldset
        disabled={submitting}
        className={
          "grid grid-cols-1 gap-6 pb-8 xl:grid-cols-2 xl:gap-8 " +
          (submitting ? "opacity-60 pointer-events-none" : "")
        }
      >
        {/* Columna izquierda: dónde y cuándo */}
        <div className="space-y-6">
          <Section label="Tipo de reunión">
            <div className="grid grid-cols-2 gap-2 auto-rows-fr sm:gap-3 sm:grid-cols-4">
              <TypeCard
                active={isPhysical}
                onClick={() => {
                  setType(RESERVATION_TYPES.PHYSICAL);
                  if (!roomId && rooms.length > 0) setRoomId(rooms[0].id);
                }}
                icon={Building2}
                color="#2C3E50"
                title="En sala"
                subtitle="Sala física"
              />
              <TypeCard
                active={isOfficeType}
                disabled={!currentUserDeptId}
                disabledReason="Necesitas un departamento asignado"
                onClick={() => {
                  setType(RESERVATION_TYPES.OFFICE);
                  setRoomId(null);
                }}
                icon={Briefcase}
                color="#E67E22"
                title="Oficina"
                subtitle={
                  currentUserOfficeName ?? "Oficina del departamento"
                }
              />
              <TypeCard
                active={isVirtualType}
                onClick={() => {
                  setType(RESERVATION_TYPES.VIRTUAL);
                  setRoomId(null);
                }}
                icon={Video}
                color="#8B5CF6"
                title="Virtual"
                subtitle="Solo agenda"
              />
              <TypeCard
                active={isExternalType}
                onClick={() => {
                  setType(RESERVATION_TYPES.EXTERNAL);
                  setRoomId(null);
                }}
                icon={MapPin}
                color="#27AE60"
                title="Fuera"
                subtitle="Cliente o evento"
              />
            </div>

            {isVirtualType && (
              <p className="mt-3 flex items-start gap-1.5 text-xs text-gray-500">
                <Info className="mt-0.5 h-3.5 w-3.5 shrink-0" />
                <span>
                  Solo bloquea tu agenda y la de los colaboradores. No reserva
                  ninguna sala física.
                </span>
              </p>
            )}
            {isExternalType && (
              <p className="mt-3 flex items-start gap-1.5 text-xs text-gray-500">
                <Info className="mt-0.5 h-3.5 w-3.5 shrink-0" />
                <span>
                  Solo bloquea tu agenda y la de los colaboradores invitados.
                  No reserva ninguna sala física.
                </span>
              </p>
            )}
          </Section>

          {isPhysical && (
            <Section label="Sala">
              {loadingRooms ? (
                <div className="flex flex-col gap-2">
                  <Skeleton className="h-16 w-full" count={2} />
                </div>
              ) : (
                <>
                  <RoomPickerCards
                    rooms={rooms}
                    value={roomId}
                    onChange={(id) => setRoomId(id)}
                  />
                  {selectedRoom && (
                    <p className="mt-2 flex items-start gap-1.5 text-xs text-gray-500">
                      <Info className="mt-0.5 h-3.5 w-3.5 shrink-0" />
                      <span>
                        Reserva la sala física. Nadie más podrá usarla en este
                        horario.
                      </span>
                    </p>
                  )}
                </>
              )}
            </Section>
          )}

          {isExternalType && (
            <Section label="Detalle de la actividad">
              <div className="space-y-4">
                <div>
                  <label className="mb-1.5 block text-sm font-medium text-gray-700">
                    Tipo de actividad{" "}
                    <span className="text-millenium-red">*</span>
                  </label>
                  <div className="grid grid-cols-2 gap-2 auto-rows-fr sm:gap-3 md:grid-cols-4">
                    {EXTERNAL_SUBTYPE_ORDER.map((value) => {
                      const isActive = externalSubtype === value;
                      return (
                        <button
                          key={value}
                          type="button"
                          onClick={() => setExternalSubtype(value)}
                          aria-pressed={isActive}
                          className={
                            "h-full w-full rounded-lg border px-3 py-2 text-sm text-center wrap-break-word leading-tight transition " +
                            (isActive
                              ? "border-millenium-green bg-millenium-green/10 font-medium text-millenium-green"
                              : "border-gray-200 bg-white text-gray-700 hover:border-gray-300")
                          }
                        >
                          {EXTERNAL_SUBTYPE_LABELS[value]}
                        </button>
                      );
                    })}
                  </div>
                </div>

                <Input
                  label="Empresa o lugar (opcional)"
                  value={externalCompany}
                  onChange={(e) => setExternalCompany(e.target.value)}
                  placeholder="Ej.: Cliente Disney, Hotel Marriott"
                  maxLength={120}
                />

                <div>
                  <label
                    htmlFor="external-address"
                    className="mb-1.5 block text-sm font-medium text-gray-700"
                  >
                    Dirección <span className="text-millenium-red">*</span>
                  </label>
                  <textarea
                    id="external-address"
                    value={externalAddress}
                    onChange={(e) => setExternalAddress(e.target.value)}
                    placeholder="Ej.: Av. Central 123, San José"
                    maxLength={MAX_EXTERNAL_ADDRESS}
                    rows={2}
                    required
                    className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:border-millenium-green focus:outline-none focus:ring-2 focus:ring-millenium-green/40"
                  />
                  <p className="mt-1 text-right text-xs text-gray-500 tabular-nums">
                    {externalAddress.length}/{MAX_EXTERNAL_ADDRESS}
                  </p>
                </div>

                <div>
                  <label
                    htmlFor="external-maps-url"
                    className="mb-1.5 block text-sm font-medium text-gray-700"
                  >
                    Enlace a Google Maps (opcional)
                  </label>
                  <input
                    id="external-maps-url"
                    type="url"
                    inputMode="url"
                    value={externalMapsUrl}
                    onChange={(e) => setExternalMapsUrl(e.target.value)}
                    placeholder="https://maps.google.com/..."
                    maxLength={MAX_MEETING_LINK}
                    aria-invalid={!!(externalMapsUrl && !isValidUrl(externalMapsUrl))}
                    aria-describedby={
                      externalMapsUrl && !isValidUrl(externalMapsUrl)
                        ? "external-maps-url-error"
                        : undefined
                    }
                    className={
                      "w-full rounded-lg border px-3 py-2 text-sm focus:outline-none focus:ring-2 " +
                      (externalMapsUrl && !isValidUrl(externalMapsUrl)
                        ? "border-millenium-red bg-red-50 focus:ring-millenium-red/40"
                        : "border-gray-300 focus:ring-millenium-green/40")
                    }
                  />
                  {externalMapsUrl && !isValidUrl(externalMapsUrl) && (
                    <p
                      id="external-maps-url-error"
                      role="alert"
                      className="mt-1 flex items-center gap-1 text-xs text-millenium-red"
                    >
                      <AlertCircle className="h-3 w-3 shrink-0" aria-hidden="true" />
                      <span>{getUrlError(externalMapsUrl, "enlace de Maps")}</span>
                    </p>
                  )}
                </div>

                <Input
                  label="Persona de contacto (opcional)"
                  value={externalContact}
                  onChange={(e) => setExternalContact(e.target.value)}
                  placeholder="Nombre del contacto en el lugar"
                  maxLength={120}
                />
              </div>
            </Section>
          )}

          <Section label="Fecha">
            <DateQuickPicks
              value={date}
              onChange={setDate}
              onOpenMore={() => setDatePopoverOpen(true)}
            />
          </Section>
          <DatePopover
            open={datePopoverOpen}
            value={date}
            minDate={dateRange.min}
            maxDate={dateRange.max}
            onChange={setDate}
            onClose={() => setDatePopoverOpen(false)}
          />

          <Section label="Horario">
            <TimeRangeInput
              selectedDate={parseYmd(date)}
              startsAt={startsAtDate}
              endsAt={endsAtDate}
              onChange={handleTimeChange}
              conflictMessage={conflictMessage}
              minHour={OPEN_HOUR}
              maxHour={CLOSE_HOUR}
              minDurationMin={MIN_DURATION_MIN}
              onValidityChange={setTimeValid}
            />

            {/* Banner de conflicto con sugerencia "Usar HH:MM - HH:MM".
                Tono ámbar: el submit ya no se bloquea, solo se advierte. */}
            {conflictInfo &&
              conflictInfo.conflict &&
              conflictInfo.conflictingMeeting && (
                <div className="animate-fadeIn mt-2 rounded-lg border border-amber-300 bg-amber-50 p-3">
                  <div className="flex items-start gap-2">
                    <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-amber-600" />
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-medium text-amber-700">
                        Estas horas ya no están disponibles
                      </p>
                      <p className="mt-1 text-xs text-gray-700">
                        {conflictInfo.conflictingMeeting.creatorName ? (
                          <>
                            <strong>
                              {conflictInfo.conflictingMeeting.creatorName}
                            </strong>{" "}
                            reservó{" "}
                          </>
                        ) : (
                          <>Otro usuario reservó </>
                        )}
                        <strong>
                          &ldquo;{conflictInfo.conflictingMeeting.title}&rdquo;
                        </strong>{" "}
                        en ese horario (
                        {fmtTime(conflictInfo.conflictingMeeting.startsAt)} —{" "}
                        {fmtTime(conflictInfo.conflictingMeeting.endsAt)}).
                        Elige otras horas o cambia de sala.
                      </p>
                      {conflictInfo.nextFreeSlot ? (
                        <button
                          type="button"
                          onClick={() => {
                            const s = new Date(
                              conflictInfo.nextFreeSlot!.startsAt
                            );
                            const e = new Date(
                              conflictInfo.nextFreeSlot!.endsAt
                            );
                            setStartsAtDate(s);
                            setEndsAtDate(e);
                            setConflictInfo(null);
                          }}
                          className="mt-2 inline-flex items-center gap-1.5 rounded-md border border-millenium-blue/30 bg-white px-2.5 py-1.5 text-xs font-medium text-millenium-blue transition hover:bg-millenium-blue/5"
                        >
                          <ArrowRight className="h-3.5 w-3.5" />
                          Usar {fmtTime(conflictInfo.nextFreeSlot.startsAt)} —{" "}
                          {fmtTime(conflictInfo.nextFreeSlot.endsAt)}
                        </button>
                      ) : (
                        <p className="mt-1 text-xs italic text-gray-500">
                          No hay más horarios libres hoy en esta sala.
                        </p>
                      )}
                    </div>
                  </div>
                </div>
              )}

            {/* Grid de slots de 30 min — solo salas físicas no externas. */}
            {showSlotGrid && roomId !== null && (
              <TimeSlotGrid
                roomId={roomId}
                date={date}
                selectedStart={startsAtDate}
                selectedEnd={endsAtDate}
                excludeReservationId={editId}
                onSelectStart={handleAvailabilityClick}
                onSelectEnd={handleSelectEnd}
                minHour={OPEN_HOUR}
                maxHour={CLOSE_HOUR}
              />
            )}

            {/* Resumen sutil del rango */}
            {startsAtDate &&
              endsAtDate &&
              durationMinutes !== null &&
              durationMinutes > 0 && (
                <div className="mt-3 flex items-center gap-3 rounded-lg border border-millenium-blue/20 bg-millenium-blue/5 p-3">
                  <p className="flex flex-1 items-center gap-2 text-sm text-gray-700">
                    <Check className="h-4 w-4 shrink-0 text-millenium-blue" />
                    <span>
                      Agendarás de{" "}
                      <strong className="text-gray-900">
                        {formatHHMM(startsAtDate)} - {formatHHMM(endsAtDate)}
                      </strong>
                      <span className="text-gray-500">
                        {" "}
                        ({formatDuration(durationMinutes)})
                      </span>
                    </span>
                  </p>
                </div>
              )}
          </Section>

          {!isEditing && (
            <Section label="Recurrencia">
              <label
                className={
                  "flex items-start gap-2 " +
                  (isOfficeType ? "cursor-not-allowed" : "cursor-pointer")
                }
              >
                <input
                  type="checkbox"
                  checked={isRecurring && !isOfficeType}
                  onChange={(e) => setIsRecurring(e.target.checked)}
                  disabled={isOfficeType}
                  className="mt-0.5 h-4 w-4 rounded border-gray-300 text-millenium-blue focus:ring-millenium-blue/40 disabled:cursor-not-allowed disabled:opacity-50"
                />
                <span
                  className={
                    "flex flex-1 items-center gap-1.5 text-sm " +
                    (isOfficeType ? "text-gray-400" : "text-gray-700")
                  }
                >
                  <Repeat className="h-3.5 w-3.5 text-millenium-blue" />
                  Esta reunión se repite
                </span>
              </label>
              {isOfficeType && (
                <p className="mt-1 ml-6 text-xs text-gray-500">
                  Las reuniones de oficina no admiten recurrencia. Crea
                  instancias individuales.
                </p>
              )}
              {isRecurring && !isOfficeType && startsAtDate && (
                <div className="mt-3">
                  <RecurringConfig
                    initialDate={startsAtDate}
                    value={recurringConfig}
                    onChange={setRecurringConfig}
                  />
                </div>
              )}
            </Section>
          )}
        </div>

        {/* Columna derecha: qué y con quién */}
        <div className="space-y-6">
          <Section label="Detalle">
            <div className="flex flex-col gap-4">
              <div>
                <Input
                  label="Título"
                  name="title"
                  value={title}
                  maxLength={MAX_TITLE}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="Reunión semanal de equipo"
                  required
                />
                <p className="mt-1 text-right text-xs text-gray-500 tabular-nums">
                  {title.length}/{MAX_TITLE}
                </p>
              </div>
              <div>
                <Textarea
                  label="Descripción (opcional)"
                  id="description"
                  name="description"
                  rows={3}
                  maxLength={MAX_DESCRIPTION}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                />
                <p className="mt-1 text-right text-xs text-gray-500 tabular-nums">
                  {description.length}/{MAX_DESCRIPTION}
                </p>
              </div>
            </div>
          </Section>

          {showLinkSection && (
            <Section label="Reunión virtual">
              <div className="space-y-4">
                <div>
                  <label className="mb-1.5 block text-sm font-medium text-gray-700">
                    Plataforma (opcional)
                  </label>
                  <div className="grid grid-cols-2 gap-2 md:grid-cols-4">
                    {VIRTUAL_PLATFORMS.map((value) => {
                      const isActive = virtualPlatform === value;
                      return (
                        <button
                          key={value}
                          type="button"
                          onClick={() =>
                            setVirtualPlatform(isActive ? null : value)
                          }
                          aria-pressed={isActive}
                          className={
                            "rounded-lg border px-3 py-2 text-sm transition " +
                            (isActive
                              ? "border-purple-500 bg-purple-50 font-medium text-purple-700"
                              : "border-gray-200 bg-white text-gray-700 hover:border-gray-300")
                          }
                        >
                          {VIRTUAL_PLATFORM_LABELS[value]}
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div>
                  <label
                    htmlFor="meeting-link"
                    className="mb-1.5 block text-sm font-medium text-gray-700"
                  >
                    Enlace de reunión (opcional)
                  </label>
                  <input
                    id="meeting-link"
                    type="url"
                    inputMode="url"
                    name="meetingLink"
                    placeholder="https://meet.google.com/abc-defg-hij"
                    value={meetingLink}
                    onChange={(e) => setMeetingLink(e.target.value)}
                    maxLength={MAX_MEETING_LINK}
                    aria-invalid={!!(meetingLink && !isValidUrl(meetingLink))}
                    aria-describedby={
                      meetingLink && !isValidUrl(meetingLink)
                        ? "meeting-link-error"
                        : undefined
                    }
                    className={
                      "w-full rounded-lg border px-3 py-2 text-sm focus:outline-none focus:ring-2 " +
                      (meetingLink && !isValidUrl(meetingLink)
                        ? "border-millenium-red bg-red-50 focus:ring-millenium-red/40"
                        : "border-gray-300 focus:ring-purple-500/40")
                    }
                  />
                  {meetingLink && !isValidUrl(meetingLink) ? (
                    <p
                      id="meeting-link-error"
                      role="alert"
                      className="mt-1 flex items-center gap-1 text-xs text-millenium-red"
                    >
                      <AlertCircle className="h-3 w-3 shrink-0" aria-hidden="true" />
                      <span>{getUrlError(meetingLink, "enlace de reunión")}</span>
                    </p>
                  ) : (
                    <p className="mt-1.5 flex items-center gap-1.5 text-sm text-gray-500">
                      <LinkIcon className="h-4 w-4" />
                      Compartido con los colaboradores en el correo de
                      invitación.
                    </p>
                  )}
                </div>
              </div>
            </Section>
          )}

          <Section label="Colaboradores (opcional)">
            <ParticipantPicker
              value={participants}
              onChange={setParticipants}
              alreadyIncludedIds={departmentMemberIds}
              alreadyIncludedReason="Ya incluido por departamento"
            />

            {blockedUsers.length > 0 && (
              <div className="mt-3 rounded-lg border border-amber-300 bg-amber-50 p-3 text-sm">
                <div className="flex items-start gap-2">
                  <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-amber-600" />
                  <div className="min-w-0 flex-1">
                    <p className="font-medium text-amber-900">
                      {blockedUsers.length === 1
                        ? "Un colaborador tiene un bloqueo personal a esa hora"
                        : `${blockedUsers.length} colaboradores tienen un bloqueo personal a esa hora`}
                    </p>
                    <ul className="mt-1 space-y-0.5 text-xs text-amber-700">
                      {blockedUsers.map((b) => (
                        <li key={`${b.userId}-${b.blockId}`}>
                          <strong>{b.userName}</strong> · {b.blockName}
                        </li>
                      ))}
                    </ul>
                    <p className="mt-2 text-xs text-amber-700">
                      Si confirmas, se les enviará una petición y deberán
                      aceptar para participar.
                    </p>
                  </div>
                </div>
              </div>
            )}
          </Section>

          {!isEditing && departments.length > 0 && (
            <Section label="Invitar departamentos (opcional)">
              <p className="mb-3 text-xs text-gray-500">
                Se invitará a todos los miembros activos del departamento al
                momento de crear la reunión.
              </p>

              {selectedDepartments.length > 0 && (
                <ul className="mb-3 space-y-2">
                  {selectedDepartments.map((d) => {
                    const isExpanded = expandedDepts.has(d.id);
                    const members = departmentMembersCache[d.id] || [];
                    const memberCount =
                      typeof d.memberCount === "number"
                        ? d.memberCount
                        : members.length;
                    return (
                      <li
                        key={d.id}
                        className="overflow-hidden rounded-lg border border-gray-200"
                      >
                        <div className="flex items-center gap-2 bg-gray-50 p-2">
                          <span
                            className="inline-block h-3 w-3 shrink-0 rounded-full"
                            style={{
                              backgroundColor: d.colorHex || "#475569",
                            }}
                          />
                          <span className="flex-1 truncate text-sm font-medium text-gray-900">
                            {d.name}
                          </span>
                          <span className="text-xs text-gray-500">
                            {memberCount}{" "}
                            {memberCount === 1 ? "miembro" : "miembros"}
                          </span>
                          <button
                            type="button"
                            onClick={() => toggleDeptExpanded(d.id)}
                            className="rounded p-1 text-gray-400 transition hover:bg-gray-200 hover:text-gray-700"
                            aria-expanded={isExpanded}
                            aria-label={
                              isExpanded
                                ? `Ocultar miembros de ${d.name}`
                                : `Ver miembros de ${d.name}`
                            }
                          >
                            <ChevronDown
                              className={
                                "h-4 w-4 transition-transform " +
                                (isExpanded ? "rotate-180" : "")
                              }
                            />
                          </button>
                          <button
                            type="button"
                            onClick={() =>
                              setSelectedDepartments((prev) =>
                                prev.filter((p) => p.id !== d.id)
                              )
                            }
                            className="rounded p-1 text-gray-400 transition hover:text-millenium-red"
                            aria-label={`Quitar departamento: ${d.name}`}
                          >
                            <X className="h-4 w-4" />
                          </button>
                        </div>

                        {isExpanded && (
                          <div className="max-h-48 space-y-1 overflow-y-auto border-t border-gray-200 bg-white p-2">
                            {members.length === 0 ? (
                              <p className="py-2 text-center text-xs text-gray-500">
                                No hay miembros activos en este departamento.
                              </p>
                            ) : (
                              members.map((m) => (
                                <div
                                  key={m.id}
                                  className="flex items-center gap-2 p-1.5 text-sm"
                                >
                                  {m.avatarUrl || m.fullName ? (
                                    <Avatar
                                      name={m.fullName || m.email}
                                      email={m.email}
                                      avatarUrl={m.avatarUrl}
                                      size="sm"
                                    />
                                  ) : (
                                    <span
                                      className="inline-flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-gray-200 text-gray-500"
                                      aria-hidden="true"
                                    >
                                      <Mail className="h-3.5 w-3.5" />
                                    </span>
                                  )}
                                  <div className="min-w-0 flex-1">
                                    <p className="truncate text-sm text-gray-700">
                                      {m.fullName || m.email}
                                    </p>
                                    {m.fullName && (
                                      <p className="truncate text-xs text-gray-500">
                                        {m.email}
                                      </p>
                                    )}
                                  </div>
                                </div>
                              ))
                            )}
                          </div>
                        )}
                      </li>
                    );
                  })}
                </ul>
              )}

              {showDeptPicker ? (
                <div className="rounded-lg border border-gray-200 bg-white p-2">
                  <div className="max-h-48 overflow-y-auto">
                    {departments
                      .filter(
                        (d) =>
                          !selectedDepartments.some((sel) => sel.id === d.id)
                      )
                      .map((d) => (
                        <button
                          key={d.id}
                          type="button"
                          onClick={() => {
                            setSelectedDepartments((prev) => [...prev, d]);
                          }}
                          className="flex w-full items-center gap-2 rounded p-2 text-left transition hover:bg-gray-50"
                        >
                          <span
                            className="inline-block h-3 w-3 shrink-0 rounded-full"
                            style={{
                              backgroundColor: d.colorHex || "#475569",
                            }}
                          />
                          <span className="flex-1 truncate text-sm text-gray-900">
                            {d.name}
                          </span>
                          {typeof d.memberCount === "number" && (
                            <span className="text-xs text-gray-400">
                              {d.memberCount}{" "}
                              {d.memberCount === 1 ? "miembro" : "miembros"}
                            </span>
                          )}
                        </button>
                      ))}
                    {departments.filter(
                      (d) =>
                        !selectedDepartments.some((sel) => sel.id === d.id)
                    ).length === 0 && (
                      <p className="px-2 py-3 text-center text-xs text-gray-500">
                        Ya agregaste todos los departamentos disponibles.
                      </p>
                    )}
                  </div>
                  <button
                    type="button"
                    onClick={() => setShowDeptPicker(false)}
                    className="mt-2 w-full rounded p-1 text-xs text-gray-500 transition hover:bg-gray-50"
                  >
                    Cerrar
                  </button>
                </div>
              ) : (
                <button
                  type="button"
                  onClick={() => setShowDeptPicker(true)}
                  className="inline-flex items-center gap-1.5 text-sm font-medium text-millenium-blue hover:underline"
                >
                  <Plus className="h-4 w-4" />
                  Agregar departamento
                </button>
              )}
            </Section>
          )}

          <Section label="Invitados externos (opcional)">
            <p className="mb-3 text-xs text-gray-500">
              Correos de clientes o personas externas a la empresa. Puedes
              elegir si enviarles la invitación por correo.
            </p>

            {/* Invitados ya guardados (modo edición) */}
            {existingGuests.length > 0 && (
              <ul className="mb-3 space-y-2">
                {existingGuests.map((g) => (
                  <li
                    key={g.guestId}
                    className="flex items-center gap-2 rounded bg-gray-50 p-2"
                  >
                    <Mail className="h-4 w-4 shrink-0 text-gray-400" />
                    <div className="min-w-0 flex-1">
                      <p
                        className="truncate text-sm text-gray-900"
                        title={g.displayName || g.email}
                      >
                        {g.displayName || g.email}
                      </p>
                      {g.displayName && (
                        <p
                          className="truncate text-xs text-gray-500"
                          title={g.email}
                        >
                          {g.email}
                        </p>
                      )}
                    </div>
                    {g.notified && (
                      <span className="inline-flex shrink-0 items-center gap-1 text-xs text-millenium-green">
                        <Check className="h-3 w-3" />
                        Notificado
                      </span>
                    )}
                    <button
                      type="button"
                      onClick={() => removeExistingGuest(g.guestId)}
                      className="rounded p-1 text-gray-400 hover:text-millenium-red"
                      aria-label="Quitar invitado"
                    >
                      <X className="h-4 w-4" />
                    </button>
                  </li>
                ))}
              </ul>
            )}

            {/* Invitados nuevos en este form (pendientes de POST) */}
            {externalGuests.length > 0 && (
              <ul className="mb-3 space-y-2">
                {externalGuests.map((g, idx) => (
                  <li
                    key={`new-${idx}`}
                    className="flex items-center gap-2 rounded bg-millenium-blue/5 p-2"
                  >
                    <Mail className="h-4 w-4 shrink-0 text-gray-400" />
                    <div className="min-w-0 flex-1">
                      <p
                        className="truncate text-sm text-gray-900"
                        title={g.displayName || g.email}
                      >
                        {g.displayName || g.email}
                      </p>
                      {g.displayName && (
                        <p
                          className="truncate text-xs text-gray-500"
                          title={g.email}
                        >
                          {g.email}
                        </p>
                      )}
                    </div>
                    {g.sendInvitation && (
                      <span className="inline-flex shrink-0 items-center gap-1 text-xs text-millenium-blue">
                        <Send className="h-3 w-3" />
                        Invitación
                      </span>
                    )}
                    <button
                      type="button"
                      onClick={() => removeNewGuest(idx)}
                      className="rounded p-1 text-gray-400 hover:text-millenium-red"
                      aria-label="Quitar invitado"
                    >
                      <X className="h-4 w-4" />
                    </button>
                  </li>
                ))}
              </ul>
            )}

            {/* Form para agregar nuevo */}
            <div className="grid grid-cols-1 gap-2 md:grid-cols-2">
              <div>
                <label
                  htmlFor="new-guest-email"
                  className="mb-1 block text-xs font-medium text-gray-700"
                >
                  Correo del invitado
                </label>
                <input
                  id="new-guest-email"
                  type="email"
                  inputMode="email"
                  value={newGuestEmail}
                  onChange={(e) => setNewGuestEmail(e.target.value)}
                  placeholder="cliente@empresa.com"
                  maxLength={254}
                  className="w-full rounded border border-gray-300 px-3 py-2 text-sm focus:border-millenium-blue focus:outline-none focus:ring-2 focus:ring-millenium-blue/20"
                />
              </div>
              <div>
                <label
                  htmlFor="new-guest-name"
                  className="mb-1 block text-xs font-medium text-gray-700"
                >
                  Nombre <span className="text-gray-500">(opcional)</span>
                </label>
                <input
                  id="new-guest-name"
                  type="text"
                  value={newGuestName}
                  onChange={(e) => setNewGuestName(e.target.value)}
                  placeholder="Juan Pérez"
                  maxLength={120}
                  className="w-full rounded border border-gray-300 px-3 py-2 text-sm focus:border-millenium-blue focus:outline-none focus:ring-2 focus:ring-millenium-blue/20"
                />
              </div>
            </div>
            <label className="mt-2 flex cursor-pointer items-center gap-2 text-sm">
              <input
                type="checkbox"
                checked={newGuestSendInvitation}
                onChange={(e) =>
                  setNewGuestSendInvitation(e.target.checked)
                }
                className="h-4 w-4 rounded border-gray-300 text-millenium-blue focus:ring-millenium-blue/40"
              />
              <span className="text-gray-700">
                Enviar invitación por correo a este invitado
              </span>
            </label>
            <button
              type="button"
              onClick={addNewGuest}
              disabled={!isValidEmail(newGuestEmail)}
              className="mt-2 inline-flex items-center gap-1.5 text-sm font-medium text-millenium-blue hover:underline disabled:cursor-not-allowed disabled:text-gray-400 disabled:no-underline"
            >
              <Plus className="h-4 w-4" />
              Agregar invitado
            </button>
          </Section>
        </div>
      </fieldset>

      <div className="sticky-footer sticky bottom-0 z-20 -mx-6 border-t border-gray-200 bg-white/95 px-6 pt-4 backdrop-blur md:-mx-8 md:px-8">
        <div className="flex flex-col items-stretch gap-2 sm:flex-row sm:items-center sm:justify-between">
          <div className="truncate text-base text-gray-600">
            {isExternalType ? (
              <span>
                <span className="font-medium text-gray-900">
                  Fuera de oficina
                </span>
                <span className="text-gray-400"> · </span>
                <span>{summaryDate}</span>
                {selectionRangeLabel && (
                  <>
                    <span className="text-gray-400"> · </span>
                    <span className="font-medium text-gray-900">
                      {selectionRangeLabel}
                    </span>
                  </>
                )}
              </span>
            ) : isVirtualType ? (
              <span>
                <span className="font-medium text-gray-900">
                  Reunión virtual
                </span>
                <span className="text-gray-400"> · </span>
                <span>{summaryDate}</span>
                {selectionRangeLabel && (
                  <>
                    <span className="text-gray-400"> · </span>
                    <span className="font-medium text-gray-900">
                      {selectionRangeLabel}
                    </span>
                  </>
                )}
              </span>
            ) : selectedRoom ? (
              <span>
                <span className="font-medium text-gray-900">
                  {selectedRoom.name}
                </span>
                <span className="text-gray-400"> · </span>
                <span>{summaryDate}</span>
                {selectionRangeLabel && (
                  <>
                    <span className="text-gray-400"> · </span>
                    <span className="font-medium text-gray-900">
                      {selectionRangeLabel}
                    </span>
                  </>
                )}
              </span>
            ) : (
              <span className="text-gray-500">
                Elija una sala, fecha y hora para continuar
              </span>
            )}
          </div>
          <div className="flex justify-end gap-2">
            <Button
              type="button"
              variant="outline"
              onClick={() => router.back()}
            >
              Cancelar
            </Button>
            <Button
              type="submit"
              variant="primary"
              loading={submitting}
              disabled={!canSubmit || submitting}
            >
              <Check className="h-4 w-4" />
              {submitting
                ? "Agendando..."
                : isEditing
                  ? "Guardar cambios"
                  : conflictInfo?.conflict
                    ? "Intentar reservar de todos modos"
                    : "Confirmar reunión"}
            </Button>
          </div>
        </div>
      </div>

      {showEditChoice && (
        <EditRecurringChoiceModal
          onClose={() => setShowEditChoice(false)}
          onChoice={(choice) => {
            setShowEditChoice(false);
            submitWithChoice(choice);
          }}
        />
      )}
    </form>
  );
}
