"use client";

interface Props {
  className?: string;
}

/**
 * Skeleton con shimmer. Usa la animacion `animate-shimmer` definida en
 * globals.css.
 */
export default function Skeleton({ className = "" }: Props) {
  return <div className={`animate-shimmer ${className}`} aria-hidden="true" />;
}
