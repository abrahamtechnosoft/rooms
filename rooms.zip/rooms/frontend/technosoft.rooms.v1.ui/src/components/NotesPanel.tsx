"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { Plus, RefreshCw } from "lucide-react";
import api from "@/lib/api";
import NoteCard from "@/components/NoteCard";
import NoteFormModal from "@/components/NoteFormModal";
import type { NoteVisibility, Reply, UserNote } from "@/types";

interface Props {
  currentUserId: number;
  currentUserDeptId: number | null;
}

type Tab = "personal" | "department";

export default function NotesPanel({
  currentUserId,
  currentUserDeptId,
}: Props) {
  const [tab, setTab] = useState<Tab>("personal");
  const [notes, setNotes] = useState<UserNote[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [editingNote, setEditingNote] = useState<UserNote | null>(null);
  const [creatingFor, setCreatingFor] = useState<NoteVisibility | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(false);
    try {
      const res = await api.get<Reply<UserNote[]>>("/notes");
      setNotes(res.data.obj || []);
    } catch {
      setError(true);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const filtered = useMemo(
    () =>
      notes.filter((n) =>
        tab === "personal"
          ? n.visibility === "personal"
          : n.visibility === "department"
      ),
    [notes, tab]
  );

  const handleSaved = () => {
    setEditingNote(null);
    setCreatingFor(null);
    load();
  };

  const canCreateDept = currentUserDeptId !== null;

  return (
    <div className="flex h-full flex-col rounded-lg border border-gray-200 bg-white">
      {/* Header con tabs */}
      <div className="flex items-center justify-between border-b border-gray-200 px-3 py-2">
        <div className="flex gap-1">
          <button
            type="button"
            onClick={() => setTab("personal")}
            className={
              "rounded-md px-2.5 py-1 text-xs font-medium transition-colors " +
              (tab === "personal"
                ? "bg-millenium-blue text-white"
                : "text-gray-600 hover:bg-gray-100")
            }
            aria-pressed={tab === "personal"}
          >
            Mis notas
          </button>
          <button
            type="button"
            onClick={() => setTab("department")}
            disabled={!canCreateDept}
            title={!canCreateDept ? "Sin departamento asignado" : undefined}
            className={
              "rounded-md px-2.5 py-1 text-xs font-medium transition-colors disabled:cursor-not-allowed disabled:opacity-50 " +
              (tab === "department"
                ? "bg-millenium-blue text-white"
                : "text-gray-600 hover:bg-gray-100")
            }
            aria-pressed={tab === "department"}
          >
            Departamento
          </button>
        </div>
        <button
          type="button"
          onClick={() => setCreatingFor(tab)}
          disabled={tab === "department" && !canCreateDept}
          className="inline-flex items-center gap-1 rounded-md bg-millenium-blue px-2 py-1 text-xs font-medium text-white transition hover:opacity-90 disabled:cursor-not-allowed disabled:opacity-50"
        >
          <Plus className="h-3 w-3" />
          Nueva
        </button>
      </div>

      {/* Body */}
      <div className="min-h-0 flex-1 space-y-2 overflow-y-auto p-3">
        {loading ? (
          <div className="space-y-2">
            <div className="h-20 animate-pulse rounded bg-gray-100" />
            <div className="h-20 animate-pulse rounded bg-gray-100" />
            <div className="h-20 animate-pulse rounded bg-gray-100" />
          </div>
        ) : error ? (
          <div className="py-8 text-center">
            <p className="mb-2 text-sm text-gray-500">
              No se pudieron cargar las notas
            </p>
            <button
              type="button"
              onClick={load}
              className="inline-flex items-center gap-1 text-xs font-medium text-millenium-blue hover:underline"
            >
              <RefreshCw className="h-3 w-3" />
              Reintentar
            </button>
          </div>
        ) : filtered.length === 0 ? (
          <div className="py-8 text-center">
            <p className="mb-3 text-sm text-gray-400">Sin notas todavía</p>
            <button
              type="button"
              onClick={() => setCreatingFor(tab)}
              disabled={tab === "department" && !canCreateDept}
              className="text-xs font-medium text-millenium-blue hover:underline disabled:cursor-not-allowed disabled:opacity-50"
            >
              Crear primera nota
            </button>
          </div>
        ) : (
          filtered.map((note) => (
            <NoteCard
              key={note.noteId}
              note={note}
              isOwn={note.authorId === currentUserId}
              showAuthor={tab === "department"}
              onEdit={() => setEditingNote(note)}
              onChanged={load}
            />
          ))
        )}
      </div>

      {(creatingFor || editingNote) && (
        <NoteFormModal
          note={editingNote}
          defaultVisibility={
            creatingFor ?? (editingNote ? editingNote.visibility : "personal")
          }
          canCreateDept={canCreateDept}
          onSaved={handleSaved}
          onCancel={() => {
            setCreatingFor(null);
            setEditingNote(null);
          }}
        />
      )}
    </div>
  );
}
