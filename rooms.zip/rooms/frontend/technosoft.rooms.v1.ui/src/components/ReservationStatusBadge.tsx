import type { ReservationVisualStatus } from "@/lib/reservationStatus";

type Size = "sm" | "md";
type Props = { status: ReservationVisualStatus; size?: Size };

const sizeCls: Record<Size, string> = {
  sm: "px-2.5 py-1 text-xs",
  md: "px-3 py-1.5 text-sm",
};

const dotCls: Record<Size, string> = {
  sm: "h-2 w-2",
  md: "h-2.5 w-2.5",
};

export default function ReservationStatusBadge({ status, size = "sm" }: Props) {
  const sz = sizeCls[size];
  const dot = dotCls[size];

  if (status === "live") {
    return (
      <span
        className={`inline-flex items-center gap-1.5 rounded-full border border-green-200 bg-green-50 font-medium text-millenium-green ${sz}`}
      >
        <span className={`relative flex ${dot}`}>
          <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-millenium-green opacity-75"></span>
          <span
            className={`relative inline-flex rounded-full bg-millenium-green ${dot}`}
          ></span>
        </span>
        En curso
      </span>
    );
  }

  if (status === "upcoming") {
    return (
      <span
        className={`inline-flex items-center rounded-full border border-blue-200 bg-blue-50 font-medium text-millenium-blue ${sz}`}
      >
        Próxima
      </span>
    );
  }

  if (status === "past") {
    return (
      <span
        className={`inline-flex items-center rounded-full border border-gray-200 bg-gray-100 font-medium text-gray-500 ${sz}`}
      >
        Finalizada
      </span>
    );
  }

  return (
    <span
      className={`inline-flex items-center rounded-full border border-red-200 bg-red-50 font-medium text-millenium-red ${sz}`}
    >
      Cancelada
    </span>
  );
}
