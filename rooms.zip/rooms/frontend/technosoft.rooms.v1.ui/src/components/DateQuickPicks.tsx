"use client";

import { useMemo } from "react";
import { format, addDays, isSameDay } from "date-fns";
import { es } from "date-fns/locale";
import { Calendar } from "lucide-react";

interface Props {
  value: string;
  onChange: (yyyymmdd: string) => void;
  onOpenMore: () => void;
}

const pad = (n: number) => String(n).padStart(2, "0");

const toIso = (d: Date): string =>
  `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;

const parseYmd = (ymd: string): Date => {
  const [y, m, d] = ymd.split("-").map((v) => parseInt(v, 10));
  return new Date(y, (m || 1) - 1, d || 1, 0, 0, 0, 0);
};

const cap = (s: string) =>
  s.length === 0 ? s : s[0].toUpperCase() + s.slice(1);

const labelOf = (d: Date, today: Date): string => {
  if (isSameDay(d, today)) return "Hoy";
  if (isSameDay(d, addDays(today, 1))) return "Mañana";
  return `${cap(format(d, "EEE", { locale: es }))} ${d.getDate()}`;
};

export default function DateQuickPicks({
  value,
  onChange,
  onOpenMore,
}: Props) {
  const today = useMemo(() => {
    const t = new Date();
    t.setHours(0, 0, 0, 0);
    return t;
  }, []);

  const days = useMemo(
    () => [0, 1, 2, 3, 4].map((i) => addDays(today, i)),
    [today]
  );

  const selectedDate = parseYmd(value);
  const isOutOfQuickRange = !days.some((d) => isSameDay(d, selectedDate));
  const moreActive = isOutOfQuickRange;
  const moreLabel = isOutOfQuickRange
    ? `${cap(format(selectedDate, "EEE", { locale: es }))} ${selectedDate.getDate()} ${cap(format(selectedDate, "MMM", { locale: es }))}`
    : "Más fechas";

  return (
    <div className="-mx-1 flex flex-wrap items-center gap-2 px-1 pb-1">
      {days.map((d) => {
        const iso = toIso(d);
        const active = iso === value;
        return (
          <button
            key={iso}
            type="button"
            aria-pressed={active}
            onClick={() => onChange(iso)}
            className={
              "inline-flex shrink-0 items-center whitespace-nowrap rounded-full px-3 py-1.5 text-sm font-medium transition " +
              (active
                ? "bg-millenium-blue text-white"
                : "border border-gray-200 bg-white text-gray-700 hover:border-gray-300")
            }
          >
            {labelOf(d, today)}
          </button>
        );
      })}
      <button
        type="button"
        onClick={onOpenMore}
        aria-pressed={moreActive}
        className={
          "inline-flex shrink-0 items-center gap-1.5 whitespace-nowrap rounded-full px-3 py-1.5 text-sm font-medium transition " +
          (moreActive
            ? "bg-millenium-blue text-white"
            : "border border-gray-200 bg-white text-gray-700 hover:border-gray-300")
        }
      >
        <Calendar className="h-4 w-4" />
        {moreLabel}
      </button>
    </div>
  );
}
