"use client";

import { useEffect, useState } from "react";
import {
  ChevronDown,
  ChevronUp,
  Edit2,
  Loader2,
  MessageSquare,
  Plus,
  Reply as ReplyIcon,
  Trash2,
} from "lucide-react";
import { toast } from "@/lib/toastHelpers";
import api from "@/lib/api";
import Avatar from "@/components/Avatar";
import type { NoteEdit, Reply, ThreadedNote } from "@/types";

interface Props {
  reservationId: number;
  canEdit: boolean;
  currentUserId: number | null;
  isOrganizer?: boolean;
  isAdmin?: boolean;
}

const MAX_NOTE = 1000;

function formatRelativeTime(iso: string): string {
  const date = new Date(iso);
  const diffMs = Date.now() - date.getTime();
  const diffMin = Math.floor(diffMs / 60000);
  const diffHr = Math.floor(diffMin / 60);
  const diffDay = Math.floor(diffHr / 24);
  if (diffMin < 1) return "Hace un momento";
  if (diffMin < 60)
    return `Hace ${diffMin} ${diffMin === 1 ? "minuto" : "minutos"}`;
  if (diffHr < 24) return `Hace ${diffHr} ${diffHr === 1 ? "hora" : "horas"}`;
  if (diffDay < 7) return `Hace ${diffDay} ${diffDay === 1 ? "día" : "días"}`;
  return date.toLocaleDateString("es", { day: "numeric", month: "short" });
}

export default function NotesList({
  reservationId,
  canEdit,
  currentUserId,
  isOrganizer = false,
  isAdmin = false,
}: Props) {
  const [notes, setNotes] = useState<ThreadedNote[]>([]);
  const [loading, setLoading] = useState(false);
  const [adding, setAdding] = useState(false);
  const [newContent, setNewContent] = useState("");
  const [replyParentId, setReplyParentId] = useState<number | null>(null);
  const [replyContent, setReplyContent] = useState("");
  const [editingId, setEditingId] = useState<number | null>(null);
  const [editingContent, setEditingContent] = useState("");
  const [submitting, setSubmitting] = useState(false);
  // G3 — Acordeon inline para el historial de ediciones. Solo se expande una
  // nota a la vez. `editsByNote` cachea las versiones cargadas por noteId.
  const [expandedEditsNoteId, setExpandedEditsNoteId] = useState<number | null>(
    null
  );
  const [editsByNote, setEditsByNote] = useState<Record<number, NoteEdit[]>>(
    {}
  );
  const [loadingEditsId, setLoadingEditsId] = useState<number | null>(null);

  const load = async () => {
    setLoading(true);
    try {
      const res = await api.get<Reply<ThreadedNote[]>>(
        `/reservations/${reservationId}/notes`
      );
      setNotes(res.data.obj || []);
    } catch {
      // silencioso
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [reservationId]);

  async function handleAdd() {
    if (newContent.trim().length === 0 || submitting) return;
    setSubmitting(true);
    try {
      const res = await api.post<Reply<unknown>>(
        `/reservations/${reservationId}/notes`,
        { content: newContent.trim() }
      );
      if (!res.data.ok) {
        toast.error(res.data.msg || "No fue posible agregar la nota");
        return;
      }
      // La nota aparece en la lista al recargar, sin toast.
      await load();
      setNewContent("");
      setAdding(false);
    } catch (e: unknown) {
      const errObj = e as { response?: { data?: { msg?: string } } };
      toast.error(
        errObj?.response?.data?.msg || "No fue posible agregar la nota"
      );
    } finally {
      setSubmitting(false);
    }
  }

  async function handleReply(parentId: number) {
    if (replyContent.trim().length === 0 || submitting) return;
    setSubmitting(true);
    try {
      const res = await api.post<Reply<unknown>>(
        `/reservations/${reservationId}/notes`,
        { content: replyContent.trim(), parentNoteId: parentId }
      );
      if (!res.data.ok) {
        toast.error(res.data.msg || "No fue posible responder");
        return;
      }
      // La respuesta aparece anidada al recargar, sin toast.
      await load();
      setReplyParentId(null);
      setReplyContent("");
    } catch (e: unknown) {
      const errObj = e as { response?: { data?: { msg?: string } } };
      toast.error(
        errObj?.response?.data?.msg || "No fue posible responder"
      );
    } finally {
      setSubmitting(false);
    }
  }

  async function handleSaveEdit(noteId: number) {
    if (editingContent.trim().length === 0 || submitting) return;
    setSubmitting(true);
    try {
      const res = await api.patch<Reply<unknown>>(
        `/reservations/${reservationId}/notes/${noteId}`,
        { content: editingContent.trim() }
      );
      if (!res.data.ok) {
        toast.error(res.data.msg || "No fue posible actualizar la nota");
        return;
      }
      // El contenido se actualiza en su lugar al recargar, sin toast.
      await load();
      setEditingId(null);
      setEditingContent("");
    } catch (e: unknown) {
      const errObj = e as { response?: { data?: { msg?: string } } };
      toast.error(
        errObj?.response?.data?.msg || "No fue posible actualizar la nota"
      );
    } finally {
      setSubmitting(false);
    }
  }

  async function handleDelete(noteId: number) {
    if (submitting) return;
    if (!window.confirm("¿Eliminar esta nota?")) return;
    setSubmitting(true);
    try {
      await api.delete(`/reservations/${reservationId}/notes/${noteId}`);
      await load();
      toast.success("Nota eliminada");
    } catch (e: unknown) {
      const errObj = e as { response?: { data?: { msg?: string } } };
      toast.error(
        errObj?.response?.data?.msg || "No fue posible eliminar la nota"
      );
    } finally {
      setSubmitting(false);
    }
  }

  function canEditNote(n: ThreadedNote): boolean {
    return !n.isDeleted && n.authorId === currentUserId;
  }
  function canDeleteNote(n: ThreadedNote): boolean {
    if (n.isDeleted) return false;
    return n.authorId === currentUserId || isOrganizer || isAdmin;
  }
  function canSeeEdits(n: ThreadedNote): boolean {
    if (n.editCount === 0) return false;
    if (isAdmin) return true;
    if (isOrganizer) return true;
    return false;
  }

  async function handleToggleEdits(noteId: number) {
    // Comportamiento "uno a la vez": si ya esta expandido, colapsar.
    if (expandedEditsNoteId === noteId) {
      setExpandedEditsNoteId(null);
      return;
    }
    // Cargar el historial si todavia no esta en cache.
    if (!editsByNote[noteId]) {
      setLoadingEditsId(noteId);
      try {
        const res = await api.get<Reply<NoteEdit[]>>(
          `/reservations/${reservationId}/notes/${noteId}/edits`
        );
        const data = res.data.obj ?? [];
        setEditsByNote((prev) => ({ ...prev, [noteId]: data }));
      } catch (e: unknown) {
        const errObj = e as { response?: { data?: { msg?: string } } };
        toast.error(
          errObj?.response?.data?.msg || "No fue posible cargar el historial"
        );
        setLoadingEditsId(null);
        return;
      }
      setLoadingEditsId(null);
    }
    setExpandedEditsNoteId(noteId);
  }

  function renderNote(note: ThreadedNote, isReply: boolean) {
    const isEditing = editingId === note.noteId;
    const isReplying = replyParentId === note.noteId;
    return (
      <div
        key={note.noteId}
        className={
          "rounded-lg border border-gray-200 bg-gray-50 p-3 " +
          (isReply ? "ml-6 border-l-2 border-l-millenium-blue/30 bg-white" : "")
        }
      >
        {isEditing ? (
          <div>
            <textarea
              value={editingContent}
              onChange={(e) => setEditingContent(e.target.value)}
              maxLength={MAX_NOTE}
              rows={4}
              className="w-full rounded border border-gray-300 bg-white p-2 text-sm focus:border-millenium-blue focus:outline-none focus:ring-2 focus:ring-millenium-blue/20"
            />
            <p className="mt-1 text-right text-xs text-gray-500 tabular-nums">
              {editingContent.length}/{MAX_NOTE}
            </p>
            <div className="mt-2 flex justify-end gap-2">
              <button
                type="button"
                onClick={() => {
                  setEditingId(null);
                  setEditingContent("");
                }}
                className="text-xs text-gray-600 hover:text-gray-900"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={() => handleSaveEdit(note.noteId)}
                disabled={submitting}
                className="rounded bg-millenium-blue px-2 py-1 text-xs font-medium text-white disabled:opacity-50"
              >
                Guardar
              </button>
            </div>
          </div>
        ) : (
          <>
            <div className="mb-2 flex items-start gap-2">
              <Avatar
                name={note.authorName}
                email={note.authorEmail}
                avatarUrl={note.authorAvatarUrl}
                noDefaultSize
                className="h-6 w-6 text-[10px]"
              />
              <div className="min-w-0 flex-1">
                <p className="text-xs text-gray-600">
                  <span className="font-medium text-gray-900">
                    {note.authorName || note.authorEmail}
                  </span>
                  <span className="text-gray-400">
                    {" · "}
                    {formatRelativeTime(note.createdAt)}
                  </span>
                  {note.editCount > 0 &&
                    (canSeeEdits(note) ? (
                      <button
                        type="button"
                        onClick={() => handleToggleEdits(note.noteId)}
                        className="ml-1 inline-flex items-center italic text-gray-400 hover:text-millenium-blue hover:underline"
                        title={
                          expandedEditsNoteId === note.noteId
                            ? "Ocultar historial"
                            : "Ver historial de ediciones"
                        }
                      >
                        · editada
                        {note.editCount > 1 ? ` (${note.editCount} veces)` : ""}
                        {expandedEditsNoteId === note.noteId ? (
                          <ChevronUp className="ml-0.5 inline h-3 w-3" />
                        ) : (
                          <ChevronDown className="ml-0.5 inline h-3 w-3" />
                        )}
                      </button>
                    ) : (
                      <span
                        className="ml-1 italic text-gray-400"
                        title="La nota fue editada"
                      >
                        · editada
                      </span>
                    ))}
                  {note.isDeleted && (
                    <span className="ml-1 italic text-gray-400">
                      · eliminada
                    </span>
                  )}
                </p>
              </div>
              {!note.isDeleted && (
                <div className="flex shrink-0 gap-1">
                  {canEditNote(note) && (
                    <button
                      type="button"
                      onClick={() => {
                        setEditingId(note.noteId);
                        setEditingContent(note.content);
                      }}
                      className="rounded p-1 text-gray-400 hover:text-gray-700"
                      aria-label="Editar"
                    >
                      <Edit2 className="h-3.5 w-3.5" />
                    </button>
                  )}
                  {canDeleteNote(note) && (
                    <button
                      type="button"
                      onClick={() => handleDelete(note.noteId)}
                      className="rounded p-1 text-gray-400 hover:text-millenium-red"
                      aria-label="Eliminar"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  )}
                </div>
              )}
            </div>
            <p
              className={
                note.isDeleted
                  ? "whitespace-pre-wrap text-sm italic text-gray-400"
                  : "whitespace-pre-wrap text-sm text-gray-900"
              }
            >
              {note.content}
            </p>

            {/* Acordeon inline con historial de ediciones (organizador / admin). */}
            {expandedEditsNoteId === note.noteId && (
              <div className="mt-2 rounded-md border border-gray-200 bg-gray-50 p-3">
                <div className="mb-2 text-xs font-semibold text-gray-600">
                  Historial de versiones
                </div>
                {loadingEditsId === note.noteId ? (
                  <div className="flex items-center gap-2 text-xs text-gray-500">
                    <Loader2 className="h-3 w-3 animate-spin" />
                    Cargando historial...
                  </div>
                ) : editsByNote[note.noteId]?.length ? (
                  <ul className="space-y-2">
                    {editsByNote[note.noteId].map((edit, idx) => (
                      <li
                        key={edit.id}
                        className="border-l-2 border-gray-300 pl-3"
                      >
                        <div className="mb-1 text-xs text-gray-500">
                          Versión{" "}
                          {editsByNote[note.noteId].length - idx} · editada por{" "}
                          <span className="font-medium text-gray-700">
                            {edit.editedByName || edit.editedByEmail}
                          </span>
                          {" · "}
                          {formatRelativeTime(edit.editedAt)}
                        </div>
                        <div className="whitespace-pre-wrap text-sm text-gray-700">
                          {edit.previousContent}
                        </div>
                      </li>
                    ))}
                  </ul>
                ) : (
                  <div className="text-xs text-gray-500">
                    No hay versiones previas.
                  </div>
                )}
              </div>
            )}

            {/* Acción "responder" solo para notas raíz (no a respuestas) */}
            {!isReply && !note.isDeleted && canEdit && (
              <div className="mt-2">
                {isReplying ? (
                  <div className="rounded border border-millenium-blue/40 bg-white p-2">
                    <textarea
                      value={replyContent}
                      onChange={(e) => setReplyContent(e.target.value)}
                      placeholder={`Responder a ${note.authorName || note.authorEmail}...`}
                      maxLength={MAX_NOTE}
                      rows={2}
                      autoFocus
                      className="w-full rounded border border-gray-300 p-2 text-sm focus:border-millenium-blue focus:outline-none focus:ring-2 focus:ring-millenium-blue/20"
                    />
                    <div className="mt-1 flex items-center justify-between">
                      <span className="text-xs text-gray-500 tabular-nums">
                        {replyContent.length}/{MAX_NOTE}
                      </span>
                      <div className="flex gap-2">
                        <button
                          type="button"
                          onClick={() => {
                            setReplyParentId(null);
                            setReplyContent("");
                          }}
                          className="text-xs text-gray-600 hover:text-gray-900"
                        >
                          Cancelar
                        </button>
                        <button
                          type="button"
                          onClick={() => handleReply(note.noteId)}
                          disabled={
                            submitting || replyContent.trim().length === 0
                          }
                          className="inline-flex items-center gap-1 rounded bg-millenium-blue px-2 py-1 text-xs font-medium text-white disabled:opacity-50"
                        >
                          {submitting && (
                            <Loader2 className="h-3 w-3 animate-spin" />
                          )}
                          Responder
                        </button>
                      </div>
                    </div>
                  </div>
                ) : (
                  <button
                    type="button"
                    onClick={() => {
                      setReplyParentId(note.noteId);
                      setReplyContent("");
                    }}
                    className="inline-flex items-center gap-1 text-xs text-millenium-blue hover:underline"
                  >
                    <ReplyIcon className="h-3 w-3" />
                    Responder
                  </button>
                )}
              </div>
            )}

            {note.replies && note.replies.length > 0 && (
              <div className="mt-2 space-y-2">
                {note.replies.map((reply) => renderNote(reply, true))}
              </div>
            )}
          </>
        )}
      </div>
    );
  }

  return (
    <div className="space-y-3">
      <h4 className="flex items-center gap-2 text-sm font-semibold text-gray-700">
        <MessageSquare className="h-4 w-4" />
        Notas
        {notes.length > 0 && (
          <span className="text-xs font-normal text-gray-400">
            ({notes.length})
          </span>
        )}
      </h4>

      {loading && notes.length === 0 && (
        <p className="text-sm text-gray-500">Cargando notas…</p>
      )}

      {!loading && notes.length === 0 && !adding && (
        <p className="text-sm italic text-gray-500">Sin notas todavía.</p>
      )}

      {notes.map((note) => renderNote(note, false))}

      {canEdit && !adding && (
        <button
          type="button"
          onClick={() => setAdding(true)}
          className="flex w-full items-center justify-center gap-2 rounded-lg border border-dashed border-gray-300 px-3 py-2 text-sm text-millenium-blue transition hover:bg-gray-50"
        >
          <Plus className="h-4 w-4" />
          Agregar nota
        </button>
      )}

      {adding && (
        <div className="rounded-lg border border-millenium-blue bg-white p-3">
          <textarea
            value={newContent}
            onChange={(e) => setNewContent(e.target.value)}
            maxLength={MAX_NOTE}
            rows={3}
            placeholder="Acuerdos, próximos pasos, comentarios…"
            autoFocus
            className="w-full rounded border border-gray-300 p-2 text-sm focus:border-millenium-blue focus:outline-none focus:ring-2 focus:ring-millenium-blue/20"
          />
          <p className="mt-1 text-right text-xs text-gray-500 tabular-nums">
            {newContent.length}/{MAX_NOTE}
          </p>
          <div className="mt-2 flex justify-end gap-2">
            <button
              type="button"
              onClick={() => {
                setAdding(false);
                setNewContent("");
              }}
              className="text-sm text-gray-600 hover:text-gray-900"
            >
              Cancelar
            </button>
            <button
              type="button"
              onClick={handleAdd}
              disabled={newContent.trim().length === 0 || submitting}
              className="inline-flex items-center gap-1.5 rounded bg-millenium-blue px-3 py-1 text-sm font-medium text-white disabled:opacity-50"
            >
              {submitting && <Loader2 className="h-3.5 w-3.5 animate-spin" />}
              {submitting ? "Guardando…" : "Guardar nota"}
            </button>
          </div>
        </div>
      )}

    </div>
  );
}
