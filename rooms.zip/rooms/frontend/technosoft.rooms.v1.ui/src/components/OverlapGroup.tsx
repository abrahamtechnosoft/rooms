"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import type { CSSProperties } from "react";
import type { Reservation } from "@/types";
import type { OverlapItem } from "@/lib/timelineLayout";
import TimelineBlock from "@/components/TimelineBlock";
import { effectiveEndsAt } from "@/lib/reservationStatus";

interface Props {
  items: OverlapItem[];
  now: Date;
  /** Pixeles por hora — usado para picar variante (large/medium/compact). */
  hourHeightPx: number;
  largeMaxAvatars?: number;
  /** Padding lateral del item (en px). Default 1. */
  edgePx?: number;
  onReservationClick: (r: Reservation) => void;
  onOverflowClick: (hidden: Reservation[], anchorRect: DOMRect) => void;
}

const HOVER_ENTER_DELAY_MS = 150;

function durationMin(meeting: Reservation): number {
  const start = new Date(meeting.startsAt).getTime();
  const end = new Date(effectiveEndsAt(meeting)).getTime();
  return Math.max(0, (end - start) / 60000);
}

/**
 * Envuelve las cards de un mismo grupo de solape.
 *
 * Hover behavior:
 *   - Entrar en una card: dispara debounce de 150 ms. Si el mouse se queda
 *     ese tiempo, la card crece al 80% del area visible y las hermanas se
 *     reparten el 20% restante manteniendo su orden de columnas. Las cards
 *     NO se reordenan ni se mueven a la izquierda — solo cambia su ancho
 *     y, cuando aplica, su `leftPct` para quedar pegadas a la card en foco.
 *   - Salir del grupo: vuelta al layout original instantanea (sin debounce).
 *   - Chip "+N" nunca se mueve ni se encoge.
 *
 * El componente mide su contenedor padre via ResizeObserver para poder
 * calcular el ancho real en pixeles de cada card y pasarlo al
 * `TimelineBlock`. Asi la variante (large/medium/compact) se decide en
 * base al ancho efectivo, no solo a la altura.
 */
export default function OverlapGroup({
  items,
  now,
  hourHeightPx,
  largeMaxAvatars = 5,
  edgePx = 1,
  onReservationClick,
  onOverflowClick,
}: Props) {
  // hoveredCol = intent del mouse (cambia al instante).
  // debouncedHover = lo que efectivamente dispara el layout (con delay al
  // entrar para evitar disparos por "mouse de paso", instantaneo al salir).
  const [hoveredCol, setHoveredCol] = useState<number | null>(null);
  const [debouncedHover, setDebouncedHover] = useState<number | null>(null);
  const enterTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    if (enterTimerRef.current) {
      clearTimeout(enterTimerRef.current);
      enterTimerRef.current = null;
    }
    if (hoveredCol !== null) {
      enterTimerRef.current = setTimeout(() => {
        setDebouncedHover(hoveredCol);
      }, HOVER_ENTER_DELAY_MS);
    } else {
      // Salida instantanea.
      setDebouncedHover(null);
    }
    return () => {
      if (enterTimerRef.current) {
        clearTimeout(enterTimerRef.current);
        enterTimerRef.current = null;
      }
    };
  }, [hoveredCol]);

  // Wrapper que abarca todo el carril del padre (position relative). Sirve
  // de "containing block" para los hijos absolute Y como elemento medido
  // por ResizeObserver para conocer el ancho real del lane.
  const wrapperRef = useRef<HTMLDivElement>(null);
  const [containerWidthPx, setContainerWidthPx] = useState(0);

  useEffect(() => {
    const el = wrapperRef.current;
    if (!el) return;
    setContainerWidthPx(el.clientWidth);
    const observer = new ResizeObserver((entries) => {
      for (const entry of entries) {
        setContainerWidthPx(entry.contentRect.width);
      }
    });
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  const visibleCards = useMemo(
    () => items.filter((i) => !i.isOverflowSlot),
    [items]
  );
  const overflowItem = useMemo(
    () => items.find((i) => i.isOverflowSlot),
    [items]
  );

  // Mapa col → layout efectivo, recalculado cuando cambia el hover.
  const layoutMap = useMemo(() => {
    const map = new Map<number, { widthPct: number; leftPct: number }>();

    // Sin hover activo: layout original.
    if (debouncedHover === null) {
      for (const c of visibleCards) {
        map.set(c.col, { widthPct: c.widthPct, leftPct: c.leftPct });
      }
      return map;
    }

    const hoveredItem = visibleCards.find((c) => c.col === debouncedHover);
    if (!hoveredItem) {
      for (const c of visibleCards) {
        map.set(c.col, { widthPct: c.widthPct, leftPct: c.leftPct });
      }
      return map;
    }

    // Espacio disponible para las cards visibles (excluye chip overflow).
    const visibleTotal = visibleCards.reduce(
      (sum, c) => sum + c.widthPct,
      0
    );
    const visibleStart =
      visibleCards.length > 0
        ? Math.min(...visibleCards.map((c) => c.leftPct))
        : 0;

    const hoveredWidth = visibleTotal * 0.8;
    const siblings = visibleCards.length - 1;
    const siblingWidth = siblings > 0 ? (visibleTotal * 0.2) / siblings : 0;

    // Asignar leftPct con cursor secuencial siguiendo el orden de col ASC.
    // Esto garantiza que las cards NO cambien su orden visual al hacer hover.
    const ordered = [...visibleCards].sort((a, b) => a.col - b.col);
    let cursor = visibleStart;
    for (const c of ordered) {
      const w = c.col === debouncedHover ? hoveredWidth : siblingWidth;
      map.set(c.col, { widthPct: w, leftPct: cursor });
      cursor += w;
    }

    return map;
  }, [debouncedHover, visibleCards]);

  function buildStyle(
    item: OverlapItem,
    layout: { widthPct: number; leftPct: number },
    isHovered: boolean
  ): CSSProperties {
    return {
      position: "absolute",
      top: `${item.topPct}%`,
      height: `${item.heightPct}%`,
      left: `calc(${layout.leftPct}% + ${edgePx}px)`,
      width: `calc(${layout.widthPct}% - ${edgePx * 2 + 1}px)`,
      transition: "width 250ms ease-out, left 250ms ease-out",
      zIndex: isHovered ? 40 : 10,
    };
  }

  // Ancho real de la card en px, basado en la medida del wrapper y el
  // widthPct efectivo (ya considerando hover). Fallback 200 mientras no se
  // ha medido para que TimelineBlock arranque con una variante razonable.
  function effectiveWidthPx(layoutWidthPct: number): number {
    if (containerWidthPx <= 0) return 200;
    const usable = Math.max(0, containerWidthPx - (edgePx * 2 + 1));
    return (usable * layoutWidthPct) / 100;
  }

  return (
    <div ref={wrapperRef} className="pointer-events-none absolute inset-0">
      {visibleCards.map((item) => {
        if (!item.meeting) return null;
        const layout = layoutMap.get(item.col) ?? {
          widthPct: item.widthPct,
          leftPct: item.leftPct,
        };
        const isHovered = debouncedHover === item.col;
        const isShrunk =
          debouncedHover !== null && debouncedHover !== item.col;
        return (
          <div
            key={item.meeting.id}
            onMouseEnter={() => setHoveredCol(item.col)}
            onMouseLeave={() => setHoveredCol(null)}
            onFocus={() => setHoveredCol(item.col)}
            onBlur={() => setHoveredCol(null)}
            style={buildStyle(item, layout, isHovered)}
            className={
              "pointer-events-auto " +
              (isHovered ? "rounded-lg shadow-lg" : "")
            }
          >
            <TimelineBlock
              reservation={item.meeting}
              heightPx={(durationMin(item.meeting) / 60) * hourHeightPx}
              widthPx={effectiveWidthPx(layout.widthPct)}
              largeMaxAvatars={largeMaxAvatars}
              now={now}
              shrunk={isShrunk}
              positionStyle={{
                position: "absolute",
                inset: 0,
              }}
              onOpen={onReservationClick}
            />
          </div>
        );
      })}

      {overflowItem && (
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            onOverflowClick(
              overflowItem.hiddenMeetings ?? [],
              e.currentTarget.getBoundingClientRect()
            );
          }}
          style={{
            position: "absolute",
            top: `${overflowItem.topPct}%`,
            height: `${overflowItem.heightPct}%`,
            left: `calc(${overflowItem.leftPct}% + ${edgePx}px)`,
            width: `calc(${overflowItem.widthPct}% - ${edgePx * 2 + 1}px)`,
          }}
          className="pointer-events-auto z-10 flex cursor-pointer items-center justify-center overflow-hidden rounded-md border border-dashed border-gray-300 bg-gray-50 px-1 text-xs font-medium text-gray-600 transition hover:border-gray-400 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-millenium-blue/40"
          aria-label={`Ver ${overflowItem.hiddenMeetings?.length ?? 0} reuniones mas`}
          title={`Ver ${overflowItem.hiddenMeetings?.length ?? 0} reuniones mas`}
        >
          +{overflowItem.hiddenMeetings?.length ?? 0}
        </button>
      )}
    </div>
  );
}
