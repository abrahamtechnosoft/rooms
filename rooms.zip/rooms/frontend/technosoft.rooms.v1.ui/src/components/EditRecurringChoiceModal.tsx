"use client";

import { Calendar, CalendarRange, X } from "lucide-react";

interface Props {
  onClose: () => void;
  onChoice: (choice: "instance" | "future") => void;
}

export default function EditRecurringChoiceModal({
  onClose,
  onChoice,
}: Props) {
  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4"
      onClick={onClose}
    >
      <div
        className="flex max-h-[90vh] w-full max-w-md flex-col rounded-xl bg-white shadow-xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex shrink-0 items-center justify-between border-b border-gray-200 p-4">
          <h3 className="font-semibold text-gray-900">¿Qué quieres editar?</h3>
          <button
            type="button"
            onClick={onClose}
            className="rounded p-1 text-gray-400 transition hover:bg-gray-100 hover:text-gray-700"
            aria-label="Cerrar"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="flex-1 space-y-2 overflow-y-auto p-4">
          <button
            type="button"
            onClick={() => onChoice("instance")}
            className="flex w-full items-start gap-3 rounded-lg border border-gray-200 p-3 text-left transition hover:border-millenium-blue hover:bg-blue-50 focus:outline-none focus:ring-2 focus:ring-millenium-blue/40"
          >
            <Calendar className="mt-0.5 h-5 w-5 shrink-0 text-millenium-blue" />
            <div>
              <p className="text-sm font-medium text-gray-900">
                Solo esta reunión
              </p>
              <p className="mt-0.5 text-xs text-gray-500">
                Los cambios solo aplicarán a esta fecha específica. La serie
                sigue igual.
              </p>
            </div>
          </button>

          <button
            type="button"
            onClick={() => onChoice("future")}
            className="flex w-full items-start gap-3 rounded-lg border border-gray-200 p-3 text-left transition hover:border-millenium-blue hover:bg-blue-50 focus:outline-none focus:ring-2 focus:ring-millenium-blue/40"
          >
            <CalendarRange className="mt-0.5 h-5 w-5 shrink-0 text-millenium-blue" />
            <div>
              <p className="text-sm font-medium text-gray-900">
                Esta reunión y todas las futuras
              </p>
              <p className="mt-0.5 text-xs text-gray-500">
                Los cambios aplicarán a esta fecha y a todas las siguientes que
                aún no hayan pasado.
              </p>
              <p className="mt-1 text-xs italic text-amber-700">
                Las futuras editadas individualmente no se cambian.
              </p>
            </div>
          </button>
        </div>

        <div className="flex shrink-0 justify-end border-t border-gray-200 p-3">
          <button
            type="button"
            onClick={onClose}
            className="rounded px-3 py-1.5 text-sm text-gray-500 transition hover:text-gray-900"
          >
            Cancelar
          </button>
        </div>
      </div>
    </div>
  );
}
