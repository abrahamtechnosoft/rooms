"use client";

import { useState } from "react";
import { Calendar, Clock, Edit2, Power, Trash2 } from "lucide-react";
import { toast } from "@/lib/toastHelpers";
import api from "@/lib/api";
import type { Reply, UserBlock } from "@/types";
import UserBlockFormModal from "@/components/UserBlockFormModal";

interface Props {
  blocks: UserBlock[];
  onUpdate: () => void;
}

const DAY_LABELS: Record<string, string> = {
  "1": "Lun",
  "2": "Mar",
  "3": "Mié",
  "4": "Jue",
  "5": "Vie",
  "6": "Sáb",
  "7": "Dom",
};

function formatDateLocal(iso?: string | null): string {
  if (!iso) return "—";
  try {
    const d = new Date(iso);
    return d.toLocaleDateString("es-CR", {
      day: "2-digit",
      month: "short",
      year: "numeric",
    });
  } catch {
    return "—";
  }
}

function formatDays(csv: string | null): string {
  if (!csv) return "";
  return csv
    .split(",")
    .filter(Boolean)
    .map((d) => DAY_LABELS[d] || d)
    .join(", ");
}

export default function UserBlocksList({ blocks, onUpdate }: Props) {
  const [editingBlock, setEditingBlock] = useState<UserBlock | null>(null);

  async function toggleActive(block: UserBlock) {
    try {
      const res = await api.patch<Reply<unknown>>(
        `/users/me/blocks/${block.id}`,
        { isActive: !block.isActive }
      );
      if (!res.data.ok) {
        toast.error(res.data.msg || "No fue posible cambiar el estado");
        return;
      }
      toast.success(
        block.isActive ? "Bloqueo desactivado" : "Bloqueo activado"
      );
      onUpdate();
    } catch (e: unknown) {
      const errObj = e as { response?: { data?: { msg?: string } } };
      toast.error(
        errObj?.response?.data?.msg || "No fue posible cambiar el estado"
      );
    }
  }

  async function handleDelete(block: UserBlock) {
    if (typeof window !== "undefined") {
      const okConfirm = window.confirm(
        `¿Eliminar el bloqueo "${block.name}"?`
      );
      if (!okConfirm) return;
    }
    try {
      const res = await api.delete<Reply<unknown>>(
        `/users/me/blocks/${block.id}`
      );
      if (!res.data.ok) {
        toast.error(res.data.msg || "No fue posible eliminar");
        return;
      }
      toast.success(res.data.msg || "Bloqueo eliminado");
      onUpdate();
    } catch (e: unknown) {
      const errObj = e as { response?: { data?: { msg?: string } } };
      toast.error(
        errObj?.response?.data?.msg || "No fue posible eliminar"
      );
    }
  }

  if (blocks.length === 0) {
    return (
      <p className="py-6 text-center text-sm text-gray-400">
        No tienes bloqueos. Agrega uno para no recibir reuniones a esa hora.
      </p>
    );
  }

  return (
    <>
      <ul className="space-y-2">
        {blocks.map((block) => {
          const isRecurring = block.blockType === "recurring";
          return (
            <li
              key={block.id}
              className={
                "flex items-center gap-3 rounded-lg border p-3 transition " +
                (block.isActive
                  ? "border-gray-200 bg-white"
                  : "border-gray-100 bg-gray-50 opacity-60")
              }
            >
              <div
                className={
                  "rounded-lg p-2 " +
                  (isRecurring ? "bg-purple-50" : "bg-amber-50")
                }
              >
                {isRecurring ? (
                  <Clock className="h-4 w-4 text-purple-600" />
                ) : (
                  <Calendar className="h-4 w-4 text-amber-600" />
                )}
              </div>

              <div className="min-w-0 flex-1">
                <p
                  className="truncate text-sm font-medium text-gray-900"
                  title={block.name}
                >
                  {block.name}
                </p>
                <p className="truncate text-xs text-gray-500">
                  {isRecurring ? (
                    <>
                      {formatDays(block.daysOfWeek)} ·{" "}
                      {block.startTime} - {block.endTime}
                    </>
                  ) : (
                    <>
                      Del {formatDateLocal(block.startAt)} al{" "}
                      {formatDateLocal(block.endAt)}
                    </>
                  )}
                </p>
              </div>

              <div className="flex shrink-0 items-center gap-1">
                <button
                  type="button"
                  onClick={() => setEditingBlock(block)}
                  className="rounded p-1.5 text-gray-400 transition hover:bg-gray-100 hover:text-gray-700"
                  aria-label="Editar bloqueo"
                  title="Editar"
                >
                  <Edit2 className="h-4 w-4" />
                </button>
                <button
                  type="button"
                  onClick={() => toggleActive(block)}
                  className="rounded p-1.5 text-gray-400 transition hover:bg-gray-100 hover:text-gray-700"
                  aria-label={
                    block.isActive
                      ? "Desactivar bloqueo"
                      : "Activar bloqueo"
                  }
                  title={block.isActive ? "Desactivar" : "Activar"}
                >
                  <Power className="h-4 w-4" />
                </button>
                <button
                  type="button"
                  onClick={() => handleDelete(block)}
                  className="rounded p-1.5 text-gray-400 transition hover:bg-gray-100 hover:text-millenium-red"
                  aria-label="Eliminar bloqueo"
                  title="Eliminar"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            </li>
          );
        })}
      </ul>

      {editingBlock && (
        <UserBlockFormModal
          block={editingBlock}
          onClose={() => setEditingBlock(null)}
          onSaved={() => {
            onUpdate();
            setEditingBlock(null);
          }}
        />
      )}
    </>
  );
}
