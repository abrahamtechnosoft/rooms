"use client";

import { useEffect, useState } from "react";
import { FileText, Loader2, Plus } from "lucide-react";
import { toast } from "@/lib/toastHelpers";
import api from "@/lib/api";
import type { Reply, SummaryItem } from "@/types";

interface Props {
  reservationId: number;
  canEdit: boolean;
}

const MAX_SUMMARY = 2000;

export default function SummarySection({ reservationId, canEdit }: Props) {
  const [items, setItems] = useState<SummaryItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [content, setContent] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const load = async () => {
    setLoading(true);
    try {
      const res = await api.get<Reply<SummaryItem[]>>(
        `/reservations/${reservationId}/summary`
      );
      setItems(res.data.obj || []);
    } catch {
      // silencioso
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [reservationId]);

  async function handleSubmit() {
    if (content.trim().length === 0 || submitting) return;
    setSubmitting(true);
    try {
      const res = await api.post<Reply<unknown>>(
        `/reservations/${reservationId}/summary`,
        { content: content.trim() }
      );
      if (!res.data.ok) {
        toast.error(res.data.msg || "No fue posible agregar el punto");
        return;
      }
      // El punto aparece en la lista al recargar, sin toast.
      setContent("");
      setShowForm(false);
      await load();
    } catch (e: unknown) {
      const errObj = e as { response?: { data?: { msg?: string } } };
      toast.error(
        errObj?.response?.data?.msg || "No fue posible agregar el punto"
      );
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <h4 className="flex items-center gap-2 text-sm font-semibold text-gray-700">
          <FileText className="h-4 w-4" />
          Resumen de la reunión
          {items.length > 0 && (
            <span className="text-xs font-normal text-gray-400">
              ({items.length} {items.length === 1 ? "punto" : "puntos"})
            </span>
          )}
        </h4>
        {canEdit && !showForm && (
          <button
            type="button"
            onClick={() => setShowForm(true)}
            className="inline-flex items-center gap-1 text-xs font-medium text-millenium-blue hover:underline"
          >
            <Plus className="h-3.5 w-3.5" />
            {items.length === 0 ? "Iniciar resumen" : "Agregar punto"}
          </button>
        )}
      </div>

      {showForm && (
        <div className="space-y-2 rounded-lg border border-gray-200 bg-gray-50 p-3">
          <textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            maxLength={MAX_SUMMARY}
            rows={3}
            placeholder="Describe un punto importante de la reunión…"
            autoFocus
            className="w-full rounded border border-gray-300 bg-white p-2 text-sm focus:border-millenium-blue focus:outline-none focus:ring-2 focus:ring-millenium-blue/20"
          />
          <p className="text-xs italic text-amber-700">
            ⚠️ Una vez agregado, no podrás eliminar ni editar este punto.
          </p>
          <div className="flex items-center justify-between">
            <span className="text-xs text-gray-500 tabular-nums">
              {content.length}/{MAX_SUMMARY}
            </span>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => {
                  setShowForm(false);
                  setContent("");
                }}
                className="text-xs text-gray-600 hover:text-gray-900"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={handleSubmit}
                disabled={submitting || content.trim().length === 0}
                className="inline-flex items-center gap-1 rounded bg-millenium-blue px-3 py-1 text-xs font-medium text-white disabled:opacity-50"
              >
                {submitting && <Loader2 className="h-3 w-3 animate-spin" />}
                Agregar
              </button>
            </div>
          </div>
        </div>
      )}

      {loading && items.length === 0 ? (
        <p className="text-sm text-gray-500">Cargando resumen…</p>
      ) : items.length === 0 && !showForm ? (
        <p className="text-sm italic text-gray-500">
          Sin resumen.{" "}
          {canEdit && "Inicia uno cuando termine la reunión."}
        </p>
      ) : (
        items.length > 0 && (
          <ol className="list-decimal space-y-2 pl-5">
            {items.map((item) => (
              <li key={item.id} className="text-sm leading-relaxed text-gray-900">
                <span className="whitespace-pre-wrap">{item.content}</span>
                <span className="ml-2 text-xs text-gray-400">
                  — {item.authorName || item.authorEmail}
                </span>
              </li>
            ))}
          </ol>
        )
      )}
    </div>
  );
}
