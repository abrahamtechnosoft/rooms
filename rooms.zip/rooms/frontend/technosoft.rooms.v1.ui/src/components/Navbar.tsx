"use client";

import Link from "next/link";
import { Menu } from "lucide-react";
import MilleniumLogo from "./MilleniumLogo";
import NotificationsBell from "./NotificationsBell";
import UserMenu from "./UserMenu";

interface Props {
  onOpenMobileMenu?: () => void;
}

export default function Navbar({ onOpenMobileMenu }: Props) {
  return (
    <header className="z-30 flex h-16 shrink-0 items-center justify-between gap-4 border-b border-gray-200 bg-white px-4 md:px-6">
      <div className="flex items-center gap-2">
        <button
          type="button"
          onClick={onOpenMobileMenu}
          className="rounded-lg p-2 text-gray-600 hover:bg-gray-100 md:hidden"
          aria-label="Abrir menú"
        >
          <Menu className="h-5 w-5" />
        </button>
        <Link href="/dashboard" className="flex items-center gap-2.5">
          <MilleniumLogo size={36} withText={false} />
          <span className="text-base font-semibold text-gray-700">Rooms</span>
        </Link>
      </div>
      <div className="flex items-center gap-1">
        <NotificationsBell />
        <UserMenu />
      </div>
    </header>
  );
}
