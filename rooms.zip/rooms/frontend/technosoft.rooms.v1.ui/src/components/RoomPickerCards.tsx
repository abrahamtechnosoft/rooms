"use client";

import { Check } from "lucide-react";
import type { Room } from "@/types";
import { getRoomColor, getRoomIcon } from "@/lib/roomIcons";

interface Props {
  rooms: Room[];
  value: number | null;
  onChange: (id: number) => void;
}

export default function RoomPickerCards({ rooms, value, onChange }: Props) {
  if (rooms.length === 0) {
    return (
      <div className="rounded-lg border border-dashed border-gray-300 bg-white p-4 text-base text-gray-500">
        No hay salas disponibles.
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-2">
      {rooms.map((r) => {
        const active = value === r.id;
        const color = getRoomColor(r.colorHex);
        const Icon = getRoomIcon(r.iconName);
        return (
          <button
            type="button"
            key={r.id}
            onClick={() => onChange(r.id)}
            aria-pressed={active}
            className={
              "flex w-full items-center gap-3 rounded-lg border-2 p-3 text-left transition " +
              (active
                ? "border-millenium-blue bg-millenium-blue/5"
                : "border-gray-200 hover:border-gray-300")
            }
          >
            <span
              className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg"
              style={{ backgroundColor: `${color}26`, color }}
            >
              <Icon className="h-5 w-5" />
            </span>

            <span className="min-w-0 flex-1">
              <span className="truncate text-sm font-semibold text-gray-900">
                {r.name}
              </span>
              <span className="mt-0.5 block truncate text-xs text-gray-500">
                Capacidad {r.capacity}
                {r.location ? ` · ${r.location}` : ""}
              </span>
            </span>

            {active && (
              <Check className="h-5 w-5 shrink-0 text-millenium-blue" />
            )}
          </button>
        );
      })}
    </div>
  );
}
