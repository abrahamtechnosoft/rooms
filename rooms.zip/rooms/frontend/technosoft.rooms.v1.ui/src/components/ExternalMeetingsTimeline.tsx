"use client";

import { useMemo, useState } from "react";
import { MapPin, Plus } from "lucide-react";
import type { Reservation } from "@/types";
import OverflowPopover from "@/components/OverflowPopover";
import OverlapGroup from "@/components/OverlapGroup";
import { effectiveEndsAt } from "@/lib/reservationStatus";
import { useNowTick } from "@/hooks/useNowTick";
import {
  computeOverlapLayout,
  type OverlapItem,
  type OverlapLayout,
} from "@/lib/timelineLayout";

interface SlotPick {
  date: string;
  hour: number;
  minute: number;
}

interface Props {
  date: string;
  reservations: Reservation[];
  currentUserId?: number | null;
  onReservationClick?: (r: Reservation) => void;
  onEmptyClick?: (slot: SlotPick) => void;
}

const OPEN_HOUR = 8;
const CLOSE_HOUR = 17;
const TOTAL_HOURS = CLOSE_HOUR - OPEN_HOUR;
const TOTAL_MINUTES = TOTAL_HOURS * 60;
const SLOT_MIN = 30;
const TOTAL_SLOTS = TOTAL_MINUTES / SLOT_MIN;
const HOUR_HEIGHT_PX = 140;

const EXTERNAL_COLOR = "#27AE60";

const pad = (n: number) => String(n).padStart(2, "0");

const localDate = (date: string, h: number, m: number): Date => {
  const [y, mo, d] = date.split("-").map((v) => parseInt(v, 10));
  return new Date(y, (mo || 1) - 1, d || 1, h, m, 0, 0);
};

const pctFromHours = (h: number) =>
  ((Math.max(OPEN_HOUR, Math.min(CLOSE_HOUR, h)) - OPEN_HOUR) / TOTAL_HOURS) *
  100;

interface GroupedItems {
  groupId: string;
  items: OverlapItem[];
}

function groupByGroupId(layout: OverlapLayout): GroupedItems[] {
  const map = new Map<string, OverlapItem[]>();
  for (const it of layout.items) {
    const arr = map.get(it.groupId);
    if (arr) arr.push(it);
    else map.set(it.groupId, [it]);
  }
  return Array.from(map.entries()).map(([groupId, items]) => ({
    groupId,
    items,
  }));
}

export default function ExternalMeetingsTimeline({
  date,
  reservations,
  currentUserId,
  onReservationClick,
  onEmptyClick,
}: Props) {
  const dayReservations = useMemo(
    () =>
      reservations.filter(
        (r) =>
          r.type === "external" &&
          r.status === "active" &&
          new Date(r.startsAt).toDateString() ===
            localDate(date, 12, 0).toDateString()
      ),
    [reservations, date]
  );

  const now = useNowTick(1000);
  const isToday =
    now.toDateString() === localDate(date, 12, 0).toDateString();
  const nowH = now.getHours() + now.getMinutes() / 60;
  const showNowLine = isToday && nowH >= OPEN_HOUR && nowH <= CLOSE_HOUR;
  const nowPercent = pctFromHours(nowH);
  const nowLabel = `${pad(now.getHours())}:${pad(now.getMinutes())}`;

  const HALF_STEPS = TOTAL_HOURS * 2;
  const labelMarks = Array.from({ length: HALF_STEPS }, (_, i) => {
    const hour = OPEN_HOUR + Math.floor(i / 2);
    const minute = (i % 2) * 30;
    return {
      label: `${pad(hour)}:${pad(minute)}`,
      pct: (i / HALF_STEPS) * 100,
      isHour: minute === 0,
    };
  });
  labelMarks.push({
    label: `${pad(CLOSE_HOUR)}:00`,
    pct: 100,
    isHour: true,
  });

  const hourLines = Array.from({ length: TOTAL_HOURS + 1 }, (_, i) => ({
    pct: (i / TOTAL_HOURS) * 100,
  }));

  const layout = useMemo(
    () =>
      computeOverlapLayout(dayReservations, currentUserId ?? null, {
        openHour: OPEN_HOUR,
        closeHour: CLOSE_HOUR,
      }),
    [dayReservations, currentUserId]
  );

  const groups = useMemo(() => groupByGroupId(layout), [layout]);

  const [overflowPopover, setOverflowPopover] = useState<{
    meetings: Reservation[];
    anchorRect: DOMRect;
  } | null>(null);

  return (
    <div
      className="flex h-full flex-col overflow-hidden rounded-xl border border-gray-200 bg-white shadow-sm"
      style={{ minHeight: `${HOUR_HEIGHT_PX * TOTAL_HOURS + 160}px` }}
    >
      <div
        className="flex min-h-[160px] shrink-0 flex-col border-b border-l-4 border-gray-200 bg-gray-50/60 p-5 md:p-6"
        style={{ borderLeftColor: EXTERNAL_COLOR }}
      >
        <div className="mb-1 flex items-center gap-2">
          <MapPin className="h-6 w-6" style={{ color: EXTERNAL_COLOR }} />
          <h3 className="text-lg font-semibold text-gray-900">
            Fuera de oficina
          </h3>
        </div>
        <p className="text-sm text-gray-500">Todas las del día</p>
        {/* Espacio reservado equivalente al "Reservar ahora" de los carriles
            físicos, para que las cards mantengan la misma altura. */}
        <div className="mt-auto min-h-[32px] pt-3" aria-hidden="true" />
      </div>

      <div className="flex min-h-0 flex-1 pt-6 pb-12">
        {/* Columna de horas */}
        <div className="relative w-20 shrink-0">
          {labelMarks.map((m) => (
            <span
              key={m.label}
              className={
                "absolute right-3 -mt-1 leading-none tabular-nums " +
                (m.isHour
                  ? "text-base font-semibold text-gray-700"
                  : "text-sm text-gray-500")
              }
              style={{ top: `${m.pct}%` }}
            >
              {m.label}
            </span>
          ))}
        </div>

        {/* Carriles */}
        <div className="relative min-h-0 flex-1 overflow-hidden pl-2 pr-3">
          <div className="relative h-full w-full">
            {hourLines.map((l, i) => (
              <div
                key={i}
                className="absolute left-0 right-0 z-0 border-t border-gray-200"
                style={{ top: `${l.pct}%` }}
              />
            ))}

            {/* Slots clickeables (cada 30 min) — sólo se rendiriza el slot si
                está vacío (sin reuniones que lo crucen) y no es pasado. */}
            {Array.from({ length: TOTAL_SLOTS }, (_, idx) => {
              const hour = OPEN_HOUR + Math.floor(idx / 2);
              const minute = (idx % 2) * SLOT_MIN;
              const slotStart = localDate(date, hour, minute);
              const slotEnd = new Date(slotStart.getTime() + SLOT_MIN * 60000);

              const occupied = dayReservations.some((r) => {
                const rs = new Date(r.startsAt);
                const re = new Date(effectiveEndsAt(r));
                return rs < slotEnd && re > slotStart;
              });
              const inPast = slotStart <= now;

              if (occupied || inPast || !onEmptyClick) return null;

              const top = (idx / TOTAL_SLOTS) * 100;
              const height = 100 / TOTAL_SLOTS;
              const time = `${pad(hour)}:${pad(minute)}`;

              return (
                <button
                  type="button"
                  key={idx}
                  onClick={() => onEmptyClick({ date, hour, minute })}
                  className="group absolute inset-x-1 z-0 flex cursor-pointer items-center justify-center rounded transition hover:bg-millenium-green/5"
                  style={{ top: `${top}%`, height: `${height}%` }}
                  title={`Agendar a las ${time}`}
                  aria-label={`Agendar a las ${time}`}
                >
                  <span className="pointer-events-none flex items-center gap-1 text-xs text-millenium-green/40 transition md:text-millenium-green/0 md:group-hover:text-millenium-green/70">
                    <Plus className="h-3 w-3" />
                    Agendar aquí
                  </span>
                </button>
              );
            })}

            {/* Grupos de solape */}
            {groups.map((g) => (
              <OverlapGroup
                key={g.groupId}
                items={g.items}
                now={now}
                hourHeightPx={HOUR_HEIGHT_PX}
                largeMaxAvatars={5}
                edgePx={2}
                onReservationClick={(r) =>
                  onReservationClick && onReservationClick(r)
                }
                onOverflowClick={(hidden, anchorRect) =>
                  setOverflowPopover({ meetings: hidden, anchorRect })
                }
              />
            ))}

            {/* Linea "ahora": fina, semi-transparente con mix-blend para no tapar */}
            {showNowLine && (
              <div
                className="pointer-events-none absolute inset-x-0 z-20 animate-[fadeIn_180ms_ease-out]"
                style={{ top: `${nowPercent}%` }}
              >
                <div className="relative w-full">
                  <span
                    className="absolute z-30 rounded bg-millenium-red px-3 py-1.5 text-sm font-bold tabular-nums text-white shadow-sm"
                    style={{ left: "-4.25rem", top: "-1rem" }}
                  >
                    {nowLabel}
                  </span>
                  <div
                    className="absolute -left-1.5 h-2.5 w-2.5 rounded-full bg-millenium-red/80 ring-2 ring-white"
                    style={{ top: "-5px" }}
                  ></div>
                  <div className="h-px w-full bg-millenium-red/70 mix-blend-multiply"></div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
      {overflowPopover && (
        <OverflowPopover
          meetings={overflowPopover.meetings}
          anchorRect={overflowPopover.anchorRect}
          onMeetingClick={(m) => onReservationClick && onReservationClick(m)}
          onClose={() => setOverflowPopover(null)}
        />
      )}
    </div>
  );
}
