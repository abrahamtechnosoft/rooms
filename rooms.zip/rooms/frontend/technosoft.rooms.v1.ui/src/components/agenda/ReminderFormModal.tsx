"use client";

import { useEffect, useState } from "react";
import { Loader2 } from "lucide-react";
import api from "@/lib/api";
import { toast } from "@/lib/toastHelpers";
import { emitWidgetEvent } from "@/lib/widgetEvents";
import type { Reply, UserReminder } from "@/types";

interface Props {
  reminder: UserReminder | null;
  onSaved: () => void;
  onCancel: () => void;
}

function toLocalInputValue(iso: string): string {
  const d = new Date(iso);
  const pad = (n: number) => String(n).padStart(2, "0");
  const y = d.getFullYear();
  const mo = pad(d.getMonth() + 1);
  const da = pad(d.getDate());
  const h = pad(d.getHours());
  const m = pad(d.getMinutes());
  return `${y}-${mo}-${da}T${h}:${m}`;
}

function defaultRemindAt(): string {
  const d = new Date(Date.now() + 60 * 60 * 1000);
  return toLocalInputValue(d.toISOString());
}

export default function ReminderFormModal({ reminder, onSaved, onCancel }: Props) {
  const isEdit = reminder !== null;
  const [title, setTitle] = useState(reminder?.title ?? "");
  const [content, setContent] = useState(reminder?.content ?? "");
  const [remindAt, setRemindAt] = useState(
    reminder?.remindAt ? toLocalInputValue(reminder.remindAt) : defaultRemindAt()
  );
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape" && !saving) onCancel();
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [saving, onCancel]);

  const handleSave = async () => {
    if (saving) return;
    if (!title.trim()) {
      toast.error("El título es requerido");
      return;
    }
    if (!remindAt) {
      toast.error("La fecha es requerida");
      return;
    }
    const remindDate = new Date(remindAt);
    if (isNaN(remindDate.getTime())) {
      toast.error("Fecha inválida");
      return;
    }
    setSaving(true);
    try {
      const payload = {
        title: title.trim(),
        content: content.trim() || null,
        remindAt: remindDate.toISOString(),
      };
      if (isEdit && reminder) {
        await api.put<Reply<{ reminderId: number }>>(
          `/reminders/${reminder.reminderId}`,
          payload
        );
        toast.success("Recordatorio actualizado");
      } else {
        await api.post<Reply<{ reminderId: number }>>("/reminders", payload);
        toast.success("Recordatorio creado");
      }
      emitWidgetEvent("reminders:changed");
      onSaved();
    } catch (e: unknown) {
      const errObj = e as { response?: { data?: { msg?: string } } };
      toast.error(errObj?.response?.data?.msg || "No fue posible guardar");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="reminder-modal-title"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4"
      onClick={saving ? undefined : onCancel}
    >
      <div
        className="flex max-h-[90vh] w-full max-w-md flex-col rounded-lg bg-white shadow-xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="shrink-0 border-b px-4 py-3">
          <h3 id="reminder-modal-title" className="text-base font-semibold">
            {isEdit ? "Editar recordatorio" : "Nuevo recordatorio"}
          </h3>
        </div>
        <div className="flex-1 space-y-3 overflow-y-auto p-4">
          <div>
            <label className="mb-1 block text-xs font-medium text-gray-600">
              Título
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              maxLength={120}
              className="w-full rounded-md border px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-millenium-blue"
              placeholder="Llamar al cliente..."
              autoFocus
            />
          </div>
          <div>
            <label className="mb-1 block text-xs font-medium text-gray-600">
              Notas (opcional)
            </label>
            <textarea
              value={content}
              onChange={(e) => setContent(e.target.value)}
              maxLength={2000}
              rows={3}
              className="w-full resize-none rounded-md border px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-millenium-blue"
              placeholder="Detalles..."
            />
          </div>
          <div>
            <label className="mb-1 block text-xs font-medium text-gray-600">
              Recordar el
            </label>
            <input
              type="datetime-local"
              value={remindAt}
              onChange={(e) => setRemindAt(e.target.value)}
              className="w-full rounded-md border px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-millenium-blue"
            />
          </div>
        </div>
        <div className="flex shrink-0 justify-end gap-2 border-t bg-gray-50 px-4 py-3">
          <button
            type="button"
            onClick={onCancel}
            disabled={saving}
            className="rounded-md border px-3 py-1.5 text-sm hover:bg-gray-50 disabled:opacity-60"
          >
            Cancelar
          </button>
          <button
            type="button"
            onClick={handleSave}
            disabled={saving || !title.trim()}
            className="inline-flex items-center gap-1.5 rounded-md bg-millenium-blue px-3 py-1.5 text-sm font-medium text-white transition hover:opacity-90 disabled:opacity-50"
          >
            {saving && <Loader2 className="h-3.5 w-3.5 animate-spin" />}
            {saving ? "Guardando..." : "Guardar"}
          </button>
        </div>
      </div>
    </div>
  );
}
