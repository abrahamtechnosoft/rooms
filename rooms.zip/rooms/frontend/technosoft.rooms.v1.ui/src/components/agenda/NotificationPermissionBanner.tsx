"use client";

import { useEffect, useState } from "react";
import { Bell, X } from "lucide-react";

const DISMISS_KEY = "rooms.notif.bannerDismissed";

export default function NotificationPermissionBanner() {
  const [supported, setSupported] = useState(false);
  const [permission, setPermission] = useState<NotificationPermission>("default");
  const [dismissed, setDismissed] = useState(false);

  useEffect(() => {
    if (typeof window === "undefined" || !("Notification" in window)) {
      setSupported(false);
      return;
    }
    setSupported(true);
    setPermission(Notification.permission);
    if (localStorage.getItem(DISMISS_KEY) === "true") {
      setDismissed(true);
    }
  }, []);

  if (!supported) return null;
  if (permission === "granted") return null;
  if (permission === "denied") return null;
  if (dismissed) return null;

  const handleEnable = async () => {
    try {
      const result = await Notification.requestPermission();
      setPermission(result);
    } catch {
      // ignore
    }
  };

  const handleDismiss = () => {
    try {
      localStorage.setItem(DISMISS_KEY, "true");
    } catch {
      // ignore
    }
    setDismissed(true);
  };

  return (
    <div className="flex items-start gap-3 rounded-md border border-millenium-blue/30 bg-millenium-blue/5 p-3">
      <Bell className="mt-0.5 h-4 w-4 shrink-0 text-millenium-blue" />
      <div className="flex-1 text-sm">
        <p className="font-medium text-millenium-blue">
          Activa las notificaciones del navegador
        </p>
        <p className="mt-0.5 text-xs text-gray-600">
          Recibe avisos antes de tus reuniones y cuando llegue un recordatorio.
        </p>
      </div>
      <div className="flex items-center gap-2">
        <button
          type="button"
          onClick={handleEnable}
          className="rounded-md bg-millenium-blue px-3 py-1 text-xs font-medium text-white transition hover:opacity-90"
        >
          Activar
        </button>
        <button
          type="button"
          onClick={handleDismiss}
          className="text-gray-400 hover:text-gray-600"
          title="No mostrar"
          aria-label="No mostrar"
        >
          <X className="h-4 w-4" />
        </button>
      </div>
    </div>
  );
}
