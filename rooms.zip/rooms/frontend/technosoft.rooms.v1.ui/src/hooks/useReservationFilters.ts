"use client";

import { useCallback, useEffect, useState } from "react";
import {
  DEFAULT_FILTERS,
  type ChipFilter,
  type ReservationFilters,
} from "@/types/filters";

const STORAGE_KEY = "rooms.filters.v2";

function sanitizeChip(value: unknown): ChipFilter | null {
  if (!value || typeof value !== "object") return null;
  const v = value as { kind?: unknown; roomId?: unknown };
  if (v.kind === "all") return { kind: "all" };
  if (v.kind === "virtual") return { kind: "virtual" };
  if (v.kind === "external") return { kind: "external" };
  if (v.kind === "room" && typeof v.roomId === "number") {
    return { kind: "room", roomId: v.roomId };
  }
  return null;
}

function sanitize(parsed: unknown): ReservationFilters | null {
  if (!parsed || typeof parsed !== "object") return null;
  const obj = parsed as Partial<ReservationFilters>;
  const chip = sanitizeChip(obj.chip);
  if (!chip) return null;
  if (!Array.isArray(obj.departmentIds)) return null;
  const departmentIds = obj.departmentIds.filter(
    (n): n is number => typeof n === "number" && Number.isFinite(n)
  );
  return { chip, departmentIds };
}

/**
 * Hook de filtros globales del dashboard. Persiste en `window.localStorage`
 * con la clave `rooms.filters.v2`. Compartido entre vista diaria y semanal.
 *
 * `hasAdvancedFilters` indica si hay departamentos seleccionados (utilizado
 * por el boton "Mas filtros" para mostrar el badge).
 */
export function useReservationFilters() {
  const [filters, setFilters] = useState<ReservationFilters>(DEFAULT_FILTERS);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    if (typeof window === "undefined") return;
    try {
      const raw = window.localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        const clean = sanitize(parsed);
        if (clean) setFilters(clean);
      }
    } catch {
      // localStorage puede fallar (incognito) — silencioso.
    }
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    if (typeof window === "undefined") return;
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(filters));
    } catch {
      // silencioso
    }
  }, [filters, hydrated]);

  const reset = useCallback(() => setFilters(DEFAULT_FILTERS), []);
  const hasAdvancedFilters = filters.departmentIds.length > 0;

  return {
    filters,
    setFilters,
    reset,
    hasAdvancedFilters,
    hydrated,
  } as const;
}
