"use client";

import { useEffect, useState } from "react";

/**
 * Devuelve la hora actual y la refresca cada `intervalMs` milisegundos.
 * Es un tick LOCAL — no consulta backend, es barato.
 *
 * Se pausa cuando la pestaña pasa a background (visibilitychange) y refresca
 * inmediatamente al volver visible.
 */
export function useNowTick(intervalMs: number = 1000): Date {
  const [now, setNow] = useState<Date>(() => new Date());

  useEffect(() => {
    let id: ReturnType<typeof setInterval> | null = null;

    function start() {
      if (id) return;
      id = setInterval(() => setNow(new Date()), intervalMs);
    }

    function stop() {
      if (id) {
        clearInterval(id);
        id = null;
      }
    }

    function handleVisibility() {
      if (document.visibilityState === "visible") {
        setNow(new Date());
        start();
      } else {
        stop();
      }
    }

    if (
      typeof document === "undefined" ||
      document.visibilityState === "visible"
    ) {
      start();
    }
    document.addEventListener("visibilitychange", handleVisibility);

    return () => {
      stop();
      document.removeEventListener("visibilitychange", handleVisibility);
    };
  }, [intervalMs]);

  return now;
}
