"use client";

import { useEffect, useState } from "react";

/**
 * Hook para persistir un boolean en `window.localStorage`.
 *
 * En SSR se devuelve siempre `defaultValue` para evitar hydration mismatch.
 * El flag `hydrated` indica si ya se aplico el valor real del storage.
 * Cuando `hydrated` pasa a true, el valor refleja el storage si existe.
 *
 * @param key clave en localStorage (ej. "rooms.week.showWeekends")
 * @param defaultValue valor por defecto si no existe la clave
 * @returns tupla `[value, setValue, hydrated]`
 */
export function useLocalStorageBoolean(
  key: string,
  defaultValue: boolean
): readonly [boolean, (next: boolean) => void, boolean] {
  const [value, setValue] = useState<boolean>(defaultValue);
  const [hydrated, setHydrated] = useState(false);

  // Hidratar desde localStorage en client-side.
  useEffect(() => {
    if (typeof window === "undefined") return;
    try {
      const stored = window.localStorage.getItem(key);
      if (stored !== null) {
        setValue(stored === "true");
      }
    } catch {
      // localStorage puede fallar (modo incognito, etc.) — silencioso.
    }
    setHydrated(true);
  }, [key]);

  // Persistir cambios solo despues de haber hidratado, para no sobrescribir
  // el valor real con el default antes de leerlo.
  useEffect(() => {
    if (!hydrated) return;
    if (typeof window === "undefined") return;
    try {
      window.localStorage.setItem(key, String(value));
    } catch {
      // silencioso
    }
  }, [key, value, hydrated]);

  return [value, setValue, hydrated] as const;
}
