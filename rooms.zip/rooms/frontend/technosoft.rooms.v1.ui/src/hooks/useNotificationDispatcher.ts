"use client";

import { useEffect, useRef, useState } from "react";
import api from "@/lib/api";
import type {
  NotificationPreferences,
  Reply,
  Reservation,
  UserReminder,
} from "@/types";

const POLL_INTERVAL_MS = 30 * 1000;
const PERMISSION_POLL_MS = 5 * 1000;
const MEETING_FIRED_KEY = "rooms.notif.meetingsFired";

interface FiredMeeting {
  id: number;
  startsAt: string;
}

function loadFired(): FiredMeeting[] {
  try {
    const raw = sessionStorage.getItem(MEETING_FIRED_KEY);
    if (!raw) return [];
    const arr = JSON.parse(raw);
    if (!Array.isArray(arr)) return [];
    return arr.filter(
      (x) =>
        x &&
        typeof x === "object" &&
        typeof x.id === "number" &&
        typeof x.startsAt === "string"
    );
  } catch {
    return [];
  }
}

function saveFired(items: FiredMeeting[]): void {
  try {
    sessionStorage.setItem(MEETING_FIRED_KEY, JSON.stringify(items));
  } catch {
    // ignore quota errors
  }
}

/**
 * Dispara notificaciones del navegador para reuniones próximas y recordatorios
 * vencidos. Solo corre si el usuario otorgó permiso. Polling cada 30s.
 */
export function useNotificationDispatcher(): void {
  const prefsRef = useRef<NotificationPreferences | null>(null);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const [permission, setPermission] = useState<NotificationPermission | null>(
    null
  );

  // Watcher: si el usuario otorga permiso despues del mount, lo detectamos
  // aqui y disparamos el dispatcher (no requiere reload).
  useEffect(() => {
    if (typeof window === "undefined" || !("Notification" in window)) return;
    setPermission(Notification.permission);
    const id = setInterval(() => {
      const current = Notification.permission;
      setPermission((prev) => (prev === current ? prev : current));
    }, PERMISSION_POLL_MS);
    return () => clearInterval(id);
  }, []);

  useEffect(() => {
    if (typeof window === "undefined") return;
    if (!("Notification" in window)) return;
    if (permission !== "granted") return;

    let cancelled = false;

    const loadPrefs = async () => {
      try {
        const res = await api.get<Reply<NotificationPreferences>>(
          "/users/me/notification-preferences"
        );
        if (!cancelled) prefsRef.current = res.data.obj || null;
      } catch {
        if (!cancelled) prefsRef.current = null;
      }
    };

    const tick = async () => {
      const prefs = prefsRef.current;
      if (!prefs) return;

      const now = new Date();

      // 1) Reuniones próximas
      if (prefs.browserMeetingReminder) {
        try {
          const res = await api.get<Reply<Reservation[]>>(
            "/reservations/mine"
          );
          const reservations = (res.data.obj || []).filter(
            (r) => r.status === "active"
          );
          const fired = loadFired();
          const firedById = new Map(fired.map((f) => [f.id, f.startsAt]));
          const minutesBefore = prefs.browserMeetingReminderMinutes || 10;

          for (const r of reservations) {
            const startsAt = new Date(r.startsAt);
            const diffMin = (startsAt.getTime() - now.getTime()) / 60000;
            if (diffMin <= minutesBefore && diffMin > 0) {
              // Si ya disparamos para este id+startsAt, saltar.
              const prevStart = firedById.get(r.id);
              if (prevStart === r.startsAt) continue;
              try {
                new Notification("Reunión próxima", {
                  body: `${r.title} empieza en ${Math.max(
                    1,
                    Math.round(diffMin)
                  )} min`,
                  tag: `meeting-${r.id}`,
                });
              } catch {
                // ignore
              }
              firedById.set(r.id, r.startsAt);
            }
          }
          saveFired(
            Array.from(firedById, ([id, startsAt]) => ({ id, startsAt }))
          );
        } catch {
          // silencioso — siguiente tick reintenta
        }
      }

      // 2) Recordatorios vencidos
      if (prefs.browserReminderDue) {
        try {
          const res = await api.get<Reply<UserReminder[]>>("/reminders");
          const reminders = res.data.obj || [];
          for (const rem of reminders) {
            if (rem.isDone || rem.notified) continue;
            const remindAt = new Date(rem.remindAt);
            if (remindAt <= now) {
              try {
                new Notification("Recordatorio", {
                  body: rem.title,
                  tag: `reminder-${rem.reminderId}`,
                });
              } catch {
                // ignore
              }
              api
                .post(`/reminders/${rem.reminderId}/notified`)
                .catch(() => {});
            }
          }
        } catch {
          // silencioso
        }
      }
    };

    loadPrefs().then(() => {
      if (cancelled) return;
      tick();
      timerRef.current = setInterval(tick, POLL_INTERVAL_MS);
    });

    return () => {
      cancelled = true;
      if (timerRef.current) {
        clearInterval(timerRef.current);
        timerRef.current = null;
      }
    };
  }, [permission]);
}
