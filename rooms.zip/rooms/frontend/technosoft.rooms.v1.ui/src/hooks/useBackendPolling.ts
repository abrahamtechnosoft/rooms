"use client";

import { useEffect, useRef } from "react";

interface PollingOptions {
  /** Si es true, los errores del fetchFn no se loguean en consola. */
  silentOnError?: boolean;
}

/**
 * Ejecuta `fetchFn` cada `intervalMs` MIENTRAS la pestaña esté visible.
 * - Pausa el polling al pasar a background.
 * - Al volver visible re-ejecuta inmediatamente y reanuda el ciclo.
 * - `deps` controla cuándo reiniciar el ciclo (cambios de filtros, etc.).
 * - `intervalMs` se incluye automáticamente en las deps: si cambia (p. ej. de
 *   30000 a 5000 cuando un form se abre), el ciclo se recrea con el nuevo valor.
 *
 * NOTA: este hook NO dispara el primer fetch — eso queda a cargo del caller
 * (típicamente con un useEffect propio). Lo que sí hace es disparar fetches
 * recurrentes y un fetch al volver visible.
 */
export function useBackendPolling(
  fetchFn: () => void | Promise<void>,
  intervalMs: number = 30_000,
  deps: ReadonlyArray<unknown> = [],
  options?: PollingOptions
): void {
  const fetchRef = useRef(fetchFn);
  const silent = options?.silentOnError === true;

  useEffect(() => {
    fetchRef.current = fetchFn;
  }, [fetchFn]);

  useEffect(() => {
    let id: ReturnType<typeof setInterval> | null = null;
    let cancelled = false;

    async function safeFetch() {
      if (cancelled) return;
      try {
        await fetchRef.current();
      } catch (e) {
        if (!silent) {
          console.error("[useBackendPolling]", e);
        }
      }
    }

    function start() {
      if (id) return;
      id = setInterval(safeFetch, intervalMs);
    }

    function stop() {
      if (id) {
        clearInterval(id);
        id = null;
      }
    }

    function handleVisibility() {
      if (document.visibilityState === "visible") {
        // Re-fetch inmediato al volver.
        safeFetch();
        start();
      } else {
        stop();
      }
    }

    if (
      typeof document === "undefined" ||
      document.visibilityState === "visible"
    ) {
      start();
    }
    document.addEventListener("visibilitychange", handleVisibility);

    return () => {
      cancelled = true;
      stop();
      document.removeEventListener("visibilitychange", handleVisibility);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [intervalMs, silent, ...deps]);
}
