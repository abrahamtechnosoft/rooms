"use client";

import type { Reservation } from "@/types";
import { effectiveEndsAt } from "@/lib/reservationStatus";
import { useNowTick } from "@/hooks/useNowTick";

export type RoomAvailabilityStatus = "free" | "soon" | "occupied";

export interface RoomAvailability {
  isFreeNow: boolean;
  isOccupied: boolean;
  occupiedUntil?: Date;
  nextStartsAt?: Date;
  /** Minutos hasta la próxima reunión (si hay una próxima). */
  minutesUntilNext?: number;
  status: RoomAvailabilityStatus;
}

/**
 * Calcula el estado de la sala en este instante.
 * Considera `ended_at` cuando la reunión actual terminó antes de tiempo.
 * Usa `useNowTick(1000)` — refresca cada segundo para que los contadores
 * "Próxima en X min" y "Ocupada hasta HH:MM" estén siempre actualizados.
 * Los datos de `reservations` los refresca el padre (Dashboard) con polling
 * propio de 30 segundos.
 */
export function useRoomAvailability(
  roomId: number,
  reservations: Reservation[]
): RoomAvailability {
  const now = useNowTick(1000);

  const roomMeetings = reservations.filter(
    (m) => m.roomId === roomId && m.status === "active"
  );

  // Reunión en curso (considera ended_at).
  const inProgress = roomMeetings.find((m) => {
    const starts = new Date(m.startsAt);
    const ends = new Date(effectiveEndsAt(m));
    return now >= starts && now < ends;
  });

  if (inProgress) {
    return {
      isFreeNow: false,
      isOccupied: true,
      occupiedUntil: new Date(effectiveEndsAt(inProgress)),
      status: "occupied",
    };
  }

  // Próxima reunión en esta sala.
  const upcoming = roomMeetings
    .filter((m) => new Date(m.startsAt) > now)
    .sort(
      (a, b) =>
        new Date(a.startsAt).getTime() - new Date(b.startsAt).getTime()
    )[0];

  if (upcoming) {
    const minutesUntil = Math.floor(
      (new Date(upcoming.startsAt).getTime() - now.getTime()) / 60000
    );
    return {
      isFreeNow: true,
      isOccupied: false,
      nextStartsAt: new Date(upcoming.startsAt),
      minutesUntilNext: minutesUntil,
      status: minutesUntil <= 15 ? "soon" : "free",
    };
  }

  return {
    isFreeNow: true,
    isOccupied: false,
    status: "free",
  };
}
