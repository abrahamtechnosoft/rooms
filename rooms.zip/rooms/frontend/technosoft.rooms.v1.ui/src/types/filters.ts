/**
 * Filtros del dashboard:
 *   - `chip`: SINGLE-select. Reemplaza al modelo anterior multi-select.
 *     Posibles valores: 'all' | sala especifica | 'virtual' | 'external'.
 *   - `departmentIds`: MULTI-select del dropdown "Mas filtros".
 */
export type ChipFilter =
  | { kind: "all" }
  | { kind: "room"; roomId: number }
  | { kind: "office" }
  | { kind: "virtual" }
  | { kind: "external" };

export interface ReservationFilters {
  chip: ChipFilter;
  departmentIds: number[];
}

export const DEFAULT_FILTERS: ReservationFilters = {
  chip: { kind: "all" },
  departmentIds: [],
};
