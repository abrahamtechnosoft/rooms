import type {
  ExternalSubtype,
  ReservationType,
  VirtualPlatform,
} from "@/constants/reservationTypes";

export type Role = "admin" | "empleado";

export interface Department {
  id: number;
  name: string;
  description: string | null;
  colorHex: string | null;
  isActive: boolean;
  createdAt?: string;
  memberCount?: number;
}

export interface User {
  id: number;
  email: string;
  fullName: string;
  role: Role;
  isActive?: boolean;
  createdAt?: string;
  avatarUrl?: string | null;
  avatarPromptSeen?: boolean;
  departmentId?: number | null;
  departmentName?: string | null;
  departmentColor?: string | null;
  officeName?: string | null;
}

export interface Room {
  id: number;
  name: string;
  capacity: number;
  location?: string | null;
  isActive: boolean;
  colorHex?: string | null;
  iconName?: string | null;
  description?: string | null;
  createdAt?: string;
}

export type InvitationStatus =
  | "auto_accepted"
  | "pending"
  | "accepted"
  | "rejected";

export interface UserPickerItem {
  id: number;
  email: string;
  fullName: string;
  avatarUrl?: string | null;
  status?: "active" | "cancelled";
  cancelledAt?: string | null;
  cancelReason?: string | null;
  invitationStatus?: InvitationStatus;
  invitationResponseAt?: string | null;
  invitationBlockedById?: number | null;
  invitationBlockedByName?: string | null;
}

export type BlockType = "recurring" | "one_time";

export interface UserBlock {
  id: number;
  name: string;
  blockType: BlockType;
  daysOfWeek: string | null;
  startTime: string | null;
  endTime: string | null;
  startAt: string | null;
  endAt: string | null;
  isActive: boolean;
  createdAt: string;
}

export interface MyRequest {
  id: number;
  title: string;
  startsAt: string;
  endsAt: string;
  type: ReservationType;
  organizerId: number;
  organizerName: string;
  organizerEmail?: string | null;
  organizerAvatarUrl?: string | null;
  roomName?: string | null;
  blockName?: string | null;
  invitationStatus: InvitationStatus;
  meetingLink?: string | null;
  externalAddress?: string | null;
  virtualPlatform?: VirtualPlatform | null;
}

export interface Reservation {
  id: number;
  /** Tipo de reunión: physical (sala), virtual (solo agenda) o external (fuera de oficina). */
  type: ReservationType;
  /** Solo definido cuando type === 'physical'. */
  roomId: number | null;
  roomName: string | null;
  roomColor: string | null;
  roomIcon: string | null;
  roomDescription?: string | null;
  roomCapacity?: number | null;
  roomLocation?: string | null;
  /** Dirección visible cuando type === 'external'. */
  externalAddress?: string | null;
  externalSubtype?: ExternalSubtype | null;
  externalCompany?: string | null;
  externalMapsUrl?: string | null;
  externalContact?: string | null;
  /** Plataforma de la reunión virtual (zoom/meet/teams/etc). */
  virtualPlatform?: VirtualPlatform | null;
  /** Solo definido cuando type === 'virtual'. */
  meetingLink?: string | null;
  createdBy: number;
  userFullName: string;
  userEmail?: string;
  userAvatarUrl?: string | null;
  /** Departamento del organizador. Null si el usuario no esta asignado a uno. */
  organizerDepartmentId?: number | null;
  /** Solo cuando type === 'office'. Nombre de la oficina del departamento. */
  officeName?: string | null;
  /** Departamento al que pertenece la oficina (igual a organizerDepartmentId). */
  officeDepartmentId?: number | null;
  title: string;
  description?: string | null;
  startsAt: string;
  endsAt: string;
  status: "active" | "cancelled";
  createdAt?: string;
  participantsCount?: number;
  attachmentsCount?: number;
  notesCount?: number;
  pendingResponsesCount?: number;
  participants?: UserPickerItem[];
  isMine?: boolean;
  publicView?: boolean;
  cancelledAt?: string | null;
  cancelledBy?: number | null;
  cancelledByName?: string | null;
  cancelReason?: string | null;
  /** Reunión terminada antes de su hora de fin original. */
  endedEarly?: boolean;
  endedAt?: string | null;
  endedById?: number | null;
  endedByName?: string | null;
  endEarlyReason?: string | null;
  /** Confirmación de uso (reuniones fantasma sin asistencia). */
  usageConfirmed?: boolean;
  usageConfirmedAt?: string | null;
  usageConfirmationRequestedAt?: string | null;
  /** Si la reunión es una instancia de una serie recurrente. */
  recurringSeriesId?: number | null;
  /** Cuando la instancia fue editada individualmente, deja de heredar cambios de la serie. */
  isException?: boolean;
  series?: {
    id: number;
    title: string | null;
    pattern: RecurringPattern | null;
    daysOfWeek?: string | null;
    frequencyWeeks?: number | null;
    dayOfMonth?: number | null;
  } | null;
}

export type RecurringPattern = "weekly" | "monthly";

export interface RecurringSeriesSummary {
  id: number;
  title: string;
  description: string | null;
  reservationType: "physical" | "virtual" | "external";
  roomId: number | null;
  roomName: string | null;
  meetingLink: string | null;
  externalAddress: string | null;
  pattern: RecurringPattern;
  daysOfWeek: string | null;
  frequencyWeeks: number | null;
  dayOfMonth: number | null;
  startTime: string;
  endTime: string;
  seriesStartDate: string;
  seriesEndDate: string;
  createdBy: number;
  createdByName: string | null;
  isActive: boolean;
  createdAt: string;
  stats: {
    total: number;
    upcoming: number;
    past: number;
    cancelled: number;
    exceptions: number;
  };
}

export interface RecurringSeriesInstance {
  id: number;
  title: string;
  startsAt: string;
  endsAt: string;
  status: "active" | "cancelled";
  isException: boolean;
}

export interface ReservationCreateResponse extends Reservation {
  participantsNotified?: number;
}

export interface Attachment {
  id: number;
  reservationId: number;
  name: string;
  url: string;
  addedById: number;
  addedByName: string;
  addedByEmail?: string | null;
  createdAt: string;
}

export type ReservationChangeType =
  | "rescheduled"
  | "room_changed"
  | "title_changed"
  | "link_changed"
  | "modality_changed"
  | "participant_cancelled"
  | "cancelled"
  | "cancelled_in_progress"
  | "ended_early";

export type NotificationType =
  | "invited"
  | "rescheduled"
  | "updated"
  | "cancelled"
  | "participant_cancelled"
  | "attachment_added"
  | "invitation_blocked"
  | "invitation_responded"
  | "note_added"
  | "note_reply"
  | "summary_updated";

export interface AppNotification {
  id: number;
  reservationId: number | null;
  type: NotificationType;
  title: string;
  body: string | null;
  isRead: boolean;
  createdAt: string;
  readAt?: string | null;
}

export interface NotificationsListResponse {
  items: AppNotification[];
  unreadCount: number;
}

export interface ThreadedNote {
  noteId: number;
  parentNoteId: number | null;
  content: string;
  createdAt: string;
  updatedAt: string | null;
  editCount: number;
  isDeleted: boolean;
  deletedById: number | null;
  deletedAt: string | null;
  authorId: number;
  authorName: string | null;
  authorEmail: string;
  authorAvatarUrl?: string | null;
  replies: ThreadedNote[];
}

export interface NoteEdit {
  id: number;
  previousContent: string;
  editedAt: string;
  editedById: number;
  editedByName: string | null;
  editedByEmail: string;
}

export interface SummaryItem {
  id: number;
  authorId: number;
  authorName: string | null;
  authorEmail: string;
  authorAvatarUrl?: string | null;
  content: string;
  itemOrder: number;
  createdAt: string;
}

export interface NotificationPreferences {
  emailNewNote: boolean;
  emailNoteReply: boolean;
  emailSummaryChange: boolean;
  emailParticipationCancelled: boolean;
  emailReminders: boolean;
  emailBlockedInvitation: boolean;
  emailAttendanceMarked: boolean;
  browserMeetingReminder: boolean;
  browserMeetingReminderMinutes: number;
  browserReminderDue: boolean;
}

export interface UserReminder {
  reminderId: number;
  title: string;
  content: string | null;
  remindAt: string;
  isDone: boolean;
  notified: boolean;
  notifiedAt: string | null;
  createdAt: string;
  updatedAt: string | null;
}

export type PersonStatus =
  | { kind: "available" }
  | {
      kind: "in_meeting";
      endsAt: string;
      title: string;
      type?: ReservationType;
      roomName: string;
      roomIsVirtual: boolean;
    }
  | { kind: "soon"; minutesUntil: number; startsAt: string };

export interface Person {
  id: number;
  email: string;
  fullName: string | null;
  avatarUrl?: string | null;
  role: Role;
  status: PersonStatus;
  departmentId?: number | null;
  departmentName?: string | null;
  departmentColor?: string | null;
}

export interface PersonMeeting {
  id: number;
  title: string;
  startsAt: string;
  endsAt: string;
  type?: ReservationType;
  roomName: string;
  roomIsVirtual: boolean;
  state: "in_progress" | "upcoming";
}

export interface PersonDetail extends Omit<Person, "status"> {
  isActive: boolean;
  meetings: PersonMeeting[];
}

export interface ReservationHistoryEntry {
  id: number;
  changeType: ReservationChangeType;
  oldValue: string | null;
  newValue: string | null;
  changedAt: string;
  changedBy: number;
  changedByName: string | null;
  changedByEmail: string;
  changedByAvatarUrl?: string | null;
}

export interface Reply<T = unknown> {
  ok: boolean;
  obj: T | null;
  msg: string;
}

export interface LoginResponse {
  token: string;
  user: User;
}

export type NoteVisibility = "personal" | "department";

export interface UserNote {
  noteId: number;
  authorId: number;
  authorName: string;
  authorAvatarUrl?: string | null;
  departmentId: number | null;
  visibility: NoteVisibility;
  title: string | null;
  content: string;
  colorHex: string;
  isDone: boolean;
  isPinned: boolean;
  sortOrder: number;
  createdAt: string;
  updatedAt: string | null;
}
